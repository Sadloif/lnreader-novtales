# NovTales — Android Companion + LNReader plugin

Build of the Android companion APK and the matching LNReader source plugin,
per [`NovTales_Android_Companion_Build_Specification.md`](./spec/NovTales_Android_Companion_Build_Specification.md).

> **Installable test build — not a verified working release.**
> The code compiles, is signed and installs. The critical request path has not
> been proven on the physical Oppo Reno 15. See
> [`novtales-companion/docs/TEST_REPORT.md`](./novtales-companion/docs/TEST_REPORT.md).
>
> **There are no screenshots and no sanitised device logs in this delivery.**
> Spec section 13 asks for both, and neither exists, because nothing has run on
> the device. Section 6 of the test report lists exactly what has to be captured
> and the sanitisation rules for it. Nothing has been invented in their place.

---

## Contents

| Path | What it is |
|---|---|
| [`novtales-companion/`](./novtales-companion/) | Android companion app — Kotlin, Gradle, `docs/`, `scripts/` |
| [`dist/NovTales-Companion-0.1.0.apk`](./dist/) | **The signed installable APK** |
| [`dist/NovTales-Companion-0.1.0-source.zip`](./dist/) | **The source archive** — there is no `.git` in this tree (see [`docs/DEVIATIONS.md`](./novtales-companion/docs/DEVIATIONS.md) §7) |
| ↳ `docs/API.md` | Local API reference |
| ↳ `docs/BUILD.md` | Build and signing instructions |
| ↳ `docs/TEST_REPORT.md` | What was tested, what was not |
| ↳ `docs/DEVIATIONS.md` | Every departure from the spec, with evidence |
| [`lnreader-plugin/`](./lnreader-plugin/) | LNReader TypeScript plugin, compiled JS, manifest, README |
| ↳ `lnreader-plugin/_working/` | Plugin verification harnesses — **shipped**, because the plugin README tells reviewers to run `node _working/smoke.mjs` |
| [`spec/`](./spec/) | The build specification and the prior investigation evidence |
| [`CONTRACTS.md`](./CONTRACTS.md) | Internal interfaces, fixed before parallel implementation |

> The APK Gradle writes to,
> `novtales-companion/app/build/outputs/apk/release/app-release.apk`, is **not**
> in the delivery — `app/build/` is a build cache and is excluded by
> `sync-to-app.ps1`. The shipped artefact is the staged one in `dist/`.

## Digests

| | |
|---|---|
| **APK** | [`dist/NovTales-Companion-0.1.0.apk`](./dist/) — 867,033 bytes |
| **APK SHA-256** | `39f9363965c9bc8a1a928377d6303e17c0e4574a69afb6f850efc504c7c198d4` |
| **Signing certificate SHA-256** | `b8:64:3b:c4:25:e4:d4:f3:d3:87:e9:1a:f7:4c:0c:94:0a:9a:6a:14:fb:8e:b7:34:4d:69:a6:b8:3a:c3:88:90` |
| Signature schemes | v1, v2 and v3 — all applied and verified |
| Tests | 704 JVM + 420 Node + 127 plugin smoke, 0 failures |
| **Screenshots / sanitised device logs** | ❌ **none** — nothing has run on the device yet, see [`docs/TEST_REPORT.md` §6](./novtales-companion/docs/TEST_REPORT.md) |

> **On the signing schemes.** `apksigner verify` prints
> `Verified using v1 scheme: false` for this APK. That is **not** evidence that v1
> is absent: `apksigner` reads min-SDK from the manifest, and at minSdk 26 the
> JAR scheme is unnecessary so it skips the check. `enableV1Signing = true` in
> `app/build.gradle.kts`, and `META-INF/CERT.RSA` / `CERT.SF` / `MANIFEST.MF` are
> in the APK. Forcing the check with `apksigner verify --min-sdk-version 23`
> reports `Verified using v1 scheme (JAR signing): true`.

> **The published SHA-256 is not re-derivable by rebuilding.** All 385 zip
> entries — and the v1/v2/v3 signatures — are byte-identical on a rebuild; the
> only 3,018 differing bytes sit in one auxiliary signing-block pair that is not
> signed content. So the build is content-reproducible and cryptographically
> equivalent, but not bit-reproducible. Hash the APK you were given; do not
> expect a rebuild to reproduce the digest.
>
> **Do not mistake `res/9N.9.png` and `res/9n.9.png` for duplicate entries.**
> They are case-differing names, and there are 385 distinct entries. PowerShell's
> `Group-Object` is case-insensitive and misreports the pair. Not a defect.

## Quick start

1. Install `dist\NovTales-Companion-0.1.0.apk` **alongside** the official
   LNReader app. It does not replace it and does not touch its data.
2. Open **NovTales Companion** → **Start**.
3. Complete any website check in the visible companion browser.
4. **Copy pairing key** → paste into the LNReader NovTales plugin settings.
5. Open the catalogue in LNReader and fetch a public chapter.

Install the plugin by adding the `lnreader-plugin/` repository manifest to
LNReader as a plugin source — see
[`lnreader-plugin/README.md`](./lnreader-plugin/README.md).

## Rebuilding

`build.ps1`, `sync-to-app.ps1` and `make-source-zip.ps1` are at the **repository
root**, not under `novtales-companion/`.

```powershell
# toolchain check (reports which JDK/SDK it found)
.\novtales-companion\scripts\setup-env.ps1

# build + test. Uses the committed Gradle wrapper (novtales-companion\gradlew.bat).
# NOTE: "assembleRelease" needs a release keystore the delivery does not carry.
# See the box below. Use -Debug, or "test assembleDebug", on a clean checkout.
.\build.ps1 -Task "test assembleRelease"

# checksums, certificate fingerprint and signature-scheme verification
.\novtales-companion\scripts\release-evidence.ps1

# rebuild dist\NovTales-Companion-<version>-source.zip
.\make-source-zip.ps1 -Force

# copy the finished deliverable to E:\CodexData\APP
.\sync-to-app.ps1
```

`build.ps1` prefers the committed wrapper and only falls back to the downloaded
Gradle distribution under `tools/gradle-dist/` if the wrapper is unusable — and
says so loudly when it does. That fallback directory is **not** in the delivery.

> ### `assembleRelease` will fail on a clean checkout — that is intended
>
> The delivered tree contains **no release keystore**. `novtales-release.jks` and
> `keystore.properties` are deliberately not published; the private key must never
> leave the build machine.
>
> `app/build.gradle.kts` now **throws** rather than falling back to the debug key,
> and prints the `keytool` command to create a real identity. This matters
> because the old fallback produced an APK that passed every automated check —
> `BUILD SUCCESSFUL`, `apksigner verify` → `Verifies`, correct package and version
> — while being signed `CN=Android Debug`. Such an APK **cannot update an
> existing installation**; installing it forces an uninstall and loses the user's
> app data, with nothing in the output saying so.
>
> * Want a local build? Use `.\build.ps1 -Debug` / `gradlew.bat assembleDebug`.
>   **Never distribute a debug-signed APK.**
> * Want a release? Create the identity as [`docs/BUILD.md`](./novtales-companion/docs/BUILD.md)
>   describes, then build.
> * Want the real release APK? It is `dist/NovTales-Companion-0.1.0.apk`, signed
>   `b8643bc4…`. To confirm you have that artefact and not a debug-signed
>   impostor, compare the **certificate digest**, not the exit code of `verify`.

On a normal developer machine you can ignore `build.ps1` entirely and use the
wrapper directly, as [`docs/BUILD.md`](./novtales-companion/docs/BUILD.md)
describes:

```powershell
cd novtales-companion
.\gradlew.bat test assembleDebug
```

## The one-paragraph summary

LNReader stays the reading app. The companion runs a real Android System WebView
on the same phone, holds the browser session NovTales accepts, and exposes a
small authenticated loopback API on `127.0.0.1:5301`. The plugin asks the
companion for catalogue, metadata, chapter lists and **complete** chapter HTML,
and returns the existing LNReader result types. No PC, no remote server, no
modified LNReader, no root, no accessibility service, no scraping proxy.

A chapter is only ever returned complete when the site itself signals it — an
exact `End of Chapter N` marker matching the requested chapter, matching chapter
metadata, and a body with readable text after sanitising. An incomplete or
preview response is a **failure**, never a short chapter that looks like a
success.
