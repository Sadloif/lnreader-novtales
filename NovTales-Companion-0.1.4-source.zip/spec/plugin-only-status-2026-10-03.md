# Plugin-only scope correction

The user explicitly rejected a custom LNReader build. The experimental APK workflow
was canceled, and its six preview/build files were retired from the repository's
current tree. Their Git history and local work are preserved.

Published commit: d31f9f58d4b92aa00407e71b4ace5f2dc4544920.
Manifest and compiled plugin version: 1.0.4.

The plugin uses existing official LNReader interfaces. It corrects the unsupported
TLS explanation, caches successful catalogue data for five minutes, and rejects
incomplete chapter previews. It does not implement protected chapter delivery.

Verified all five published files against local bytes, the live manifest version,
absence of the retired app files, and absence of a browser bridge dependency.
Compiled parser fixtures pass. Prior strict TypeScript, lint, and formatting checks
passed. Actual NovTales access remains unresolved: command-line requests receive
HTTP 429 with browser-verification markers; official Android behavior is unverified.

All further work must remain plugin-only. Do not claim that these corrections fix
access or guarantee compatibility with every future LNReader release. The active
goal remains incomplete.

## Follow-up evidence from the user's official Android app

The user updated to 1.0.4 and reported: "Novtales: the site blocked this page
request with browser verification HTTP 429". The user then opened the website in
LNReader's own globe/source WebView and retried the catalogue; the website opened,
but the catalogue still returned 429. Opening that WebView does not resolve the
plugin's transport failure on this device.

Desktop rechecks returned 429/challenge for Explore, the observed chapter-list
endpoint, the current reader script, and one public Chapter 1 grant POST. No grants,
session credentials, or chapter text were exported. No verification was bypassed.

Newly observed public footer links /rss.xml and /rss/free.xml returned 200 RSS XML
to native requests. The free feed explicitly states "Chapter titles and links only;
no chapter text." This disproves the old blanket claim that all non-browser requests
are rejected, but does not provide a complete reading implementation. Its XML was
saved at site-scripts/free-feed.xml. Do not substitute a partial RSS release index
for the requested full catalogue, metadata, chapter lists, and readable chapters.

Completion is unproven: compiled-parser tests pass, but catalogue transport fails
in the official app and protected full chapter delivery is absent. The remaining
blocker is an accessible content request path supported by the official plugin API.

## Latest implementation decision

The user's request is to fix and deliver a usable plugin. No new working release
has been produced or published. Version 1.0.4 remains unsuitable for this site on
the user's phone.

The anonymous Supabase API-description request, made with the site's supplied
publishable client key, returned HTTP 401 with "Secret API key required". This
result applies to the API description; it does not prove that every public data
endpoint is unavailable. No records were queried and no secret/session key was
used. See public-api-inspection.json.

The official app's fetch helpers use ordinary React Native fetch. The source
WebView can save opted-in localStorage/sessionStorage, but has no supported plugin
browser-fetch or complete-chapter return interface. Changing error wording,
request headers or a storage flag does not establish a working solution.

A companion service is an architecture seen in the upstream Linovelib plugin.
It could preserve the official LNReader app, but would change the self-contained
plugin requirement and require a running host. It is a candidate, not a verified
NovTales solution. The user has been asked whether this dependency is acceptable;
dependent implementation/deployment remains pending that scope decision.
