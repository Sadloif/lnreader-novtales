# NovTales Android Companion Build Specification

Prepared 3 October 2026 · Specification version 1.0

## 1 Purpose and required outcome

Build a separate Android companion APK and a compatible NovTales source plugin for the **official LNReader app**. The user will install both on an Oppo Reno 15. LNReader must remain the reading app and keep its existing library and downloaded chapters.

The companion provides a browser session that can load NovTales pages and return their usable data to the plugin through a local API on the same phone. The purpose is to address the observed difference between successful website access in a WebView and failed requests from the current plugin. The proposed companion architecture is **not yet validated on Android**. Validate the critical path before building a polished interface.

The finished solution must load the catalogue, search, novel details, chapter lists and complete available chapters. LNReader must be able to save those chapters and reopen them offline after the companion has stopped. Returning a preview, a website iframe or a message saying that the chapter was downloaded is not a successful download.

This specification supersedes the proposed Windows companion service. No PC, remote server or modified LNReader APK is required by the intended design.

## 2 Evidence and unresolved questions

### Confirmed observations

- The user reported that other sources work in official LNReader 2.1.4. The published NovTales plugin version 1.0.4 still reports browser verification with HTTP 429.
- NovTales opens in LNReader's own globe or source WebView. Returning to the source and retrying its catalogue still produces HTTP 429.
- Desktop native requests to several relevant NovTales routes returned HTTP 429 with a browser-verification marker. This does not establish that the TLS handshake is the cause.
- A public first chapter has loaded completely in Brave while signed out. Sign-in must not be imposed as a blanket requirement for public chapters.
- NovTales uses Next.js page data and browser-driven chapter delivery. The initial chapter HTML can contain only a preview.
- In the inspected reader, `locked` indicates protected delivery. It does not by itself mean that a paid membership is required. `membersOnly` is a separate access indicator.
- LNReader exposes ordinary fetch, parsing and storage helpers to plugins. Its source WebView does not expose a supported browser-fetch function or complete-chapter return channel to an installed plugin.
- NovTales RSS feeds are reachable by native requests, but the free feed contains titles and links without chapter text. A feed is not a substitute for the full reading implementation.

### Questions the builder must resolve

The companion's WebView must pass ordinary website verification on the actual phone. It must also continue loading and rendering chapter parts while the user is in LNReader. A foreground service can keep an operation running, but does not guarantee that a background WebView will behave like a visible browser.

Confirm loopback HTTP access from the installed official LNReader build. The inspected app configuration enables cleartext traffic, but the installed build is the final authority. Record the phone's Android version, ColorOS version and Android System WebView version; do not infer them from the model name.

## 3 Scope and preservation of LNReader features

Deliver two independent components:

1. **NovTales Companion APK:** a small native Android application with a WebView, a local API, request coordination and a status screen.
2. **NovTales plugin:** a normal LNReader TypeScript source plugin that obtains data from that local API and returns the existing LNReader result types.

Keep the plugin ID `novtales` and the existing novel and chapter paths. Update its semantic version and repository manifest when its behavior changes. A companion dependency is a substantial change and must be documented in the release notes.

| LNReader function | Required behavior |
| --- | --- |
| Catalogue and search | Return normal source results with working pagination and covers |
| Library and bookmarks | Continue using LNReader's existing data and controls |
| Chapter ordering and updates | Preserve chapter numbers, decimal chapters and stable paths |
| Reading progress and display | Continue using LNReader's own progress, fonts and themes |
| TTS | Receive clean chapter text usable by LNReader's TTS |
| Downloads | Save complete chapter HTML through LNReader's normal downloader |
| Offline reading | Open saved chapters with airplane mode enabled and the companion stopped |

Do not rebuild LNReader, replace its database, add a second novel reader, require root or accessibility services, or depend on a public scraping proxy. Website audio, reactions, comments, tips and account billing are outside the first release. The companion may display the original website's controls when the user needs to handle an access check.

## 4 Languages and development stack

| Component | Recommended language or technology | Purpose |
| --- | --- | --- |
| Android application | Kotlin with native Android SDK | Activity, service, request queue and lifecycle |
| Browser view | Android System WebView | Run the website's normal scripts and maintain its own session |
| Page adapter | JavaScript bundled as an APK asset | Read page data and extract completed rendered chapter HTML |
| LNReader plugin | TypeScript compiled to the supported JavaScript target | Implement the existing source plugin interface |
| Local API | HTTP and JSON using an Android-compatible embedded server | Communicate between the two apps on the same device |
| Build | Gradle wrapper, Android Gradle Plugin and compatible JDK | Reproducible signed APK builds |

Kotlin is the recommended application language. Java is acceptable if the builder prefers it, provided the Android compatibility and lifecycle requirements are met. React Native, Flutter, Node.js, Python and a bundled desktop browser are unnecessary for the intended phone implementation.

Use a maintained embedded HTTP server, such as an Android-compatible NanoHTTPD implementation or equivalent, rather than an unrestricted ad hoc proxy. Verify its current maintenance and suitability before choosing the dependency.

An initial minimum SDK of API 26 is reasonable; the Oppo is the primary test device. Select and record compatible current stable build-tool versions. Target SDK selection must account for current foreground-service rules. API 35 can be an initial prototype baseline, but is not a promise that it satisfies every future distribution requirement. Prefer an architecture-neutral APK when no native libraries are needed.

## 5 Architecture and user workflow

The intended request flow is:

```text
Official LNReader
  -> NovTales plugin
  -> authenticated API at http://127.0.0.1:5301
  -> companion request queue
  -> companion Android WebView
  -> NovTales website and its normal reader scripts
  -> completed data or an explicit access error
  -> plugin result
  -> LNReader reading view or downloaded chapter storage
```

The loopback address refers to the **phone itself**. It is not a Windows computer address and does not require both devices to share Wi-Fi. Internet is needed to retrieve new website content, but not to read chapters already saved in LNReader.

### First use

1. Install the separate companion APK alongside the official LNReader app.
2. Open the companion and select Start. The app creates its private browser session and local service.
3. Let NovTales load. If the website presents verification, the user completes it in the visible companion browser.
4. Copy the companion's pairing key into the NovTales plugin settings in LNReader.
5. Open the catalogue in LNReader and fetch a public chapter.

Show simple statuses: Stopped, Ready, Loading, Needs your attention and Error. Show the current operation and chapter number without logging credentials. Provide Start, Stop, Open website, Copy pairing key and Reset pairing key controls. Clearing the website session must be a separate deliberate action; resetting pairing must not silently sign the user out.

A persistent notification should open the companion and offer Stop. Explain that the companion is needed while fetching new content. Do not promise automatic startup after force-stop or indefinite background execution.

## 6 Android service and WebView requirements

Create and operate WebView on Android's main thread. Run socket handling and blocking work off that thread. Serialize website navigation through one worker so simultaneous LNReader requests cannot overwrite each other's pages.

The worker should own a consistent browser session. Moving between the companion activity and LNReader must not destroy that session or lose the active request. Implement safe attachment and detachment of the WebView when displaying it, and avoid retaining a destroyed Activity. Handle WebView renderer crashes explicitly.

Start the service from a user action while the companion activity is visible. Provide the required foreground notification and applicable permissions. Choose and justify the foreground-service type using Android's current rules. `dataSync` is subject to time limits on recent Android versions; `specialUse` requires a legitimate declared explanation and must not be selected merely to avoid a timeout. Do not misclassify the app as media playback or another unrelated service type.

Handle service timeout, process death, force-stop, device reboot, lost internet and socket-port conflicts. Fail pending operations clearly when the service stops. A plugin cannot start an arbitrary Android service through the existing source interface; it must tell the user to open the companion when unavailable.

Test returning to LNReader, screen-off behavior, battery saver and ColorOS background restrictions. Do not automatically request blanket battery exemptions or keep an indefinite wake lock. If normal operation requires the companion to remain visible or split-screen, document that limitation and obtain the user's agreement before treating it as the finished solution.

## 7 Local API contract

The following is a **proposed interface to implement**, not an API already available from NovTales. Version it independently from the website adapter.

Bind only to `127.0.0.1`, initially port `5301`. Never bind to `0.0.0.0`, a LAN interface or a public address. Require a randomly generated pairing key with at least 256 bits of entropy on every endpoint:

```http
Authorization: Bearer <local pairing key>
Content-Type: application/json
```

This key authorizes access to the local companion. It is not a NovTales account token. Store it in private app storage with backup disabled; LNReader stores its own copy in plugin settings. Do not put it in URLs, logs or repository files. Allow the user to rotate it and show a useful error when the plugin's key no longer matches.

### Endpoints

| Method and route | Required result |
| --- | --- |
| GET /v1/health | API version, companion version and current readiness state |
| POST /v1/jobs | Validate and enqueue one operation; return HTTP 202 with a job ID |
| GET /v1/jobs/{jobId} | Return its current state and completed result or error |
| DELETE /v1/jobs/{jobId} | Cancel it and release associated work where possible |

Use asynchronous jobs so a long website operation does not require a single fragile HTTP connection. Suggested polling is once per second initially, then once every two seconds. Keep queue size, job retention and timeouts bounded.

Supported operations are `catalogue`, `search`, `novel`, `chapters` and `chapter`. Catalogue and search use `page`, `sort` and `query` as appropriate. Novel and chapters use a stable `/novel/{slug}` path; chapters also uses a one-based page. Chapter uses `/chapter/{slug}-{number}`, preserving decimal numbers.

Example request:

```json
{"operation":"chapter","path":"/chapter/surviving-the-game-as-a-barbarian-1"}
```

Example accepted response:

```json
{"apiVersion":1,"jobId":"opaque-job-id","state":"queued"}
```

Allowed states are `queued`, `loading`, `needs_user`, `completed`, `failed` and `cancelled`. A completed job includes `result`. A failed or needs-user job includes a structured error. Separate `needs_user` from automatic retry; notify the user and require an explicit retry after the website action is finished.

## 8 Result shapes and plugin integration

### Catalogue and search

Return an object containing `items`, `page` and `hasNext`. Each item contains `name`, stable `path` and optional `cover`. Obtain results from the real catalogue, not the limited RSS release index. Search should support the site's available titles and alternative names. Do not invent popularity scores or metadata.

### Novel details

Return `name`, `path`, optional `cover`, `summary`, `author`, `genres`, `status`, `rating`, `chapters` and `totalPages`. For a paged source, `chapters` may be empty while `totalPages` tells LNReader which pages to fetch. Map status values to LNReader's supported values and return Unknown when appropriate.

### Chapter lists

Return `chapters` containing `name`, `path`, `chapterNumber` and optional `releaseTime`. Use ascending chronological order for the app. Preserve decimal chapter numbers and deduplicate by stable path. The observed website pages run newest to oldest; the adapter must translate page order consistently and check for pagination changes when new chapters are published.

### Complete chapter

```json
{
  "path":"/chapter/surviving-the-game-as-a-barbarian-1",
  "chapterNumber":1,
  "complete":true,
  "content":"<p>Complete example chapter text.</p>"
}
```

The plugin returns `content` as its `parseChapter` HTML string only after checking `complete === true`, the requested path and chapter number. HTML must contain actual chapter text. Never mark an incomplete response complete to make a download appear successful.

Implement the existing LNReader methods: `popularNovels`, `searchNovels`, `parseNovel`, `parsePage`, `parseChapter` and `resolveUrl`. Keep `resolveUrl` pointed at the original NovTales website so the normal globe action remains useful. Use only helpers available in the official plugin runtime, including `@libs/fetch`, `@libs/storage` and supported parsing libraries. Do not import an invented `@libs/browser` helper.

Use the official runtime's text-input filter for pairing if the installed version supports it. Persist the entered key through the supported plugin storage helper so `searchNovels`, `parseNovel`, `parsePage` and `parseChapter` can retrieve it even though they do not receive catalogue filter options. Confirm this setup in Stage A; do not assume there is a separate settings API. Never compile a user's key into the plugin.

Adapt local API results to the exact upstream types: `popularNovels` and `searchNovels` return arrays of novel items, `parsePage` returns `{ chapters }`, and `parseChapter` returns an HTML string. `parsePage` receives a string page argument. Novel genres are a comma-separated string in the inspected contract, and ratings are numbers out of five. Validate the contract against the targeted official app and plugin repository versions before release.

Read stored configuration when making a request, validate API version and result shapes, handle cancellation where the runtime allows it, and avoid endless polling. A chapter timeout must produce a retryable failure without storing partial content. Existing library paths must keep working after the plugin update.

## 9 Website adapter and complete chapter delivery

Use the companion's own WebView to navigate to allowed NovTales pages. Enable the JavaScript and browser storage the website requires. Let the website maintain its session and perform its own reader requests. Do not export cookies or Supabase session tokens to LNReader.

The observed site streams page data in `self.__next_f.push` script entries. Parse the encoded strings as JSON, combine their content and extract a balanced value for `catalogue`, `novel` or `chapter`. Do not evaluate arbitrary website source strings in Kotlin, the service or the plugin.

For chapter delivery, the site's scripts use `/api/public/chapter-grant` and subsequent `/api/public/chapter-body` requests. The first release can avoid reimplementing their token and cursor protocol by extracting the **finished rendered chapter** after the site's reader has done that work. Normal scrolling may be needed to expose the next-part trigger.

Require an explicit completion signal tied to the requested chapter. An observed signal is an exact `End of Chapter N` marker in the article, alongside matching chapter metadata and a nonempty `.nv-chapter-body`. Confirm this signal on the current site. Character count alone, a successful HTTP response, a removed spinner or a nonempty preview is insufficient. If the site changes, fail safely until the adapter is updated.

Stop for sign-in, membership, browser verification, CAPTCHA, reading notices, rate limits or suspended delivery. Show the actual required user action. Do not automatically solve checks, acknowledge warnings, click purchase controls, rotate identities, forge delivery grants or bypass paid access. Public chapters must work without sign-in where the website allows it.

Strip scripts, styles, event handlers, forms, buttons, hidden tracking elements and security-canary links from the returned chapter. Preserve paragraphs, emphasis, scene breaks and readable images. Resolve relative image URLs safely and reject script or unsafe URL schemes. Test image behavior separately: complete text stored offline does not prove external images are also available offline.

## 10 Request coordination and failure behavior

Use one active WebView operation and a bounded queue. As initial configurable defaults, allow four waiting jobs, a 45-second metadata deadline and a 120-second chapter deadline after work starts. Add a separate maximum queue wait. These are starting values to measure on the phone, not assumed website guarantees.

Collapse identical simultaneous requests into shared work where safe. Keep each caller's cancellation independent. Clear or invalidate a job when navigation changes unexpectedly. Check request identity inside every asynchronous callback so a late result from a previous chapter cannot complete the next job.

Cache only successfully parsed metadata and explicitly completed chapters. Keep short, bounded caches within the current browser identity. Clear identity-sensitive data on sign-out, session reset or account change. Never use another identity's cached member content as an access fallback.

Suggested error envelope:

```json
{"code":"VERIFICATION_REQUIRED","message":"Open the companion to finish the website check.","retryable":false}
```

| Code | Required handling |
| --- | --- |
| COMPANION_UNAVAILABLE | Ask the user to open and start the companion |
| UNAUTHORIZED | Explain that the pairing key needs to be copied again |
| VERIFICATION_REQUIRED or SIGN_IN_REQUIRED | Open the visible browser workflow; do not auto-retry |
| MEMBERSHIP_REQUIRED | Report the website access requirement without returning a preview |
| RATE_LIMITED | Respect the site's wait or retry-after indication |
| QUEUE_FULL | Return a bounded retry delay without starting more browser work |
| TIMEOUT or INCOMPLETE_CHAPTER | Fail the download and preserve a retry path |
| WRONG_CHAPTER or SITE_CHANGED | Reject the result and provide a useful diagnostic |

Separate local API failures, website HTTP responses and adapter errors. HTTP 429 alone must not be labeled browser verification unless a verified marker or response identifies that condition. Do not claim a TLS cause without evidence.

## 11 Security and data handling

Localhost is not authentication: other apps on the phone can attempt to contact the port. Authenticate before enqueuing a job, compare pairing keys safely, validate methods and payloads, bound body and response sizes, and reject malformed requests.

Allow only the defined operations and normalized NovTales paths. Reject arbitrary destination URLs, traversal, repeated encoding and redirects to unrelated content. The service must not become a general-purpose proxy. External login navigation, if supported, must be deliberate and keep account credentials inside the browser session.

Avoid a privileged `addJavascriptInterface` bridge on untrusted website pages. Prefer a main-thread `evaluateJavascript` call that reads narrowly defined page data and returns a JSON string. Decode that result correctly, including escaped quotes and null results. Validate it again in native code before returning it to the plugin.

Keep TLS certificate verification and WebView Safe Browsing enabled. Do not use `onReceivedSslError(...).proceed()`, install a trust-all certificate manager or disable browser protections. Disable file access and unnecessary universal URL access. Do not expose account credentials, browser storage, chapter text or pairing keys in diagnostics.

Request only permissions needed for internet access, the selected foreground-service type and notifications. Broad storage, contacts, location, camera, microphone and accessibility access are not required for this design. The local API is plaintext only on loopback; website access remains HTTPS. Verify the official LNReader build accepts that loopback connection without modifying the app.

## 12 Build stages and acceptance tests

### Stage A Prove the architecture

Before building the full interface, show an authenticated health call from a test LNReader plugin to the APK, then fetch one complete signed-out public chapter while LNReader is foregrounded. Demonstrate that the WebView session survives switching apps. If this fails, report the exact blocker rather than releasing another plugin with different error wording.

### Stage B Implement the source

Add catalogue, search, metadata, paginated chapter lists and complete chapter extraction. Test novel and chapter identity checks, decimal chapters, escaping and formatting. Confirm that incomplete delivery never becomes a successful result.

### Stage C Validate the phone and downloads

| Test | Pass condition |
| --- | --- |
| Fresh setup | Install, start, pair and load the catalogue in official LNReader |
| Signed-out public chapter | Full chapter loads without imposing sign-in |
| Multi-part chapter | Every part is returned and completion is explicit |
| Pagination | Several pages are ordered correctly without duplicate paths |
| Simultaneous requests | A small download batch returns the correct text for each path |
| Website access check | User can complete it visibly; no automatic bypass occurs |
| App switching and screen off | Documented behavior is reliable on the Oppo and fails clearly if interrupted |
| Download completeness | Stored LNReader HTML matches the completed website content |
| Offline reopening | Stop the companion, enable airplane mode, restart LNReader and read saved chapters |
| Reader features | Progress, bookmarks, themes and TTS still work on returned chapters |
| Failure and recovery | Lost internet, renderer crash, killed service and wrong key yield useful recoverable errors |
| Local API security | Wrong keys, oversized input and arbitrary URL requests are rejected |

Passing compilation, mocked tests or a desktop browser demonstration is not sufficient to claim Android success. Record which tests ran on an emulator, which ran on the actual Oppo, and which remain untested.

## 13 Delivery and review requirements

Provide the complete companion source, complete TypeScript plugin source, compiled plugin JavaScript, icon, repository manifest, signed installable APK, build instructions and setup instructions. Include a reproducible Gradle wrapper, dependency versions, APK SHA-256 checksum and signing-certificate fingerprint. Keep a stable signing identity for later APK updates and do not publish its private key.

Include the Android manifest, selected foreground-service rationale, local API documentation, automated tests and a test report. The report must record the installed LNReader version, phone OS, WebView version, plugin version, companion version and actual test outcomes. Distinguish an installable test build from a verified working release.

For review, supply a source repository or source ZIP alongside the APK. APK-only review cannot fully assess lifecycle, parsing, security or maintainability. Supply sanitized logs and screenshots of setup and results; exclude account credentials, pairing keys and copied copyrighted chapter text from shared logs.

The reviewer should first inspect the local transport, foreground-service and WebView lifecycle; then inspect job isolation, completion checks, HTML cleanup and plugin compatibility. The final release gate is a successful download and offline reopen in the official LNReader app on the user's phone.

## 14 Primary references

The implementation should use current upstream source and Android documentation. These references establish the relevant interfaces and platform constraints; they do not establish that the proposed NovTales companion already works.

- [Official LNReader plugin repository](https://github.com/lnreader/lnreader-plugins)
- [LNReader 2.1.4 plugin runtime helpers](https://github.com/LNReader/lnreader/blob/v2.1.4/src/plugins/helpers/fetch.ts)
- [LNReader 2.1.4 source WebView](https://github.com/LNReader/lnreader/blob/v2.1.4/src/screens/WebviewScreen/WebviewScreen.tsx)
- [Upstream Linovelib companion-service example](https://github.com/lnreader/lnreader-plugins/blob/e297ac5aa6e213d602438d3d27717a09501c52a4/plugins/chinese/linovelib.ts) uses an external descrambling service; its live operation and applicability to NovTales are not verified.
- [Android WebView documentation](https://developer.android.com/develop/ui/views/layout/webapps/webview)
- [Android foreground service types](https://developer.android.com/develop/background-work/services/fgs/service-types)
- [Android foreground service timeouts](https://developer.android.com/develop/background-work/services/fgs/timeout)
- [NovTales public chapter used for observations](https://novtales.com/chapter/surviving-the-game-as-a-barbarian-1)

## 15 Instructions to the builder

Implement the separate Android companion APK and the standard LNReader plugin described here. Start with Stage A and report whether the critical request path works before expanding the application. Preserve official LNReader and its data, return only complete accessible chapters, and prove offline downloads on the Oppo. Record justified deviations from this specification. Deliver the source and build evidence so the completed work can be reviewed.
