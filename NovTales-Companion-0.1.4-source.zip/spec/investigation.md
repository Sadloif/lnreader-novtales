# NovTales request investigation

Status: **historical notes — see [current plugin-only status](./plugin-only-status-2026-10-03.md).**

The older findings file overstates the access and authentication conclusions. The
user confirmed that a public chapter loads signed out in a browser, while the
official app's native catalogue request still fails after visiting its WebView.
Complete chapter delivery is not implemented in the published plugin.

## Confirmed evidence

- The user runs LNReader 2.1.4. Other source plugins work.
- The website renders an initial chapter preview. The initial public React payload for
  Chapter 1 includes eight paragraphs, `locked: true`, `membersOnly: false`, and
  `wordCount: 1014`. Browser JavaScript subsequently replaces the initial chapter
  display. Therefore parsing only initial `.nv-chapter-body` HTML can return a preview.
- Current WebToEpub and lightnovel-crawler source trees contain no NovTales
  implementation. WebToEpub's older issue describes Bubble/elasticsearch endpoints; the
  current site uses Next.js and has been rebuilt, so those old endpoints do not apply.
- LNReader 2.1.4 exposes native fetch, parsing, and storage helpers to plugins. Its
  source WebView saves localStorage/sessionStorage for opted-in plugins; it does not
  expose a browser-fetch helper or inject a plugin's customJS into the source WebView.
  customJS runs in the reading view.

## Evidence from client scripts supplied by the user

The route-specific chapter script defines `RestrictedChapterGate`. It calls
`GET /api/reader/chapter/{encodedNovelSlug}?number={number}` through `authedFetch` and
expects `novel` and `chapter` objects. This is the restricted novel gate, not the
complete ordinary public chapter delivery implementation.

The user supplied the main reader chunk 5493. It confirms:

- Chapter lists use `GET /api/public/novel-chapters/{slug}` with page, pageSize,
  optional q/anchor, and optional order.
- Ordinary protected chapter text uses `POST /api/public/chapter-grant`. The body
  includes slug, number, deviceId, and a browser-derived `v` value. Headers include a
  device identifier, delivery request identifier, reader page/session identifier, and
  request start timestamp.
- A successful grant returns a grant token and initialBlock containing paragraphs,
  nextCursor, and complete. Further text uses `POST /api/public/chapter-body` with grant
  and cursor headers.
- Device registration uses `POST /api/public/me/device` after the server responds with
  DEVICE_REVOKED or DEVICE_REGISTRATION_REQUIRED.

The initially requested chunk named 4205 does NOT define module 4205 or `authedFetch`;
it contains UI components. Module identifiers and chunk file identifiers do not
necessarily match. The supplied main reader references module 4205 for `authedFetch`
and its Supabase session client, and module 73144 for `deviceId`. The user subsequently
supplied module 4205 in chunk 811.

The user subsequently supplied the root layout and chunk 5239. The layout confirms that
AuthGate registers the device after Supabase `getSession` resolves a signed-in identity,
and that reader preference synchronization explicitly sends a Bearer access token.
Neither supplied file defines `authedFetch`. Chunk 5239 contains Radix and Tailwind
utilities. Manual filename guessing was then replaced by a browser Sources search,
which located the definition described in the next section.

The published plugin has no `webStorageUtilized` flag and does not import
localStorage/sessionStorage. Consequently the source WebView does not save these stores
for this plugin.

LNReader's installed plugin customJS is loaded into the reading WebView, whose online
HTML base URL is the source site. This is a potential avenue for browser-based chapter
loading, but does not by itself cover catalogue, novel metadata, or chapter-list
requests in the native plugin runtime.

## Authentication helper now identified

The user supplied chunk 811, including the actual module 4205 definition. It creates a
Supabase browser client for `https://llcuhbcnkkcezqnibwmw.supabase.co` with a public
publishable API key. Its custom storage reads and writes `document.cookie`, using the
auth storage key `sb-llcuhbcnkkcezqnibwmw-auth-token`. It does not obtain its sign-in
token from the localStorage/sessionStorage saved by LNReader's source WebView.

`authedFetch` gets the current session access token, adds
`Authorization: Bearer <access token>` when signed in, and adds a UUID in
`x-novtales-request-id`. It uses ordinary fetch and retries once after a 401 only if
Supabase supplies a different refreshed token.

After a sufficiently long hidden interval, the browser cookie adapter can resynchronize
readable auth cookies through `POST /api/public/auth/session-cookie` using its existing
same-origin session.

The snippet most recently pasted by the user is `signOutThisDevice`: it sends
`action: "revoke"` to `/api/public/me/device` and then signs out. It is not session
setup and must not be executed as a diagnostic or fix.

The helper's observed Supabase table query is for the signed-in user's `profiles` row.
It does not establish a public catalogue table or chapter API.

## Data access boundaries

No browser session cookies, private storage, or internal browser state were extracted.
Schema introspection was not pursued: the plugin does not need a secret key or
private-table access, and the site's own client demonstrates no such API is in use.

## Release criteria

The criteria applied before release were: identify an observed public endpoint, then
test catalogue, metadata, chronological pagination and free chapter delivery using
LNReader's exact fetch helper. A release must distinguish ordinary rate limiting, access
gates and incomplete chapter previews, and must not rest on mocked tests alone. The
results are recorded in [findings.md](./findings.md).

## Primary references

- https://github.com/LNReader/lnreader/blob/v2.1.4/src/plugins/helpers/fetch.ts
- https://github.com/LNReader/lnreader/blob/v2.1.4/src/screens/WebviewScreen/WebviewScreen.tsx
- https://github.com/dteviot/WebToEpub/issues/1296#issuecomment-2084613034
- https://github.com/dteviot/WebToEpub/issues/2289#issuecomment-3736476214
- https://novtales.com/chapter/surviving-the-game-as-a-barbarian-1
