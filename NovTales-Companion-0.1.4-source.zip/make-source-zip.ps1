param([string]$OutputDirectory, [switch]$Force)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
if (-not $OutputDirectory) { $OutputDirectory = Join-Path $root 'dist' }
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$gradleKts = Get-Content -LiteralPath (Join-Path $root 'novtales-companion\app\build.gradle.kts') -Raw
if ($gradleKts -notmatch 'versionName\s*=\s*"([^"]+)"') { throw 'App version is missing.' }
$out = Join-Path $OutputDirectory "NovTales-Companion-$($Matches[1])-source.zip"
if ((Test-Path -LiteralPath $out) -and -not $Force) { throw 'Archive exists; pass -Force to replace it.' }
# Traverse source directories only. Do not stage build caches or signing files.
$excludeRoot = @('_working', '_verify_rebuild', 'tools', 'dist')
$excludeDirs = @('node_modules', 'build', '.gradle', '.kotlin', '.git')
$excludeFiles = @('keystore.properties', 'local.properties')
$rootFull = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
$pending = [Collections.Generic.Stack[string]]::new()
$pending.Push($root)
$files = [Collections.Generic.List[IO.FileInfo]]::new()
while ($pending.Count) {
    $dir = $pending.Pop()
    foreach ($item in Get-ChildItem -LiteralPath $dir -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        if ($item.PSIsContainer) {
            if ($excludeDirs -contains $item.Name) { continue }
            if ($dir -eq $root -and $excludeRoot -contains $item.Name) { continue }
            $pending.Push($item.FullName)
        } elseif ($excludeFiles -notcontains $item.Name -and $item.Extension -notin @('.jks', '.keystore', '.p12', '.pfx')) {
            $files.Add($item)
        }
    }
}
$relative = @($files | ForEach-Object { $_.FullName.Substring($rootFull.Length).Replace('\', '/') })
foreach ($required in @('novtales-companion/tools/js-tests/adapter.test.js', 'lnreader-plugin/_working/smoke.mjs', 'novtales-companion/app/src/main/AndroidManifest.xml')) {
    if ($relative -notcontains $required) { throw "Missing required source: $required" }
}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$temp = Join-Path $OutputDirectory ('source-' + [Guid]::NewGuid().ToString('N') + '.tmp')
$zip = [IO.Compression.ZipFile]::Open($temp, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in ($files | Sort-Object FullName)) {
        $entry = $file.FullName.Substring($rootFull.Length).Replace('\', '/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $entry, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally { $zip.Dispose() }
Move-Item -LiteralPath $temp -Destination $out -Force
Write-Host "Source ZIP: $out ($($files.Count) files)"
Get-FileHash -LiteralPath $out -Algorithm SHA256
