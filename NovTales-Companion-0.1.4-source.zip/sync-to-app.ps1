# Copies the finished deliverable to E:\CodexData\APP.
#
# Run from anywhere after the final build. Excludes build caches, scratch trees,
# the Gradle distribution, the signing keystore and keystore.properties - the
# private key must never leave this machine.
#
# SHIPPED, deliberately:
#   dist\                      the APK and the source ZIP
#   lnreader-plugin\_working\  the plugin verification harnesses. The plugin
#                              README tells reviewers to run `node _working/smoke.mjs`,
#                              so that file has to actually be here.
#
# EXCLUDED:
#   _verify_rebuild\           scratch from the two-variant rebuild check. It holds
#                              a SECOND COPY of novtales-release.jks and
#                              keystore.properties; shipping it would leak the
#                              signing identity.
#   tools\                     the downloaded Gradle distribution (full path, so
#                              the real source folder novtales-companion\tools
#                              - which holds tools\js-tests - is kept)
#   local.properties           machine-specific; carries an absolute SDK path that
#                              breaks the build on any other machine
#   *.jks, keystore.properties the private signing identity

param(
    [string]$Destination = "E:\CodexData\APP",
    # Skips the post-copy assertions. Only useful when inspecting a partial copy.
    [switch]$NoVerify
)

$ErrorActionPreference = "Stop"

$source = Split-Path -Parent $PSCommandPath

Write-Host "Syncing $source -> $Destination" -ForegroundColor Cyan

if (-not (Test-Path $Destination)) {
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
}

# Top-level scratch/tooling trees, excluded by FULL PATH. A bare name matches at
# every depth and that is how `tools` once stripped the real source folder
# novtales-companion\tools\js-tests - and how a bare `_working` would strip
# lnreader-plugin\_working, which is deliberately shipped.
$excludeDirsByPath = @(
    (Join-Path $source "_working"),
    (Join-Path $source "_verify_rebuild"),
    (Join-Path $source "tools")
)

# Names that are unambiguously build output, safe to match at any depth.
$excludeDirsByName = @(
    "node_modules",
    "build",
    ".gradle",
    ".kotlin"
)

# Secrets. The signing identity stays here; only the built APK travels.
$excludeFiles = @(
    "novtales-release.jks",
    "keystore.properties"
)

# Machine-specific. Both .gitignore files list local.properties, but it holds an
# absolute SDK path from the build machine (sdk.dir=E:\Deepseek\Linksi\...). A
# reviewer on another machine would get a build failure pointing at a directory
# that does not exist for them. docs/BUILD.md explains how to write their own.
$excludeFiles += "local.properties"

$robocopyArgs = @(
    "`"$source`"",
    "`"$Destination`"",
    "/E",
    "/R:2", "/W:1",
    "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
    "/XD"
) + $excludeDirsByPath + $excludeDirsByName + @("/XF") + $excludeFiles

# ROBOCOPY exits 0-7 for success; anything above 7 is a real failure.
& robocopy @robocopyArgs | Out-Null
$code = $LASTEXITCODE

if ($code -ge 8) {
    Write-Host "robocopy failed with exit code $code" -ForegroundColor Red
    exit $code
}

Write-Host "Synced." -ForegroundColor Green
Write-Host ""

# ---------------------------------------------------------------------------
# `build/` is excluded from the copy, so the shipped artefact is the staged one.
# ---------------------------------------------------------------------------
$apk = Join-Path $Destination "dist\NovTales-Companion-0.1.0.apk"
if (Test-Path $apk) {
    $hash = (Get-FileHash $apk -Algorithm SHA256).Hash
    Write-Host "APK    $apk" -ForegroundColor Cyan
    Write-Host "SHA256 $hash" -ForegroundColor Cyan
} else {
    Write-Host "No APK in dist\ - stage one after building:" -ForegroundColor Yellow
    Write-Host "  Copy-Item novtales-companion\app\build\outputs\apk\release\app-release.apk dist\NovTales-Companion-0.1.0.apk" -ForegroundColor Yellow
}

$zip = Get-ChildItem (Join-Path $Destination "dist") -Filter "*-source.zip" -ErrorAction SilentlyContinue |
       Select-Object -First 1
if ($zip) {
    Write-Host "SOURCE $($zip.FullName)  ($($zip.Length) bytes)" -ForegroundColor Cyan
} else {
    Write-Host "No source ZIP in dist\ - run make-source-zip.ps1." -ForegroundColor Yellow
}

if ($NoVerify) {
    Write-Host ""
    Write-Host "-NoVerify passed: post-copy assertions skipped." -ForegroundColor Yellow
    exit 0
}

# ---------------------------------------------------------------------------
# Post-copy assertions. An exclude list that silently strips real source is the
# failure mode this guards: every entry below is something the delivery is
# supposed to contain, or definitely must not.
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "Checking the copy..." -ForegroundColor Cyan

$problems = @()

# 1. No secrets anywhere in the destination.
$leaks = Get-ChildItem $Destination -Recurse -Force -Include *.jks, keystore.properties -ErrorAction SilentlyContinue
foreach ($l in $leaks) { $problems += "SECRET SHIPPED: $($l.FullName)" }

# 2. Must be present - real source and reviewer-facing harnesses.
$mustHave = @(
    "novtales-companion\tools\js-tests\adapter.test.js",   # real source; lost to a bare `tools` exclude once
    "lnreader-plugin\_working\smoke.mjs",                  # lnreader-plugin README tells reviewers to run it
    "lnreader-plugin\_working\manifest-check.mjs",
    "novtales-companion\docs\TEST_REPORT.md",
    "novtales-companion\docs\API.md",
    "README.md"
)
foreach ($m in $mustHave) {
    if (-not (Test-Path (Join-Path $Destination $m))) { $problems += "MISSING FROM DELIVERY: $m" }
}

# 3. Must be absent - machine-specific paths, caches and the downloaded toolchain.
# local.properties is the trap here: it is git-ignored but carries this machine's
# absolute SDK path, and shipping it breaks the build on every other machine.
$mustNotHave = @(
    "tools\gradle-dist",
    "_verify_rebuild",
    "novtales-companion\local.properties"
)
foreach ($m in $mustNotHave) {
    if (Test-Path (Join-Path $Destination $m)) { $problems += "UNWANTED IN DELIVERY: $m" }
}
# The top-level scratch tree must be gone; lnreader-plugin\_working must survive.
if (Test-Path (Join-Path $Destination "_working")) { $problems += "UNWANTED IN DELIVERY: _working (top-level scratch)" }

Write-Host ""
if ($problems.Count -gt 0) {
    Write-Host "SYNC CHECK FAILED:" -ForegroundColor Red
    foreach ($p in $problems) { Write-Host "  $p" -ForegroundColor Red }
    exit 1
}

Write-Host "  no .jks or keystore.properties in the destination      OK" -ForegroundColor Green
Write-Host "  no local.properties in the destination                  OK" -ForegroundColor Green
Write-Host "  novtales-companion\tools\js-tests present              OK" -ForegroundColor Green
Write-Host "  lnreader-plugin\_working present (README runs smoke.mjs) OK" -ForegroundColor Green
Write-Host "  dist\ (APK + source ZIP) present                      OK" -ForegroundColor Green
Write-Host "  tools\gradle-dist absent                              OK" -ForegroundColor Green
Write-Host ""
exit 0