# The local API, pairing key handling and job queue are plain Kotlin and must
# survive shrinking intact. Keep line numbers for readable crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Nothing in the app is reflected over, so the default shrinking rules are
# sufficient. Keep Android component entry points.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver