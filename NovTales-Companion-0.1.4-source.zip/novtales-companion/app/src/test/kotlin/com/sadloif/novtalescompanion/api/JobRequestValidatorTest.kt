package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Operation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/** Validates a body that is expected to be accepted, and returns the request. */
private fun valid(body: String): JobRequest {
    val result = JobRequestValidator.validate(body)
    assertTrue("expected valid, got $result", result is JobRequestValidator.Result.Valid)
    return (result as JobRequestValidator.Result.Valid).request
}

/** Validates a body that is expected to be refused, and returns the message. */
private fun invalid(body: String): String {
    val result = JobRequestValidator.validate(body)
    assertTrue("expected invalid, got $result", result is JobRequestValidator.Result.Invalid)
    val error = (result as JobRequestValidator.Result.Invalid).error
    assertEquals(ErrorCode.BAD_REQUEST, error.code)
    return error.message
}

/**
 * `POST /v1/jobs` body validation tests.
 *
 * Promoted from `_working/compilecheck/test/SmokeTest.kt`, where every one of
 * these was a 400 observed over a real socket. Driving [JobRequestValidator]
 * directly additionally pins the rejection *message*, which is what tells a
 * plugin author which field to fix.
 *
 * Pure JVM: no `android.*` import anywhere in the `api` package.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class JobRequestValidatorTest {

    // =========================================================================
    // The operation itself
    // =========================================================================

    class Operations {

        @Test
        fun `a missing operation is refused`() {
            assertEquals("\"operation\" is required.", invalid("{}"))
        }

        @Test
        fun `a non-string operation is refused`() {
            assertEquals("\"operation\" must be a string.", invalid("""{"operation":7}"""))
        }

        @Test
        fun `an unknown operation is refused and the message lists the five`() {
            val message = invalid("""{"operation":"nope"}""")
            assertTrue(message, message.contains("catalogue"))
            assertTrue(message, message.contains("chapter"))
        }

        @Test
        fun `a sixth operation cannot be smuggled in by case`() {
            assertTrue(invalid("""{"operation":"delete"}""").isNotEmpty())
        }

        @Test
        fun `all five operations resolve from their wire names`() {
            assertEquals(Operation.CATALOGUE, valid("""{"operation":"catalogue","page":1}""").operation)
            assertEquals(
                Operation.SEARCH,
                valid("""{"operation":"search","query":"x"}""").operation,
            )
            assertEquals(
                Operation.NOVEL,
                valid("""{"operation":"novel","path":"/novel/slug"}""").operation,
            )
            assertEquals(
                Operation.CHAPTERS,
                valid("""{"operation":"chapters","path":"/novel/slug","page":1}""").operation,
            )
            assertEquals(
                Operation.CHAPTER,
                valid("""{"operation":"chapter","path":"/chapter/slug-1"}""").operation,
            )
        }
    }

    // =========================================================================
    // Path shape, and the one field each operation accepts
    // =========================================================================

    class Paths {

        @Test
        fun `a chapter request needs a path`() {
            assertEquals("\"path\" is required for \"chapter\".", invalid("""{"operation":"chapter"}"""))
        }

        // Regression: only chapter and chapters used to demand a path. A novel
        // request with no path validated successfully and then failed further
        // downstream with a less useful message instead of a clean 400.
        @Test
        fun `a novel request needs a path`() {
            assertEquals("\"path\" is required for \"novel\".", invalid("""{"operation":"novel"}"""))
        }

        @Test
        fun `a null path is not the same as a missing one`() {
            assertEquals(
                "\"path\" is required for \"novel\".",
                invalid("""{"operation":"novel","path":null}"""),
            )
            assertEquals(
                "\"path\" is required for \"chapter\".",
                invalid("""{"operation":"chapter","path":null}"""),
            )
        }

        @Test
        fun `a chapters request needs a path`() {
            assertEquals(
                "\"path\" is required for \"chapters\".",
                invalid("""{"operation":"chapters","page":1}"""),
            )
        }

        @Test
        fun `a chapter request needs a chapter path and not a novel path`() {
            assertTrue(
                invalid("""{"operation":"chapter","path":"/novel/slug"}""")
                    .contains("/chapter/{slug}-{number}"),
            )
        }

        @Test
        fun `a novel request needs a novel path and not a chapter path`() {
            assertTrue(
                invalid("""{"operation":"novel","path":"/chapter/slug-1"}""")
                    .contains("/novel/{slug}"),
            )
        }

        @Test
        fun `traversal is refused`() {
            assertEquals(
                "\"path\" is not a NovTales novel or chapter path.",
                invalid("""{"operation":"novel","path":"/novel/slug/../../etc"}"""),
            )
        }

        @Test
        fun `an absolute off-site URL is refused`() {
            assertEquals(
                "\"path\" is not a NovTales novel or chapter path.",
                invalid("""{"operation":"novel","path":"https://evil.example/novel/x"}"""),
            )
        }

        @Test
        fun `a plaintext site URL is refused`() {
            assertEquals(
                "\"path\" is not a NovTales novel or chapter path.",
                invalid("""{"operation":"novel","path":"http://novtales.com/novel/x"}"""),
            )
        }

        @Test
        fun `a non-string path is refused`() {
            assertEquals("\"path\" must be a string.", invalid("""{"operation":"novel","path":7}"""))
        }

        @Test
        fun `a path on catalogue is refused rather than silently dropped`() {
            // Silently dropping is how a client ends up paginating nothing and
            // debugging it for an afternoon.
            assertEquals(
                "\"path\" is not accepted for \"catalogue\".",
                invalid("""{"operation":"catalogue","path":"/novel/slug","page":1}"""),
            )
        }

        @Test
        fun `a path on search is refused`() {
            assertEquals(
                "\"path\" is not accepted for \"search\".",
                invalid("""{"operation":"search","path":"/novel/slug","query":"x"}"""),
            )
        }

        @Test
        fun `a page on chapter is refused`() {
            assertEquals(
                "\"page\" is not accepted for \"chapter\".",
                invalid("""{"operation":"chapter","path":"/chapter/slug-1","page":1}"""),
            )
        }

        @Test
        fun `a query on a non-search operation is refused`() {
            assertEquals(
                "\"query\" is not accepted for \"chapter\".",
                invalid("""{"operation":"chapter","path":"/chapter/slug-1","query":"x"}"""),
            )
        }

        @Test
        fun `a sort on chapter is refused`() {
            assertEquals(
                "\"sort\" is not accepted for \"chapter\".",
                invalid("""{"operation":"chapter","path":"/chapter/slug-1","sort":"latest"}"""),
            )
        }

        @Test
        fun `an absolute site URL is normalised to a relative path`() {
            assertEquals(
                "/novel/slug",
                valid("""{"operation":"novel","path":"https://novtales.com/novel/slug"}""").path,
            )
        }
    }

    // =========================================================================
    // Paging
    // =========================================================================

    class Paging {

        @Test
        fun `chapters needs a page`() {
            assertEquals(
                "\"page\" is required for \"chapters\".",
                invalid("""{"operation":"chapters","path":"/novel/slug"}"""),
            )
        }

        @Test
        fun `catalogue needs a page`() {
            assertEquals(
                "\"page\" is required for \"catalogue\".",
                invalid("""{"operation":"catalogue"}"""),
            )
        }

        @Test
        fun `page zero is refused`() {
            assertTrue(
                invalid("""{"operation":"chapters","path":"/novel/slug","page":0}""")
                    .contains("between 1"),
            )
        }

        @Test
        fun `a fractional page is refused`() {
            assertEquals(
                "\"page\" must be a whole number.",
                invalid("""{"operation":"chapters","path":"/novel/slug","page":1.5}"""),
            )
        }

        @Test
        fun `an overflowing page is refused as non finite`() {
            assertEquals(
                "\"page\" must be a finite whole number.",
                invalid("""{"operation":"chapters","path":"/novel/slug","page":1e400}"""),
            )
        }

        @Test
        fun `a string page is refused`() {
            assertEquals(
                "\"page\" must be a number.",
                invalid("""{"operation":"chapters","path":"/novel/slug","page":"1"}"""),
            )
        }

        @Test
        fun `the page ceiling is enforced`() {
            assertTrue(
                invalid("""{"operation":"chapters","path":"/novel/slug","page":100001}""")
                    .contains("between 1"),
            )
        }

        @Test
        fun `the page ceiling itself is accepted`() {
            assertEquals(
                100_000,
                valid("""{"operation":"chapters","path":"/novel/slug","page":100000}""").page!!,
            )
        }

        @Test
        fun `page is optional for search`() {
            assertNull(valid("""{"operation":"search","query":"x"}""").page)
        }
    }

    // =========================================================================
    // Query and sort
    // =========================================================================

    class QueryAndSort {

        @Test
        fun `search needs a query`() {
            assertTrue(
                invalid("""{"operation":"search"}""").contains("required"),
            )
        }

        @Test
        fun `a blank search query is refused`() {
            assertEquals(
                "\"query\" is required for \"search\" and must not be blank.",
                invalid("""{"operation":"search","query":"   "}"""),
            )
        }

        @Test
        fun `a query carrying a control character is refused`() {
            assertEquals(
                "\"query\" must not contain control characters.",
                invalid("{\"operation\":\"search\",\"query\":\"a\\u0001b\"}"),
            )
        }

        @Test
        fun `a non-string query is refused`() {
            assertEquals("\"query\" must be a string.", invalid("""{"operation":"search","query":7}"""))
        }

        @Test
        fun `an allowlisted sort is accepted and canonicalised to lower case`() {
            assertEquals(
                "latest",
                valid("""{"operation":"search","query":"x","sort":"LATEST"}""").sort,
            )
        }

        @Test
        fun `a sort outside the allowlist is refused`() {
            assertEquals(
                "\"sort\" must be one of latest, popular, rating, title, updated.",
                invalid("""{"operation":"search","query":"x","sort":";drop"}"""),
            )
        }

        @Test
        fun `a non-string sort is refused`() {
            assertEquals("\"sort\" must be a string.", invalid("""{"operation":"search","query":"x","sort":7}"""))
        }

        @Test
        fun `every allowlisted sort is accepted`() {
            for (sort in JobRequestValidator.SORT_ALLOWLIST) {
                assertEquals(
                    sort,
                    valid("""{"operation":"search","query":"x","sort":"$sort"}""").sort,
                )
            }
        }

        @Test
        fun `a long query is trimmed to the ceiling rather than refused`() {
            val long = "q".repeat(JobRequestValidator.MAX_QUERY_CHARS + 50)
            assertEquals(
                JobRequestValidator.MAX_QUERY_CHARS,
                valid("""{"operation":"search","query":"$long"}""").query!!.length,
            )
        }
    }

    // =========================================================================
    // Body shape
    // =========================================================================

    class Bodies {

        @Test
        fun `a body that is not JSON is refused`() {
            assertEquals("The request body is not valid JSON.", invalid("not json"))
        }

        @Test
        fun `a body that is not an object is refused`() {
            assertEquals("The request body must be a JSON object.", invalid("""["chapter"]"""))
            assertEquals("The request body must be a JSON object.", invalid("""7"""))
        }

        @Test
        fun `an empty body is refused`() {
            assertEquals("The request body is not valid JSON.", invalid(""))
        }

        @Test
        fun `every rejection is a 400 BAD_REQUEST and none carries the pairing key`() {
            // Nothing in a request body can hold the key, cookie or chapter text,
            // so no rejection message can echo one.
            for (body in listOf("{}", """{"operation":"nope"}""", "not json", """{"operation":7}""")) {
                assertTrue(invalid(body).isNotEmpty())
            }
        }
    }
}