package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Test

class NovelFlightReferenceTest {
    @Test fun `title and synopsis rows must arrive before metadata is accepted`() {
        val initial = "1:{\"slug\":\"example\",\"title\":\"${'$'}2\",\"synopsis\":\"${'$'}3\"}\n"
        fun envelope(flight: String) = jsonObject("flight" to Json.Str(flight))
        fun assertStillArriving(flight: String) {
            try {
                NovTalesExtraction.novel(envelope(flight), "/novel/example")
                throw AssertionError("Unresolved text was accepted")
            } catch (error: CompanionException) {
                assertEquals(ErrorCode.SITE_CHANGED, error.code)
            }
        }
        assertStillArriving(initial)
        val titled = initial + "2:\"Example\"\n"
        assertStillArriving(titled)
        val ready = NovTalesExtraction.novel(envelope(titled + "3:\"Synopsis\"\n"), "/novel/example")
        assertEquals("Example", ready.str("name"))
        assertEquals("Synopsis", ready.str("summary"))
    }

    @Test fun `plain JSON dollar-prefixed metadata is not a Flight reference`() {
        val value = Json.parse("""{"slug":"example","title":"${'$'}2","synopsis":"${'$'}3"}""")
        val novel = NovTalesExtraction.novel(jsonObject("value" to value), "/novel/example")
        assertEquals("${'$'}2", novel.str("name"))
        assertEquals("${'$'}3", novel.str("summary"))
    }

    @Test fun `raw text row with quotes and Unicode cannot consume the next novel row`() {
        val caption = "A Korean 한 novel 😀 with an unmatched quote \" and brace {"
        val length = caption.toByteArray(Charsets.UTF_8).size.toString(16)
        val flight = "1:T$length,$caption" +
            "\n2:{\"slug\":\"example\",\"title\":\"Example\",\"synopsis\":\"${'$'}1\"}\n"
        val novel = NovTalesExtraction.novel(jsonObject(
            "value" to Json.Str("${'$'}2"), "flight" to Json.Str(flight)), "/novel/example")
        assertEquals("Example", novel.str("name"))
        assertEquals(caption, novel.str("summary"))
    }

    @Test fun `inline novel metadata remains usable without the full stream`() {
        val value = Json.parse("""{"slug":"example","title":"Example","synopsis":"Inline"}""")
        val novel = NovTalesExtraction.novel(jsonObject(
            "value" to value, "flight" to Json.Str("incomplete")), "/novel/example")
        assertEquals("Inline", novel.str("summary"))
    }

    @Test fun `references inside inline props resolve before using the prop`() {
        val value = Json.parse("""{"slug":"example","title":"${'$'}3","synopsis":"${'$'}4"}""")
        val flight = "1:" + value.write() + "\n3:\"Example\"\n4:\"Synopsis\"\n"
        val novel = NovTalesExtraction.novel(jsonObject(
            "value" to value, "flight" to Json.Str(flight)), "/novel/example")
        assertEquals("Example", novel.str("name"))
        assertEquals("Synopsis", novel.str("summary"))
    }

    @Test fun `novel prop reference retains the other Flight rows`() {
        val flight = """
            1:["${'$'}","component",null,{"novel":"${'$'}a"}]
            a:{"slug":"example","title":"Example","synopsis":"${'$'}b","author":"Author","genres":[]}
            b:"Referenced synopsis"
        """.trimIndent()
        val envelope = jsonObject(
            "ok" to Json.Bool(true),
            "value" to Json.Str("${'$'}a"),
            "flight" to Json.Str(flight),
        )
        val novel = NovTalesExtraction.novel(envelope, "/novel/example")
        assertEquals("Example", novel.str("name"))
        assertEquals("Referenced synopsis", novel.str("summary"))
        assertEquals("/novel/example", novel.str("path"))
    }

    @Test fun `recommended novel cannot replace requested novel metadata`() {
        val envelope = jsonObject("value" to Json.parse(
            """{"slug":"other","title":"Recommended","synopsis":"Other novel"}"""))
        try {
            NovTalesExtraction.novel(envelope, "/novel/example")
            throw AssertionError("Unrelated metadata was accepted")
        } catch (error: CompanionException) {
            assertEquals(ErrorCode.SITE_CHANGED, error.code)
        }
    }
}
