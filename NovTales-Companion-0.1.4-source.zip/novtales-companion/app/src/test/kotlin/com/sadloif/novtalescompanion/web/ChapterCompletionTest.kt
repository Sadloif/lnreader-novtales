package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/**
 * Chapter completion rule tests (CONTRACTS.md section 4).
 *
 * Promoted from `_working/verify/Verify.kt`. Pure JVM: `ChapterCompletion` has no
 * `android.*` import, which is exactly why the whole decision was put in an
 * `object` instead of in the WebView callback.
 *
 * **Regression pinned here:** the harness found that a chapter *preview* - real
 * prose, no `End of Chapter N` marker - was being classified as
 * `WRONG_CHAPTER`. A preview is not a contradiction: it is an ordinary
 * intermediate state, and reporting it as a failure saved nothing but made the
 * reader see an error on every chapter that streamed in parts. The fix gives it
 * its own `Reason.PREVIEW_WITHOUT_MARKER`, and the `previewWithoutMarker...`
 * tests below are what keep that from regressing into either
 * `WRONG_CHAPTER` or `Complete`.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class ChapterCompletionTest {

    // =========================================================================
    // The happy path, and the rule that only it can produce it
    // =========================================================================

    class Completion {

        private val path = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val body = "<p>One.</p><p>Two.</p>"

        @Test
        fun `a marker matching the request with settled metadata completes`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/surviving-the-game-as-a-barbarian-1",
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 1",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            val complete = verdict as ChapterCompletion.Verdict.Complete
            assertEquals("/chapter/surviving-the-game-as-a-barbarian-1", complete.path)
            assertEquals("1", complete.chapterNumber)
            assertTrue(complete.html, complete.html.contains("<p>One.</p>"))
        }

        @Test
        fun `the delivered html is sanitised`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/surviving-the-game-as-a-barbarian-1",
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to "<p>One.</p><script>steal()</script>",
                    "endMarker" to "End of Chapter 1",
                ),
            ) as ChapterCompletion.Verdict.Complete

            assertEquals("<p>One.</p>", verdict.html)
        }

        @Test
        fun `a decimal chapter number completes`() {
            // 944.5 is a real chapter on the site; an integer-only parser would
            // truncate it to 944 and deliver the wrong chapter.
            val verdict = ChapterCompletion.evaluate(
                "/chapter/some-novel-944.5",
                jsonObject(
                    "path" to "/chapter/some-novel-944.5",
                    "chapterNumber" to "944.5",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 944.5",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals("944.5", (verdict as ChapterCompletion.Verdict.Complete).chapterNumber)
        }

        @Test
        fun `a stale spinner does not veto a chapter that passed every rule`() {
            // The site often leaves a spinner in the chrome long after the last
            // part lands. The exact marker is the authority.
            val verdict = ChapterCompletion.evaluate(
                "/chapter/surviving-the-game-as-a-barbarian-1",
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 1",
                    "stillLoading" to true,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        @Test
        fun `the delivered path is rebuilt from the slug and the normalised number`() {
            // The page reported `/chapter/slug-12.0`; the result must carry the
            // canonical `/chapter/slug-12` rather than echoing the page.
            val verdict = ChapterCompletion.evaluate(
                "/chapter/surviving-the-game-as-a-barbarian-12",
                jsonObject(
                    "path" to "/chapter/surviving-the-game-as-a-barbarian-12.0",
                    "chapterNumber" to "12.0",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 12",
                ),
            ) as ChapterCompletion.Verdict.Complete

            assertEquals("/chapter/surviving-the-game-as-a-barbarian-12", verdict.path)
            assertEquals("12", verdict.chapterNumber)
        }

        @Test
        fun `a settled verdict is terminal and an unsettled one is not`() {
            val complete = ChapterCompletion.Verdict.Complete("/chapter/a-b-1", "1", "<p>x</p>")
            assertTrue(ChapterCompletion.isTerminal(complete))
            assertTrue(
                ChapterCompletion.isTerminal(
                    ChapterCompletion.Verdict.NeedsUser(ErrorCode.SIGN_IN_REQUIRED, "m"),
                ),
            )
            assertTrue(
                ChapterCompletion.isTerminal(
                    ChapterCompletion.Verdict.Failed(ErrorCode.WRONG_CHAPTER, "m"),
                ),
            )
            assertFalse(
                ChapterCompletion.isTerminal(
                    ChapterCompletion.Verdict.NotReady(ChapterCompletion.Reason.EMPTY_BODY, "m"),
                ),
            )
            assertFalse(ChapterCompletion.isTerminal(ChapterCompletion.Verdict.StillLoading))
        }
    }

    // =========================================================================
    // The four rejection cases
    // =========================================================================

    class Rejections {

        private val requested = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val path = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val body = "<p>One.</p><p>Two.</p>"

        /** REGRESSION: this was a `WRONG_CHAPTER` failure. */
        @Test
        fun `a preview without a marker is never complete`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        /** REGRESSION: the same case, asserting the classification as well. */
        @Test
        fun `a preview without a marker is not a wrong chapter`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "",
                    "stillLoading" to false,
                ),
            )

            assertFalse("a preview must never be a failure", verdict is ChapterCompletion.Verdict.Failed)
            assertFalse("a preview must never need the user", verdict is ChapterCompletion.Verdict.NeedsUser)
        }

        @Test
        fun `End of Chapter 10 for a chapter 1 request fails as WRONG_CHAPTER once settled`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 10",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Failed)
            assertEquals(
                ErrorCode.WRONG_CHAPTER,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
        }

        @Test
        fun `a contradictory marker is only believed after the settle window`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 10",
                    "stillLoading" to false,
                ),
                settled = false,
            )

            assertTrue(
                "a client side transition can briefly show the previous chapter",
                verdict is ChapterCompletion.Verdict.NotReady,
            )
        }

        @Test
        fun `metadata and marker disagreeing fails as WRONG_CHAPTER once settled`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to "/chapter/surviving-the-game-as-a-barbarian-2",
                    "chapterNumber" to "2",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 1",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Failed)
            assertEquals(
                ErrorCode.WRONG_CHAPTER,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
        }

        @Test
        fun `a marker that is not exactly an end marker is never complete`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 1 of 3",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
        }

        @Test
        fun `a pay wall needs the user`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to "",
                    "endMarker" to "",
                    "membershipRequired" to true,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NeedsUser)
            assertEquals(
                ErrorCode.MEMBERSHIP_REQUIRED,
                (verdict as ChapterCompletion.Verdict.NeedsUser).code,
            )
        }

        @Test
        fun `a sign-in prompt needs the user`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject("path" to path, "signInRequired" to true, "bodyHtml" to ""),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NeedsUser)
            assertEquals(
                ErrorCode.SIGN_IN_REQUIRED,
                (verdict as ChapterCompletion.Verdict.NeedsUser).code,
            )
        }

        @Test
        fun `a browser challenge is neither a sign-in nor a terminal failure`() {
            // A challenge is resolvable by the reader in the browser tab, so the
            // poll keeps going; it must not be reported as `needs_user` or failed.
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject("path" to path, "verificationRequired" to true, "bodyHtml" to ""),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.VERIFICATION_PAGE,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `a page that never says which chapter it is fails as SITE_CHANGED once settled`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject("bodyHtml" to "<p>Text.</p>", "endMarker" to "End of Chapter 1"),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Failed)
            assertEquals(
                ErrorCode.SITE_CHANGED,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
        }

        @Test
        fun `a requested path that is not a chapter path is a bad request`() {
            val failure = runCatching {
                ChapterCompletion.evaluate("/novel/slug", jsonObject("path" to "/novel/slug"))
            }.exceptionOrNull()

            assertTrue(failure is com.sadloif.novtalescompanion.core.CompanionException)
            assertEquals(
                ErrorCode.BAD_REQUEST,
                (failure as com.sadloif.novtalescompanion.core.CompanionException).code,
            )
        }
    }

    // =========================================================================
    // 429 must never turn into a verification verdict, and must never veto work
    // =========================================================================

    class RateLimits {

        private val requested = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val path = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val body = "<p>One.</p><p>Two.</p>"

        @Test
        fun `a rate-limit flag cannot veto a chapter that already passed the rule`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "chapterNumber" to "1",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 1",
                    "rateLimited" to true,
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        @Test
        fun `a rate limit with no marker is RATE_LIMITED and not verification`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "bodyHtml" to "",
                    "endMarker" to "",
                    "rateLimited" to true,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.RATE_LIMITED,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `a rate limit is never reported as a sign-in`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "bodyHtml" to "",
                    "endMarker" to "",
                    "rateLimited" to true,
                ),
            )

            assertFalse(
                "HTTP 429 and browser verification are different things",
                verdict is ChapterCompletion.Verdict.NeedsUser,
            )
        }
    }

    // =========================================================================
    // Bodies that cannot be a chapter
    // =========================================================================

    class Bodies {

        private val requested = "/chapter/surviving-the-game-as-a-barbarian-1"
        private val path = "/chapter/surviving-the-game-as-a-barbarian-1"

        @Test
        fun `an empty body cannot complete even with a marker`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject("path" to path, "bodyHtml" to "", "endMarker" to "End of Chapter 1"),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.EMPTY_BODY,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `an image-only body cannot complete`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "bodyHtml" to "<p><img src=\"/a.jpg\"></p>",
                    "endMarker" to "End of Chapter 1",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.NO_TEXT_AFTER_SANITISING,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `a body that sanitises away to nothing cannot complete`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "bodyHtml" to "<script>onlyScript()</script>",
                    "endMarker" to "End of Chapter 1",
                    "stillLoading" to false,
                ),
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.NotReady)
            assertEquals(
                ChapterCompletion.Reason.NO_TEXT_AFTER_SANITISING,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `an empty body while the page is still delivering reports StillLoading`() {
            val verdict = ChapterCompletion.evaluate(
                requested,
                jsonObject(
                    "path" to path,
                    "bodyHtml" to "",
                    "endMarker" to "",
                    "stillLoading" to true,
                ),
            )

            assertEquals(ChapterCompletion.Verdict.StillLoading, verdict)
        }
    }

    // =========================================================================
    // Chapter numbers compared by value
    // =========================================================================

    class Numbers {

        @Test
        fun `twelve and twelve point zero are the same chapter`() {
            assertTrue(ChapterCompletion.numbersMatch("12", "12.0"))
        }

        @Test
        fun `twelve and twelve point five are not the same chapter`() {
            assertFalse(ChapterCompletion.numbersMatch("12", "12.5"))
        }

        @Test
        fun `identical strings always match`() {
            assertTrue(ChapterCompletion.numbersMatch("944.5", "944.5"))
        }

        @Test
        fun `a non-numeric value never matches`() {
            assertFalse(ChapterCompletion.numbersMatch("12", "twelve"))
            assertFalse(ChapterCompletion.numbersMatch("", "1"))
        }

        @Test
        fun `an article heading yields its chapter number`() {
            assertEquals("12", ChapterCompletion.headingNumber("Chapter 12: The Title"))
            assertEquals("12", ChapterCompletion.headingNumber("  Chapter 12 - The Title  "))
            assertEquals("12.5", ChapterCompletion.headingNumber("CHAPTER 12.5"))
        }

        @Test
        fun `a heading with no chapter number yields null`() {
            assertNull(ChapterCompletion.headingNumber("Prologue"))
            assertNull(ChapterCompletion.headingNumber(null))
            assertNull(ChapterCompletion.headingNumber("Chapter"))
        }

        @Test
        fun `an over long heading yields null rather than scanning it`() {
            assertNull(ChapterCompletion.headingNumber("Chapter 12 " + "x".repeat(400)))
        }
    }
}