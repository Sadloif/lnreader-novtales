package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith
import java.io.File

// ---------------------------------------------------------------------------
// Fixtures. Top-level and private on purpose: JUnit 4's Enclosed runner treats
// every static nested class as a suite, so helpers live out here rather than in a
// companion object.
// ---------------------------------------------------------------------------

/** The reference novel from the verified live report. */
private const val SLUG = "surviving-the-game-as-a-barbarian"
private const val NOVEL_PATH = "/novel/$SLUG"

/**
 * The one named page size. Every slice width below is asserted against this, so a
 * second hard-coded 50 anywhere in the adapter fails the build rather than
 * quietly desynchronising the reader from the site.
 */
private const val PAGE_SIZE = WebViewBrowserGateway.CHAPTER_PAGE_SIZE

/**
 * One page of the public JSON chapter index, in the shape the crawl really
 * reads. `NovTalesExtraction.chapterEntryCount` finds the array by its elements
 * rather than by its key, which is what makes the crawl work at all.
 */
private fun apiPage(firstChapter: Int, count: Int): Json = jsonObject(
    "data" to jsonObject(
        "chapters" to (0 until count).map { index ->
            val number = firstChapter + index
            jsonObject("number" to number, "title" to "Chapter $number")
        },
    ),
)

/**
 * The complete ascending list, exactly as `runChapters` holds it before it
 * slices: real crawl pages, merged by the real merger.
 */
private fun completeIndex(chapters: Int): Json {
    val pages = ArrayList<Json>()
    var first = 1
    var left = chapters
    while (left > 0) {
        val size = minOf(PAGE_SIZE, left)
        pages.add(apiPage(first, size))
        first += size
        left -= size
    }
    return NovTalesExtraction.chaptersFromApiPages(pages, NOVEL_PATH, exhausted = true)
}

/** What `runChapters` returns for `page`. */
private fun serve(page: Int, chapters: Int = 120): Json =
    ChapterPaging.pageResult(completeIndex(chapters), page, PAGE_SIZE)

private fun numbers(result: Json): List<Double> =
    result.arr("chapters")!!.items.map { (it as Json.Obj).num("chapterNumber")!! }

private fun paths(result: Json): List<String> =
    result.arr("chapters")!!.items.map { (it as Json.Obj).str("path")!! }

private fun format(value: Double): String = value.toString()

// ---------------------------------------------------------------------------

/**
 * Regression tests for `chapters` paging.
 *
 * ## The bug these exist for
 *
 * `JobRequestValidator` has always **required** `page` on a `chapters` request,
 * and `WebViewBrowserGateway.runChapters` never read it: it crawled the whole
 * public chapter index and returned the whole novel for every requested page.
 * The plugin therefore stored `chapterTotalPages` - 81 for the reference novel -
 * byte-identical copies of a 944-chapter list, each one behind a full 19-request
 * serialised WebView crawl, and the reader appeared to hang. With
 * `MAX_WAITING_JOBS = 4` the surplus calls hit `QUEUE_FULL`.
 *
 * Every test below fails against that behaviour. There are no sleeps and no
 * `android.*` import: `ChapterPaging` and `NovTalesExtraction` are pure JVM, so
 * the whole crawl-merge-slice path runs here exactly as `runChapters` runs it.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class ChapterPagingTest {

    // =========================================================================
    // The regression: page 1 and page 2 must not be the same list
    // =========================================================================

    class DistinctPages {

        @Test
        fun `page 1 and page 2 of the same novel are not the same list`() {
            // The assertion the whole bug turns on. Before the fix this compared
            // 944 chapters to 944 identical chapters and passed.
            val first = paths(serve(1))
            val second = paths(serve(2))

            assertNotEquals("page 1 and page 2 returned identical lists", first, second)
        }

        @Test
        fun `page 1 holds exactly one page of chapters`() {
            assertEquals(PAGE_SIZE, serve(1).arr("chapters")!!.items.size)
        }

        @Test
        fun `page 2 holds exactly one page of chapters`() {
            assertEquals(PAGE_SIZE, serve(2).arr("chapters")!!.items.size)
        }

        @Test
        fun `page 1 starts at the first chapter and page 2 starts after it`() {
            assertEquals(1.0, numbers(serve(1)).first(), 0.0001)
            assertEquals(51.0, numbers(serve(2)).first(), 0.0001)
        }

        @Test
        fun `page 2 ends at chapter 100 of a 120-chapter novel`() {
            assertEquals(100.0, numbers(serve(2)).last(), 0.0001)
        }

        @Test
        fun `the last page holds only the remainder`() {
            assertEquals(20, serve(3).arr("chapters")!!.items.size)
            assertEquals(120.0, numbers(serve(3)).last(), 0.0001)
        }

        @Test
        fun `no page carries the whole novel`() {
            for (page in 1..3) {
                assertTrue(
                    "page $page returned the whole novel",
                    serve(page).arr("chapters")!!.items.size <= PAGE_SIZE,
                )
            }
        }
    }

    // =========================================================================
    // Beyond the end, and below the start
    // =========================================================================

    class OutOfRange {

        @Test
        fun `a page past the end is empty rather than an error`() {
            // 120 chapters, 50 per page: page 4 does not exist.
            val fourth = serve(4)
            assertTrue("an out-of-range page is still a result", fourth is Json.Obj)
            assertEquals(0, fourth.arr("chapters")!!.items.size)
        }

        @Test
        fun `a page far past the end is empty too`() {
            assertEquals(0, serve(81).arr("chapters")!!.items.size)
        }

        @Test
        fun `page 99999 - the validator's ceiling - is empty`() {
            assertEquals(0, serve(99_999).arr("chapters")!!.items.size)
        }

        @Test
        fun `the reported total is the same on every page`() {
            // A client that only ever sees page 1 must still be able to count.
            for (page in 1..4) {
                assertEquals(3, serve(page).int("totalPages"))
                assertEquals(120, serve(page).int("chapterCount"))
            }
        }

        @Test
        fun `a page below 1 is empty`() {
            val one = listOf(Json.Str("x"))
            assertTrue(ChapterPaging.slice(one, 0, PAGE_SIZE).isEmpty())
            assertTrue(ChapterPaging.slice(one, -5, PAGE_SIZE).isEmpty())
        }

        @Test
        fun `a page size below 1 is empty rather than a division by zero`() {
            val one = listOf(Json.Str("x"))
            assertTrue(ChapterPaging.slice(one, 1, 0).isEmpty())
            assertTrue(ChapterPaging.slice(one, 1, -1).isEmpty())
        }

        @Test
        fun `totalPages is never below 1`() {
            assertEquals(1, ChapterPaging.totalPages(0, PAGE_SIZE))
            assertEquals(1, ChapterPaging.totalPages(-5, PAGE_SIZE))
        }
    }

    // =========================================================================
    // Order, decimals and de-duplication survive the slice
    // =========================================================================

    class OrderAndDedup {

        @Test
        fun `every page is ascending`() {
            for (page in 1..3) {
                val values = numbers(serve(page))
                assertEquals("page $page is not ascending", values.sortedBy { it }, values)
            }
        }

        @Test
        fun `page 2 carries no chapter from page 1`() {
            val first = paths(serve(1)).toSet()
            for (path in paths(serve(2))) {
                assertFalse("page 2 repeated $path", first.contains(path))
            }
        }

        @Test
        fun `the three pages together cover the novel exactly once`() {
            val all = (1..3).flatMap { paths(serve(it)) }
            assertEquals(120, all.size)
            assertEquals("chapters repeated across pages", 120, all.toSet().size)
        }

        @Test
        fun `a decimal chapter number survives a page boundary`() {
            // 12.5 must never be written 12.50. Pages are cut by position, never
            // by re-formatting a number.
            val chapters = jsonObject(
                "chapters" to listOf(
                    jsonObject(
                        "path" to "/chapter/$SLUG-12.5",
                        "name" to "Chapter 12.5",
                        "chapterNumber" to 12.5,
                    ),
                ),
            )
            val served = ChapterPaging.pageResult(chapters, 1, PAGE_SIZE)
            val first = served.arr("chapters")!!.items[0] as Json.Obj

            assertEquals("/chapter/$SLUG-12.5", first.str("path"))
            assertEquals(12.5, first.num("chapterNumber")!!, 0.0001)
        }

        @Test
        fun `a chapter repeated by the site is served once`() {
            // The crawler de-duplicates and sorts; pageResult then only cuts the
            // list, so it must not add an entry back or lose one.
            val crawled = NovTalesExtraction.chaptersFromApiPages(
                listOf(
                    jsonObject(
                        "data" to jsonObject(
                            "chapters" to listOf(
                                jsonObject("number" to 1, "title" to "One"),
                                jsonObject("number" to 1, "title" to "One again"),
                                jsonObject("number" to 2, "title" to "Two"),
                            ),
                        ),
                    ),
                ),
                NOVEL_PATH,
                exhausted = true,
            )
            val served = ChapterPaging.pageResult(crawled, 1, PAGE_SIZE)

            assertEquals(2, served.int("chapterCount"))
            assertEquals(2, served.arr("chapters")!!.items.size)
            assertEquals(
                "1.0,2.0",
                numbers(served).joinToString(",") { format(it) },
            )
        }

        @Test
        fun `slicing does not reorder or mutate the list it was given`() {
            val original = listOf(Json.Num(1.0), Json.Num(2.0), Json.Num(3.0))
            val slice = ChapterPaging.slice(original, 1, 2)

            assertEquals(2, slice.size)
            assertEquals(3, original.size)
            assertEquals(Json.Num(1.0), slice[0])
        }
    }

    // =========================================================================
    // The page size is one named constant
    // =========================================================================

    class PageSizeContract {

        @Test
        fun `the shipped page size is fifty`() {
            assertEquals(50, WebViewBrowserGateway.CHAPTER_PAGE_SIZE)
        }

        @Test
        fun `a full page is exactly the named constant wide`() {
            assertEquals(WebViewBrowserGateway.CHAPTER_PAGE_SIZE, serve(1).arr("chapters")!!.items.size)
        }

        @Test
        fun `totalPages is ceil of count over the named constant`() {
            assertEquals(3, ChapterPaging.totalPages(120, PAGE_SIZE))
            assertEquals(3, ChapterPaging.totalPages(121, PAGE_SIZE))
            assertEquals(3, ChapterPaging.totalPages(150, PAGE_SIZE))
            assertEquals(4, ChapterPaging.totalPages(151, PAGE_SIZE))
        }

        @Test
        fun `an exactly-full novel does not gain a phantom trailing page`() {
            // 100 chapters over 50-per-page is two pages, not three.
            assertEquals(2, serve(2, chapters = 100).int("totalPages"))
            assertEquals(0, serve(3, chapters = 100).arr("chapters")!!.items.size)
        }
    }

    // =========================================================================
    // runChapters end to end, minus the WebView
    // =========================================================================

    class ThroughTheCrawler {

        @Test
        fun `the verified fixture index still merges and still slices`() {
            val page = Json.parse(
                ChapterPagingTest::class.java.classLoader!!
                    .getResourceAsStream("fixtures/chapter-index-page.json")
                    .use { String(it.readBytes(), Charsets.UTF_8) },
            )
            val merged = NovTalesExtraction.chaptersFromApiPages(
                listOf(page), NOVEL_PATH, exhausted = true,
            )
            val served = ChapterPaging.pageResult(merged, 1, PAGE_SIZE)

            assertEquals("943.5,944.0,944.5", numbers(served).joinToString(",") { format(it) })
            assertEquals(3, served.int("chapterCount"))
            assertEquals(1, served.int("totalPages"))
        }

        @Test
        fun `an unexhausted crawl is still a timeout, never a short page`() {
            val partial = runCatching {
                NovTalesExtraction.chaptersFromApiPages(
                    listOf(apiPage(1, PAGE_SIZE)), NOVEL_PATH, exhausted = false,
                )
            }.exceptionOrNull()

            assertTrue("a partial index must never become a page", partial != null)
            assertEquals(ErrorCode.TIMEOUT, (partial as CompanionException).code)
        }

        @Test
        fun `the 944-chapter novel is nineteen site pages and nineteen local pages`() {
            // The numbers from the verified live report.
            assertEquals(19, serve(19, chapters = 944).int("totalPages"))
            assertEquals(944, serve(19, chapters = 944).int("chapterCount"))
            assertEquals(44, serve(19, chapters = 944).arr("chapters")!!.items.size)
            assertEquals(944.0, numbers(serve(19, chapters = 944)).last(), 0.0001)
            assertEquals(0, serve(20, chapters = 944).arr("chapters")!!.items.size)
        }
    }

    // =========================================================================
    // The wiring: `runChapters` has to hand the *requested* page to `pageResult`.
    //
    // Everything above tests `ChapterPaging.pageResult` directly, and the helper
    // is well covered: nine of the fourteen assertions in the M10 mutation go
    // red when it is reverted to "every page is the whole novel". What nothing
    // reached is the line that calls it. Change
    //
    //     ChapterPaging.pageResult(complete, plan.page, CHAPTER_PAGE_SIZE)
    //
    // to `pageResult(complete, 1, CHAPTER_PAGE_SIZE)` - one token, no compile
    // error, no warning - and bug 2 comes back verbatim: the plugin is told
    // `totalPages = 81` and every one of those 81 requests returns all 944
    // chapters. No test in the JVM suite can fail, because none of them calls
    // `runChapters`, which needs a WebView; `smoke.mjs` mocks the *server*, not
    // the gateway, so it does not see it either.
    //
    // ## Why this is a source-level assertion
    //
    // The alternative was to ask for a seam: `runChapters` calls `navigate`,
    // `webViewForWork`, `pageAdapter.inject`, `fetchJsonOnce` and `withContext`,
    // so the whole function would have to be rewritten around an interface
    // before one line of it could be executed. That is a change to
    // `app/src/main/**`, which this test tree does not own, and it is a much
    // larger change than the bug it would pin. So the wiring is pinned as text.
    //
    // It is ugly. It is also honest in the way that matters: it fails the moment
    // someone breaks the wiring, and - because each check is shown below against
    // a perturbed copy of the same file - it fails *only* when the wiring is
    // broken, not when it is merely formatted differently. The parser is
    // deliberately insensitive to line breaks, spacing and the name of the local
    // holding the merged list, because a pin that trips on reformatting trains
    // people to ignore it.
    // =========================================================================


}

// ---------------------------------------------------------------------------
// The wiring helpers. File top level for the same reason as the fixtures.
// ---------------------------------------------------------------------------

/**
 * Walks up from the working directory until the file is found, as
 * `HtmlSanitiserMirrorTest` does. Failing to find it is a test failure.
 */
private fun gatewaySource(): String {
    var dir: File? = File(System.getProperty("user.dir") ?: ".").absoluteFile
    repeat(10) {
        val candidate = File(
            dir,
            "app${File.separator}src${File.separator}main${File.separator}kotlin" +
                "${File.separator}com${File.separator}sadloif${File.separator}" +
                "novtalescompanion${File.separator}web${File.separator}WebViewBrowserGateway.kt",
        )
        if (candidate.isFile) return candidate.readText()
        dir = dir?.parentFile
    }
    error("WebViewBrowserGateway.kt not found from ${System.getProperty("user.dir")}")
}

/** The body of `runChapters`, braces balanced, or null when it is not there. */
private fun runChaptersBody(text: String): String? {
    val at = text.indexOf("fun runChapters")
    if (at < 0) return null
    val open = text.indexOf('{', at)
    if (open < 0) return null
    var depth = 0
    for (i in open until text.length) {
        when (text[i]) {
            '{' -> depth++
            '}' -> {
                depth--
                if (depth == 0) return text.substring(open, i + 1)
            }
        }
    }
    return null
}

/**
 * The arguments of every `pageResult(...)` call inside `runChapters`, one list
 * per call site, in source order.
 *
 * Only the second argument is load-bearing, so the splitter is a plain
 * paren-balance rather than a parser: it has to cope with a nested call in an
 * argument (`CHAPTER_PAGE_SIZE` is a constant, but `plan.page` is not guaranteed
 * to stay the only expression in that position forever) and it must not care how
 * the call is laid out across lines.
 */
private fun pageResultCalls(text: String): List<List<String>> {
    val body = runChaptersBody(text) ?: return emptyList()
    val out = ArrayList<List<String>>()
    var i = 0
    while (true) {
        val at = body.indexOf("pageResult", i)
        if (at < 0) break
        var open = at + "pageResult".length
        while (open < body.length && body[open].isWhitespace()) open++
        if (open >= body.length || body[open] != '(') { i = at + 1; continue }
        var depth = 0
        var close = -1
        var argumentStart = open + 1
        val args = ArrayList<String>()
        for (j in open until body.length) {
            when (body[j]) {
                '(' -> depth++
                ')' -> {
                    depth--
                    if (depth == 0) {
                        val last = body.substring(argumentStart, j)
                        if (last.isNotBlank()) args.add(last)
                        close = j
                    }
                }
                ',' -> if (depth == 1) {
                    args.add(body.substring(argumentStart, j))
                    argumentStart = j + 1
                }
            }
            if (close >= 0) break
        }
        if (close < 0) return emptyList()
        out.add(args)
        i = close + 1
    }
    return out
}