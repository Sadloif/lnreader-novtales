package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Operation
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AttentionPolicyTest {
    @Test fun `locked chapter does not block browsing or another chapter`() {
        val blocked = "/chapter/example-10"
        for (next in listOf(
            JobRequest(Operation.CATALOGUE),
            JobRequest(Operation.SEARCH, query = "example"),
            JobRequest(Operation.NOVEL, path = "/novel/example"),
            JobRequest(Operation.CHAPTERS, path = "/novel/example", page = 1),
            JobRequest(Operation.CHAPTER, path = "/chapter/example-1"),
            JobRequest(Operation.CHAPTER, path = "/chapter/other-10"),
        )) assertFalse(AttentionPolicy.preserves(ErrorCode.MEMBERSHIP_REQUIRED, blocked, next))
        assertTrue(AttentionPolicy.preserves(ErrorCode.MEMBERSHIP_REQUIRED, blocked,
            JobRequest(Operation.CHAPTER, path = blocked)))
    }

    @Test fun `verification and reading notices still need the user before navigating`() {
        for (code in listOf(ErrorCode.VERIFICATION_REQUIRED, ErrorCode.READING_NOTICE_REQUIRED,
            ErrorCode.SIGN_IN_REQUIRED)) {
            assertTrue(AttentionPolicy.preserves(code, "/chapter/example-10", JobRequest(Operation.CATALOGUE)))
        }
    }
}
