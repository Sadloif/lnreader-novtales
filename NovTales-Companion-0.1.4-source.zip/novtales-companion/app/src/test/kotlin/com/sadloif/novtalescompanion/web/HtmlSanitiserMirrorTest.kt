package com.sadloif.novtalescompanion.web

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith
import java.io.File

// ---------------------------------------------------------------------------
// Fixtures and parsing helpers. File top level and private on purpose.
//
// JUnit 4's Enclosed runner turns every *declared* class into a suite in its own
// right, which is what makes a `private companion object` unusable here: the
// generated `Companion` class has no public zero-argument constructor and no
// runnable methods, and the suite fails with `initializationError`. A nested
// class also cannot see its outer class's members, so the helpers cannot live on
// the outer class either. File-private top-level declarations are invisible to
// Enclosed and visible to every nested suite.
// ---------------------------------------------------------------------------

private const val ADAPTER_RELATIVE =
    "app/src/main/assets/adapter/novtales-adapter.js"
private const val SANITISER_RELATIVE =
    "app/src/main/kotlin/com/sadloif/novtalescompanion/web/HtmlSanitiser.kt"

/**
 * Walks up from the working directory until the file is found.
 *
 * Gradle runs a `Test` task with the module directory as its working directory,
 * but the project root, the repository root and an IDE's module directory are
 * all plausible in other setups, so this asks for the file rather than assuming
 * where it is. Failing to find it is a test failure, never a silent pass.
 */
private fun sourceFile(relative: String): File? {
    var dir: File? = File(System.getProperty("user.dir") ?: ".").absoluteFile
    repeat(10) {
        val candidate = File(dir, relative.replace('/', File.separatorChar))
        if (candidate.isFile) return candidate
        dir = dir?.parentFile
    }
    return null
}

private val adapterSource: String by lazy {
    sourceFile(ADAPTER_RELATIVE)?.readText()
        ?: error("$ADAPTER_RELATIVE not found from ${System.getProperty("user.dir")}")
}

private val sanitiserSource: String by lazy {
    sourceFile(SANITISER_RELATIVE)?.readText()
        ?: error("$SANITISER_RELATIVE not found from ${System.getProperty("user.dir")}")
}

/** The lower-case tag names of a Kotlin `setOf("a", "b", ...)`. */
private fun kotlinSet(name: String, text: String = sanitiserSource): List<String>? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val open = text.indexOf("setOf(", at)
    if (open < 0 || open - at > name.length + 40) return null
    if (text.substring(at, open).contains(';')) return null
    val close = text.indexOf(')', open)
    if (close < 0) return null
    return Regex("\"([a-z][a-z0-9-]*)\"")
        .findAll(text.substring(open, close))
        .map { it.groupValues[1] }
        .sorted()
        .toList()
}

/**
 * The keys of the adapter's `NAME = { tag: 1, ... }` literal, which is written
 * with bare identifiers rather than strings.
 */
private fun adapterBareKeys(name: String, text: String = adapterSource): List<String>? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val open = text.indexOf('{', at)
    val close = text.indexOf('}', open)
    if (open < 0 || close < 0) return null
    return Regex("([a-z][a-z0-9-]*)\\s*:\\s*1\\b")
        .findAll(text.substring(open, close))
        .map { it.groupValues[1] }
        .sorted()
        .toList()
}

/** The quoted keys of the adapter's `NAME = { 'a': 1, ... }` literal. */
private fun adapterQuotedKeys(name: String, text: String = adapterSource): List<String>? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val open = text.indexOf('{', at)
    val close = text.indexOf('}', open)
    if (open < 0 || close < 0) return null
    return Regex("'([^']+)'\\s*:\\s*1\\b")
        .findAll(text.substring(open, close))
        .map { it.groupValues[1] }
        .sorted()
        .toList()
}

/** The quoted names of the adapter's `NAME = ['a', 'b']` literal. */
private fun adapterStringList(name: String, text: String = adapterSource): List<String>? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val open = text.indexOf('[', at)
    if (open < 0 || open - at > name.length + 40) return null
    if (text.substring(at, open).contains(';')) return null
    val close = text.indexOf(']', open)
    if (close < 0) return null
    return Regex("'([^']+)'")
        .findAll(text.substring(open, close))
        .map { it.groupValues[1] }
        .sorted()
        .toList()
}

/** A Kotlin `Regex("...")` literal, with its `\\` escapes resolved. */
private fun kotlinRegex(name: String, text: String = sanitiserSource): String? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val r = text.indexOf("Regex(", at)
    // The declaration must be the one that follows: no other statement in between.
    if (r < 0 || r - at > name.length + 40) return null
    if (text.substring(at, r).contains(';')) return null
    val open = text.indexOf('"', r + 6)
    if (open < 0) return null
    val out = StringBuilder()
    var i = open + 1
    while (i < text.length && text[i] != '"') {
        if (text[i] == '\\') {
            out.append(text[i + 1])
            i += 2
            continue
        }
        out.append(text[i])
        i++
    }
    return if (i >= text.length) null else out.toString()
}

/** A JS regex literal as `source to flags`. */
private fun adapterRegex(name: String, text: String = adapterSource): Pair<String, String>? {
    val at = text.indexOf(name)
    if (at < 0) return null
    val open = text.indexOf('/', at)
    if (open < 0) return null
    val close = text.indexOf('/', open + 1)
    if (close < 0) return null
    val flags = Regex("^[gimsuy]*").find(text.substring(close + 1))?.value ?: ""
    return text.substring(open + 1, close) to flags
}

/** The body of a named function, braces balanced. */
private fun functionBody(signature: String, text: String = adapterSource): String? {
    val at = text.indexOf(signature)
    if (at < 0) return null
    val open = text.indexOf('{', at)
    if (open < 0) return null
    var depth = 0
    for (i in open until text.length) {
        when (text[i]) {
            '{' -> depth++
            '}' -> {
                depth--
                if (depth == 0) return text.substring(open, i + 1)
            }
        }
    }
    return null
}

/** The quoted values of the `when` branch inside a named Kotlin function. */
private fun kotlinWhenValues(function: String, text: String = sanitiserSource): List<String>? {
    val body = functionBody(function, text) ?: return null
    val whenAt = body.indexOf("->")
    if (whenAt < 0) return null
    val open = body.lastIndexOf('{', whenAt)
    val close = body.indexOf('}', whenAt)
    if (open < 0 || close < 0) return null
    return Regex("\"([^\"]*)\"")
        .findAll(body.substring(open, close))
        .map { it.groupValues[1] }
        .sorted()
        .toList()
}

/**
 * Pins the adapter's mirror of `HtmlSanitiser` to the sanitiser itself.
 *
 * One rule is written down twice - in `HtmlSanitiser.kt`, which decides what
 * survives into the stored chapter, and in
 * `app/src/main/assets/adapter/novtales-adapter.js`, which decides whether the
 * end marker may complete it - and for a long time nothing kept them apart.
 * They have now drifted **three times**:
 *
 *  1. `findEndMarker` walked text nodes with no tag and no visibility test at all,
 *     so a marker in a `<script>` completed a chapter whose stored body was one
 *     preview sentence;
 *  2. when that was fixed, the drop list itself drifted from the sanitiser's;
 *  3. the drop *tags* were then pinned (26/26) but the scene-break,
 *     `data-security-canary` and hidden-content rules still had no cross-language
 *     check at all, so `<p class="scene-break">End of Chapter 12</p>` completed a
 *     chapter stored as `<p>Real prose</p><hr>` - the marker that justified
 *     completion was not in the file that was saved.
 *
 * So the pin covers **every** mechanism, not just the tag list, and it runs
 * inside the ordinary build: `tools/js-tests/adapter.test.js` makes the same
 * comparisons under Node, but nothing in `gradlew test` ran them, so a drift
 * could land and stay green until somebody remembered.
 *
 * Source-level comparisons, deliberately. A behavioural check can only cover the
 * inputs the author thought of; comparing the declared lists covers every entry,
 * including the ones nobody exercised. Each comparison is paired with a
 * perturbation of one side so the pin is shown to be able to fail.
 *
 * Pure JVM: no `android.*` import, no sleeps.
 */
@RunWith(Enclosed::class)
class HtmlSanitiserMirrorTest {

    /**
     * A pin that silently compares nothing is worse than no pin: it goes green
     * and says nothing. So the two files are proved to be the real ones first.
     */
    class SourcesArePresent {

        @Test
        fun `both source files are found from the test working directory`() {
            assertNotNull(
                "$ADAPTER_RELATIVE not found from ${System.getProperty("user.dir")}",
                sourceFile(ADAPTER_RELATIVE),
            )
            assertNotNull(
                "$SANITISER_RELATIVE not found from ${System.getProperty("user.dir")}",
                sourceFile(SANITISER_RELATIVE),
            )
            assertTrue("novtales-adapter.js is not the real one", adapterSource.contains("__novChapterState"))
            assertTrue("HtmlSanitiser.kt is not the real one", sanitiserSource.contains("DROP_SUBTREE_TAGS"))
            assertTrue(adapterSource.length > 1000)
            assertTrue(sanitiserSource.length > 1000)
        }
    }

    // =========================================================================
    // 1. The dropped-tag list.
    // =========================================================================

    class DropSubtreeTags {

        @Test
        fun `the two lists declare the same tags`() {
            val js = adapterBareKeys("SANITISER_DROP_TAGS")
                ?: error("SANITISER_DROP_TAGS not found in the adapter")
            val kt = kotlinSet("DROP_SUBTREE_TAGS")
                ?: error("DROP_SUBTREE_TAGS not found in HtmlSanitiser.kt")

            assertEquals(
                "SANITISER_DROP_TAGS and DROP_SUBTREE_TAGS have drifted",
                kt,
                js,
            )
        }

        @Test
        fun `the list is the size it claims to be, and holds the original repros`() {
            val tags = adapterBareKeys("SANITISER_DROP_TAGS")
                ?: error("SANITISER_DROP_TAGS not found in the adapter")
            assertEquals(26, tags.size)
            for (tag in listOf("script", "style", "template", "noscript")) {
                assertTrue("$tag must be dropped by both", tags.contains(tag))
            }
        }

        @Test
        fun `a tag added to one side alone is caught`() {
            val perturbed = adapterBareKeys(
                "SANITISER_DROP_TAGS",
                adapterSource.replace("script: 1,", "script: 1, marquee: 1,"),
            )
            assertTrue(
                "the pin cannot detect a drift",
                perturbed != adapterBareKeys("SANITISER_DROP_TAGS"),
            )
        }
    }

    // =========================================================================
    // 2. The scene-break rule: class expression, the tags that make a scene
    // break a container, and the values of `data-scene-break` that mean off.
    // =========================================================================

    class SceneBreakRule {

        @Test
        fun `the class expression is character for character the same`() {
            val js = adapterRegex("SANITISER_SCENE_BREAK_CLASS")
                ?: error("SANITISER_SCENE_BREAK_CLASS not found in the adapter")
            val kt = kotlinRegex("SCENE_BREAK_CLASS")
                ?: error("SCENE_BREAK_CLASS not found in HtmlSanitiser.kt")

            assertTrue("the sanitiser's expression must be case-insensitive", kt.startsWith("(?i)"))
            assertTrue("the adapter's expression must be case-insensitive", js.second.contains('i'))
            assertEquals(
                "the scene-break class expression has drifted",
                js.first,
                kt.removePrefix("(?i)"),
            )
        }

        @Test
        fun `the shared expression still behaves the way its comment says`() {
            val shared = kotlinRegex("SCENE_BREAK_CLASS")?.removePrefix("(?i)")
                ?: error("SCENE_BREAK_CLASS not found in HtmlSanitiser.kt")
            val expression = Regex(shared, RegexOption.IGNORE_CASE)

            assertTrue("scene-break", expression.containsMatchIn("scene-break"))
            assertTrue("scene divider", expression.containsMatchIn("scene divider"))
            assertTrue("Scene_Divider", expression.containsMatchIn("Scene_Divider"))
            assertTrue("inside a class list", expression.containsMatchIn("prose scene-break mt-4"))
            // The ones that must never match: each of these has cost the project
            // real chapter prose at some point.
            assertFalse("the bare word break", expression.containsMatchIn("break"))
            assertFalse("break-words (Tailwind)", expression.containsMatchIn("break-words"))
            assertFalse("text-break", expression.containsMatchIn("text-break"))
            assertFalse(
                "md:scene-break - the responsive prefix is deliberately not matched",
                expression.containsMatchIn("md:scene-break"),
            )
        }

        @Test
        fun `the glyph-run expressions are identical`() {
            val js = adapterRegex("SANITISER_SCENE_BREAK_GLYPHS")
                ?: error("SANITISER_SCENE_BREAK_GLYPHS not found in the adapter")
            val kt = kotlinRegex("SCENE_BREAK_GLYPHS")
                ?: error("SCENE_BREAK_GLYPHS not found in HtmlSanitiser.kt")

            assertEquals(
                "the scene-break glyph expression has drifted",
                // The adapter needs its own anchors because a JS `test` is
                // unanchored; Kotlin's `matches` is already a full match.
                js.first.removePrefix("^").removeSuffix("$"),
                kt,
            )
        }

        @Test
        fun `the shared glyph expression still tells markers from prose`() {
            val shared = kotlinRegex("SCENE_BREAK_GLYPHS")
                ?: error("SCENE_BREAK_GLYPHS not found in HtmlSanitiser.kt")
            val glyph = Regex("^(?:$shared)$")

            for (sample in listOf("* * *", "***", "· · ·", "—", "   ", "", "~-~ 3")) {
                assertTrue("\"$sample\" is a scene-break marker", glyph.matches(sample))
            }
            for (sample in listOf("End of Chapter 12", "Click through.", "One.")) {
                assertFalse("\"$sample\" is prose, and is kept", glyph.matches(sample))
            }
        }

        @Test
        fun `the values that mean off are identical`() {
            val js = adapterQuotedKeys("SANITISER_NEGATIVE_VALUES")
                ?: error("SANITISER_NEGATIVE_VALUES not found in the adapter")
            val kt = kotlinWhenValues("private fun isAffirmative")
                ?: error("isAffirmative not found in HtmlSanitiser.kt")

            assertEquals("the data-scene-break negative sets have drifted", kt, js)
            assertEquals(listOf("0", "false", "no", "none", "null", "off", "undefined"), js)
        }

        @Test
        fun `the value-length budget is present on both sides`() {
            // `parseAttributes` cannot tell `<div data-scene-break>` from
            // `<div data-scene-break="">`, so an empty value means on; anything
            // absurdly long means the author meant something else.
            assertTrue("the adapter lost its 20-character budget", adapterSource.contains("length > 20"))
            assertTrue(
                "the sanitiser lost its 20-character budget",
                sanitiserSource.contains("trimmed.length > 20"),
            )
        }

        @Test
        fun `a loosened expression on one side alone is caught`() {
            val perturbed = kotlinRegex(
                "SCENE_BREAK_CLASS",
                sanitiserSource.replace(
                    "scene[-_ ]?(?:break|divider)",
                    "scene[-_ ]?(?:break|divider)|div",
                ),
            )
            assertNotNull("the perturbation did not parse", perturbed)
            assertTrue("the pin cannot detect a drift", perturbed != kotlinRegex("SCENE_BREAK_CLASS"))
        }

        @Test
        fun `an extra block tag on the sanitiser side alone is caught`() {
            val perturbed = kotlinSet(
                "BLOCK_TAGS",
                sanitiserSource.replace(
                    "\"h1\", \"h2\", \"h3\", \"h4\", \"h5\", \"h6\", \"hr\", \"img\"",
                    "\"h1\", \"h2\", \"h3\", \"h4\", \"h5\", \"h6\", \"hr\", \"img\", \"mark\"",
                ),
            )
            assertTrue(
                "the pin cannot detect a drift",
                perturbed != adapterStringList("SANITISER_BLOCK_TAGS"),
            )
        }
    }

    // =========================================================================
    // 3. The hidden-content rules.
    //
    // These were mirrored **by hand** between Kotlin `isHidden` and JS
    // `discardsSubtree` with no cross-language check at all: make the Kotlin
    // side require a case-sensitive `"true"` for `aria-hidden`, or make the
    // adapter read a different attribute, and both suites stay green. That is
    // the same drift as the tag list had, one step further in.
    // =========================================================================

    class HiddenRule {

        @Test
        fun `both sides are gated on the same four things`() {
            val js = functionBody("function discardsSubtree")
                ?: error("discardsSubtree not found in the adapter")
            val kt = functionBody("private fun isHidden", sanitiserSource)
                ?: error("isHidden not found in HtmlSanitiser.kt")

            for (rule in listOf("hidden", "aria-hidden", "style", "display:none", "visibility:hidden")) {
                assertTrue("the sanitiser lost the \"$rule\" rule", kt.contains(rule))
                assertTrue("the adapter lost the \"$rule\" rule", js.contains(rule))
            }
        }

        @Test
        fun `aria-hidden is compared case-insensitively on both sides`() {
            // The exact mutation that would have gone unnoticed: Kotlin
            // `value.trim().equals("true")` with no ignoreCase. A browser
            // resolves `aria-hidden="TRUE"` to hidden, so the sanitiser has to,
            // and so does the adapter.
            val kt = functionBody("private fun isHidden", sanitiserSource)
                ?: error("isHidden not found")
            assertTrue(
                "HtmlSanitiser.isHidden must fold case before comparing \"true\"",
                kt.contains("ignoreCase = true"),
            )
            val js = functionBody("function discardsSubtree")
                ?: error("discardsSubtree not found")
            assertTrue(
                "the adapter must fold case before comparing \"true\"",
                js.contains("toLowerCase() === 'true'"),
            )
        }

        @Test
        fun `the inline style is normalised the same way on both sides`() {
            // Kotlin drops every whitespace character; the adapter collapses
            // runs with `\s+` first. Neither is wrong, but a divergence here is
            // invisible, so both spellings are pinned.
            val kt = functionBody("private fun isHidden", sanitiserSource)
                ?: error("isHidden not found")
            val js = functionBody("function discardsSubtree")
                ?: error("discardsSubtree not found")
            assertTrue(
                "Kotlin must strip whitespace before searching the style",
                kt.contains("filterNot { it.isWhitespace() }"),
            )
            assertTrue(
                "the adapter must collapse whitespace before searching the style",
                js.contains("replace(/\\s+/g, '')"),
            )
        }

        @Test
        fun `the hidden test runs before the element is kept`() {
            // If `hidden` were checked after KEEP_TAGS, `<p hidden>` would keep
            // its text and the mirror would be worthless.
            val hiddenAt = sanitiserSource.indexOf("if (isHidden(attributes))")
            val keepAt = sanitiserSource.indexOf("if (name in KEEP_TAGS)")
            assertTrue("isHidden must exist", hiddenAt >= 0)
            assertTrue("the keep branch must exist", keepAt >= 0)
            assertTrue("isHidden must run before the keep branch", hiddenAt < keepAt)
        }
    }

    // =========================================================================
    // 4. The canary.
    // =========================================================================

    class CanaryRule {

        @Test
        fun `both sides name the same attribute and match it on the href`() {
            val kt = functionBody("private fun isCanary", sanitiserSource)
                ?: error("isCanary not found in HtmlSanitiser.kt")
            val js = functionBody("function isCanary")
                ?: error("isCanary not found in the adapter")

            assertTrue(kt.contains("data-security-canary"))
            assertTrue(js.contains("data-security-canary"))
            assertTrue("the sanitiser must also match it on href", kt.contains("href"))
            assertTrue("the adapter must also match it on href", js.contains("href"))
            assertTrue(
                "the adapter must fold case before searching the href",
                js.contains("toLowerCase()"),
            )
        }

        @Test
        fun `both sides apply it to anchors only`() {
            assertTrue(
                "the sanitiser no longer gates the canary on <a>",
                Regex("""name\s*==\s*"a"\s*&&\s*isCanary\(""").containsMatchIn(sanitiserSource),
            )
            assertTrue(
                "the adapter no longer gates the canary on <a>",
                Regex("""tag\s*===\s*'a'\s*&&\s*isCanary\(""").containsMatchIn(adapterSource),
            )
        }
    }

    // =========================================================================
    // 5. The other direction, and the one a naive fix would get wrong: the
    // adapter must not be *stricter* than the sanitiser either.
    // =========================================================================

    class TheAdapterIsNotStricter {

        @Test
        fun `the marker walk does not consult getComputedStyle`() {
            // `HtmlSanitiser.isHidden` reads the inline `style` attribute and
            // nothing else. A marker a stylesheet hides is therefore kept by the
            // sanitiser, and an adapter that also asked `getComputedStyle` would
            // refuse a chapter that is complete - a denial of service on the
            // reader, not a bypass.
            val walk = functionBody("function discardsSubtree")
                ?: error("discardsSubtree not found in the adapter")
            assertFalse(
                "the adapter must model the sanitiser, not a stricter browser",
                walk.contains("getComputedStyle"),
            )
        }

        @Test
        fun `the inline style attribute is still read, exactly as the sanitiser reads it`() {
            val walk = functionBody("function discardsSubtree")
                ?: error("discardsSubtree not found in the adapter")
            assertTrue(walk.contains("indexOf('display:none') >= 0"))
            assertTrue(walk.contains("indexOf('visibility:hidden') >= 0"))
            assertTrue(walk.contains("hasAttribute('hidden')"))
            assertTrue(walk.contains("'aria-hidden'"))
        }
    }

    // =========================================================================
    // 6. And the behaviour the whole mirror exists for, stated in Kotlin so it
    // is checked from this side too: what the sanitiser deletes is exactly what
    // the adapter must refuse, and what it keeps it must find.
    // =========================================================================

    class WhatTheSanitiserActuallyDoes {

        @Test
        fun `a scene-break slot holding the marker keeps it`() {
            // Finding 2-03's original harm was that a scene-break marker was
            // deleted, so the marker that justified completion was not in the
            // file that was saved. That is now impossible from this direction: a
            // scene break only ever swallows separator glyphs.
            val stored = HtmlSanitiser.sanitise(
                "<p>Real prose</p><p class=\"scene-break\">End of Chapter 12</p>"
            )

            assertEquals("<p>Real prose</p><hr>End of Chapter 12", stored)
            assertTrue(
                "the marker is in the stored chapter, so counting it is correct",
                stored.contains("End of Chapter 12"),
            )
        }

        @Test
        fun `a scene-break glyph run is still exactly an hr`() {
            assertEquals(
                "<p>Real prose</p><hr>",
                HtmlSanitiser.sanitise("<p>Real prose</p><p class=\"scene-break\">* * *</p>"),
            )
        }

        @Test
        fun `a scene-break container keeps its block content`() {
            // The direction a lazy "delete every scene break" fix gets wrong, and
            // which would lose real downloads.
            val stored = HtmlSanitiser.sanitise(
                "<div class=\"scene-break\"><p>Real prose</p><p>End of Chapter 12</p></div>"
            )

            assertTrue("the prose must survive", stored.contains("Real prose"))
            assertTrue("the marker must survive", stored.contains("End of Chapter 12"))
        }

        @Test
        fun `data-scene-break is read on its value, not its presence`() {
            for (value in listOf("false", "0", "no", "off", "none", "null", "undefined")) {
                val stored = HtmlSanitiser.sanitise("<p data-scene-break=\"$value\">End of Chapter 12</p>")
                assertTrue(
                    "data-scene-break=\"$value\" must keep its content",
                    stored.contains("End of Chapter 12"),
                )
                assertFalse(
                    "data-scene-break=\"$value\" is not a scene break, so no <hr>",
                    stored.contains("<hr"),
                )
            }
            // A valueless attribute is a scene break, but its text is prose, so
            // it is kept; only the glyph run is collapsed.
            assertEquals(
                "<hr>End of Chapter 12",
                HtmlSanitiser.sanitise("<p data-scene-break>End of Chapter 12</p>"),
            )
        }

        @Test
        fun `a canary anchor and its subtree are gone`() {
            for (body in listOf(
                "<a data-security-canary=\"1\">End of Chapter 12</a>",
                "<a href=\"/login#data-security-canary\">End of Chapter 12</a>",
            )) {
                val stored = HtmlSanitiser.sanitise("$body<p>Real prose</p>")
                assertEquals("<p>Real prose</p>", stored)
            }
        }

        @Test
        fun `an ordinary anchor keeps its text`() {
            assertTrue(
                HtmlSanitiser.sanitise("<a href=\"/chapter/x-12\">End of Chapter 12</a>")
                    .contains("End of Chapter 12"),
            )
        }

        @Test
        fun `hidden content is gone whatever spells it`() {
            for (attributes in listOf(
                "hidden",
                "aria-hidden=\"true\"",
                "aria-hidden=\"TRUE\"",
                "aria-hidden=\" true \"",
                "style=\"display:none\"",
                "style=\"display : none\"",
                "style=\"visibility:hidden\"",
            )) {
                val stored = HtmlSanitiser.sanitise("<p $attributes>End of Chapter 12</p>")
                assertTrue(
                    "<p $attributes> must not keep its text",
                    !stored.contains("End of Chapter 12"),
                )
            }
        }

        @Test
        fun `a marker a stylesheet would hide is still kept`() {
            // The sanitiser is a string scanner; it has no cascade. So this is
            // what it does, and the adapter has to do the same or a complete
            // chapter is refused for ever.
            val stored = HtmlSanitiser.sanitise("<p class=\"marker-holder\">End of Chapter 12</p>")
            assertTrue(
                "no stylesheet means no display:none",
                stored.contains("End of Chapter 12"),
            )
        }
    }
}
