package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test

class ChapterIndexValidationRegressionTest {
    // Observed HTTP-success fallback for Return of Mount Hua Sect: the site
    // returned its default width and an empty count to a width-50 request.
    private fun emptyDefaultResponse(): Json = jsonObject(
        "chapters" to Json.Arr(emptyList()), "page" to 1,
        "pageSize" to 100, "total" to 0, "totalPages" to 1,
    )

    private fun assertRejected(response: Json, expectedTotal: Int? = null) {
        try {
            NovTalesExtraction.validateIndexPage(response, 1, 50, expectedTotal)
            fail("An inconsistent index must not be accepted as an empty novel")
        } catch (error: CompanionException) {
            assertEquals(ErrorCode.SITE_CHANGED, error.code)
        }
    }

    @Test fun `repeated empty default response remains invalid after retry`() {
        repeat(2) { assertRejected(emptyDefaultResponse()) }
    }

    @Test fun `complete corrected response is valid after rejecting the default response`() {
        assertRejected(emptyDefaultResponse())
        val corrected = jsonObject(
            "chapters" to Json.Arr((100 downTo 51).map {
                jsonObject("number" to it, "title" to "Chapter $it")
            }),
            "page" to 1, "pageSize" to 50, "total" to 100, "totalPages" to 2,
        )
        assertEquals(100, NovTalesExtraction.validateIndexPage(corrected, 1, 50))
    }

    @Test fun `matching page width alone cannot make a short index complete`() {
        val stillIncomplete = jsonObject(
            "chapters" to Json.Arr(emptyList()), "page" to 1,
            "pageSize" to 50, "total" to 100, "totalPages" to 2,
        )
        assertRejected(stillIncomplete, expectedTotal = 100)
    }
}
