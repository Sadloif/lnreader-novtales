package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.JobState
import com.sadloif.novtalescompanion.core.Operation
import com.sadloif.novtalescompanion.core.jsonObject
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.Readiness
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/** A chapter request for `slug`. */
private fun chapter(slug: String) =
    JobRequest(Operation.CHAPTER, path = "/chapter/$slug")

/** Submits a request that must be accepted, and returns the job it produced. */
private fun accepted(runner: JobRunner, request: JobRequest) =
    (runner.submit(request) as JobRunner.SubmitOutcome.Accepted).job

/**
 * Job queue tests: bounding, collapsing, expiry, per-caller release and stop.
 *
 * Promoted from `_working/compilecheck/test/QueueExpiryTest.kt` plus the queue
 * half of `SmokeTest.kt`. Every wait here is driven by an injected clock
 * (`clock: () -> Long`) and injected bounds, so neither the production 45 s /
 * 120 s deadlines nor the 20 s queue ceiling is ever actually waited out: the
 * constants below are milliseconds.
 *
 * Pure JVM: `JobRunner` imports nothing from `android.*`, which is why the
 * gateway arrives through a provider lambda.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class JobRunnerTest {

    // =========================================================================
    // Queue wait expiry - the MAX_QUEUE_WAIT_MS rule
    // =========================================================================

    class QueueExpiry {

        /** Rule 1: the sweeper expires a job that waited too long. */
        @Test
        fun `the sweeper fails a queued job that out waited the ceiling`() {
            val clock = AtomicLong(0)
            val gate = GateGateway()
            val runner = JobRunner(
                gatewayProvider = { gate },
                clock = { clock.get() },
                maxQueueWaitMs = 1_000L,
                sweepIntervalMs = 20L,
                retentionMs = 600_000L,
            )
            runner.start()

            val busy = runner.submit(chapter("slug-1"))
            assertTrue("first job accepted", busy is JobRunner.SubmitOutcome.Accepted)
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))

            val waiting = runner.submit(chapter("slug-2"))
            val waitingId = (waiting as JobRunner.SubmitOutcome.Accepted).job.id
            assertEquals(JobState.QUEUED, runner.job(waitingId)!!.state)

            // Pretend five seconds of queue wait: nothing sleeps, the clock moves.
            clock.set(5_000L)

            awaitUntil("the sweeper to expire the queued job") {
                runner.job(waitingId)?.state == JobState.FAILED
            }

            val expired = runner.job(waitingId)!!
            assertEquals(ErrorCode.TIMEOUT, expired.error?.code)
            assertEquals(Config.QUEUE_FULL_RETRY_AFTER_MS, expired.error?.retryAfterMs)
            assertEquals(true, expired.error?.retryable)
            assertNull("an expired job must never have started", expired.startedAt)
            assertEquals(0, runner.store.queuedCount())

            gate.unblock()
            runner.stop()
        }

        /** Rule 2: the same ceiling, enforced in `takeNext()` rather than by the sweeper. */
        @Test
        fun `the worker refuses to start a job that already out waited the ceiling`() {
            val clock = AtomicLong(0)
            val gate = GateGateway()
            val runner = JobRunner(
                gatewayProvider = { gate },
                clock = { clock.get() },
                maxQueueWaitMs = 1_000L,
                sweepIntervalMs = 3_600_000L, // effectively never sweeps
                retentionMs = 600_000L,
            )
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val waitingId = (runner.submit(chapter("slug-2")) as JobRunner.SubmitOutcome.Accepted).job.id

            clock.set(9_000L)
            gate.unblock() // let the busy job finish so the worker reaches slug-2

            awaitUntil("the worker to skip the expired job") {
                runner.job(waitingId)?.state == JobState.FAILED
            }

            val skipped = runner.job(waitingId)!!
            assertEquals(ErrorCode.TIMEOUT, skipped.error?.code)
            assertNull("it must never have started", skipped.startedAt)

            runner.stop()
        }

        /** Rule 3: a job inside the ceiling still runs. */
        @Test
        fun `a job inside the ceiling still completes`() {
            val clock = AtomicLong(0)
            val gate = GateGateway()
            val runner = JobRunner(
                gatewayProvider = { gate },
                clock = { clock.get() },
                maxQueueWaitMs = 1_000L,
                sweepIntervalMs = 20L,
                retentionMs = 600_000L,
            )
            runner.start()
            gate.unblock() // never blocks

            val id = (runner.submit(chapter("slug-3")) as JobRunner.SubmitOutcome.Accepted).job.id

            awaitUntil("the job to complete") { runner.job(id)?.state == JobState.COMPLETED }
            runner.stop()
        }

        /**
         * The boundary is strict: a job that has waited *exactly* the ceiling is
         * still inside the window and must be allowed to run.
         */
        @Test
        fun `a job exactly at the ceiling is inside the window`() {
            val clock = AtomicLong(0)
            val gate = GateGateway()
            val runner = JobRunner(
                gatewayProvider = { gate },
                clock = { clock.get() },
                maxQueueWaitMs = 1_000L,
                sweepIntervalMs = 3_600_000L, // the sweeper must not be what decides
                retentionMs = 600_000L,
            )
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val waitingId = (runner.submit(chapter("slug-2")) as JobRunner.SubmitOutcome.Accepted).job.id

            clock.set(1_000L)
            gate.unblock()

            awaitUntil("the worker to take the job at the boundary") {
                val state = runner.job(waitingId)?.state
                state == JobState.LOADING || state == JobState.COMPLETED
            }

            assertNull("the boundary must not be an expiry", runner.job(waitingId)!!.error)

            runner.stop()
        }
    }

    // =========================================================================
    // Bounding the queue
    // =========================================================================

    class QueueBounds {

        @Test
        fun `the queue is refused once the waiting bound is reached`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate }, maxWaitingJobs = 2)
            runner.start()

            runner.submit(chapter("busy"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            accepted(runner, JobRequest(Operation.NOVEL, path = "/novel/a"))
            accepted(runner, JobRequest(Operation.NOVEL, path = "/novel/b"))

            val refused = runner.submit(JobRequest(Operation.NOVEL, path = "/novel/c"))

            assertTrue("expected a rejection, got $refused", refused is JobRunner.SubmitOutcome.Rejected)
            val error = (refused as JobRunner.SubmitOutcome.Rejected).error
            assertEquals(ErrorCode.QUEUE_FULL, error.code)
            assertEquals(Config.QUEUE_FULL_RETRY_AFTER_MS, error.retryAfterMs)

            gate.unblock()
            runner.stop()
        }

        @Test
        fun `collapsing is checked before the queue bound`() {
            // An identical request adds no browser work, so refusing it would only
            // make the client do the same work twice.
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate }, maxWaitingJobs = 1)
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            accepted(runner, JobRequest(Operation.NOVEL, path = "/novel/a"))

            val collapsed = runner.submit(chapter("slug-1"))

            assertTrue(collapsed is JobRunner.SubmitOutcome.Accepted)
            assertTrue((collapsed as JobRunner.SubmitOutcome.Accepted).collapsed)
            assertEquals(2, runner.job(collapsed.job.id)!!.waiterCount)

            gate.unblock()
            runner.stop()
        }

        @Test
        fun `the waiter count on one collapsed job is capped`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate }, maxWaitingJobs = 4)
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))

            repeat(JobRunner.MAX_WAITERS_PER_JOB - 1) {
                assertTrue(runner.submit(chapter("slug-1")) is JobRunner.SubmitOutcome.Accepted)
            }
            val overflow = runner.submit(chapter("slug-1"))

            assertTrue(overflow is JobRunner.SubmitOutcome.Rejected)
            assertEquals(
                ErrorCode.QUEUE_FULL,
                (overflow as JobRunner.SubmitOutcome.Rejected).error.code,
            )

            gate.unblock()
            runner.stop()
        }

        @Test
        fun `a different request is never collapsed onto a running one`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val other = runner.submit(chapter("slug-2"))

            assertTrue(other is JobRunner.SubmitOutcome.Accepted)
            assertFalse((other as JobRunner.SubmitOutcome.Accepted).collapsed)

            gate.unblock()
            runner.stop()
        }
    }

    // =========================================================================
    // No gateway at all
    // =========================================================================

    class MissingGateway {

        @Test
        fun `a job with no gateway fails as COMPANION_UNAVAILABLE`() {
            val runner = JobRunner(gatewayProvider = { null })
            runner.start()

            val id = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id

            awaitUntil("the job to fail") { runner.job(id)?.state == JobState.FAILED }
            assertEquals(ErrorCode.COMPANION_UNAVAILABLE, runner.job(id)!!.error?.code)
            runner.stop()
        }

        @Test
        fun `a gateway that is installed later is picked up on the next job`() {
            // The provider is read per job, not cached at start().
            val gate = GateGateway()
            gate.unblock()
            var installed = false
            val runner = JobRunner(gatewayProvider = { if (installed) gate else null })
            runner.start()

            val missingId = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id
            awaitUntil("the first job to fail") { runner.job(missingId)?.state == JobState.FAILED }

            installed = true
            val okId = (runner.submit(chapter("slug-2")) as JobRunner.SubmitOutcome.Accepted).job.id
            awaitUntil("the second job to complete") { runner.job(okId)?.state == JobState.COMPLETED }

            runner.stop()
        }
    }

    // =========================================================================
    // Release - per-caller cancellation
    // =========================================================================

    class Release {

        @Test
        fun `releasing one of two callers keeps the job running`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val second = runner.submit(chapter("slug-1"))
            val id = (second as JobRunner.SubmitOutcome.Accepted).job.id

            val release = runner.release(id)

            assertTrue(release is JobRunner.ReleaseOutcome.Shared)
            assertFalse("must not cancel while another caller waits", gate.cancelled)
            assertEquals(JobState.LOADING, runner.job(id)!!.state)

            gate.unblock()
            runner.stop()
        }

        @Test
        fun `releasing the last waiter cancels the job and the browser`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val id = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id
            runner.release(id) // one of two

            val release = runner.release(id) // the last one

            assertTrue(release is JobRunner.ReleaseOutcome.Released)
            assertTrue((release as JobRunner.ReleaseOutcome.Released).cancelled)
            assertTrue("cancel must reach the browser", gate.cancelled)
            assertEquals(JobState.CANCELLED, release.job.state)

            runner.stop()
        }

        @Test
        fun `an unknown job id releases to null`() {
            val runner = JobRunner(gatewayProvider = { GateGateway() })
            assertNull(runner.release("00000000-0000-0000-0000-000000000000"))
        }

        @Test
        fun `releasing a job that already finished is not an error`() {
            // A finished job cannot be cancelled, but the caller has still stopped
            // waiting and nothing is left to interrupt in the browser.
            val gate = GateGateway()
            gate.unblock()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            val id = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id
            awaitUntil("the job to complete") { runner.job(id)?.state == JobState.COMPLETED }

            val release = runner.release(id)

            assertTrue(release is JobRunner.ReleaseOutcome.Released)
            assertFalse((release as JobRunner.ReleaseOutcome.Released).cancelled)
            assertEquals(JobState.COMPLETED, release.job.state)

            runner.stop()
        }
    }

    // =========================================================================
    // Stop
    // =========================================================================

    class Stopping {

        @Test
        fun `stop fails every unfinished job and cancels the browser`() {
            val gate = GateGateway()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            runner.submit(chapter("slug-1"))
            assertTrue(gate.started.await(5, TimeUnit.SECONDS))
            val loadingId = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id
            val queuedId = accepted(runner, JobRequest(Operation.NOVEL, path = "/novel/a")).id

            runner.stop()

            for (id in listOf(queuedId, loadingId)) {
                val job = runner.job(id)!!
                assertEquals(JobState.FAILED, job.state)
                assertEquals(ErrorCode.COMPANION_UNAVAILABLE, job.error?.code)
            }
            assertTrue(gate.cancelled)
        }

        @Test
        fun `stop is idempotent`() {
            val runner = JobRunner(gatewayProvider = { GateGateway() })
            runner.start()
            runner.stop()
            runner.stop()
        }

        @Test
        fun `a job that already finished is left alone by stop`() {
            val gate = GateGateway()
            gate.unblock()
            val runner = JobRunner(gatewayProvider = { gate })
            runner.start()

            val id = (runner.submit(chapter("slug-1")) as JobRunner.SubmitOutcome.Accepted).job.id
            awaitUntil("the job to complete") { runner.job(id)?.state == JobState.COMPLETED }

            runner.stop()

            assertEquals(JobState.COMPLETED, runner.job(id)!!.state)
        }
    }
}