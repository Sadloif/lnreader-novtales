package com.sadloif.novtalescompanion.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.experimental.runners.Enclosed

/**
 * The companion's JSON sits directly behind the pairing key, so this reader is
 * deliberately strict: an unexpected token is an error, never a best guess.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class JsonTest {

    // =========================================================================
    // Round trip
    // =========================================================================

    class RoundTrip {

        @Test
        fun `an object of every scalar type survives a write and parse cycle`() {
            val original = jsonObject(
                "a" to "x",
                "b" to 1,
                "c" to true,
                "d" to null,
            )
            val parsed = Json.parse(original.write())

            assertEquals("x", parsed.str("a"))
            assertEquals(1L, parsed.long("b"))
            assertEquals(1.0, parsed.num("b")!!, 0.0)
            assertEquals(true, parsed.bool("c"))
            assertTrue(parsed.isNull("d"))
            assertEquals(original.write(), parsed.write())
        }

        @Test
        fun `the written form uses the exact punctuation the local API specifies`() {
            assertEquals("""{"a":"x","b":1,"c":true,"d":null}""", jsonObject(
                "a" to "x",
                "b" to 1,
                "c" to true,
                "d" to null,
            ).write())
        }

        @Test
        fun `field order is preserved so responses are stable`() {
            // LinkedHashMap, not a hash map: the plugin's snapshots depend on this.
            assertEquals(
                """{"z":1,"a":2,"m":3}""",
                jsonObject("z" to 1, "a" to 2, "m" to 3).write(),
            )
        }

        @Test
        fun `a negative number and a fractional number survive the cycle`() {
            val parsed = Json.parse(jsonObject("cold" to -7, "temp" to 1.25).write())
            assertEquals(-7L, parsed.long("cold"))
            assertEquals(1.25, parsed.num("temp")!!, 0.0)
        }

        @Test
        fun `an absent key is distinguishable from a key whose value is null`() {
            val parsed = Json.parse(jsonObject("present" to null).write())
            assertTrue(parsed.has("present"))
            assertTrue(parsed.isNull("present"))
            assertFalse(parsed.has("absent"))
            assertFalse(parsed.isNull("absent"))
        }
    }

    // =========================================================================
    // Number formatting - the LNReader TypeScript contract
    // =========================================================================

    class WholeNumberFormatting {

        @Test
        fun `an Int is written without a decimal point`() {
            // The LNReader TypeScript side reads chapterNumber as a number and
            // stringifies it; "1.0" reaching it would break the chapter match.
            assertEquals("""{"chapterNumber":1}""", jsonObject("chapterNumber" to 1).write())
        }

        @Test
        fun `a Long is written without a decimal point`() {
            assertEquals("""{"n":1}""", jsonObject("n" to 1L).write())
        }

        @Test
        fun `a Double that happens to be whole is written without a decimal point`() {
            assertEquals("""{"n":1}""", jsonObject("n" to 1.0).write())
            assertEquals("""{"n":0}""", jsonObject("n" to 0.0).write())
            assertEquals("""{"n":-42}""", jsonObject("n" to -42.0).write())
        }

        @Test
        fun `no whole value anywhere in a document carries a trailing dot zero`() {
            val written = jsonObject(
                "a" to 0,
                "b" to 1,
                "c" to 1000000L,
                "d" to listOf(1, 2, 3),
            ).write()
            assertEquals("""{"a":0,"b":1,"c":1000000,"d":[1,2,3]}""", written)
            assertFalse(written, written.contains(".0"))
        }

        @Test
        fun `a fractional number keeps its decimal point`() {
            assertEquals("""{"n":12.75}""", jsonObject("n" to 12.75).write())
            assertEquals("""{"n":0.5}""", jsonObject("n" to 0.5).write())
        }

        @Test
        fun `a chapter number written as a decimal survives as a decimal`() {
            assertEquals("""{"n":944.5}""", jsonObject("n" to 944.5).write())
            assertEquals(944.5, Json.parse(jsonObject("n" to 944.5).write()).num("n")!!, 0.0)
        }

        @Test
        fun `a non-finite Double is written as null rather than as NaN`() {
            // Real behaviour, and the right one: "NaN" is not valid JSON, so the
            // writer substitutes null. Parsing NaN back in is rejected (see below).
            assertEquals("""{"n":null}""", jsonObject("n" to Double.NaN).write())
            assertEquals("""{"n":null}""", jsonObject("n" to Double.POSITIVE_INFINITY).write())
        }

        @Test
        fun `an integer beyond double precision does not round trip exactly`() {
            // Real behaviour, inherent to the Double-backed model: values above 2^53
            // lose their low bits and are written in exponent form. It cannot affect
            // real chapter numbers, but a caller must not assume 64-bit fidelity.
            val original = 9007199254740993L // 2^53 + 1
            val written = jsonObject("n" to original).write()
            assertTrue(written, written.contains("E15"))
            assertNotEquals(original, Json.parse(written).long("n"))
        }
    }

    // =========================================================================
    // Strings
    // =========================================================================

    class Strings {

        @Test
        fun `quotes backslashes newlines tabs slashes and non-ascii all round trip`() {
            val awkward = "quote:\"" + " backslash:\\" +
                " slash:/" +
                " newline:\n" +
                " return:\r" +
                " tab:\t" +
                " backspace:\b" +
                " formfeed:\u000C" +
                " control:\u0001" +
                " hangul:\uAC00" +
                " emdash:\u2014"
            val parsed = Json.parse(jsonObject("s" to awkward).write())
            assertEquals(awkward, parsed.str("s"))
        }

        @Test
        fun `the dangerous characters are escaped on the wire`() {
            // The expected value is a normal string literal, not a raw one, so the
            // escapes under test are visibly the writer's and not the compiler's.
            val expected = "{\"s\":\"a\\\"b\\\\c\\nd\\te\\u0001\"}"
            val value = "a\"b\\c\nd\te" + 1.toChar()
            val written = jsonObject("s" to value).write()
            assertEquals(expected, written)
            assertFalse("a raw newline must never appear inside a JSON string", written.contains("\n"))
            assertFalse("a raw tab must never appear inside a JSON string", written.contains("\t"))
        }

        @Test
        fun `a solidus is written raw rather than escaped`() {
            // Real behaviour, and valid JSON: "/" needs no escape in a string. It is
            // worth pinning because "\/" is the form some other writers emit.
            assertEquals("""{"s":"a/b"}""", jsonObject("s" to "a/b").write())
            assertEquals("a/b", Json.parse("""{"s":"a\/b"}""").str("s"))
        }

        @Test
        fun `non-ascii characters are written raw and read back`() {
            val parsed = Json.parse(jsonObject("s" to "\uAC00\u2014\u00E9").write())
            assertEquals("\uAC00\u2014\u00E9", parsed.str("s"))
        }

        @Test
        fun `a unicode escape decodes to the character it names`() {
            assertEquals("\uAC00", Json.parse("\"\\uAC00\"").let { (it as Json.Str).value })
            assertEquals("\u2014", Json.parse("\"\\u2014\"").let { (it as Json.Str).value })
            assertEquals("\u0000", Json.parse("\"\\u0000\"").let { (it as Json.Str).value })
        }

        @Test
        fun `a surrogate pair escape decodes to one astral character`() {
            val parsed = Json.parse("\"\\uD83D\\uDE00\"").let { (it as Json.Str).value }
            assertEquals("\uD83D\uDE00", parsed)
            assertEquals(2, parsed.length) // two UTF-16 code units, one code point
            assertEquals(1, parsed.codePointCount(0, parsed.length))
        }

        @Test
        fun `an escape for a literal quote or backslash decodes to that character`() {
            assertEquals("\"", Json.parse("\"\\\"\"").let { (it as Json.Str).value })
            assertEquals("\\", Json.parse("\"\\\\\"").let { (it as Json.Str).value })
            assertEquals("\n", Json.parse("\"\\n\"").let { (it as Json.Str).value })
            assertEquals("\t", Json.parse("\"\\t\"").let { (it as Json.Str).value })
        }

        @Test
        fun `an empty string is a valid string`() {
            assertEquals("", Json.parse("\"\"").let { (it as Json.Str).value })
            assertEquals("", Json.parse(jsonObject("s" to "").write()).str("s"))
        }
    }

    // =========================================================================
    // Structure
    // =========================================================================

    class Structure {

        @Test
        fun `nested objects and arrays round trip`() {
            val original = jsonObject(
                "novel" to jsonObject(
                    "slug" to "surviving-the-game-as-a-barbarian",
                    "tags" to listOf("fantasy", "isekai"),
                    "stats" to jsonObject("chapters" to 944, "words" to 1234567L),
                ),
                "chapters" to listOf(1, 2, 3),
            )
            val parsed = Json.parse(original.write())

            assertEquals("surviving-the-game-as-a-barbarian", parsed.obj("novel")?.str("slug"))
            assertEquals(
                listOf("fantasy", "isekai"),
                parsed.obj("novel")?.arr("tags")?.items?.map { (it as Json.Str).value },
            )
            assertEquals(944L, parsed.obj("novel")?.obj("stats")?.long("chapters"))
            assertEquals(3, parsed.arr("chapters")?.items?.size)
            assertEquals(original.write(), parsed.write())
        }

        @Test
        fun `an array of mixed and null values round trips`() {
            val original = jsonObject("mixed" to listOf(1, "two", true, null, 3.5))
            val parsed = Json.parse(original.write())
            val items = parsed.arr("mixed")!!.items
            assertEquals(5, items.size)
            assertEquals(1L, (items[0] as Json.Num).value.toLong())
            assertEquals("two", (items[1] as Json.Str).value)
            assertEquals(true, (items[2] as Json.Bool).value)
            assertSame(Json.Null, items[3])
            assertEquals(3.5, (items[4] as Json.Num).value, 0.0)
        }

        @Test
        fun `an empty object and an empty array round trip`() {
            assertEquals("{}", Json.parse("{}").write())
            assertEquals("[]", Json.parse("[]").write())
            assertEquals("{}", jsonObject().write())
            assertEquals(0, (Json.parse("{}") as Json.Obj).fields.size)
            assertEquals(0, Json.parse("[]").let { (it as Json.Arr).items.size })
        }

        @Test
        fun `whitespace between tokens is ignored`() {
            val parsed = Json.parse("  {\n\t\"a\" : [ 1 , 2 ] ,\r\n \"b\" : null \n}  ")
            assertEquals(2, parsed.arr("a")?.items?.size)
            assertTrue(parsed.isNull("b"))
        }

        @Test
        fun `a duplicate key keeps the last value rather than failing`() {
            // Real behaviour: the reader writes into a map, so a later duplicate
            // silently overwrites an earlier one. Strictness gap, not a crash.
            val parsed = Json.parse("""{"a":1,"a":2}""")
            assertEquals(2L, parsed.long("a"))
            assertEquals(1, (parsed as Json.Obj).fields.size)
        }

        @Test
        fun `an accessor on the wrong type returns null instead of throwing`() {
            val parsed = Json.parse("""{"s":"text","n":1,"o":{},"a":[]}""")
            assertNull(parsed.obj("s"))
            assertNull(parsed.arr("s"))
            assertNull(parsed.str("n"))
            assertNull(parsed.num("s"))
            assertNull(parsed.bool("n"))
            assertNull(parsed.obj("n"))
            assertNull(parsed.arr("o"))
            assertNull(parsed.str("o"))
        }

        @Test
        fun `the of and arr helpers build the same values as the string overloads`() {
            assertEquals(Json.Str("x"), Json.of("x"))
            assertEquals(Json.Null, Json.of(null as String?))
            assertEquals("""["a","b"]""", Json.arrOf(listOf("a", "b")).write())
            assertEquals("""[1]""", Json.arr(listOf(Json.of(1))).write())
            assertEquals(
                jsonObject("a" to 1, "b" to "x"),
                jsonObject("a" to Json.of(1), "b" to Json.of("x")),
            )
        }

        @Test
        fun `an unsupported value type is refused at construction time`() {
            // Failing here is better than writing "null" and losing the field silently.
            try {
                jsonObject("bad" to Any())
                fail("expected an unsupported JSON value to be refused")
            } catch (expected: IllegalArgumentException) {
                assertTrue(expected.message!!.contains("Unsupported JSON value"))
            }
        }
    }

    // =========================================================================
    // Malformed input - the reader must refuse rather than guess
    // =========================================================================

    class MalformedInput {

        @Test
        fun `a trailing comma in an object is rejected`() {
            assertRejected("""{"a":1,}""")
        }

        @Test
        fun `a trailing comma in an array is rejected`() {
            assertRejected("[1,2,]")
        }

        @Test
        fun `an unquoted object key is rejected`() {
            assertRejected("{a:1}")
            assertRejected("{1:2}")
        }

        @Test
        fun `single quoted strings are rejected`() {
            // Threat: Python-flavoured JSON must not be silently accepted by a
            // request body parser that runs before the pairing key check.
            assertRejected("{'a':1}")
            assertRejected("'a'")
        }

        @Test
        fun `an unterminated string is rejected`() {
            assertRejected("\"abc")
            assertRejected("""{"a":"abc}""")
            assertRejected("{\"a\":\"abc\\\"")
        }

        @Test
        fun `a bare word is rejected`() {
            assertRejected("abc")
            assertRejected("yes")
            assertRejected("undefined")
            assertRejected("NaN")
            assertRejected("Infinity")
            assertRejected("-Infinity")
        }

        @Test
        fun `trailing content after the value is rejected`() {
            // Threat: two documents in one body, where a lax parser reads only the
            // first and the rest is smuggled into whatever reads the body next.
            assertRejected("""{"a":1} {"b":2}""")
            assertRejected("""{"a":1}{"b":2}""")
            assertRejected("1 2")
            assertRejected("true false")
            assertRejected("\"a\" junk")
        }

        @Test
        fun `an unescaped control character inside a string is rejected`() {
            assertRejected("\"a\u0001b\"")
            assertRejected("\"line\nbreak\"")
            assertRejected("\"tab\there\"")
        }

        @Test
        fun `empty and whitespace-only input is rejected`() {
            assertRejected("")
            assertRejected("   ")
            assertRejected("\n\t ")
        }

        @Test
        fun `a truncated document is rejected`() {
            assertRejected("""{"a":1""")
            assertRejected("""{"a"""")
            assertRejected("""{"a":""")
            assertRejected("[1,2")
            assertRejected("[")
            assertRejected("{")
        }

        @Test
        fun `a missing or misplaced colon is rejected`() {
            assertRejected("""{"a" 1}""")
            assertRejected("""{"a"::1}""")
            assertRejected("""{"a"=1}""")
        }

        @Test
        fun `a missing value is rejected`() {
            assertRejected("""{"a":}""")
            assertRejected("""[1,,2]""")
        }

        @Test
        fun `a bad escape sequence is rejected`() {
            assertRejected("\"\\q\"")
            assertRejected("\"\\x41\"")
            assertRejected("\"\\u00\"")
            assertRejected("\"\\uZZZZ\"")
            assertRejected("\"abc\\\"")
        }

        @Test
        fun `a malformed number is rejected`() {
            assertRejected("-")
            assertRejected(".")
            assertRejected(".5")
            assertRejected("+1")
            assertRejected("1e")
            assertRejected("1e+")
            assertRejected("--1")
        }

        @Test
        fun `a number with a leading zero or a bare point is accepted instead of rejected`() {
            // Real behaviour, and a strictness gap worth knowing: RFC 8259 forbids
            // leading zeros and "1.", and this reader - documented as strict - takes
            // both. Harmless for the wire format (the companion only ever writes or
            // reads its own documents) but it is not the strictness the KDoc claims.
            assertEquals(1.0, Json.parse("01").let { (it as Json.Num).value }, 0.0)
            assertEquals(1.0, Json.parse("1.").let { (it as Json.Num).value }, 0.0)
            assertEquals(0.5, Json.parse("0.5").let { (it as Json.Num).value }, 0.0)
            assertEquals(150.0, Json.parse("1.5e2").let { (it as Json.Num).value }, 0.0)
            assertEquals(150.0, Json.parse("1.5E2").let { (it as Json.Num).value }, 0.0)
        }
    }

    // =========================================================================
    // Depth limit
    // =========================================================================

    class NestingDepth {

        private fun nest(depth: Int): String = "[".repeat(depth) + "1" + "]".repeat(depth)

        @Test
        fun `nesting at the depth limit is accepted`() {
            // Real behaviour: parseValue rejects depth > 64, so 64 nested arrays parse.
            val parsed = Json.parse(nest(64))
            var cursor: Json = parsed
            var depth = 0
            while (cursor is Json.Arr && cursor.items.isNotEmpty()) {
                cursor = cursor.items[0]
                depth++
            }
            assertEquals(64, depth)
        }

        @Test
        fun `nesting one level past the limit is rejected as invalid JSON`() {
            assertRejected(nest(65))
        }

        @Test
        fun `absurdly deep nesting is rejected rather than overflowing the stack`() {
            // The point of the limit: a hostile document must produce a catchable
            // IllegalArgumentException, never a StackOverflowError that would take
            // down the companion's HTTP thread.
            assertRejected("[".repeat(10_000) + "1" + "]".repeat(10_000))
            assertRejected("""{"a":""" .repeat(10_000) + "1" + "}".repeat(10_000))
        }
    }

    // =========================================================================
    // Null and numeric accessors
    // =========================================================================

    class Accessors {

        @Test
        fun `parsing the null literal yields Json Null`() {
            assertSame(Json.Null, Json.parse("null"))
        }

        @Test
        fun `every accessor on Json Null returns null instead of throwing`() {
            val parsed = Json.parse("null")
            assertNull(parsed.str("x"))
            assertNull(parsed.num("x"))
            assertNull(parsed.bool("x"))
            assertNull(parsed.obj("x"))
            assertNull(parsed.arr("x"))
            assertNull(parsed.long("x"))
            assertNull(parsed.int("x"))
            assertFalse(parsed.has("x"))
        }

        @Test
        fun `isNull is false on Json Null itself and true on a null field`() {
            // Real behaviour: isNull asks "is the key present AND null", so calling it
            // on a non-object can never be true.
            assertFalse(Json.parse("null").isNull("x"))
            assertFalse(Json.Null.isNull("x"))
            assertTrue(jsonObject("d" to null).isNull("d"))
        }

        @Test
        fun `long and int read an integral number`() {
            val parsed = jsonObject("n" to 12)
            assertEquals(12L, parsed.long("n"))
            assertEquals(12, parsed.int("n"))
            assertNull(parsed.long("missing"))
            assertNull(parsed.int("missing"))
            assertNull(jsonObject("s" to "12").long("s"))
        }

        @Test
        fun `long and int return null for a non-finite number`() {
            val nan = Json.Obj(mapOf<String, Json>("n" to Json.Num(Double.NaN)))
            val infinite = Json.Obj(mapOf<String, Json>("n" to Json.Num(Double.NEGATIVE_INFINITY)))
            assertNull(nan.long("n"))
            assertNull(nan.int("n"))
            assertNull(infinite.long("n"))
            assertNull(infinite.int("n"))
            // num() still hands back the raw value; only the integer readers guard.
            assertTrue(nan.num("n")!!.isNaN())
        }

        @Test
        fun `long and int return null for a fractional number instead of truncating`() {
            // A chapter number is the value isSameChapter is asked to check. Silently
            // turning 12.75 into 12 would let a malformed page or a hostile payload
            // pick a different chapter, so the fraction must be refused outright.
            assertNull(jsonObject("chapterNumber" to 12.75).long("chapterNumber"))
            assertNull(jsonObject("chapterNumber" to 12.75).int("chapterNumber"))
            assertNull(jsonObject("n" to -1.5).long("n"))
            assertNull(jsonObject("n" to 0.5).int("n"))
            // num() still hands back the raw value; only the integer readers refuse.
            assertEquals(12.75, jsonObject("n" to 12.75).num("n")!!, 0.0)
        }

        @Test
        fun `int returns null for a value outside the Int range instead of clamping`() {
            // Real behaviour: the range check refuses the value rather than letting
            // Double.toInt() saturate it to Int.MAX_VALUE, which would look like a
            // plausible count rather than an overflow.
            assertNull(jsonObject("n" to 3000000000L).int("n"))
            assertNull(jsonObject("n" to Long.MAX_VALUE).int("n"))
            assertNull(jsonObject("n" to -3000000000L).int("n"))
            // long() still reads it: it is in range for a Long.
            assertEquals(3000000000L, jsonObject("n" to 3000000000L).long("n"))
        }

        @Test
        fun `long refuses magnitudes it cannot represent instead of saturating`() {
            // Json.Num is Double-backed, so Long.MAX_VALUE is *written* as
            // Long.MAX_VALUE but *parses* to 2^63, which no Long can hold.
            // Reading it back as Long.MAX_VALUE would be silent saturation - the
            // value the caller supplied would change under them. Refusing is the
            // honest answer, and it is what the accessor now does.
            //
            // This test previously asserted `Long.MAX_VALUE` came back out, which
            // made it incapable of failing: 2^63 saturates to exactly the value it
            // claimed to check.
            assertNull(jsonObject("n" to Long.MAX_VALUE).long("n"))
            assertNull(jsonObject("n" to Long.MIN_VALUE).long("n"))

            // Nothing between 2^53 and 2^63 round-trips, because a Double cannot
            // hold it: `Long.MAX_VALUE - 1` becomes exactly 2^63 by the time the
            // accessor sees it, which is out of range, so it is refused too. The
            // honest statement is where the boundary actually is.
            assertNull(jsonObject("n" to (Long.MAX_VALUE - 1)).long("n"))
            assertNull(jsonObject("n" to (Long.MIN_VALUE + 1)).long("n"))

            // 2^53 is the largest integer a Double holds exactly, and it does
            // round-trip in both directions. `2^53 + 1` rounds to `2^53` *before*
            // the accessor ever sees it, so what comes back is what the store
            // actually holds - a real Long, not a saturation of an out-of-range
            // one.
            val exact = 1L shl 53
            assertEquals(exact, jsonObject("n" to exact).long("n"))
            assertEquals(-exact, jsonObject("n" to -exact).long("n"))
            assertEquals(exact, jsonObject("n" to (exact + 1)).long("n"))

            // Int is Double-exact, so its extremes really do round-trip.
            assertEquals(Int.MAX_VALUE, jsonObject("n" to Int.MAX_VALUE).int("n"))
            assertEquals(Int.MIN_VALUE, jsonObject("n" to Int.MIN_VALUE).int("n"))
        }

        @Test
        fun `long refuses a literal above the Long range parsed from the wire`() {
            // 2^63 and -2^63-1 straight from JSON, which is the shape a hostile or
            // malformed payload would actually take.
            assertNull(Json.parse("""{"n":9223372036854775808}""").long("n"))
            assertNull(Json.parse("""{"n":-9223372036854775809}""").long("n"))

            // `9223372036854775807` is in range for a Long, but reading it as a
            // Double gives 2^63, which is not - so it is refused rather than
            // silently returned as something the payload never said. The largest
            // integer literal that survives the round trip is 2^53.
            assertNull(Json.parse("""{"n":9223372036854775807}""").long("n"))
            assertEquals(9007199254740992L, Json.parse("""{"n":9007199254740992}""").long("n"))
            assertEquals(-9007199254740992L, Json.parse("""{"n":-9007199254740992}""").long("n"))
        }

        @Test
        fun `long and int still read a whole number written with a decimal point`() {
            // Real behaviour: the check is on the value, not on the source text, so
            // "12.0" parsed from the wire reads as 12 exactly, without rounding.
            val parsed = Json.parse("""{"a":12.0,"b":12.5,"c":-3.0}""")
            assertEquals(12L, parsed.long("a"))
            assertEquals(12, parsed.int("a"))
            assertNull(parsed.long("b"))
            assertEquals(-3L, parsed.long("c"))
        }
    }
}

/** Parses [text], expecting a hard failure rather than a coerced value. */
private fun assertRejected(text: String) {
    try {
        Json.parse(text)
        fail("expected invalid JSON to be rejected: <$text>")
    } catch (expected: IllegalArgumentException) {
        // The reader's documented failure mode.
    }
}
