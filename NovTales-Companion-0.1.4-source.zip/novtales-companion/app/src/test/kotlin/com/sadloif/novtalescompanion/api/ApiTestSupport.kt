package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.jsonObject
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.Readiness
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Shared fakes and helpers for the local API tests.
 *
 * Promoted from `_working/compilecheck/test/`. Nothing here imports `android.*`:
 * the whole `api` package is deliberately Android-free so it can be driven on a
 * plain JVM with a fake gateway.
 *
 * Nothing here sleeps for a fixed period either. [awaitUntil] polls a predicate
 * with a short interval and a generous ceiling, so the tests are both fast (the
 * injected constants are milliseconds, not the 45 s / 120 s production ones) and
 * robust on a loaded machine.
 */

/** The pairing key every API test presents. Shape is irrelevant to the server. */
const val TEST_KEY: String = "test-pairing-key-0123456789"

/**
 * Waits until [condition] holds, polling every few milliseconds.
 *
 * A fixed `Thread.sleep(500)` would be both slower and flakier: this returns as
 * soon as the state the test is waiting for is actually observable.
 */
fun awaitUntil(
    what: String,
    ceilingMs: Long = 10_000L,
    intervalMs: Long = 2L,
    condition: () -> Boolean,
) {
    val deadline = System.nanoTime() + ceilingMs * 1_000_000L
    while (System.nanoTime() < deadline) {
        if (condition()) return
        Thread.sleep(intervalMs)
    }
    if (!condition()) {
        throw AssertionError("timed out after ${ceilingMs}ms waiting for: $what")
    }
}

/**
 * A gateway that answers with whatever [behaviour] returns.
 *
 * By default it returns straight away. Pass `blockUntilReleased = true` (or use
 * [BlockingGateway] / [GateGateway]) when a test needs the window in which a job
 * is QUEUED or LOADING to be deterministic.
 */
class FakeGateway(
    private val behaviour: suspend (JobRequest, Long) -> Json = { request, _ ->
        jsonObject("echo" to request.operation.wireName)
    },
    override var readiness: Readiness = Readiness.READY,
    val blockUntilReleased: Boolean = false,
) : BrowserGateway {

    val started = CountDownLatch(1)
    val release = CountDownLatch(1)

    @Volatile
    var cancelled: Boolean = false

    @Volatile
    var executions: Int = 0

    @Volatile
    var lastDeadlineMs: Long = 0L

    override suspend fun execute(request: JobRequest, deadlineMs: Long): Json {
        executions++
        lastDeadlineMs = deadlineMs
        started.countDown()
        if (blockUntilReleased) release.await(30, TimeUnit.SECONDS)
        return behaviour(request, deadlineMs)
    }

    override fun cancelActive() {
        cancelled = true
        release.countDown()
    }

    override fun onSessionCleared() = Unit

    fun unblock() = release.countDown()
}

/**
 * A gateway that records how often it ran and is held open until it is released
 * or cancelled. Used for the queue-bound and per-caller-cancellation tests.
 */
class GateGateway : BrowserGateway {
    @Volatile
    override var readiness: Readiness = Readiness.READY

    val started = CountDownLatch(1)
    val release = CountDownLatch(1)

    @Volatile
    var cancelled: Boolean = false

    @Volatile
    var executions: Int = 0

    override suspend fun execute(request: JobRequest, deadlineMs: Long): Json {
        executions++
        started.countDown()
        release.await(30, TimeUnit.SECONDS)
        return jsonObject("echo" to request.operation.wireName)
    }

    override fun cancelActive() {
        cancelled = true
        release.countDown()
    }

    override fun onSessionCleared() = Unit

    /** Lets the in-flight operation return immediately. */
    fun unblock() = release.countDown()
}

/** A gateway that never returns until it is released or cancelled. */
class BlockingGateway : BrowserGateway {

    @Volatile
    override var readiness: Readiness = Readiness.LOADING

    val started = CountDownLatch(1)
    val release = CountDownLatch(1)

    @Volatile
    var cancelled: Boolean = false

    @Volatile
    var executions: Int = 0

    override suspend fun execute(request: JobRequest, deadlineMs: Long): Json {
        executions++
        started.countDown()
        release.await(30, TimeUnit.SECONDS)
        return jsonObject("echo" to request.operation.wireName)
    }

    override fun cancelActive() {
        cancelled = true
        release.countDown()
    }

    override fun onSessionCleared() = Unit
}

// ---- Holding a connection open on purpose ------------------------------------

/**
 * Connects, sends a request head that stops one line short of the blank line,
 * and then goes completely silent. The socket is returned open: the caller owns
 * it and must close it.
 *
 * This is the cheapest denial of service available against a loopback HTTP
 * server, and it needs no credential: the workers block while reading the head,
 * *before* the Authorization header is ever looked at. Anything the server does
 * not bound here is time and a thread that a real request needs.
 */
fun openPartialHeadAndGoSilent(port: Int, socket: Socket? = null): Socket {
    val peer = socket ?: Socket("127.0.0.1", port)
    peer.tcpNoDelay = true
    peer.soTimeout = 30_000
    val partial = "GET /v1/health HTTP/1.1\r\nHost: 127.0.0.1:$port\r\n"
    peer.getOutputStream().write(partial.toByteArray(Charsets.ISO_8859_1))
    peer.getOutputStream().flush()
    return peer
}

/** Closes every socket in the list, ignoring failures. Used from `@After`. */
fun closeAll(sockets: Iterable<Socket>) {
    for (socket in sockets) {
        try {
            socket.close()
        } catch (_: IOException) {
            // Already gone; nothing to do.
        }
    }
}

/** The outcome of one bounded attempt to reach the server. */
sealed class Probe {
    /** The server answered with a real reply. */
    data class Answered(val reply: Reply) : Probe()

    /** The connection was closed without a status line (instant refusal). */
    data class Refused(val detail: String) : Probe()

    /** No reply, and no closure, within the budget. */
    data class TimedOut(val waitedMs: Long) : Probe()

    override fun toString(): String = when (this) {
        is Answered -> "Answered(${reply.status})"
        is Refused -> "Refused($detail)"
        is TimedOut -> "TimedOut(after ${waitedMs}ms)"
    }
}

/**
 * Issues one authenticated request on its own thread and gives up after
 * [budgetMs].
 *
 * [send] reads to end-of-stream and so has no way to say "the server never
 * answered" - a hung server would simply hang the test until Gradle's timeout.
 * The DoS tests need exactly that distinction, so the request runs on a private
 * daemon thread behind a future.
 */
fun probeGet(
    port: Int,
    path: String,
    key: String? = TEST_KEY,
    budgetMs: Long = 2_000L,
): Probe {
    val runner = Executors.newSingleThreadExecutor { task ->
        Thread(task, "api-probe").apply { isDaemon = true }
    }
    try {
        val pending = runner.submit<Reply> { get(port, path, key) }
        return try {
            Probe.Answered(pending.get(budgetMs, TimeUnit.MILLISECONDS))
        } catch (timedOut: TimeoutException) {
            pending.cancel(true)
            Probe.TimedOut(budgetMs)
        } catch (failed: ExecutionException) {
            // `send` throws IllegalArgumentException when the peer closed the
            // connection without a status line: that is an instant refusal, not
            // a slow answer, and the tests must be able to tell them apart.
            Probe.Refused(failed.cause?.javaClass?.simpleName ?: "unknown")
        }
    } finally {
        runner.shutdownNow()
    }
}

/**
 * Waits until the server hangs up on [socket], or until [ceilingMs] passes.
 *
 * Anything the server sends on the way (a 408, for instance) is read and
 * discarded: what matters is the closure.
 */
fun awaitHangUp(socket: Socket, ceilingMs: Long): Boolean {
    val deadline = System.nanoTime() + ceilingMs * 1_000_000L
    val buffer = ByteArray(256)
    while (System.nanoTime() < deadline) {
        socket.soTimeout = 50
        val count = try {
            socket.getInputStream().read(buffer)
        } catch (_: SocketTimeoutException) {
            continue
        } catch (_: IOException) {
            return true
        }
        if (count < 0) return true
    }
    return false
}

/**
 * Reads exactly one reply off a keep-alive connection and leaves the socket
 * open for the next one.
 *
 * Unlike [send] this cannot read to end-of-stream, because the server is not
 * going to close: the reply is framed by its own `Content-Length`.
 */
fun readReply(socket: Socket): Reply {
    val raw = ByteArrayOutputStream()
    val buffer = ByteArray(1024)
    var split = -1
    var head = ""
    while (split < 0) {
        val count = socket.getInputStream().read(buffer)
        if (count < 0) throw AssertionError("connection closed before a complete response head")
        raw.write(buffer, 0, count)
        val text = String(raw.toByteArray(), Charsets.UTF_8)
        split = text.indexOf("\r\n\r\n")
        head = text
    }
    val length = head.substring(0, split).split("\r\n")
        .firstOrNull { it.startsWith("Content-Length:", ignoreCase = true) }
        ?.substringAfter(':')?.trim()?.toIntOrNull() ?: 0
    while (head.length - split - 4 < length) {
        val count = socket.getInputStream().read(buffer)
        if (count < 0) break
        raw.write(buffer, 0, count)
        head = String(raw.toByteArray(), Charsets.UTF_8)
    }
    return parseReply(head.substring(0, split), head.substring(split + 4, split + 4 + length))
}

// ---- A minimal HTTP client over a real loopback socket ------------------------

/** One parsed HTTP reply. */
class Reply(val status: Int, val headers: Map<String, String>, val body: String) {
    val json: Json? get() = body.takeIf { it.isNotBlank() }?.let { Json.parse(it) }
    fun state(): String? = json?.str("state")
    fun code(): String? = json?.obj("error")?.str("code")
}

/**
 * Writes one request onto a fresh loopback connection and reads the whole reply.
 *
 * `Connection: close` is sent so the reply is terminated and the socket can be
 * read to EOF without parsing Content-Length; the one test that is about
 * keep-alive uses [sendOnConnection] instead.
 */
fun send(
    port: Int,
    lines: List<String>,
    body: String? = null,
    key: String? = TEST_KEY,
): Reply {
    Socket("127.0.0.1", port).use { socket ->
        socket.tcpNoDelay = true
        socket.soTimeout = 15_000
        val head = StringBuilder()
        for (line in lines) head.append(line).append("\r\n")
        if (key != null) head.append("Authorization: Bearer ").append(key).append("\r\n")
        head.append("Connection: close\r\n\r\n")

        val out = ByteArrayOutputStream()
        out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
        if (body != null) out.write(body.toByteArray(Charsets.UTF_8))
        socket.getOutputStream().write(out.toByteArray())
        socket.getOutputStream().flush()

        val text = String(socket.getInputStream().readBytes(), Charsets.UTF_8)
        val split = text.indexOf("\r\n\r\n")
        require(split >= 0) { "connection closed without a response" }
        return parseReply(text.substring(0, split), text.substring(split + 4))
    }
}

internal fun parseReply(headerText: String, body: String): Reply {
    val headerLines = headerText.split("\r\n")
    val status = headerLines[0].split(" ")[1].toInt()
    val headers = headerLines.drop(1).mapNotNull {
        val index = it.indexOf(':')
        if (index <= 0) null else it.substring(0, index).lowercase() to it.substring(index + 1).trim()
    }.toMap()
    return Reply(status, headers, body)
}

fun post(port: Int, body: String, key: String? = TEST_KEY): Reply = send(
    port,
    listOf(
        "POST /v1/jobs HTTP/1.1",
        "Host: 127.0.0.1:$port",
        "Content-Type: application/json",
        "Content-Length: ${body.toByteArray().size}",
    ),
    body,
    key,
)

fun get(port: Int, path: String, key: String? = TEST_KEY): Reply =
    send(port, listOf("GET $path HTTP/1.1", "Host: 127.0.0.1:$port"), null, key)

fun delete(port: Int, path: String, key: String? = TEST_KEY): Reply =
    send(port, listOf("DELETE $path HTTP/1.1", "Host: 127.0.0.1:$port"), null, key)

/** Polls `GET /v1/jobs/{id}` until it reaches one of [wanted], or gives up. */
fun awaitJob(port: Int, jobId: String, wanted: Set<String>): String? {
    var last: String? = null
    awaitUntil("job $jobId to reach $wanted") {
        last = get(port, "/v1/jobs/$jobId").state()
        last != null && last in wanted
    }
    return last
}