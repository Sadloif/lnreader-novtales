package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.*
import org.junit.Assert.*
import org.junit.Test

class ReviewPaginationTest {
    private fun index(total: Int, page: Int): Json {
        val numbers = (total downTo 1).drop((page - 1) * 50).take(50)
        return jsonObject("chapters" to Json.Arr(numbers.map { jsonObject("number" to it, "title" to "Chapter $it") }),
            "page" to page, "pageSize" to 50, "total" to total, "totalPages" to ChapterPaging.totalPages(total, 50))
    }

    @Test fun `large novel index returns every chapter once with at most two site pages per reader page`() {
        for (total in listOf(1, 50, 51, 101, 4037)) {
            val received = ArrayList<Int>()
            for (page in 1..ChapterPaging.totalPages(total, 50)) {
                val range = NovTalesExtraction.indexPages(total, page, 50)
                assertTrue(range.count() <= 2)
                val result = NovTalesExtraction.chapterWindow(range.map { index(total, it) }, "/novel/test", total, page, 50)
                received.addAll(result.arr("chapters")!!.items.map { it.num("chapterNumber")!!.toInt() })
                assertEquals(total, result.int("chapterCount"))
            }
            assertEquals((1..total).toList(), received)
            val empty = NovTalesExtraction.chapterWindow(emptyList(), "/novel/test", total, 100000, 50)
            assertTrue(empty.arr("chapters")!!.items.isEmpty())
        }
    }

    @Test fun `incomplete or changing API index fails instead of hiding chapters`() {
        val first = index(101, 1) as Json.Obj
        val incomplete = Json.Obj(first.fields + ("chapters" to Json.Arr(emptyList())))
        for (body in listOf(incomplete, first)) {
            try {
                NovTalesExtraction.validateIndexPage(body, 1, 50, 100)
                fail("Incomplete or changing lists must fail")
            } catch (expected: CompanionException) { assertEquals(ErrorCode.SITE_CHANGED, expected.code) }
        }
    }

    @Test fun `catalogue pages end and searches match aliases without repeating rows`() {
        val cards = Json.Arr((1..55).map { jsonObject("slug" to "novel-$it", "title" to "Novel $it",
            "published" to true, "altNames" to Json.arrOf(listOf("Alias $it"))) })
        val all = (1..3).flatMap { NovTalesExtraction.catalogue(cards, it, null).arr("items")!!.items }
        assertEquals(55, all.size)
        assertEquals(55, all.map { it.str("path") }.distinct().size)
        assertTrue(NovTalesExtraction.catalogue(cards, 4, null).arr("items")!!.items.isEmpty())
        assertEquals(false, NovTalesExtraction.catalogue(cards, 3, null).bool("hasNext"))
        assertEquals(1, NovTalesExtraction.catalogue(cards, 1, null, "Alias 55").arr("items")!!.items.size)
        assertTrue(NovTalesExtraction.catalogue(cards, 1, null, "not present").arr("items")!!.items.isEmpty())
    }
}
