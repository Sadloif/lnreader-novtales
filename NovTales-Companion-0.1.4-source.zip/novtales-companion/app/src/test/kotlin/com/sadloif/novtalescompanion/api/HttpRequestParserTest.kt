package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Config
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream

/** Feeds a raw request head to the parser and returns the HTTP status it must be told. */
private fun statusOf(raw: String): Int = try {
    HttpRequestParser.parseHead(ByteArrayInputStream(raw.toByteArray(Charsets.ISO_8859_1)))
    200
} catch (failure: HttpParseException) {
    failure.status
}

/** Parses a raw request head, or null when the peer closed cleanly. */
private fun parse(raw: String): ParsedRequest? =
    HttpRequestParser.parseHead(ByteArrayInputStream(raw.toByteArray(Charsets.ISO_8859_1)))

/**
 * Request-head parser tests.
 *
 * Promoted from `_working/compilecheck/test/SmokeTest.kt`, where these were
 * exercised over a real socket; running them directly against
 * [HttpRequestParser] additionally pins the *status* each rejection must produce,
 * which is what the socket version could only observe indirectly.
 *
 * Pure JVM: the parser imports nothing from `android.*`, by design.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class HttpRequestParserTest {

    // =========================================================================
    // The request line
    // =========================================================================

    class RequestLine {

        @Test
        fun `a well formed request line parses`() {
            val request = parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!
            assertEquals("GET", request.method)
            assertEquals("/v1/health", request.path)
            assertEquals("HTTP/1.1", request.version)
            assertEquals(HttpMethod.GET, request.httpMethod)
        }

        @Test
        fun `the query string is kept raw and never decoded`() {
            val request = parse("GET /v1/jobs?a=%2Fb HTTP/1.1\r\nHost: h\r\n\r\n")!!
            assertEquals("/v1/jobs", request.path)
            assertEquals("a=%2Fb", request.query)
        }

        @Test
        fun `a request with no query reports a null query`() {
            assertNull(parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!.query)
        }

        @Test
        fun `an empty stream is a clean end of connection and not an error`() {
            assertNull(parse(""))
        }

        @Test
        fun `a line with no version is refused`() {
            assertEquals(400, statusOf("GET /v1/health\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `a method outside the allowlist parses but has no httpMethod`() {
            // The parser does not decide the 405; the router does. What matters
            // here is that the raw token survives for the router to refuse.
            val request = parse("PUT /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!
            assertEquals("PUT", request.method)
            assertNull(request.httpMethod)
        }

        @Test
        fun `a lowercase method is not on the allowlist`() {
            // Exact, case-sensitive match: `get` is not `GET`.
            assertNull(parse("get /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!.httpMethod)
        }

        @Test
        fun `only four methods are ever routable`() {
            assertEquals(
                listOf("GET", "POST", "DELETE", "OPTIONS"),
                HttpMethod.entries.map { it.token },
            )
        }
    }

    // =========================================================================
    // Target forms: everything that smells like a proxy is refused
    // =========================================================================

    class TargetForms {

        @Test
        fun `an absolute-form target is refused`() {
            // `GET http://example.com/x` is the first half of a proxy. There is
            // no forwarding code anywhere in this server.
            assertEquals(400, statusOf("GET http://example.com/x HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `an https absolute-form target is refused`() {
            assertEquals(400, statusOf("GET https://example.com/x HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `an authority-form target is refused`() {
            // authority-form is what CONNECT sends.
            assertEquals(400, statusOf("CONNECT 127.0.0.1:5301 HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `an asterisk-form target is refused`() {
            assertEquals(400, statusOf("OPTIONS * HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `CONNECT with an origin-form target is refused by the router not the parser`() {
            // It parses; the 405 comes from the method allowlist. The socket test
            // pins the wire behaviour; this pins that the parser does not special
            // case the verb.
            assertEquals("CONNECT", parse("CONNECT /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!.method)
        }

        @Test
        fun `a percent-encoded target is refused`() {
            // Nothing in this API needs escaping; an encoded target is either a
            // mistake or a double-decoding trick.
            assertEquals(400, statusOf("GET /v1/jobs/%2e%2e HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `a dot segment in the target is refused`() {
            assertEquals(400, statusOf("GET /v1/../admin HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `a double slash in the target is refused`() {
            assertEquals(400, statusOf("GET /v1//health HTTP/1.1\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `an empty target is refused`() {
            assertEquals(400, statusOf("GET  HTTP/1.1\r\nHost: h\r\n\r\n"))
        }
    }

    // =========================================================================
    // Headers: the smuggling surface
    // =========================================================================

    class Headers {

        @Test
        fun `Transfer-Encoding is refused outright`() {
            // This server has no chunked decoder, and a request framed two ways
            // is the raw material of every request-smuggling bug.
            assertEquals(
                400,
                statusOf("POST /v1/jobs HTTP/1.1\r\nHost: h\r\nTransfer-Encoding: chunked\r\n\r\n"),
            )
        }

        @Test
        fun `a duplicated Content-Length is refused`() {
            assertEquals(
                400,
                statusOf(
                    "POST /v1/jobs HTTP/1.1\r\nHost: h\r\nContent-Length: 1\r\nContent-Length: 1\r\n\r\n{}",
                ),
            )
        }

        @Test
        fun `a disagreeing pair of Content-Length headers is also refused`() {
            assertEquals(
                400,
                statusOf(
                    "POST /v1/jobs HTTP/1.1\r\nHost: h\r\nContent-Length: 1\r\nContent-Length: 99\r\n\r\n{}",
                ),
            )
        }

        @Test
        fun `any duplicated header is refused because none is legitimately repeatable`() {
            assertEquals(
                400,
                statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nAccept: a\r\nAccept: b\r\n\r\n"),
            )
        }

        @Test
        fun `obsolete line folding is refused`() {
            // A folded header has two readings depending on who parses it.
            assertEquals(
                400,
                statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nX-Long: one\r\n two\r\n\r\n"),
            )
        }

        @Test
        fun `a header with no colon is refused`() {
            assertEquals(400, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nnonsense\r\n\r\n"))
        }

        @Test
        fun `a header name with an illegal character is refused`() {
            assertEquals(400, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nX(Bad): 1\r\n\r\n"))
        }

        @Test
        fun `a header value carrying a control character is refused`() {
            assertEquals(400, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nX-Bad: a\u0001b\r\n\r\n"))
        }

        @Test
        fun `header lookup is case insensitive`() {
            val request = parse("GET /v1/health HTTP/1.1\r\nHOST: h\r\nX-Custom: v\r\n\r\n")!!
            assertEquals("h", request.header("Host"))
            assertTrue(request.hasHeader("x-custom"))
            assertNull(request.header("x-absent"))
        }

        @Test
        fun `too many header lines is 431`() {
            val many = (1..HttpRequestParser.MAX_HEADER_LINES + 5)
                .joinToString("") { "X-Pad-$it: v\r\n" }
            assertEquals(431, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\n$many\r\n"))
        }

        @Test
        fun `an over long header line is 431 rather than a truncated read`() {
            val padding = "a".repeat(HttpRequestParser.MAX_LINE_BYTES + 100)
            assertEquals(431, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\nX-Big: $padding\r\n\r\n"))
        }

        @Test
        fun `the whole header budget is bounded`() {
            // Individually short lines that together exceed the budget.
            val many = (1..80).joinToString("") { "X-Pad-$it: ${"v".repeat(300)}\r\n" }
            assertEquals(431, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\n$many\r\n"))
        }
    }

    // =========================================================================
    // Version, length and Host
    // =========================================================================

    class Framing {

        @Test
        fun `HTTP 2 is 505`() {
            assertEquals(505, statusOf("GET /v1/health HTTP/2.0\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `HTTP one point zero is accepted`() {
            assertEquals(200, statusOf("GET /v1/health HTTP/1.0\r\nHost: h\r\n\r\n"))
        }

        @Test
        fun `HTTP one point one without a Host header is 400`() {
            assertEquals(400, statusOf("GET /v1/health HTTP/1.1\r\n\r\n"))
        }

        @Test
        fun `HTTP one point zero without a Host header is accepted`() {
            assertEquals(200, statusOf("GET /v1/health HTTP/1.0\r\n\r\n"))
        }

        @Test
        fun `a body larger than the ceiling is 413`() {
            assertEquals(
                413,
                statusOf(
                    "POST /v1/jobs HTTP/1.1\r\nHost: h\r\n" +
                        "Content-Length: ${Config.MAX_REQUEST_BODY_BYTES + 1}\r\n\r\n",
                ),
            )
        }

        @Test
        fun `a body exactly at the ceiling is accepted`() {
            assertEquals(
                200,
                statusOf(
                    "POST /v1/jobs HTTP/1.1\r\nHost: h\r\n" +
                        "Content-Length: ${Config.MAX_REQUEST_BODY_BYTES}\r\n\r\n",
                ),
            )
        }

        @Test
        fun `a non numeric Content-Length is refused`() {
            assertEquals(
                400,
                statusOf("POST /v1/jobs HTTP/1.1\r\nHost: h\r\nContent-Length: abc\r\n\r\n"),
            )
        }

        @Test
        fun `an over long Content-Length is refused rather than parsed`() {
            assertEquals(
                400,
                statusOf(
                    "POST /v1/jobs HTTP/1.1\r\nHost: h\r\nContent-Length: 123456789012345\r\n\r\n",
                ),
            )
        }

        @Test
        fun `an absent Content-Length reads as zero and not as an error`() {
            assertEquals(0, parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!.contentLength)
        }

        @Test
        fun `Expect 100-continue is 417`() {
            // The client would block waiting for a 100 before sending a body;
            // refusing keeps the read path single-shot.
            assertEquals(
                417,
                statusOf("POST /v1/jobs HTTP/1.1\r\nHost: h\r\nExpect: 100-continue\r\nContent-Length: 2\r\n\r\n{}"),
            )
        }

        @Test
        fun `headers that end without a blank line are 400`() {
            assertEquals(400, statusOf("GET /v1/health HTTP/1.1\r\nHost: h\r\n"))
        }

        @Test
        fun `a line that ends mid-token is 400`() {
            assertEquals(400, statusOf("GET /v1/heal"))
        }

        @Test
        fun `contentLength distinguishes an absent header from a declared zero`() {
            val absent = parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!
            val declared = parse("POST /v1/jobs HTTP/1.1\r\nHost: h\r\nContent-Length: 0\r\n\r\n")!!
            assertEquals(0, absent.contentLength)
            assertEquals(0, declared.contentLength)
            assertTrue(declared.hasHeader("Content-Length"))
            assertFalse(absent.hasHeader("Content-Length"))
        }
    }

    // =========================================================================
    // Keep-alive and the diagnostic summary
    // =========================================================================

    class ConnectionReuse {

        @Test
        fun `HTTP one point one keeps the connection alive by default`() {
            assertTrue(parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!.keepAlive)
        }

        @Test
        fun `Connection close closes it`() {
            assertFalse(
                parse("GET /v1/health HTTP/1.1\r\nHost: h\r\nConnection: close\r\n\r\n")!!.keepAlive,
            )
        }

        @Test
        fun `HTTP one point zero closes unless keep-alive is asked for`() {
            assertFalse(parse("GET /v1/health HTTP/1.0\r\nHost: h\r\n\r\n")!!.keepAlive)
            assertTrue(
                parse("GET /v1/health HTTP/1.0\r\nHost: h\r\nConnection: keep-alive\r\n\r\n")!!.keepAlive,
            )
        }

        @Test
        fun `the diagnostic summary never carries a header value`() {
            val summary = parse("GET /v1/health HTTP/1.1\r\nHost: h\r\nAuthorization: Bearer secret\r\n\r\n")!!
                .safeSummary()
            assertFalse("must never include the key", summary.contains("secret"))
            assertFalse("must never include a header", summary.contains("Bearer"))
            assertEquals("GET /v1/health", summary)
        }

        @Test
        fun `the diagnostic summary keeps the raw path with the query stripped`() {
            assertEquals(
                "GET /v1/jobs",
                parse("GET /v1/jobs?secret=1 HTTP/1.1\r\nHost: h\r\n\r\n")!!.safeSummary(),
            )
        }

        @Test
        fun `header accounting is reported`() {
            val request = parse("GET /v1/health HTTP/1.1\r\nHost: h\r\n\r\n")!!
            assertTrue(request.headerBytes > 0)
            assertEquals(2, request.headerLines)
        }

        @Test
        fun `a parse failure carries the status the client must be told`() {
            val failure = runCatching {
                HttpRequestParser.parseHead(
                    ByteArrayInputStream("GET /x HTTP/9.9\r\nHost: h\r\n\r\n".toByteArray()),
                )
            }.exceptionOrNull()

            assertTrue("expected a parse failure", failure is HttpParseException)
            assertEquals(505, (failure as HttpParseException).status)
            assertEquals("Only HTTP/1.0 and HTTP/1.1 are supported.", failure.message)
        }
    }
}