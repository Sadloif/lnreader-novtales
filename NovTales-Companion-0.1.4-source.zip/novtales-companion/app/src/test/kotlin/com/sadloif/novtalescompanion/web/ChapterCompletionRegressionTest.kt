package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/**
 * Regression tests for the chapter-level failures that `ChapterCompletion` is
 * the last line of defence against.
 *
 * `HtmlSanitiserRegressionTest` pins the sanitiser-side fixes; this file pins what
 * the *whole* rule now does with the exact inputs from the red-team report, so
 * that the "all three rules passed" line cannot be reached by a body with nothing
 * in it, and cannot be silently disabled by a marker casing the adapter and the
 * app disagree about.
 *
 * Pure JVM: `ChapterCompletion` has no `android.*` import.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */

// ---------------------------------------------------------------------------
// Fixtures. File top level and private on purpose: JUnit 4's Enclosed runner
// makes every static nested class a suite in its own right, and a nested class
// cannot see its outer class's members - so helpers cannot live in the outer
// class body.
// ---------------------------------------------------------------------------

private const val REQUESTED: String = "/chapter/myslug-10"
private const val PATH: String = "/chapter/myslug-10"


private fun state(
    bodyHtml: String,
    endMarker: String,
    chapterNumber: String = "10",
    stillLoading: Boolean = false,
) = jsonObject(
    "path" to PATH,
    "chapterNumber" to chapterNumber,
    "bodyHtml" to bodyHtml,
    "endMarker" to endMarker,
    "stillLoading" to stillLoading,
)

/**
 * The state `__novChapterState(false)` returns: every signal except the body.
 *
 * `bodyHtml` is the **empty string**, not an absent key - that is what the adapter
 * actually sends (`bodyHtml: wantBody ? body.innerHTML : ''`), and the cheap poll
 * is the state the chapter loop decides on.
 */
private fun cheapState(
    endMarker: String,
    bodyLength: Int = 4096,
    chapterNumber: String = "10",
    stillLoading: Boolean = false,
    path: String = PATH,
) = jsonObject(
    "version" to "1",
    "url" to "https://novtales.com$path",
    "path" to path,
    "chapterNumber" to chapterNumber,
    "heading" to "Chapter $chapterNumber: A Title",
    "bodyHtml" to "",
    "bodyLength" to bodyLength,
    "paragraphCount" to 24,
    "endMarker" to endMarker,
    "endMarkerNumber" to chapterNumber,
    "signInRequired" to false,
    "membershipRequired" to false,
    "verificationRequired" to false,
    "rateLimited" to false,
    "stillLoading" to stillLoading,
    "hasLoadMore" to false,
    "documentTitle" to "Chapter $chapterNumber - NovTales",
)

/**
 * The same page read again with `__novChapterState(true)`: identical, plus the
 * body. This is the one expensive read the loop spends when the marker appears.
 */
private fun fullState(
    bodyHtml: String,
    endMarker: String,
    chapterNumber: String = "10",
    stillLoading: Boolean = false,
    path: String = PATH,
) = jsonObject(
    "version" to "1",
    "url" to "https://novtales.com$path",
    "path" to path,
    "chapterNumber" to chapterNumber,
    "heading" to "Chapter $chapterNumber: A Title",
    "bodyHtml" to bodyHtml,
    "bodyLength" to bodyHtml.length,
    "paragraphCount" to 24,
    "endMarker" to endMarker,
    "endMarkerNumber" to chapterNumber,
    "signInRequired" to false,
    "membershipRequired" to false,
    "verificationRequired" to false,
    "rateLimited" to false,
    "stillLoading" to stillLoading,
    "hasLoadMore" to false,
    "documentTitle" to "Chapter $chapterNumber - NovTales",
)

/** Exactly the string `evaluateJavascript` hands to `PageAdapter.decode`. */
private fun bridge(envelope: Json): String = Json.parse(envelope.write()).write()

/** The marker every fixture below hides somewhere the sanitiser deletes. */
private const val MARKER: String = "End of Chapter 10"

/** What `findEndMarker` returns when it finds nothing: the empty string. */
private const val NO_MARKER: String = ""

private const val PREVIEW_SENTENCE: String = "Only a preview sentence."

/**
 * One page per way the sanitiser deletes a subtree, with the marker inside it.
 *
 * `PreviewBodiesNeverComplete` used to carry a list of seven labels that never
 * reached the input, so these are the same seven names with the HTML attached -
 * the marker really is in each fixture, and each container really is one the
 * sanitiser is expected to take with it.
 *
 * `visibility:hidden` is here as well. It is the sibling of `display:none` that
 * both `HtmlSanitiser.isHidden` and the adapter's `discardsSubtree` treat
 * identically, and it is the fourth of the four; leaving it out would have made
 * the loop seven long on a rule with eight members.
 */
private val MARKER_INSIDE_A_DROPPED_SUBTREE: List<Pair<String, String>> = listOf(
    "a <script>" to
        """<p>$PREVIEW_SENTENCE</p><script>var e = "End of Chapter 10";</script>""",
    "a <style>" to
        """<p>$PREVIEW_SENTENCE</p><style>/* End of Chapter 10 */</style>""",
    "a <template>" to
        """<p>$PREVIEW_SENTENCE</p><template>End of Chapter 10</template>""",
    "a <noscript>" to
        """<p>$PREVIEW_SENTENCE</p><noscript>End of Chapter 10</noscript>""",
    "an aria-hidden container" to
        """<p>$PREVIEW_SENTENCE</p><div aria-hidden="true"><p>End of Chapter 10</p></div>""",
    "a hidden container" to
        """<p>$PREVIEW_SENTENCE</p><div hidden><p>End of Chapter 10</p></div>""",
    "a display:none container" to
        """<p>$PREVIEW_SENTENCE</p><div style="display:none"><p>End of Chapter 10</p></div>""",
    "a visibility:hidden container" to
        """<p>$PREVIEW_SENTENCE</p><div style="visibility:hidden"><p>End of Chapter 10</p></div>""",
    "a no-break space inside the style attribute" to
        """<p>$PREVIEW_SENTENCE</p><div style="display : none"><p>End of Chapter 10</p></div>""",
)

// ---------------------------------------------------------------------------
// The cross-language marker pin. See `MarkerPatternAgreement`.
// ---------------------------------------------------------------------------

/** Where the two sources live, relative to the module root. */
private val ADAPTER_ASSET = arrayOf(
    "app", "src", "main", "assets", "adapter", "novtales-adapter.js",
)
private val COMPLETION_SOURCE = arrayOf(
    "app", "src", "main", "kotlin", "com", "sadloif", "novtalescompanion", "web",
    "ChapterCompletion.kt",
)

/**
 * Walks up from the working directory until the file is found, exactly as
 * `HtmlSanitiserMirrorTest` does. Failing to find it is a test failure, never a
 * silent pass - a pin that compares two empty strings is worse than no pin.
 */
private fun repoFile(relative: Array<String>): String? {
    var dir: java.io.File? = java.io.File(System.getProperty("user.dir") ?: ".").absoluteFile
    repeat(10) {
        val candidate = java.io.File(dir, relative.joinToString(java.io.File.separator))
        if (candidate.isFile) return candidate.readText()
        dir = dir?.parentFile
    }
    return null
}

private val adapterSource: String? by lazy { repoFile(ADAPTER_ASSET) }
private val kotlinSource: String? by lazy { repoFile(COMPLETION_SOURCE) }

/** The adapter's `END_MARKER_COMPLETE`, read out of the shipped asset. */
private fun adapterMarkerPatternFrom(text: String): Regex? {
    val at = text.indexOf("END_MARKER_COMPLETE")
    if (at < 0) return null
    if (text.substring(0, at).trimEnd().endsWith(";")) return null
    val open = text.indexOf('/', at)
    if (open < 0) return null
    val close = text.indexOf('/', open + 1)
    if (close < 0) return null
    val flags = Regex("^[gimsuy]*").find(text.substring(close + 1))?.value ?: ""
    val body = text.substring(open + 1, close)
    // Java has no `(?i)`-free way to take the flag, and no ECMAScript-only
    // construct is present here, so the translation is exact. The check below
    // proves the two engines agree on the pattern rather than assuming it.
    return Regex((if (flags.contains('i')) "(?i)" else "") + body)
}

private fun adapterMarkerPattern(): Regex? =
    adapterSource?.let { adapterMarkerPatternFrom(it) }

/** `ChapterCompletion.END_MARKER`, read out of the Kotlin source. */
private fun kotlinMarkerPatternFrom(text: String): Regex? {
    val declaration = Regex("""val\s+END_MARKER\b""").find(text) ?: return null
    val open = text.indexOf('"', declaration.range.last)
    if (open < 0) return null
    val body = StringBuilder()
    var i = open + 1
    while (i < text.length && text[i] != '"') {
        if (text[i] == '\\') {
            body.append(text[i + 1])
            i += 2
            continue
        }
        body.append(text[i])
        i++
    }
    if (i >= text.length) return null
    return Regex(body.toString())
}

private fun kotlinMarkerPattern(): Regex? =
    kotlinSource?.let { kotlinMarkerPatternFrom(it) }

/**
 * The adapter's whitespace class, read out of the shipped asset.
 *
 * `ANY_SPACE` is a `new RegExp('...' + '...', 'g')`, so the literal has to be
 * concatenated and unescaped before it can be used - which is what makes this
 * a read of the file rather than a copy of it. The two literal `.replace()`
 * calls in the adapter's own `norm` are ASCII and are applied here as well; the
 * character class is the part that could drift, and that is the part that is
 * read.
 */
private fun adapterSpaceFrom(text: String): Regex? {
    val at = text.indexOf("ANY_SPACE")
    if (at < 0) return null
    val open = text.indexOf("new RegExp(", at)
    if (open < 0 || open - at > "ANY_SPACE = ".length + 8) return null
    val close = text.indexOf(')', open)
    if (close < 0) return null
    // Everything before the flags argument. `new RegExp('...' + '...', 'g')` -
    // the `'g'` is quoted too, so cutting at the first comma is what keeps it
    // out of the pattern. Leaving it in produced a class followed by a literal
    // `g`, i.e. a normaliser that silently matched almost nothing: it replaced
    // a run of spaces only when a `g` happened to follow it, and the Unicode
    // space cases all failed with no obvious cause.
    val args = text.substring(open + "new RegExp(".length, close)
    val patternText = args.substringBefore(',')
    val literal = Regex("'([^']*)'").findAll(patternText)
        .joinToString("") { it.groupValues[1] }
    if (literal.isEmpty()) return null
    val resolved = StringBuilder()
    var i = 0
    while (i < literal.length) {
        if (literal[i] == '\\' && i + 1 < literal.length) {
            resolved.append(literal[i]).append(literal[i + 1])
            i += 2
            continue
        }
        resolved.append(literal[i])
        i++
    }
    val pattern = resolved.toString()
    // Only the opening bracket is checked. The declaration ends with `]+`, so
    // requiring a closing bracket at the very end would reject the real one and
    // silently fall back to a pattern that matches nothing - which is the same
    // failure as a pin that compares two empty strings.
    if (!pattern.startsWith("[")) return null
    return Regex(pattern)
}

private val ADAPTER_SPACE: Regex by lazy {
    adapterSpaceFrom(adapterSource ?: "") ?: Regex("(?!)")
}

/**
 * ChapterCompletion's own whitespace class, read out of its source the same way.
 *
 * Kept beside [ADAPTER_SPACE] so a reader can see the two at once: `[\s\p{Z}…]`
 * against an explicit list of code points, written by two different people for
 * the same rule.
 */
private val KOTLIN_SPACE: Regex by lazy {
    val text = kotlinSource ?: ""
    val at = text.indexOf("ANY_WHITESPACE")
    if (at < 0) return@lazy Regex("(?!)")
    val r = text.indexOf("Regex(", at)
    if (r < 0 || r - at > "ANY_WHITESPACE = ".length + 8) return@lazy Regex("(?!)")
    val open = text.indexOf('"', r)
    if (open < 0) return@lazy Regex("(?!)")
    val body = StringBuilder()
    var i = open + 1
    while (i < text.length && text[i] != '"') {
        if (text[i] == '\\') {
            body.append(text[i + 1])
            i += 2
            continue
        }
        body.append(text[i])
        i++
    }
    Regex(body.toString())
}

/** What the adapter's `norm` does, rebuilt from the class read out of the file. */
private fun normaliseAsTheAdapterWould(text: String): String =
    text.replace('\u00A0', ' ')
        .replace(Regex("[ \t\r\n]+"), " ")
        .replace(ADAPTER_SPACE, " ")
        .trim()

/**
 * The chapter number the adapter would report in `endMarkerNumber`.
 *
 * Not `END_MARKER_COMPLETE`: that pattern has **no capture group** on purpose -
 * it only decides yes or no. The adapter extracts the digits with a second,
 * inline pattern in `__novChapterState`:
 *
 *     var markerMatch = /end of chapter\s+(\d+(?:\.\d+)?)/i.exec(marker);
 *
 * so that is the one this reads, and it is a third declaration of "what a
 * marker is" in one file - which is exactly why it is pinned here rather than
 * assumed to agree with the other two.
 */
private fun adapterMarkerNumberFor(marker: String): String? =
    adapterNumberPattern()?.matchEntire(normaliseAsTheAdapterWould(marker))?.groupValues?.get(1)

/** The adapter's inline `endMarkerNumber` extraction, read out of the file. */
private fun adapterNumberPattern(): Regex? {
    val text = adapterSource ?: return null
    val at = text.indexOf("/end of chapter\\s+(\\d+(?:\\.\\d+)?)/i")
    if (at < 0) return null
    val close = text.indexOf("/i", at)
    if (close < 0) return null
    return Regex(text.substring(at + 1, close), RegexOption.IGNORE_CASE)
}

/** Java's `\s`, from the language specification: `[ \t\n\x0B\f\r]`. */
private val JAVA_SHORTHAND_SPACE = setOf(0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x20)

/**
 * The code points where ECMAScript's `\s` and Java's `\s` disagree, and which
 * both sides therefore have to fold to an ASCII space before matching.
 *
 * These eight are the ones the earlier audit found: ogham space mark, em space,
 * six-per-em space, thin space, hair space, narrow no-break space, medium
 * mathematical space and ideographic space. A marker written with one of them
 * between two words was found by the adapter, reported verbatim, and refused by
 * Kotlin - a visibly complete chapter failing `INCOMPLETE_CHAPTER` on every poll.
 */
private val UNICODE_SPACES: List<Int> = listOf(
    0x1680, 0x2003, 0x2006, 0x2009, 0x200A, 0x202F, 0x205F, 0x3000,
)

/**
 * The corpus both marker patterns must answer identically, as
 * `label to marker to must-be-accepted`.
 *
 * Every entry carries **digits**: a fixture with the number spelled as a word
 * proves nothing, because both patterns require `[0-9]+` and the whole window
 * would be the bare phrase. Every entry is for chapter 10 or 944.5, because
 * Kotlin additionally compares the number to the request and the adapter does
 * not - a marker for another chapter would disagree for a reason that has
 * nothing to do with the pattern.
 */
private val MARKER_CORPUS: List<Triple<String, String, Boolean>> = buildList {
    add(Triple("the site's own markup", "End of Chapter 10", true))
    add(Triple("lowercase", "end of chapter 10", true))
    add(Triple("uppercase", "END OF CHAPTER 10", true))
    add(Triple("mixed case", "End Of Chapter 10", true))
    add(Triple("shouted case", "eNd oF cHaPtEr 10", true))
    add(Triple("padded with spaces", "   End of Chapter 10   ", true))
    add(Triple("a decimal chapter number", "End of Chapter 944.5", true))
    add(Triple("leading zeros", "End of Chapter 010", true))
    add(Triple("a sixteen-digit number", "End of Chapter 9007199254740993", true))

    for (code in UNICODE_SPACES) {
        val label = "U+%04X".format(code)
        val marker = "End${code.toChar()}of${code.toChar()}Chapter 10"
        add(Triple("$label between every pair of words", marker, true))
        add(Triple("$label before the number", "End of Chapter${code.toChar()}10", true))
    }

    add(Triple("a chapter count after the number", "End of Chapter 1 of 3", false))
    add(Triple("a parenthetical after the number", "THE END OF CHAPTER 10 (FINAL)", false))
    add(Triple("the number spelled as a word", "End of Chapter ten", false))
    add(Triple("a mid-sentence mention", "She reached the end of chapter 10 and closed the book.", false))
    add(Triple("a sentence that opens with the phrase", "End of Chapter 10 was the night the gate opened.", false))
    add(Triple("the phrase with no number at all", "End of Chapter", false))
    add(Triple("a trailing full stop", "End of Chapter 10.", false))
    add(Triple("trailing prose in the same element", "End of Chapter 10 and that was that.", false))
}

/**
 * The request a corpus entry must be evaluated against, so the numbers match.
 *
 * Derived the way the adapter itself derives it - by running the adapter's own
 * `endMarkerNumber` extraction over the normalised marker - and **not** by
 * scraping every digit out of the string. Scraping concatenates across the
 * marker: "End of Chapter 1 of 3" became 13 and "End of Chapter 10." became
 * 10. , which is not a chapter path, and the fixture then failed in the
 * harness instead of at the assertion it exists for.
 *
 * Entries with no digits at all - "End of Chapter", "End of Chapter ten" - fall
 * back to chapter 10 for the same reason.
 */
private fun requestedNumberFor(marker: String): String =
    adapterMarkerNumberFor(marker) ?: "10"

private fun requestedPathFor(marker: String): String {
    val number = requestedNumberFor(marker)
    return if (number == "10") REQUESTED else "/chapter/myslug-$number"
}

/**
 * True when the two sides are *expected* to report the digits identically.
 *
 * Leading zeros are the one documented exception, and it is deliberate on the
 * Kotlin side: `End of Chapter 010` is chapter 10, and
 * `NovTalesExtraction.normaliseChapterNumber` folds the zero away before the
 * comparison with the request. The adapter, by contrast, reports the string
 * verbatim because it does not decide anything - it hands the marker over. So
 * the pair agree on *which chapter it is* and not on the spelling, and pinning
 * the spelling here would be pinning a difference rather than a rule. The
 * verbatim form is pinned on the adapter side, in `tools/js-tests/adapter.test.js`
 * section 9b.
 */
private fun numberIsSpelledTheSameOnBothSides(marker: String): Boolean =
    !requestedNumberFor(marker).startsWith("0")

@RunWith(Enclosed::class)
class ChapterCompletionRegressionTest {

    // =========================================================================
    // REGRESSION (critical): `<p>&nbsp;</p>` with a valid marker was `Complete`.
    //
    // Observed wire result:
    //   {"path":"/chapter/myslug-10","chapterNumber":"10","complete":true,
    //    "content":"<p>&#160;</p>"}
    // A chapter with no words in it, silently marked complete. This is the one
    // failure the whole product exists to prevent, so every shape of it is here.
    // =========================================================================

    class EmptyBodiesCannotComplete {

        @Test
        fun `an nbsp paragraph with a valid marker is not complete`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>&nbsp;</p>", "End of Chapter 10"),
                settled = true,
            )

            assertFalse("a body with no prose must never be complete", verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.NO_TEXT_AFTER_SANITISING,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `the decimal and hexadecimal entity forms are not complete either`() {
            for (body in listOf(
                "<p>&#160;</p>",
                "<p>&#xA0;</p>",
                "<p>&nbsp;&nbsp;</p>",
                "<p>&nbsp;</p><p> </p>",
                "<p>&nbsp;</p><p>&#160;</p>",
            )) {
                val verdict = ChapterCompletion.evaluate(REQUESTED, state(body, "End of Chapter 10"))
                assertFalse(
                    "$body must not be complete",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
                assertEquals(
                    "$body must report NO_TEXT_AFTER_SANITISING",
                    ChapterCompletion.Reason.NO_TEXT_AFTER_SANITISING,
                    (verdict as ChapterCompletion.Verdict.NotReady).reason,
                )
            }
        }

        @Test
        fun `two hundred nbsp paragraphs are not complete`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>&nbsp;</p>".repeat(200), "End of Chapter 10"),
                settled = true,
            )

            assertFalse(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.NO_TEXT_AFTER_SANITISING,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        /** The same body while the page is still delivering is StillLoading, not Complete. */
        @Test
        fun `an nbsp body mid-delivery reports StillLoading rather than completing`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>&nbsp;</p>", "End of Chapter 10", stillLoading = true),
            )

            assertEquals(ChapterCompletion.Verdict.StillLoading, verdict)
        }

        /** The gate must not be so tight that real prose stops completing. */
        @Test
        fun `a real chapter with padded paragraphs still completes`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state(
                    "<p>&nbsp;The caravan left at dawn.</p><p>End of Chapter 10</p>",
                    "End of Chapter 10",
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertTrue(
                (verdict as ChapterCompletion.Verdict.Complete).html,
                verdict.html.contains("The caravan left at dawn."),
            )
        }
    }

    // =========================================================================
    // REGRESSION (critical): a marker the sanitiser deletes completed the chapter.
    //
    // `findEndMarker` walked every text node of the article, while the sanitiser
    // deletes <script>, <style>, <template>, <noscript>, `hidden`, `aria-hidden`
    // and `display:none` with their subtrees. A preview whose only marker was
    // inside one of those stored a one-sentence preview with `complete: true`.
    //
    // The adapter half is fixed and pinned in `tools/js-tests/adapter.test.js`
    // (sections 6 and 7). What is pinned here is the Kotlin half of the same
    // invariant: with no marker in the delivered view, a body of real prose is a
    // preview, never a chapter.
    // =========================================================================

    class PreviewBodiesNeverComplete {

        private val preview = "<p>Only a preview sentence.</p>"

        @Test
        fun `a one sentence preview with no marker is not complete`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state(preview, ""),
                settled = true,
            )

            assertFalse(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        /**
         * The Kotlin half of "a marker the sanitiser deletes cannot complete the
         * chapter", with a **real fixture per case**.
         *
         * The version this replaces looped over seven labels and evaluated the
         * same `state(preview, "")` seven times; the label reached the failure
         * message and nothing else, so no `<script>`, no `hidden`, no
         * `display:none` was ever built. Seven iterations of the test above it
         * with a nicer message is not seven tests.
         *
         * Each case below is the HTML the site really serves, marker and all, and
         * each is checked three ways:
         *
         *  1. the fixture **carries** the marker, so the case is not vacuous -
         *     a fixture with no marker in it proves nothing about deleting one;
         *  2. [HtmlSanitiser.sanitise] really removes that container *and its
         *     text*, which is the production behaviour the whole rule rests on
         *     and the thing this test now actually exercises;
         *  3. the verdict for the body that survives is the preview case.
         *
         * What cannot be expressed in Kotlin state, and is not pretended at
         * here: the adapter's decision to report `endMarker: ""`. This side never
         * sees the DOM - it sees a string. The decision that a marker inside a
         * `<script>` is not a marker at all is `discardsSubtree`, and it is
         * pinned against the real shipped file in
         * `tools/js-tests/adapter.test.js` (sections 6, 13 and 14) and against
         * `HtmlSanitiser.kt` in `HtmlSanitiserMirrorTest`. What this file can
         * honestly say is that the body the adapter would deliver carries no
         * marker anywhere in it, and that such a body is a preview.
         */
        @Test
        fun `a preview whose marker lived in a deleted subtree does not complete`() {
            for ((label, served) in MARKER_INSIDE_A_DROPPED_SUBTREE) {
                // 1. Guard the fixture, not the code. Without this a case whose
                //    container stops being dropped still "passes" for the wrong
                //    reason, and a case that never held a marker never could.
                assertTrue(
                    "$label: the fixture must carry a marker for the case to mean anything",
                    served.contains(MARKER),
                )

                // 2. The production behaviour: that container goes, and its text
                //    goes with it.
                val stored = HtmlSanitiser.sanitise(served)
                assertFalse(
                    "$label: the sanitiser must delete the subtree the marker was in",
                    stored.contains("End of Chapter"),
                )
                assertTrue(
                    "$label: the prose outside the deleted subtree must survive",
                    stored.contains(PREVIEW_SENTENCE),
                )

                // 3. So the delivered body is a preview with no marker in it.
                val verdict = ChapterCompletion.evaluate(
                    REQUESTED,
                    state(stored, NO_MARKER),
                    settled = true,
                )
                assertFalse(
                    "a marker only inside $label must not complete the chapter",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
                assertEquals(
                    "$label must be the preview case, not a stall",
                    ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                    (verdict as ChapterCompletion.Verdict.NotReady).reason,
                )
            }
        }

        /**
         * And if a marker ever does arrive alongside a body that holds nothing
         * but a preview, the length of the body is not what decides it - the body
         * must simply be real prose, which here it is, and the marker is what is
         * missing. This test exists to make the point that the sanitiser gate and
         * the marker gate are independent.
         */
        @Test
        fun `a preview body with a marker for a different chapter is a wrong chapter`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state(preview, "End of Chapter 9"),
                settled = true,
            )

            assertEquals(
                ErrorCode.WRONG_CHAPTER,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
        }
    }

    // =========================================================================
    // REGRESSION: the adapter and Kotlin disagreed about the marker's case.
    //
    // The adapter matched `/^end of chapter/i` and reported the text verbatim;
    // Kotlin's END_MARKER was case-sensitive. So `end of chapter 10` and
    // `END OF CHAPTER 10` were found by one half and rejected by the other, and
    // a visibly complete chapter failed `INCOMPLETE_CHAPTER` on every poll.
    // The case rule is now identical on both sides: case-insensitive.
    // =========================================================================

    class MarkerCasing {

        @Test
        fun `the marker is accepted in any case`() {
            for (marker in listOf(
                "End of Chapter 10",
                "end of chapter 10",
                "END OF CHAPTER 10",
                "End Of Chapter 10",
                "eNd oF cHaPtEr 10",
            )) {
                val verdict = ChapterCompletion.evaluate(
                    REQUESTED,
                    state("<p>Real prose here.</p>", marker),
                    settled = true,
                )
                assertTrue("$marker must complete, got $verdict", verdict is ChapterCompletion.Verdict.Complete)
                assertEquals(
                    marker,
                    "10",
                    (verdict as ChapterCompletion.Verdict.Complete).chapterNumber,
                )
            }
        }

        /**
         * Case-insensitivity must not loosen the match: `matchEntire` still
         * refuses anything with text around the number.
         */
        @Test
        fun `case-insensitivity does not make the match looser`() {
            for (marker in listOf(
                "end of chapter 1 of 3",
                "END OF CHAPTER 10 (FINAL)",
                "the end of chapter 10",
                "end of chapter ten",
                "end of chapter 10.",
            )) {
                val verdict = ChapterCompletion.evaluate(
                    REQUESTED,
                    state("<p>Real prose here.</p>", marker),
                    settled = true,
                )
                assertFalse(
                    "\"$marker\" is not an exact end marker",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
            }
        }

        @Test
        fun `a padded marker is accepted`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>Real prose here.</p>", "  End of Chapter 10  "),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        @Test
        fun `a non breaking space inside the marker is accepted`() {
            val verdict = ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>Real prose here.</p>", "End of\u00A0Chapter 10"),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        @Test
        fun `a decimal chapter number is still accepted in any case`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/some-novel-944.5",
                jsonObject(
                    "path" to "/chapter/some-novel-944.5",
                    "chapterNumber" to "944.5",
                    "bodyHtml" to "<p>Real prose here.</p>",
                    "endMarker" to "end of chapter 944.5",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals("944.5", (verdict as ChapterCompletion.Verdict.Complete).chapterNumber)
        }

        /**
         * DELETED, and replaced by `MarkerPatternAgreement` at the bottom of this
         * file.
         *
         * This was called "the adapter's own pattern and this one agree on the
         * same strings", and it built
         * `Regex("^end of chapter\\s+(\\d+(?:\\.\\d+)?)$", IGNORE_CASE)` in Kotlin
         * and checked it against three strings the same author had chosen. It
         * never opened `novtales-adapter.js`. Delete `END_MARKER_COMPLETE` from
         * the adapter, or change it to `/^fin\b/`, and this test was byte-for-byte
         * unaffected - while the two patterns had in fact been different for
         * months (`end\\s+of\\s+chapter` and `[0-9]` against a literal space and
         * `\d`, no capture group, and no leading `\\s*`). A Kotlin regex checking
         * itself is worse than no test: it claims "the two implementations agree"
         * without either implementation being present.
         *
         * The real check reads the adapter's declaration out of the real file,
         * from the other direction too, in `tools/js-tests/adapter.test.js`
         * section 13.
         */
    }

    // =========================================================================
    // REGRESSION (finding 2-02, safety): prose that merely *mentions* the
    // phrase was the end marker.
    //
    // The adapter searched the assembled article text with an unanchored
    // `/end\s+of\s+chapter/i` and cut to the number that followed, so any
    // sentence containing the words completed a truncated chapter. What is fixed
    // here is the adapter half (section 9 of tools/js-tests/adapter.test.js): the
    // marker must now be the entire text of one element, and that element must
    // not be run into prose in its own parent.
    //
    // The Kotlin half of the same rule is what these pin, and they pin it in the
    // shape the failure actually reached the reader in: a body with real prose,
    // a matching path, a matching number - and no marker. That is the preview
    // case, and it is the only thing it is allowed to be.
    // =========================================================================

    class ProseIsNeverAMarker {

        /** The exact body from the finding: real prose that contains the phrase. */
        private val truncated =
            "<p>She thought about the end of chapter 12, and then went to bed.</p>"

        /**
         * What the broken adapter reported for that body, pinned so the Kotlin
         * test below cannot quietly stop exercising it.
         */
        private val whatTheBrokenAdapterSaid = "end of chapter 12"

        @Test
        fun `the finding's own string is what the broken adapter produced`() {
            // Guard on the fixture, not the code: if this stops being true the
            // test below has stopped reproducing the finding.
            assertTrue(
                "the fixture must contain the phrase in the source's own casing",
                truncated.contains(whatTheBrokenAdapterSaid),
            )
            assertTrue(
                "and it must have digits in the window, or no number is ever cut",
                Regex("""end of chapter\s+\d""", RegexOption.IGNORE_CASE).containsMatchIn(truncated),
            )
        }

        /**
         * With the adapter fixed, the delivered marker is "", so this is the
         * preview case: real text, no marker, keep polling. Never Complete.
         */
        @Test
        fun `a truncated chapter whose prose mentions the phrase is a preview`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to truncated,
                    "endMarker" to "",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertFalse(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        /** `stillLoading` must not turn the same body into anything terminal. */
        @Test
        fun `and it is StillLoading while the page is still delivering`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to truncated,
                    "endMarker" to "",
                    "stillLoading" to true,
                ),
            )

            assertEquals(ChapterCompletion.Verdict.StillLoading, verdict)
            assertFalse(ChapterCompletion.isTerminal(verdict))
        }

        /**
         * Every confirmed trigger from the finding. These are the strings the
         * broken adapter trimmed to `End of Chapter 12`; with the fix the
         * adapter reports "" for all of them, and the Kotlin side sees a
         * preview.
         */
        @Test
        fun `every confirmed mention is refused, in every casing`() {
            for (body in listOf(
                "<p>She thought about the end of chapter 12, and then went to bed.</p>",
                "<p>End of Chapter 12 was the night the gate opened.</p>",
                "<p>Skipping ahead: the End Of Chapter 12 recap was wrong.</p>",
                "<p>Real prose.</p><strong>End of Chapter 12 recap</strong>",
                "<p>Real prose. She reached the end of chapter 12.</p>",
                "<ul><li>the end of chapter 12</li><li>and then some</li></ul>",
            )) {
                val verdict = ChapterCompletion.evaluate(
                    "/chapter/my-novel-12",
                    jsonObject(
                        "path" to "/chapter/my-novel-12",
                        "chapterNumber" to "12",
                        "bodyHtml" to body,
                        "endMarker" to "",
                        "stillLoading" to false,
                    ),
                    settled = true,
                )
                assertFalse(
                    "\"$body\" must not complete a chapter",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
                assertEquals(
                    "\"$body\" must be the preview case",
                    ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                    (verdict as ChapterCompletion.Verdict.NotReady).reason,
                )
            }
        }

        /**
         * The control: a real chapter, with the marker the site actually renders
         * - a dedicated element holding nothing else - still completes. Without
         * this, "find nothing ever" would pass every test above.
         */
        @Test
        fun `a real chapter with a dedicated marker still completes`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to "<p>The caravan left at dawn.</p>",
                    "endMarker" to "End of Chapter 12",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals("12", (verdict as ChapterCompletion.Verdict.Complete).chapterNumber)
        }
    }

    // =========================================================================
    // REGRESSION (finding 2-03, safety): a marker the sanitiser deletes
    // completed the chapter.
    //
    // `HtmlSanitiser` deletes a subtree for four mechanisms and the adapter
    // modelled two of them. Scene breaks and `data-security-canary` had no
    // model at all, so `<p>Real prose</p><p class="scene-break">End of Chapter
    // 12</p>` was stored as `<p>Real prose</p><hr>` with `complete: true` - the
    // marker that justified completion was not in the file that was saved.
    //
    // `HtmlSanitiserMirrorTest` proves the two halves have the same lists. What
    // is pinned here is the consequence, from the Kotlin side, including the
    // direction a lazy fix would get wrong.
    // =========================================================================

    class DiscardedSubtreesCannotCarryTheMarker {

        private val sceneBreakBody =
            "<p>Real prose</p><p class=\"scene-break\">End of Chapter 12</p>"

        private val canaryBody =
            "<p>Real prose</p><a data-security-canary=\"1\">End of Chapter 12</a>"

        @Test
        fun `the sanitiser really does delete the marker from the canary body`() {
            val stored = HtmlSanitiser.sanitise(canaryBody)

            assertEquals("<p>Real prose</p>", stored)
            assertFalse(
                "the marker is not in the stored chapter, so it cannot complete it",
                stored.contains("End of Chapter"),
            )
        }

        /**
         * The scene-break half of finding 2-03 is closed from the other end.
         *
         * It used to be stored as `<p>Real prose</p><hr>` - the marker gone -
         * because a scene break skipped its subtree. It no longer does: the
         * sanitiser only ever swallows a leaf of separator glyphs, so a
         * scene-break slot holding `End of Chapter 12` keeps it. The harm the
         * finding described - completing a chapter on a marker that is not in the
         * saved file - is now impossible from this direction.
         */
        @Test
        fun `a scene break can no longer swallow a marker`() {
            val stored = HtmlSanitiser.sanitise(sceneBreakBody)

            assertEquals("<p>Real prose</p><hr>End of Chapter 12", stored)
            assertTrue(
                "the marker is in the stored chapter, so counting it is correct",
                stored.contains("End of Chapter 12"),
            )
        }

        /**
         * What the page actually delivers for a canary: no marker, because the
         * only one on the page is in a deleted subtree. The verdict must be the
         * preview case, not a chapter.
         */
        @Test
        fun `a canary marker leaves a preview, not a chapter`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to canaryBody,
                    "endMarker" to "",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertFalse(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.PREVIEW_WITHOUT_MARKER,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        /**
         * And the mirror's other half: if a marker ever did arrive from a
         * canary slot, the sanitiser's own output is the proof that the rule and
         * the stored file disagree, which is what the adapter's `discardsSubtree`
         * exists to prevent.
         */
        @Test
        fun `a canary marker handed in anyway is still not in the stored chapter`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to canaryBody,
                    "endMarker" to "End of Chapter 12",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            // The adapter never reports this marker, so the state above is not
            // reachable in production. If it ever were, the chapter would
            // complete with the marker absent from the stored HTML - which is
            // exactly the harm. Asserted here so the shape is on the record.
            assertTrue(verdict is ChapterCompletion.Verdict.Complete)
            assertFalse(
                "and the stored chapter does not contain the marker that justified it",
                (verdict as ChapterCompletion.Verdict.Complete).html.contains("End of Chapter"),
            )
        }

        /**
         * The other direction. The sanitiser replaces a scene-break *container*
         * with `<hr>` and keeps its block content, so a marker inside one is in
         * the stored chapter and must still count. Deleting every scene break
         * would reject these and lose real downloads.
         */
        @Test
        fun `a scene-break container keeps its prose and its marker`() {
            val body =
                "<div class=\"scene-break\"><p>Real prose.</p><p>End of Chapter 12</p></div>"
            val verdict = ChapterCompletion.evaluate(
                "/chapter/my-novel-12",
                jsonObject(
                    "path" to "/chapter/my-novel-12",
                    "chapterNumber" to "12",
                    "bodyHtml" to body,
                    "endMarker" to "End of Chapter 12",
                    "stillLoading" to false,
                ),
                settled = true,
            )

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            val html = (verdict as ChapterCompletion.Verdict.Complete).html
            assertTrue("the prose must survive", html.contains("Real prose."))
            assertTrue("the marker must survive", html.contains("End of Chapter 12"))
        }

        /**
         * `data-scene-break` is matched on its **value**. An earlier
         * presence-only test deleted the content of `data-scene-break="false"`,
         * which is the exact inverse of what it says.
         */
        @Test
        fun `a scene break that says it is off is not a scene break`() {
            for (flag in listOf("false", "0", "no", "off", "none", "null", "undefined")) {
                val stored = HtmlSanitiser.sanitise(
                    "<p data-scene-break=\"$flag\">Real prose. End of Chapter 12</p>"
                )
                assertTrue(
                    "data-scene-break=\"$flag\" must keep its content, got $stored",
                    stored.contains("End of Chapter 12"),
                )
                assertFalse(
                    "data-scene-break=\"$flag\" is not a scene break, so no <hr>",
                    stored.contains("<hr"),
                )
            }
        }

        /** Tailwind spells its utilities `break-*`; those are ordinary prose. */
        @Test
        fun `a Tailwind break class is not a scene break`() {
            for (cls in listOf("break", "break-words", "text-break", "md:scene-break")) {
                assertTrue(
                    "class=\"$cls\" must not delete the prose",
                    HtmlSanitiser.sanitise("<p class=\"$cls\">Real prose.</p>").contains("Real prose."),
                )
            }
        }
    }

    // =========================================================================
    // REGRESSION (third time this pair drifted): the marker *pattern* must
    // accept the same strings on both sides.
    //
    // ECMAScript's `\s` is Unicode-aware and Java's is not. A marker written
    // with a thin space (U+2009) or an ideographic space (U+3000) between two
    // words was found by the adapter, reported verbatim, and then refused here -
    // a chapter that is visibly complete failing `INCOMPLETE_CHAPTER` on every
    // poll until the deadline. Both sides normalise the whole set now.
    // =========================================================================

    class MarkerWhitespaceParity {

        /**
         * Every code point ECMAScript's `\s` matches, plus U+0085 which both
         * sides normalise anyway, as `code point to name`.
         *
         * Written as code points rather than as the characters themselves: a raw
         * U+2028 or U+000B inside a source file is one encoding change away from
         * being read as something else, and this corpus has to keep meaning the
         * same thing in a year.
         */
        private val unicodeSpaces: List<Pair<Int, String>> = listOf(
            0x0009 to "U+0009 TAB",
            0x000A to "U+000A LF",
            0x000B to "U+000B VT",
            0x000C to "U+000C FF",
            0x000D to "U+000D CR",
            0x0020 to "U+0020 SPACE",
            0x0085 to "U+0085 NEXT LINE",
            0x00A0 to "U+00A0 NBSP",
            0x1680 to "U+1680 OGHAM SPACE MARK",
            0x2000 to "U+2000 EN QUAD",
            0x2003 to "U+2003 EM SPACE",
            0x2009 to "U+2009 THIN SPACE",
            0x200A to "U+200A HAIR SPACE",
            0x2028 to "U+2028 LINE SEPARATOR",
            0x2029 to "U+2029 PARAGRAPH SEPARATOR",
            0x202F to "U+202F NARROW NBSP",
            0x205F to "U+205F MEDIUM MATHEMATICAL SPACE",
            0x3000 to "U+3000 IDEOGRAPHIC SPACE",
            0xFEFF to "U+FEFF ZERO WIDTH NO-BREAK SPACE",
        )

        private fun sp(code: Int): String = code.toChar().toString()

        @Test
        fun `the corpus covers the whole ECMAScript whitespace set`() {
            // Guards the guard: a code point added to either side's class must
            // appear here, or this test stops proving parity.
            assertEquals(
                "the corpus must list every code point ECMAScript \\s matches, " +
                    "plus U+0085 which both sides normalise anyway",
                19,
                unicodeSpaces.size,
            )
            assertEquals(
                "the corpus must have no duplicates",
                unicodeSpaces.size,
                unicodeSpaces.map { it.first }.toSet().size,
            )
        }

        @Test
        fun `a marker separated by any of them is accepted`() {
            for ((code, label) in unicodeSpaces) {
                val s = sp(code)
                for (marker in listOf(
                    "End${s}of${s}Chapter${s}10",
                    "End${s}of${s}Chapter 10",
                    "  End${s}of${s}Chapter${s}10  ",
                )) {
                    val verdict = ChapterCompletion.evaluate(
                        REQUESTED,
                        state("<p>Real prose here.</p>", marker),
                        settled = true,
                    )
                    assertTrue(
                        "$label marker must complete, got $verdict",
                        verdict is ChapterCompletion.Verdict.Complete,
                    )
                }
            }
        }

        /**
         * Normalising whitespace must not loosen anything else. `matchEntire`
         * still pins the words, the digits and the nothing-else - which is what
         * stops `End of Chapter one` or `End of Chapter 1 of 3` from passing
         * just because its separators were normalised.
         */
        @Test
        fun `normalising whitespace did not loosen the marker`() {
            val thin = sp(0x2009)
            val wide = sp(0x3000)
            val nbsp = sp(0x00A0)
            for (marker in listOf(
                "End${thin}of${wide}chapter${nbsp}ten",
                "End${thin}of${wide}chapter${nbsp}1 of 3",
                "the end${thin}of${wide}chapter${nbsp}10",
                "END OF CHAPTER 10 (FINAL)",
                "End${thin}of${wide}chapter${nbsp}",
                "End${thin}of${wide}chapter${nbsp}10.5.1",
            )) {
                val verdict = ChapterCompletion.evaluate(
                    REQUESTED,
                    state("<p>Real prose here.</p>", marker),
                    settled = true,
                )
                assertFalse(
                    "\"$marker\" is not an exact end marker",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
            }
        }

        /**
         * The other half of parity: `END_MARKER` is the one place the two
         * implementations meet, and the corpus above already shows this side
         * accepts the normalised form. What it does not show is that the
         * **adapter's** expression accepts the same strings, because there is no
         * JS engine in the JVM test source set.
         *
         * So the adapter's expression is spelled out from its source and run
         * against the same corpus. If the two patterns stop agreeing, one side
         * stops accepting a marker the other reports - which is how a visibly
         * complete chapter ends up failing `INCOMPLETE_CHAPTER` on every poll.
         * `tools/js-tests/adapter.test.js` checks the same thing from the other
         * direction, against the real file.
         *
         * REPLACED. This compared against `adapterMarkerPattern()` below, which
         * **transcribed** the adapter's `END_MARKER_COMPLETE` into Kotlin. The
         * justification in the old comment - "the adapter is an asset and is not
         * on this JVM's classpath" - is true and irrelevant: the file is read as
         * text a few lines away, which is exactly what `HtmlSanitiserMirrorTest`
         * already does and what made the transcription unnecessary. A
         * transcription can drift and nothing notices; a read cannot. The
         * comparison now lives in `MarkerPatternAgreement`, where the pattern
         * comes out of `novtales-adapter.js`.
         */
        @Test
        fun `every whitespace code point is normalised before the marker is matched`() {
            for ((code, label) in unicodeSpaces) {
                val marker = "End${sp(code)}of${sp(code)}Chapter${sp(code)}10"
                assertTrue("$label: this side must accept the marker", acceptsMarker(marker))
                assertEquals(
                    "$label: normalisation must leave an ASCII string",
                    "End of Chapter 10",
                    KOTLIN_SPACE.replace(marker, " ").trim(),
                )
            }
        }

        /** True when this side accepts [marker] as the end marker for [REQUESTED]. */
        private fun acceptsMarker(marker: String): Boolean =
            ChapterCompletion.evaluate(
                REQUESTED,
                state("<p>Real prose here.</p>", marker),
                settled = true,
            ) is ChapterCompletion.Verdict.Complete
    }

    // =========================================================================
    // REGRESSION (third time this pair drifted): the two marker *patterns* must
    // accept and reject the same strings.
    //
    // `END_MARKER` in ChapterCompletion.kt and `END_MARKER_COMPLETE` in
    // novtales-adapter.js are two implementations of one rule. The only thing
    // that keeps them honest is a test that reads both declarations out of their
    // own files and makes them answer the same questions - so that is what this
    // is, and there is deliberately **no** hand-written copy of either pattern
    // anywhere in this file.
    //
    // Mirrored from the other direction in `tools/js-tests/adapter.test.js`
    // section 13, which reads ChapterCompletion.kt and compares it with the
    // adapter's. Two directions, because the JVM build and the Node suite can be
    // run independently and neither should be the only place the pin lives.
    //
    // Pure JVM. The two source files are found by walking up from the test's
    // working directory, so a missing source is a test failure and never a
    // silent skip.
    // =========================================================================

    class MarkerPatternAgreement {

        @Test
        fun `both marker declarations were read out of their own files`() {
            assertNotNull(
                "novtales-adapter.js not found from ${System.getProperty("user.dir")}",
                adapterSource,
            )
            assertNotNull("END_MARKER_COMPLETE not found in the adapter", adapterMarkerPattern())
            assertNotNull("END_MARKER not found in ChapterCompletion.kt", kotlinMarkerPattern())
            assertTrue("novtales-adapter.js is not the real one", adapterSource!!.contains("__novChapterState"))
            assertTrue("ChapterCompletion.kt is not the real one", kotlinSource!!.contains("fun evaluate("))
        }

        /**
         * The corpus, and what both sides must say about each entry.
         *
         * Restricted to the chapter that is actually requested, because Kotlin
         * additionally compares the marker's number against the request and the
         * adapter deliberately does not - it *finds* a marker, Kotlin *decides*.
         * A marker for a different chapter would disagree for a reason that has
         * nothing to do with the pattern, and this test must not produce false
         * reds.
         */
        @Test
        fun `both sides accept and reject the same strings`() {
            for ((label, marker, accepted) in MARKER_CORPUS) {
                val path = requestedPathFor(marker)
                val kotlinSays = ChapterCompletion.evaluate(
                    path,
                    jsonObject(
                        "path" to path,
                        "chapterNumber" to requestedNumberFor(marker),
                        "bodyHtml" to "<p>Real prose here.</p>",
                        "endMarker" to marker,
                        "stillLoading" to false,
                    ),
                    settled = true,
                ) is ChapterCompletion.Verdict.Complete

                val jsPattern = adapterMarkerPattern()!!
                val jsSays = jsPattern.matchEntire(normaliseAsTheAdapterWould(marker)) != null

                val verb = if (accepted) "accept" else "refuse"
                assertEquals("$label: ChapterCompletion must $verb \"$marker\"", accepted, kotlinSays)
                assertEquals(
                    "$label: the adapter's own pattern must $verb \"${normaliseAsTheAdapterWould(marker)}\"",
                    accepted,
                    jsSays,
                )
            }
        }

        /**
         * The two patterns must also read the same **number** out of a marker,
         * because that number is what Kotlin compares to the request and what
         * the adapter reports as `endMarkerNumber`. Two patterns that agreed on
         * accept and disagreed on the digits would still break every chapter.
         */
        @Test
        fun `both sides read the same chapter number out of the marker`() {
            var compared = 0
            var excluded = 0
            for ((label, marker, accepted) in MARKER_CORPUS) {
                if (!accepted) continue
                if (!numberIsSpelledTheSameOnBothSides(marker)) { excluded++; continue }
                compared++
                val number = requestedNumberFor(marker)
                val path = requestedPathFor(marker)

                val verdict = ChapterCompletion.evaluate(
                    path,
                    jsonObject(
                        "path" to path,
                        "chapterNumber" to requestedNumberFor(marker),
                        "bodyHtml" to "<p>Real prose here.</p>",
                        "endMarker" to marker,
                        "stillLoading" to false,
                    ),
                    settled = true,
                )
                assertTrue(
                    "$label: ChapterCompletion must complete \"$marker\", got $verdict",
                    verdict is ChapterCompletion.Verdict.Complete,
                )
                assertEquals(
                    "$label: ChapterCompletion reads the wrong number",
                    number,
                    (verdict as ChapterCompletion.Verdict.Complete).chapterNumber,
                )
                assertEquals(
                    "$label: the adapter's pattern reads the wrong number",
                    number,
                    adapterMarkerNumberFor(marker),
                )
            }
            // So the leading-zero exclusion above is an exclusion, not an
            // accident: the corpus still contains an entry it applies to, and
            // nearly every other entry is still compared. An exclusion that
            // silently covered everything would make this test decoration.
            assertTrue("no entry was compared at all", compared > 10)
            assertEquals(
                "the leading-zero exclusion must apply to exactly the entries that are leading-zero",
                1,
                excluded,
            )
        }

        /**
         * The whitespace classes are the harder half of parity, because `\s` means
         * different things on the two engines: Java's is `[ \t\n\x0B\f\r]` and
         * ECMAScript's covers the Unicode spaces as well. So each side folds them
         * to an ASCII space first, and both have to fold the *same* set. The
         * comparison is on the normalised string, so a class that lost a code
         * point shows up as a disagreement rather than as a shrug.
         */
        @Test
        fun `both sides normalise the same set of Unicode spaces`() {
            for (code in UNICODE_SPACES) {
                val marker = "End${code.toChar()}of${code.toChar()}Chapter 10"
                val label = "U+%04X".format(code)
                val normalised = "End of Chapter 10"

                assertEquals(
                    "$label: the adapter's normaliser left something the Kotlin one would not",
                    normalised,
                    normaliseAsTheAdapterWould(marker),
                )
                assertEquals(
                    "$label: ChapterCompletion must accept the raw form",
                    normalised,
                    KOTLIN_SPACE.replace(marker, " ").trim(),
                )
                assertTrue(
                    "$label must be a space on BOTH engines, or this corpus proves nothing: " +
                        "ECMAScript's \\s covers it, Java's does not, and folding it is the fix",
                    code !in JAVA_SHORTHAND_SPACE,
                )
                assertTrue(
                    "$label: the normalised string must be pure ASCII, or \\s means different " +
                        "things on the two engines and the comparison above is meaningless",
                    normalised.all { it.code < 128 },
                )
                assertTrue(
                    "$label: both patterns must accept the normalised form",
                    adapterMarkerPattern()!!.matchEntire(normalised) != null &&
                        kotlinMarkerPattern()!!.matchEntire(normalised) != null,
                )
            }
        }

        /**
         * The pin is only worth having if it can fail. Reading the pattern out of
         * a **perturbed** copy of the adapter proves the comparison is really
         * reading the file: change the declaration and the answers change with it.
         */
        @Test
        fun `a change to the adapter's real pattern changes what this test sees`() {
            val real = adapterMarkerPattern()!!
            assertTrue(
                "the real END_MARKER_COMPLETE must accept the site's own marker",
                real.matchEntire("End of Chapter 10") != null,
            )

            val perturbed = adapterMarkerPatternFrom(
                adapterSource!!.replace(
                    "END_MARKER_COMPLETE = /^end\\s+of\\s+chapter\\s+[0-9]+(?:\\.[0-9]+)?$/i",
                    "END_MARKER_COMPLETE = /^fin\\b/i",
                ),
            )
            assertNotNull("the perturbed declaration could not be read back", perturbed)
            assertNull(
                "a perturbed pattern must change the answer, or the extraction reads nothing",
                perturbed!!.matchEntire("End of Chapter 10"),
            )

            // And a rename is a failure, not an empty pattern that matches
            // everything or nothing.
            assertNull(adapterMarkerPatternFrom(adapterSource!!.replace("END_MARKER_COMPLETE", "SOMETHING_ELSE")))
            assertNull(kotlinMarkerPatternFrom("private val SOMETHING_ELSE = Regex(\"x\")"))
        }
    }


    // =========================================================================
    // REGRESSION: the cheap poll can never complete, and the loop knows that.
    //
    // `runChapter` polls `__novChapterState(false)`, which carries `endMarker`
    // but an **empty** `bodyHtml`. The re-read that attaches the body used to sit
    // inside the `Complete` branch of the `when` - a branch no cheap poll could
    // ever reach, because `evaluate` stops at the body rule (EMPTY_BODY) before it
    // looks at the marker. The result was a liveness failure, not a safety one:
    // a fully delivered chapter polled to the stall deadline and came back
    // INCOMPLETE_CHAPTER.
    //
    // The fix is that `runChapter` now reads `endMarker` off the **cheap** state
    // itself and spends the one expensive read on that signal. These tests pin the
    // two facts that fix rests on:
    //
    //   1. the cheap state really does carry `endMarker`, and survives the bridge;
    //   2. the cheap state can never produce `Complete`.
    //
    // Without (2) the loop would complete from a poll that never saw the text; with
    // the old code it could never complete at all. Both directions are checked.
    // =========================================================================

    class CheapPollCanNeverComplete {

        private val prose = "<p>The caravan left at dawn.</p><p>End of Chapter 10</p>"

        @Test
        fun `the cheap poll carries the end marker across the bridge`() {
            // evaluateJavascript hands `decode` a JSON **string** wrapping the
            // adapter's own JSON string. If `endMarker` did not survive that, the
            // gate in runChapter would never open and every chapter would fail.
            val page = PageAdapter(assets = { null })
            val decoded = page.decode(bridge(cheapState("End of Chapter 10")))

            assertEquals("End of Chapter 10", decoded.str("endMarker"))
            assertTrue("the cheap state must not ship the body", decoded.str("bodyHtml").isNullOrBlank())
            assertTrue(decoded.int("bodyLength")!! > 0)
        }

        @Test
        fun `a cheap poll with the marker present is still NotReady`() {
            val verdict = ChapterCompletion.evaluate(REQUESTED, cheapState("End of Chapter 10"), settled = true)

            assertFalse(
                "a cheap poll has no body, so it must never complete",
                verdict is ChapterCompletion.Verdict.Complete,
            )
            assertEquals(
                ChapterCompletion.Reason.EMPTY_BODY,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `a cheap poll is not terminal, so the loop keeps polling`() {
            // This is the whole point: `isTerminal` is what decides whether the
            // chapter loop gives up. A cheap poll must always be worth another
            // poll, however many of them have already happened.
            for (settled in listOf(false, true)) {
                assertFalse(
                    "a cheap poll is terminal at settled=$settled",
                    ChapterCompletion.isTerminal(
                        ChapterCompletion.evaluate(REQUESTED, cheapState("End of Chapter 10"), settled),
                    ),
                )
            }
        }

        @Test
        fun `a cheap poll mid delivery is StillLoading`() {
            assertEquals(
                ChapterCompletion.Verdict.StillLoading,
                ChapterCompletion.evaluate(
                    REQUESTED,
                    cheapState("End of Chapter 10", stillLoading = true),
                ),
            )
        }

        @Test
        fun `a cheap poll with no marker is NotReady too`() {
            // `runChapter` only spends the expensive read when the marker is
            // non-blank, so a blank marker must not be a reason to re-read - and it
            // must certainly not complete.
            val verdict = ChapterCompletion.evaluate(REQUESTED, cheapState(""), settled = true)

            assertFalse(verdict is ChapterCompletion.Verdict.Complete)
            assertFalse(ChapterCompletion.isTerminal(verdict))
        }

        @Test
        fun `a decimal marker on the cheap poll is NotReady, never Complete`() {
            val verdict = ChapterCompletion.evaluate(
                "/chapter/some-novel-944.5",
                cheapState(
                    "End of Chapter 944.5",
                    chapterNumber = "944.5",
                    path = "/chapter/some-novel-944.5",
                ),
                settled = true,
            )

            assertFalse(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        /**
         * The transition the loop makes, stated as a sequence: no number of cheap
         * polls ever completes, and the first poll that carries the body does.
         */
        @Test
        fun `only the poll that carries the body completes`() {
            val cheapVerdicts = (1..25).map {
                ChapterCompletion.evaluate(
                    REQUESTED,
                    cheapState("End of Chapter 10", bodyLength = 400 + it * 120),
                    settled = it > 8,
                )
            }
            assertTrue(
                "no cheap poll may complete",
                cheapVerdicts.none { it is ChapterCompletion.Verdict.Complete },
            )
            assertTrue(
                "no cheap poll may be terminal",
                cheapVerdicts.none { ChapterCompletion.isTerminal(it) },
            )

            val finalRead = ChapterCompletion.evaluate(
                REQUESTED,
                fullState(prose, "End of Chapter 10"),
                settled = true,
            )
            assertTrue(finalRead.toString(), finalRead is ChapterCompletion.Verdict.Complete)
            assertTrue((finalRead as ChapterCompletion.Verdict.Complete).html.contains("The caravan left at dawn."))
        }

        /**
         * What the old loop actually produced once it ran out of polls: an
         * INCOMPLETE_CHAPTER whose message blames the missing marker, when what was
         * actually missing was the body that the branch could never reach.
         */
        @Test
        fun `a cheap poll that is mistaken for final is reported as an empty body`() {
            val failure = ChapterCompletion.toException(
                ChapterCompletion.evaluate(REQUESTED, cheapState("End of Chapter 10"), settled = true)
                    as ChapterCompletion.Verdict.NotReady,
            )

            assertEquals(ErrorCode.INCOMPLETE_CHAPTER, failure.code)
            assertTrue(failure.message, failure.message.contains("End of Chapter"))
        }

        @Test
        fun `the same page with the body attached completes on the same poll shape`() {
            // The cheap and full reads differ in exactly one field. If that field
            // ever stopped being the body's, these two would drift and one of them
            // would be wrong - which is the bug this group exists to prevent.
            val cheap = cheapState("End of Chapter 10")
            val full = fullState(prose, "End of Chapter 10")
            val cheapKeys = (cheap as Json.Obj).fields.keys
            val fullKeys = (full as Json.Obj).fields.keys

            assertEquals(fullKeys, cheapKeys)
            assertTrue(cheap.str("bodyHtml").isNullOrBlank())
            assertTrue(!full.str("bodyHtml").isNullOrBlank())
        }
    }
}