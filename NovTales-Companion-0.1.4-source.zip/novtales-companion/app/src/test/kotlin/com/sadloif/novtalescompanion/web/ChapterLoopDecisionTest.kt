package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

// ---------------------------------------------------------------------------
// Fixtures. File top level and private on purpose: Enclosed makes every static
// nested class a suite in its own right, and a nested class cannot see its outer
// class's members.
// ---------------------------------------------------------------------------

private const val REQUESTED: String = "/chapter/myslug-10"
private const val PATH: String = "/chapter/myslug-10"

/** What `__novChapterState(false)` returns: everything except the body. */
private fun cheap(
    endMarker: String,
    bodyLength: Int = 4096,
    chapterNumber: String = "10",
    path: String = PATH,
    stillLoading: Boolean = false,
) = jsonObject(
    "version" to "1",
    "url" to "https://novtales.com$path",
    "path" to path,
    "chapterNumber" to chapterNumber,
    "heading" to "Chapter $chapterNumber: A Title",
    "bodyHtml" to "",
    "bodyLength" to bodyLength,
    "paragraphCount" to 24,
    "endMarker" to endMarker,
    "endMarkerNumber" to chapterNumber,
    "signInRequired" to false,
    "membershipRequired" to false,
    "verificationRequired" to false,
    "rateLimited" to false,
    "stillLoading" to stillLoading,
    "hasLoadMore" to false,
    "documentTitle" to "Chapter $chapterNumber - NovTales",
)

/** The same page read again with `__novChapterState(true)`. */
private fun full(bodyHtml: String, endMarker: String) = jsonObject(
    "version" to "1",
    "url" to "https://novtales.com$PATH",
    "path" to PATH,
    "chapterNumber" to "10",
    "heading" to "Chapter 10: A Title",
    "bodyHtml" to bodyHtml,
    "bodyLength" to bodyHtml.length,
    "paragraphCount" to 24,
    "endMarker" to endMarker,
    "endMarkerNumber" to "10",
    "signInRequired" to false,
    "membershipRequired" to false,
    "verificationRequired" to false,
    "rateLimited" to false,
    "stillLoading" to false,
    "hasLoadMore" to false,
    "documentTitle" to "Chapter 10 - NovTales",
)

/**
 * The chapter loop's per-poll decision, tested off-device.
 *
 * The loop itself is in `WebViewBrowserGateway` and cannot be unit-tested: it
 * needs a WebView and a Looper. Its *decision* - whether this poll needs the
 * expensive body read, and what the verdict is - was three inline lines that
 * no test executed. **Deleting them left every test in the suite green**,
 * including the ones written for the bug that lived in exactly those lines
 * (bug 16: the body re-read sat inside a `Complete` branch no cheap poll could
 * reach, so every chapter failed `INCOMPLETE_CHAPTER`). The tests for it
 * exercised `ChapterCompletion.evaluate`, which behaves identically either way.
 *
 * So the decision is now [ChapterCompletion.decideState] with the page read
 * behind a lambda, and this file exercises it the way the loop uses it.
 *
 * Pure JVM: no `android.*` import, no sleeps.
 */
@RunWith(Enclosed::class)
class ChapterLoopDecisionTest {

    // =========================================================================
    // 1. When the expensive read happens.
    // =========================================================================

    class WhenTheBodyIsRead {

        @Test
        fun `a cheap poll with no marker never reads the body`() = runTest {
            var reads = 0
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap(""),
                contradictions = 0,
            ) { includeBody ->
                reads++
                assertTrue("the body must only ever be read with includeBody=true", includeBody)
                full("<p>Never used.</p>", "")
            }

            assertEquals("the body must not have been read at all", 0, reads)
            assertFalse(verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                ChapterCompletion.Reason.EMPTY_BODY,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `a cheap poll with the marker reads the body exactly once`() = runTest {
            var reads = 0
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 10"),
                contradictions = 0,
            ) {
                reads++
                full("<p>The caravan left at dawn.</p>", "End of Chapter 10")
            }

            assertEquals("the body must be read once per poll, not more", 1, reads)
            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertEquals(
                "The caravan left at dawn.",
                (verdict as ChapterCompletion.Verdict.Complete).html
                    .replace("<p>", "").replace("</p>", ""),
            )
        }

        /**
         * The measurement from the review: nine full-body re-reads over a settle
         * window for a wrong-chapter marker, where `evaluate` never looks at the
         * body at all. The marker check comes before the body rule, so a marker
         * for another chapter is a contradiction on the cheap state alone.
         */
        @Test
        fun `a marker for another chapter never reads the body`() = runTest {
            var reads = 0
            for (settled in 0 until ChapterCompletion.SETTLE_POLLS) {
                val verdict = ChapterCompletion.decideState(
                    REQUESTED,
                    cheap("End of Chapter 9"),
                    contradictions = settled,
                ) {
                    reads++
                    full("<p>Never used.</p>", "End of Chapter 9")
                }
                assertEquals(
                    "poll $settled must be a contradiction",
                    ChapterCompletion.Reason.CONTRADICTORY_SO_FAR,
                    (verdict as ChapterCompletion.Verdict.NotReady).reason,
                )
            }
            assertEquals(
                "a wrong-chapter marker must cost zero body reads over a settle window",
                0,
                reads,
            )
        }

        /** ...and once settled, that is still a wrong chapter, not a hang. */
        @Test
        fun `a wrong-chapter marker still fails WRONG_CHAPTER when it settles`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 9"),
                contradictions = ChapterCompletion.SETTLE_POLLS,
            ) { full("<p>Never used.</p>", "End of Chapter 9") }

            assertEquals(
                ErrorCode.WRONG_CHAPTER,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
            assertTrue(ChapterCompletion.isTerminal(verdict))
        }

        /**
         * A marker the adapter cannot parse - `End of Chapter` with no number,
         * say - cannot be ruled out from the cheap state, so the body is read.
         * This is the case where being clever about it would lose a chapter.
         */
        @Test
        fun `a marker the strictness rules cannot judge is worth the read`() = runTest {
            var reads = 0
            ChapterCompletion.decideState(REQUESTED, cheap("End of Chapter ten"), 0) {
                reads++
                full("<p>Real prose.</p>", "End of Chapter ten")
            }
            assertEquals(1, reads)
        }

        @Test
        fun `a decimal marker for this chapter is still worth the read`() = runTest {
            var reads = 0
            ChapterCompletion.decideState(
                "/chapter/myslug-944.5",
                cheap("End of Chapter 944.5", chapterNumber = "944.5", path = "/chapter/myslug-944.5"),
                0,
            ) {
                reads++
                full("<p>Real prose.</p>", "End of Chapter 944.5")
            }
            assertEquals(1, reads)
        }

        @Test
        fun `worthTheBodyRead is the whole decision on its own`() {
            assertFalse("no marker", ChapterCompletion.worthTheBodyRead(REQUESTED, ""))
            assertFalse("blank marker", ChapterCompletion.worthTheBodyRead(REQUESTED, "   "))
            assertFalse("null marker", ChapterCompletion.worthTheBodyRead(REQUESTED, null))
            assertTrue("this chapter", ChapterCompletion.worthTheBodyRead(REQUESTED, "End of Chapter 10"))
            assertTrue("leading zeros", ChapterCompletion.worthTheBodyRead(REQUESTED, "End of Chapter 010"))
            assertTrue(
                "a decimal for this chapter",
                ChapterCompletion.worthTheBodyRead("/chapter/myslug-944.5", "End of Chapter 944.5"),
            )
            assertFalse("another chapter", ChapterCompletion.worthTheBodyRead(REQUESTED, "End of Chapter 9"))
            assertTrue(
                "a marker the strictness rules cannot judge",
                ChapterCompletion.worthTheBodyRead(REQUESTED, "End of Chapter"),
            )
        }
    }

    // =========================================================================
    // 2. What the loop does with the answer - the shape bug 16 broke.
    // =========================================================================

    class WhatTheLoopDoesWithIt {

        @Test
        fun `no number of cheap polls ever completes`() = runTest {
            val verdicts = (1..25).map {
                ChapterCompletion.decideState(
                    REQUESTED,
                    cheap("", bodyLength = 400 + it * 120),
                    contradictions = if (it > ChapterCompletion.SETTLE_POLLS) 99 else 0,
                ) { full("<p>Never used.</p>", "") }
            }
            assertTrue("no cheap poll may complete", verdicts.none { it is ChapterCompletion.Verdict.Complete })
            assertTrue(
                "and none may be terminal, or the loop gives up",
                verdicts.none { ChapterCompletion.isTerminal(it) },
            )
        }

        /** This is the regression: bug 16 made this assertion pass for the wrong
         *  reason, because the loop never reached the body. */
        @Test
        fun `the poll that carries the marker and the body completes`() = runTest {
            var reads = 0
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 10"),
                contradictions = 0,
            ) {
                reads++
                full("<p>The caravan left at dawn.</p><p>End of Chapter 10</p>", "End of Chapter 10")
            }

            assertEquals(1, reads)
            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
            assertTrue(ChapterCompletion.isTerminal(verdict))
        }

        @Test
        fun `a preview with a marker in it still does not complete`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 10"),
                contradictions = 0,
            ) { full("<p>Only a preview sentence.</p>", "End of Chapter 10") }

            // A real marker and real text: by the contract that *is* complete.
            // The preview case is the one with no marker, above.
            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }

        @Test
        fun `a preview body with no marker is the preview case, and is not terminal`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap(""),
                contradictions = ChapterCompletion.SETTLE_POLLS,
            ) { full("<p>Only a preview sentence.</p>", "") }

            assertFalse(verdict is ChapterCompletion.Verdict.Complete)
            assertFalse(ChapterCompletion.isTerminal(verdict))
            assertEquals(
                ChapterCompletion.Reason.EMPTY_BODY,
                (verdict as ChapterCompletion.Verdict.NotReady).reason,
            )
        }

        @Test
        fun `mid-delivery is StillLoading, and keeps the loop polling`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("", stillLoading = true),
                contradictions = 0,
            ) { full("<p>Never used.</p>", "") }

            assertEquals(ChapterCompletion.Verdict.StillLoading, verdict)
            assertFalse(ChapterCompletion.isTerminal(verdict))
        }

        /**
         * The cheap state crosses the bridge as a JSON **string** wrapping the
         * adapter's own JSON string. If `endMarker` did not survive that, the
         * gate would never open and every chapter would fail.
         */
        @Test
        fun `the marker survives the bridge round trip`() {
            val page = PageAdapter(assets = { null })
            val decoded = page.decode(Json.parse(cheap("End of Chapter 10").write()).write())

            assertEquals("End of Chapter 10", decoded.str("endMarker"))
            assertTrue(decoded.str("bodyHtml").isNullOrBlank())
        }
    }
    // =========================================================================
    // 3. A deliberate decision, recorded so it is not "fixed" by accident.
    //
    // The adapter takes the **first** qualifying marker element in document
    // order. That rule exists: a "previous chapter" teaser rendered *after* the
    // real marker used to win when the adapter kept the last match, and the
    // chapter failed WRONG_CHAPTER for ever.
    //
    // A nav placed *before* the body is the mirror image, and it still wins.
    // Three ways to "fix" it were considered and rejected:
    //
    //  - keep the **last** match instead: that re-breaks the case the rule
    //    exists for;
    //  - skip `nav`/`header`/`footer` when looking for the marker: the
    //    sanitiser keeps that text (`nav` is an unwrap tag), so skipping it
    //    makes the adapter *stricter* than the sanitiser - the same liveness
    //    trap as 2-05, where a complete chapter is refused for ever;
    //  - prefer the marker whose number matches the article heading: on a
    //    wrong-chapter page the heading matches the teaser too, so it decides
    //    nothing.
    //
    // So the behaviour stands, and what matters is that its **consequence** is
    // bounded: the worst case is a chapter that is *not stored* and reported as
    // WRONG_CHAPTER. It can never store the wrong chapter, because rule 2
    // compares the marker against the path that was requested.
    // =========================================================================

    class WhereTheMarkerWins {

        @Test
        fun `a previous-chapter marker first in the document is refused, not stored`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 9"),
                contradictions = ChapterCompletion.SETTLE_POLLS,
            ) { full("<p>Real prose.</p>", "End of Chapter 9") }

            assertEquals(
                "the worst case is a chapter that is not stored",
                ErrorCode.WRONG_CHAPTER,
                (verdict as ChapterCompletion.Verdict.Failed).code,
            )
            assertTrue(ChapterCompletion.isTerminal(verdict))
        }

        @Test
        fun `and it costs no body read, however long it settles`() = runTest {
            var reads = 0
            for (settled in 0 until ChapterCompletion.SETTLE_POLLS + 1) {
                ChapterCompletion.decideState(REQUESTED, cheap("End of Chapter 9"), settled) {
                    reads++
                    full("<p>Real prose.</p>", "End of Chapter 9")
                }
            }
            assertEquals(0, reads)
        }

        /** The marker for the chapter that was asked for still completes. */
        @Test
        fun `the right marker still completes`() = runTest {
            val verdict = ChapterCompletion.decideState(
                REQUESTED,
                cheap("End of Chapter 10"),
                contradictions = 0,
            ) { full("<p>Real prose.</p>", "End of Chapter 10") }

            assertTrue(verdict.toString(), verdict is ChapterCompletion.Verdict.Complete)
        }
    }
}

