package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.Paths
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/**
 * Payload extraction tests: the catalogue, the novel, the chapter index and the
 * Next.js flight scanner underneath all three.
 *
 * Promoted from `_working/verify/Verify.kt`. Pure JVM: `NovTalesExtraction` and
 * `NextFlight` carry no `android.*` import.
 *
 * The site shapes in `app/src/test/resources/fixtures/` are the verified live
 * ones recorded in the extraction KDoc; they are read from the test classpath so
 * a change to the shape is a one-line fixture edit rather than an edit buried in
 * a string literal.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class NovTalesExtractionTest {

    // =========================================================================
    // Catalogue
    // =========================================================================

    class Catalogue {

        private fun envelope(value: String): Json =
            jsonObject("ok" to true, "key" to "x", "source" to "next_f:novel", "value" to Json.parse(value))

        private fun cards() = envelope(
            javaClass.classLoader!!.getResourceAsStream("fixtures/catalogue-cards.json")
                .use { String(it.readBytes(), Charsets.UTF_8) },
        )

        @Test
        fun `both catalogue cards are found`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = null)
            assertEquals(2, (listing as Json.Obj).arr("items")!!.items.size)
        }

        @Test
        fun `a catalogue item carries a relative path a name and its cover`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = null) as Json.Obj
            val first = listing.arr("items")!!.items[0] as Json.Obj

            assertEquals("/novel/alpha", first.str("path"))
            assertEquals("Alpha", first.str("name"))
            assertEquals("https://cdn.novtales.com/a.jpg", first.str("cover"))
        }

        @Test
        fun `no catalogue item leaks an absolute path`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = null) as Json.Obj
            for (item in listing.arr("items")!!.items) {
                assertFalse(
                    (item as Json.Obj).str("path")!!.startsWith("http"),
                )
            }
        }

        @Test
        fun `the listing echoes the requested page`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 3, sort = null)
            assertEquals(3.0, (listing as Json.Obj).num("page"))
        }

        @Test
        fun `popular sorts by hearts descending`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = "popular") as Json.Obj
            val first = listing.arr("items")!!.items[0] as Json.Obj
            assertEquals("/novel/beta", first.str("path"))
        }

        @Test
        fun `latest sorts by added descending`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = "latest") as Json.Obj
            val first = listing.arr("items")!!.items[0] as Json.Obj
            assertEquals("/novel/beta", first.str("path"))
        }

        @Test
        fun `an unknown sort leaves the delivered order alone`() {
            val listing = NovTalesExtraction.catalogue(cards(), page = 1, sort = "nonsense") as Json.Obj
            val first = listing.arr("items")!!.items[0] as Json.Obj
            assertEquals("/novel/alpha", first.str("path"))
        }

        @Test
        fun `hasNext falls back to false when the payload states neither it nor a page size`() {
            val envelope = jsonObject(
                "ok" to true,
                "value" to Json.parse(
                    """[{"slug":"alpha","title":"Alpha","coverUrl":"https://cdn.novtales.com/a.jpg"},
                        {"slug":"beta","title":"Beta","coverUrl":"https://cdn.novtales.com/b.jpg"}]""",
                ),
            )
            val listing = NovTalesExtraction.catalogue(envelope, page = 1, sort = null)
            assertEquals(false, (listing as Json.Obj).bool("hasNext"))
        }

        @Test
        fun `hasNext uses the local page size for the full catalogue`() {
            val envelope = jsonObject(
                "ok" to true,
                "value" to Json.parse(
                    """{"pageSize":2,"items":[
                        {"slug":"alpha","title":"Alpha","coverUrl":"https://cdn.novtales.com/a.jpg"},
                        {"slug":"beta","title":"Beta","coverUrl":"https://cdn.novtales.com/b.jpg"}]}""",
                ),
            )
            val listing = NovTalesExtraction.catalogue(envelope, page = 1, sort = null)
            assertEquals(false, (listing as Json.Obj).bool("hasNext"))
        }

        @Test
        fun `hasNext is false on a short page`() {
            val envelope = jsonObject(
                "ok" to true,
                "value" to Json.parse(
                    """{"pageSize":20,"items":[
                        {"slug":"alpha","title":"Alpha","coverUrl":"https://cdn.novtales.com/a.jpg"},
                        {"slug":"beta","title":"Beta","coverUrl":"https://cdn.novtales.com/b.jpg"}]}""",
                ),
            )
            val listing = NovTalesExtraction.catalogue(envelope, page = 1, sort = null)
            assertEquals(false, (listing as Json.Obj).bool("hasNext"))
        }
    }

    // =========================================================================
    // Novel
    // =========================================================================

    class Novel {

        private fun novel(): Json.Obj {
            val payload = jsonObject(
                "ok" to true,
                "value" to Json.parse(
                    javaClass.classLoader!!.getResourceAsStream("fixtures/novel-payload.json")
                        .use { String(it.readBytes(), Charsets.UTF_8) },
                ),
            )
            return NovTalesExtraction.novel(payload, "/novel/surviving-the-game-as-a-barbarian")
                as Json.Obj
        }

        @Test
        fun `the name and the relative path are carried`() {
            val novel = novel()
            assertEquals("Surviving the Game as a Barbarian", novel.str("name"))
            assertEquals("/novel/surviving-the-game-as-a-barbarian", novel.str("path"))
        }

        @Test
        fun `genres are a comma separated string and never an array`() {
            // CONTRACTS.md section 3 types this as a string. An array here would
            // break the TypeScript client that renders it.
            val novel = novel()
            assertEquals("Action, Drama", novel.str("genres"))
            assertFalse(novel.has("genres") && novel.fields["genres"] is Json.Arr)
        }

        @Test
        fun `an uppercase HIATUS maps to OnHiatus`() {
            assertEquals("OnHiatus", novel().str("status"))
        }

        @Test
        fun `the rating is carried already out of five`() {
            assertEquals(4.42, novel().num("rating")!!, 0.0001)
        }

        @Test
        fun `totalPages comes from the payload`() {
            assertEquals(79, novel().int("totalPages"))
        }

        @Test
        fun `a relative cover is resolved against the site origin`() {
            assertEquals("https://novtales.com/covers/x.jpg", novel().str("cover"))
        }

        @Test
        fun `a synopsis containing braces and quotes survives`() {
            // A brace in the synopsis is exactly what breaks a naive scanner.
            assertEquals("A brace } and a { and a \" quote.", novel().str("summary"))
        }

        @Test
        fun `the chapter list is de-duplicated by path`() {
            // The payload deliberately lists chapter 1 twice.
            assertEquals(3, novel().arr("chapters")!!.items.size)
        }

        @Test
        fun `the chapter list is ascending oldest first`() {
            val numbers = novel().arr("chapters")!!.items
                .joinToString(",") { (it as Json.Obj).num("chapterNumber").toString() }
            assertEquals("1.0,2.0,944.5", numbers)
        }

        @Test
        fun `a status the adapter does not recognise becomes Unknown rather than a guess`() {
            val node = jsonObject("slug" to "a", "title" to "A", "status" to "SomeNewWord")
            assertEquals("Unknown", NovTalesExtraction.statusOf(node as Json.Obj))
        }

        @Test
        fun `the status mapping covers every documented branch`() {
            fun status(value: String): String =
                NovTalesExtraction.statusOf(jsonObject("status" to value) as Json.Obj)

            assertEquals("OnHiatus", status("HIATUS"))
            assertEquals("OnHiatus", status("on hold"))
            assertEquals("Cancelled", status("CANCELLED"))
            assertEquals("Completed", status("COMPLETED"))
            assertEquals("Ongoing", status("ONGOING"))
            assertEquals("Unknown", status(""))
        }
    }

    // =========================================================================
    // Chapters
    // =========================================================================

    class Chapters {

        private fun payload(): Json = jsonObject(
            "ok" to true,
            "value" to Json.parse(
                javaClass.classLoader!!.getResourceAsStream("fixtures/novel-payload.json")
                    .use { String(it.readBytes(), Charsets.UTF_8) },
            ),
        )

        private fun page(): Json = Json.parse(
            javaClass.classLoader!!.getResourceAsStream("fixtures/chapter-index-page.json")
                .use { String(it.readBytes(), Charsets.UTF_8) },
        )

        @Test
        fun `chapters from the payload are ascending`() {
            val result = NovTalesExtraction.chaptersFromPayload(
                payload(), "/novel/surviving-the-game-as-a-barbarian",
            ) as Json.Obj
            assertEquals(1.0, (result.arr("chapters")!!.items[0] as Json.Obj).num("chapterNumber"))
        }

        @Test
        fun `chapters from the payload keep their decimals`() {
            val result = NovTalesExtraction.chaptersFromPayload(
                payload(), "/novel/surviving-the-game-as-a-barbarian",
            ) as Json.Obj
            assertEquals(944.5, (result.arr("chapters")!!.items.last() as Json.Obj).num("chapterNumber"))
        }

        @Test
        fun `a chapter path is relative and built from the novel slug`() {
            val result = NovTalesExtraction.chaptersFromPayload(
                payload(), "/novel/surviving-the-game-as-a-barbarian",
            ) as Json.Obj
            val list = result.arr("chapters")!!.items
            assertEquals("/chapter/surviving-the-game-as-a-barbarian-1", (list[0] as Json.Obj).str("path"))
            for (item in list) {
                assertFalse((item as Json.Obj).str("path")!!.startsWith("http"))
            }
        }

        @Test
        fun `a release time the site gave is carried`() {
            val result = NovTalesExtraction.chaptersFromPayload(
                payload(), "/novel/surviving-the-game-as-a-barbarian",
            ) as Json.Obj
            assertEquals("2024-01-01", (result.arr("chapters")!!.items[0] as Json.Obj).str("releaseTime"))
        }

        @Test
        fun `merged API index pages come back ascending`() {
            val merged = NovTalesExtraction.chaptersFromApiPages(
                listOf(page()), "/novel/surviving-the-game-as-a-barbarian", exhausted = true,
            ) as Json.Obj
            val numbers = merged.arr("chapters")!!.items
                .joinToString(",") { (it as Json.Obj).num("chapterNumber").toString() }
            assertEquals("943.5,944.0,944.5", numbers)
        }

        @Test
        fun `an unexhausted chapter list is a timeout and not a short list`() {
            // Returning half a chapter index would silently truncate the novel in
            // the reader, so the contract is to fail instead.
            val failure = runCatching {
                NovTalesExtraction.chaptersFromApiPages(
                    listOf(page()), "/novel/surviving-the-game-as-a-barbarian", exhausted = false,
                )
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.TIMEOUT, (failure as CompanionException).code)
        }

        @Test
        fun `a chapter list with nothing usable fails as SITE_CHANGED`() {
            val failure = runCatching {
                NovTalesExtraction.chaptersFromApiPages(
                    listOf(Json.parse("""{"nope":1}""")),
                    "/novel/surviving-the-game-as-a-barbarian",
                    exhausted = true,
                )
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.SITE_CHANGED, (failure as CompanionException).code)
        }

        @Test
        fun `a payload with no chapter list fails as SITE_CHANGED rather than inventing one`() {
            val failure = runCatching {
                NovTalesExtraction.chaptersFromPayload(
                    jsonObject("ok" to true, "value" to Json.parse("""{"nothing":true}""")),
                    "/novel/surviving-the-game-as-a-barbarian",
                )
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.SITE_CHANGED, (failure as CompanionException).code)
        }

        @Test
        fun `chapterEntryCount counts the entries a page holds`() {
            assertEquals(3, NovTalesExtraction.chapterEntryCount(page()))
            assertEquals(0, NovTalesExtraction.chapterEntryCount(Json.parse("""{"nothing":true}""")))
        }
    }

    // =========================================================================
    // Chapter number normalisation
    // =========================================================================

    class Numbers {

        @Test
        fun `a trailing zero in the fraction is dropped`() {
            assertEquals("12.5", NovTalesExtraction.normaliseChapterNumber("12.50"))
        }

        @Test
        fun `a whole number written as a decimal collapses to the integer`() {
            assertEquals("12", NovTalesExtraction.normaliseChapterNumber("12.0"))
        }

        @Test
        fun `leading zeros are dropped`() {
            assertEquals("12", NovTalesExtraction.normaliseChapterNumber("012"))
        }

        @Test
        fun `a leading zero fraction survives`() {
            assertEquals("0.5", NovTalesExtraction.normaliseChapterNumber("0.5"))
        }

        @Test
        fun `a decimal chapter number is preserved verbatim`() {
            assertEquals("944.5", NovTalesExtraction.normaliseChapterNumber("944.5"))
        }

        @Test
        fun `anything that is not a plain number is rejected`() {
            assertNull(NovTalesExtraction.normaliseChapterNumber("abc"))
            assertNull(NovTalesExtraction.normaliseChapterNumber("12."))
            assertNull(NovTalesExtraction.normaliseChapterNumber(".5"))
            assertNull(NovTalesExtraction.normaliseChapterNumber("-1"))
            assertNull(NovTalesExtraction.normaliseChapterNumber("1e3"))
        }

        @Test
        fun `null and blank are rejected`() {
            assertNull(NovTalesExtraction.normaliseChapterNumber(null))
            assertNull(NovTalesExtraction.normaliseChapterNumber("   "))
        }

        @Test
        fun `surrounding whitespace and a non breaking space are trimmed`() {
            assertEquals("12.5", NovTalesExtraction.normaliseChapterNumber("  12.5 "))
            assertEquals("12.5", NovTalesExtraction.normaliseChapterNumber("\u00A012.5"))
        }
    }

    // =========================================================================
    // Path safety
    // =========================================================================

    class RelativePaths {

        @Test
        fun `an absolute off-site URL is rejected`() {
            assertNull(NovTalesExtraction.toRelativePath("https://evil.com/novel/x"))
        }

        @Test
        fun `traversal is rejected`() {
            assertNull(NovTalesExtraction.toRelativePath("/novel/../admin"))
            assertNull(NovTalesExtraction.toRelativePath("../novel/x"))
        }

        @Test
        fun `a site URL becomes relative`() {
            assertEquals("/novel/x", NovTalesExtraction.toRelativePath("https://novtales.com/novel/x"))
        }

        @Test
        fun `a path that is neither a novel nor a chapter is rejected`() {
            assertNull(NovTalesExtraction.toRelativePath("/admin/panel"))
            assertNull(NovTalesExtraction.toRelativePath("/"))
            assertNull(NovTalesExtraction.toRelativePath(""))
            assertNull(NovTalesExtraction.toRelativePath(null))
        }

        @Test
        fun `a relative image source is made absolute for display`() {
            assertEquals("https://novtales.com/c.jpg", NovTalesExtraction.toAbsoluteUrl("/c.jpg"))
            assertEquals("https://cdn.novtales.com/c.jpg", NovTalesExtraction.toAbsoluteUrl("//cdn.novtales.com/c.jpg"))
        }

        @Test
        fun `an absolute URL carrying a quote or a newline is refused`() {
            assertNull(NovTalesExtraction.toAbsoluteUrl("https://x/\"onerror=\"alert(1)"))
            assertNull(NovTalesExtraction.toAbsoluteUrl("https://x/a\nb.jpg"))
        }

        @Test
        fun `isSameChapter is what actually gates acceptance`() {
            // 12 and 12.0 are the same chapter; a different slug never is.
            assertTrue(Paths.isSameChapter("/chapter/a-b-12", "/chapter/a-b-12.0"))
            assertFalse(Paths.isSameChapter("/chapter/a-b-12", "/chapter/c-b-12"))
            assertFalse(Paths.isSameChapter("/chapter/a-b-12", "/chapter/a-b-12.5"))
        }
    }

    // =========================================================================
    // Reading a page that cannot be read
    // =========================================================================

    class FailureModes {

        private fun envelope(value: String): Json =
            jsonObject("ok" to true, "key" to "x", "source" to "next_f:novel", "value" to Json.parse(value))

        @Test
        fun `a catalogue the adapter cannot read fails loudly as SITE_CHANGED`() {
            val failure = runCatching {
                NovTalesExtraction.catalogue(envelope("""[{"foo":1}]"""), 1, null)
            }.exceptionOrNull()

            assertTrue("must not invent data", failure is CompanionException)
            assertEquals(ErrorCode.SITE_CHANGED, (failure as CompanionException).code)
        }

        @Test
        fun `an empty catalogue is also a failure rather than an empty list`() {
            val failure = runCatching {
                NovTalesExtraction.catalogue(envelope("[]"), 1, null)
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.SITE_CHANGED, (failure as CompanionException).code)
        }

        @Test
        fun `a novel payload the adapter cannot read fails as SITE_CHANGED`() {
            val failure = runCatching {
                NovTalesExtraction.novel(envelope("""{"foo":1}"""), "/novel/slug")
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.SITE_CHANGED, (failure as CompanionException).code)
        }

        @Test
        fun `a non novel path is a bad request`() {
            val failure = runCatching {
                NovTalesExtraction.novel(envelope("""{}"""), "/chapter/a-b-1")
            }.exceptionOrNull()

            assertTrue(failure is CompanionException)
            assertEquals(ErrorCode.BAD_REQUEST, (failure as CompanionException).code)
        }
    }

    // =========================================================================
    // The Next.js flight scanner
    // =========================================================================

    class NextFlightScanner {

        private val novelBody = """{"title":"T","slug":"a-b"}"""

        @Test
        fun `a balanced value is extracted past braces inside strings`() {
            // The `"}}}"` in the sibling field is the trap: a scanner that does
            // not track string literals ends the value one brace early.
            val flight = "7:[\"\$\",\"x\",null,{\"novel\":" + Json.parse(novelBody).write() +
                ",\"other\":{\"t\":\"}}}\"}}]\n"

            val balanced = NextFlight.extractBalancedValue(flight, "novel")

            assertTrue("balanced value was null", balanced != null)
            assertTrue("balanced value was $balanced", balanced!!.contains("\"slug\""))
        }

        @Test
        fun `an absent key yields null rather than a guess`() {
            assertNull(NextFlight.extractBalancedValue("""{"a":1}""", "novel"))
        }

        @Test
        fun `a truncated value yields null`() {
            assertNull(NextFlight.extractBalancedValue("""{"novel":{"a":1""", "novel"))
        }

        @Test
        fun `a scalar value is scanned without a brace counter`() {
            val end = NextFlight.scanBalanced("""12,rest""", 0)
            assertEquals(2, end)
        }

        @Test
        fun `scanBalanced rejects a start index past the end`() {
            assertEquals(-1, NextFlight.scanBalanced("abc", 9))
        }

        @Test
        fun `decoded inline push calls concatenate in document order`() {
            assertEquals(
                "a:1b:2",
                NextFlight.decodeInlineScripts(
                    listOf("self.__next_f.push([1,\"a:1\"]);self.__next_f.push([1,\"b:2\"]);"),
                ),
            )
        }

        @Test
        fun `escaped quotes survive decoding`() {
            assertEquals(
                "a\"b",
                NextFlight.decodeInlineScripts(listOf("self.__next_f.push([1,\"a\\\"b\"]);")),
            )
        }

        @Test
        fun `text that is not a push call contributes nothing`() {
            assertEquals("", NextFlight.decodeInlineScripts(listOf("console.log(1)")))
        }

        @Test
        fun `cross chunk references are resolved once`() {
            val flight = "5:[{\"title\":\"T\",\"slug\":\"a-b\"}]\n7:[\"\$L5\",\"next\"]\n"

            val root = NextFlight.rootOf(Json.Str(flight)) as Json.Arr

            assertEquals(2, root.items.size)
            val chunk = root.items[0] as Json.Arr
            assertEquals("a-b", (chunk.items[0] as Json.Obj).str("slug"))
            // `$L5` is replaced by the value of chunk 5, not left as the literal
            // reference. Chunk 5 is itself the array, so that is what lands here.
            val referenced = (root.items[1] as Json.Arr).items[0] as Json.Arr
            assertEquals("a-b", (referenced.items[0] as Json.Obj).str("slug"))
        }

        @Test
        fun `an ordinary string starting with a dollar is not a reference`() {
            // A chapter title may legitimately start with '$'; following it would
            // replace real prose with a different chunk.
            val text = "5:{\"t\":\"" + '$' + "99\"}"
            val forest = NextFlight.parseFlightText(text)

            assertEquals(1, forest.values.size)
            assertFalse(
                "there is no chunk 99, so nothing may be followed",
                forest.refs.containsKey("99"),
            )
            assertEquals("" + '$' + "99", (forest.values.single() as Json.Obj).str("t"))
        }
    }
}