package com.sadloif.novtalescompanion.web

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/**
 * HTML sanitiser tests.
 *
 * Promoted from the scratch harness in `_working/verify/Verify.kt`. Runs on a
 * plain JVM because `HtmlSanitiser` carries no `android.*` import, which is the
 * whole reason it was written as a hand-written scanner rather than on top of
 * Jsoup.
 *
 * Two of the regressions here were real bugs the harness found:
 *  - HTML entities were double-escaped (`&amp;` became `&amp;amp;`) because the
 *    entity regex carried a `^` anchor, which anchors to the start of the whole
 *    document rather than to the `startIndex` passed to `Regex.find`. See
 *    `TextAndEntities.entitiesSurvive...` below.
 *  - Nothing in this file; the chapter-preview bug lives in `ChapterCompletionTest`.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class HtmlSanitiserTest {

    // =========================================================================
    // Markup that must not survive
    // =========================================================================

    class UnsafeMarkup {

        @Test
        fun `script is removed together with its body`() {
            assertEquals(
                "<p>Hello</p>",
                HtmlSanitiser.sanitise("<script>alert(1)</script><p>Hello</p>"),
            )
        }

        @Test
        fun `iframe is removed`() {
            assertEquals(
                "<p>Hi</p>",
                HtmlSanitiser.sanitise("<iframe src=\"https://x\"></iframe><p>Hi</p>"),
            )
        }

        @Test
        fun `form input and button are removed`() {
            assertEquals(
                "<p>Kept</p>",
                HtmlSanitiser.sanitise(
                    "<form><input name=\"a\"><button>Go</button></form><p>Kept</p>",
                ),
            )
        }

        @Test
        fun `style element is removed`() {
            assertEquals(
                "<p>Kept</p>",
                HtmlSanitiser.sanitise("<style>p{color:red}</style><p>Kept</p>"),
            )
        }

        @Test
        fun `event handler attributes are dropped`() {
            // Both cases matter: the attribute name is lowercased before the
            // allow-list check, so `ONMOUSEOVER` must not slip through as chrome.
            assertEquals(
                "<p>Hi</p>",
                HtmlSanitiser.sanitise("<p onclick=\"evil()\" ONMOUSEOVER=\"x\">Hi</p>"),
            )
        }

        @Test
        fun `a javascript href is dropped but its text is kept`() {
            assertEquals("click", HtmlSanitiser.sanitise("<a href=\"javascript:alert(1)\">click</a>"))
        }

        @Test
        fun `a vbscript image source is dropped`() {
            assertEquals("", HtmlSanitiser.sanitise("<img src=\"vbscript:x.png\">"))
        }

        @Test
        fun `a data image source is dropped`() {
            assertEquals("", HtmlSanitiser.sanitise("<img src=\"data:image/png;base64,AAAA\">"))
        }

        @Test
        fun `hidden attribute removes the subtree`() {
            assertEquals(
                "<p>kept</p>",
                HtmlSanitiser.sanitise("<div hidden><p>gone</p></div><p>kept</p>"),
            )
        }

        @Test
        fun `aria-hidden removes the subtree`() {
            assertEquals(
                "<p>kept</p>",
                HtmlSanitiser.sanitise("<div aria-hidden=\"true\"><p>gone</p></div><p>kept</p>"),
            )
        }

        @Test
        fun `display none removes the subtree even with stray whitespace`() {
            assertEquals(
                "<p>kept</p>",
                HtmlSanitiser.sanitise("<div style=\"display : none\"><p>gone</p></div><p>kept</p>"),
            )
        }

        @Test
        fun `visibility hidden removes the subtree`() {
            assertEquals(
                "<p>kept</p>",
                HtmlSanitiser.sanitise("<div style=\"visibility:hidden\"><p>gone</p></div><p>kept</p>"),
            )
        }

        @Test
        fun `a data-security-canary link is removed`() {
            assertEquals(
                "<p>kept</p>",
                HtmlSanitiser.sanitise("<a data-security-canary=\"/x\" href=\"/y\">trap</a><p>kept</p>"),
            )
        }

        @Test
        fun `a 1x1 tracking pixel is dropped`() {
            assertEquals(
                "",
                HtmlSanitiser.sanitise(
                    "<img width=\"1\" height=\"1\" src=\"https://cdn.novtales.com/p.gif\">",
                ),
            )
        }

        @Test
        fun `an svg image is dropped because svg is scriptable`() {
            assertEquals("", HtmlSanitiser.sanitise("<img src=\"/cover/a.svg\">"))
        }

        @Test
        fun `an extensionless image is dropped`() {
            assertEquals("", HtmlSanitiser.sanitise("<img src=\"/cover/abc\">"))
        }

        @Test
        fun `comments are removed`() {
            assertEquals("<p>Hi</p>", HtmlSanitiser.sanitise("<!-- secret --><p>Hi</p>"))
        }

        @Test
        fun `a script inside a paragraph does not leak its text`() {
            assertEquals(
                "<p>beforeafter</p>",
                HtmlSanitiser.sanitise("<p>before<script>steal()</script>after</p>"),
            )
        }
    }

    // =========================================================================
    // Markup that must survive
    // =========================================================================

    class StructurePreservation {

        @Test
        fun `a real image is kept and its relative source resolved`() {
            assertEquals(
                "<img src=\"https://novtales.com/cover/a.jpg\" alt=\"Cover\">",
                HtmlSanitiser.sanitise("<img src=\"/cover/a.jpg\" alt=\"Cover\">"),
            )
        }

        @Test
        fun `nested identical tags both survive`() {
            // The case a naive depth counter gets wrong: the inner `</div>` must
            // not be allowed to close the outer one.
            assertEquals(
                "<div><div>inner</div></div>",
                HtmlSanitiser.sanitise("<div><div>inner</div></div>"),
            )
        }

        @Test
        fun `a scene break marker becomes an hr`() {
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p class=\"scene-break\">* * *</p>"))
        }

        @Test
        fun `an unwrapped tag keeps its prose`() {
            // `<a>` is unwrapped, not dropped: its text is chapter text.
            assertEquals(
                "kept",
                HtmlSanitiser.sanitise("<section><a href=\"/x\">kept</a></section>"),
            )
        }

        @Test
        fun `null and empty input sanitise to an empty string`() {
            assertEquals("", HtmlSanitiser.sanitise(null))
            assertEquals("", HtmlSanitiser.sanitise(""))
        }

        @Test
        fun `textOf is empty for an image only body`() {
            assertFalse(HtmlSanitiser.hasReadableText(HtmlSanitiser.sanitise("<p><img src=\"/a.jpg\"></p>")))
        }

        @Test
        fun `textOf is not empty for real prose`() {
            assertTrue(HtmlSanitiser.hasReadableText(HtmlSanitiser.sanitise("<p>Words here.</p>")))
        }
    }

    // =========================================================================
    // Text fidelity - TTS reads exactly what comes out of here
    // =========================================================================

    class TextAndEntities {

        /**
         * Regression: the entity regex used to carry a `^` anchor.
         *
         * `Regex.find(input, startIndex)` anchors `^` to the start of the whole
         * input, not to `startIndex`, so every entity after the first character of
         * a text run failed to match and was re-escaped into `&amp;amp;`. The
         * fixed code searches from `index` and requires `match.range.first == index`.
         *
         * Every character here is after the first, so a regression re-introduces
         * the double escape immediately.
         */
        @Test
        fun `paragraph text is preserved exactly`() {
            assertEquals(
                "<p>He said \"hi\" &amp; left &mdash; then 5 &gt; 3.</p>",
                HtmlSanitiser.sanitise("<p>He said \"hi\" &amp; left &mdash; then 5 &gt; 3.</p>"),
            )
        }

        @Test
        fun `an entity at the very start of a text run is not double escaped`() {
            assertEquals("<p>&amp; leading</p>", HtmlSanitiser.sanitise("<p>&amp; leading</p>"))
        }

        @Test
        fun `several entities in one paragraph all survive`() {
            assertEquals(
                "<p>&lt;a&gt; &amp; &lt;b&gt; &amp; &lt;c&gt;</p>",
                HtmlSanitiser.sanitise("<p>&lt;a&gt; &amp; &lt;b&gt; &amp; &lt;c&gt;</p>"),
            )
        }

        @Test
        fun `nbsp becomes a numeric entity`() {
            // A literal U+00A0 in the output would be invisible to the reader and
            // would not survive the JSON hop to the plugin.
            assertEquals("<p>a&#160;b</p>", HtmlSanitiser.sanitise("<p>a&nbsp;b</p>"))
        }

        @Test
        fun `a bare ampersand is escaped`() {
            assertEquals("<p>Tom &amp; Jerry</p>", HtmlSanitiser.sanitise("<p>Tom & Jerry</p>"))
        }

        @Test
        fun `a bare ampersand next to a word is not swallowed`() {
            // The match must start exactly at the `&`, so "Tom & Jerry" cannot
            // become "Tom &amp;Jerry".
            assertEquals("<p>Tom &amp; Jerry</p>", HtmlSanitiser.sanitise("<p>Tom & Jerry</p>"))
        }

        @Test
        fun `a bare less-than in prose is escaped rather than read as a tag`() {
            assertEquals("<p>1 &lt; 2</p>", HtmlSanitiser.sanitise("<p>1 < 2</p>"))
        }
    }

    // =========================================================================
    // Image source resolution
    // =========================================================================

    class ImageSources {

        @Test
        fun `a site relative source resolves against the site origin`() {
            assertEquals(
                "https://novtales.com/cover/a.jpg",
                HtmlSanitiser.resolveImageSource("/cover/a.jpg"),
            )
        }

        @Test
        fun `a protocol relative source becomes https`() {
            assertEquals(
                "https://cdn.example/a.jpg",
                HtmlSanitiser.resolveImageSource("//cdn.example/a.jpg"),
            )
        }

        @Test
        fun `an absolute https source is kept as it is`() {
            assertEquals(
                "https://cdn.example/a.jpg",
                HtmlSanitiser.resolveImageSource("https://cdn.example/a.jpg"),
            )
        }

        @Test
        fun `the query string is stripped from the emitted source`() {
            assertEquals(
                "https://cdn.example/a.jpg",
                HtmlSanitiser.resolveImageSource("https://cdn.example/a.jpg?v=2&w=800"),
            )
        }

        @Test
        fun `credentials in the authority are refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://user:pw@cdn.example/a.jpg"))
        }

        @Test
        fun `a javascript source is refused whatever its case`() {
            assertNull(HtmlSanitiser.resolveImageSource("JavaScript:alert(1)"))
            assertNull(HtmlSanitiser.resolveImageSource("  javascript:alert(1)"))
        }

        @Test
        fun `an unsupported scheme is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("blob:https://x/y"))
            assertNull(HtmlSanitiser.resolveImageSource("file:///etc/passwd"))
            assertNull(HtmlSanitiser.resolveImageSource("about:blank"))
        }

        @Test
        fun `a bare host is not an image`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example"))
        }

        @Test
        fun `a directory is not an image`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example/covers/"))
        }

        @Test
        fun `a non image extension is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("/cover/a.svg"))
            assertNull(HtmlSanitiser.resolveImageSource("/cover/a.html"))
        }

        @Test
        fun `every allowed raster extension is accepted`() {
            for (extension in listOf("jpg", "jpeg", "png", "gif", "webp", "avif", "bmp", "ico", "jfif", "apng")) {
                assertEquals(
                    "https://novtales.com/cover/a.$extension",
                    HtmlSanitiser.resolveImageSource("/cover/a.$extension"),
                )
            }
        }

        @Test
        fun `an empty or missing source resolves to null`() {
            assertNull(HtmlSanitiser.resolveImageSource(null))
            assertNull(HtmlSanitiser.resolveImageSource("   "))
        }

        @Test
        fun `a source with a smuggled control character is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example/a\n.jpg"))
        }

        @Test
        fun `an over long source is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example/${"a".repeat(2048)}.jpg"))
        }
    }
}