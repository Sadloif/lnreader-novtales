package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class IndexPageSnapshotTest {
    private fun sourcePage(page: Int, total: Int = 1_663): Json {
        val count = minOf(50, (total - (page - 1) * 50).coerceAtLeast(0))
        return jsonObject(
            "page" to page, "pageSize" to 50, "total" to total,
            "totalPages" to ChapterPaging.totalPages(total, 50),
            "chapters" to Json.Arr(List(count) { jsonObject("number" to total - (page - 1) * 50 - it) }),
        )
    }

    @Test fun `ascending full novel requests every source page only once`() {
        val snapshot = IndexPageSnapshot(sourcePage(1), 50)
        val fetched = mutableListOf(1)
        for (readerPage in 1..ChapterPaging.totalPages(snapshot.total, 50)) {
            for (sourceIndex in NovTalesExtraction.indexPages(snapshot.total, readerPage, 50)) {
                if (snapshot.page(sourceIndex) == null) {
                    fetched.add(sourceIndex)
                    snapshot.remember(sourceIndex, sourcePage(sourceIndex))
                }
            }
        }
        assertEquals(34, fetched.size)
        assertEquals((1..34).toSet(), fetched.toSet())
        assertEquals(1, fetched.count { it == 1 })
    }

    @Test fun `first count page stays pinned while neighbours have a bounded LRU`() {
        val first = sourcePage(1)
        val snapshot = IndexPageSnapshot(first, 50)
        for (page in 2..8) snapshot.remember(page, sourcePage(page))
        assertNotNull(snapshot.page(2))
        snapshot.remember(9, sourcePage(9))
        assertSame(first, snapshot.page(1))
        assertNull(snapshot.page(3))
        assertNotNull(snapshot.page(2))
        assertEquals(8, (1..9).count { snapshot.page(it) != null })
    }

    @Test fun `snapshot expires after five minutes without sliding on access`() {
        var now = 10_000L
        val snapshot = IndexPageSnapshot(sourcePage(1), 50) { now }
        snapshot.remember(2, sourcePage(2))
        now += 299_000L
        assertTrue(snapshot.isFresh())
        assertNotNull(snapshot.page(1))
        now += 1_001L
        assertFalse(snapshot.isFresh())
        assertNull(snapshot.page(1))
        assertNull(snapshot.page(2))
    }

    @Test fun `changed count or wrong page cannot enter a validated snapshot`() {
        val snapshot = IndexPageSnapshot(sourcePage(1), 50)
        for (body in listOf(sourcePage(2, 1_664), sourcePage(3))) {
            try {
                snapshot.remember(2, body)
                fail("A contradictory index response must be rejected")
            } catch (error: CompanionException) {
                assertEquals(ErrorCode.SITE_CHANGED, error.code)
            }
            assertNull(snapshot.page(2))
            assertEquals(1_663, snapshot.total)
        }
    }
}
