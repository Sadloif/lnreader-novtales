package com.sadloif.novtalescompanion.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.experimental.runners.Enclosed

/**
 * Paths is the security boundary: it is the only thing standing between a paired
 * plugin and "load any URL the attacker likes in the companion WebView". Every
 * test here is written so a regression fails loudly rather than quietly widening
 * what the companion will navigate to.
 *
 * Each rejection test says in a comment which threat it blocks.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class PathsTest {

    // =========================================================================
    // normalise - accepted
    // =========================================================================

    class NormaliseAccepts {

        @Test
        fun `a novel path is returned unchanged`() {
            assertEquals(
                "/novel/surviving-the-game-as-a-barbarian",
                Paths.normalise("/novel/surviving-the-game-as-a-barbarian"),
            )
        }

        @Test
        fun `a chapter path is returned unchanged`() {
            assertEquals(
                "/chapter/surviving-the-game-as-a-barbarian-1",
                Paths.normalise("/chapter/surviving-the-game-as-a-barbarian-1"),
            )
        }

        @Test
        fun `a decimal chapter number survives normalisation with its point intact`() {
            // The decimal must not be mangled into an integer here: it is the same
            // value the site asked for and is re-checked in isSameChapter later.
            assertEquals(
                "/chapter/surviving-the-game-as-a-barbarian-944.5",
                Paths.normalise("/chapter/surviving-the-game-as-a-barbarian-944.5"),
            )
        }

        @Test
        fun `a query string is stripped from a novel path`() {
            assertEquals("/novel/slug", Paths.normalise("/novel/slug?chapters=3"))
        }

        @Test
        fun `an https site URL is reduced to its path`() {
            assertEquals("/novel/slug", Paths.normalise("https://novtales.com/novel/slug"))
        }

        @Test
        fun `a site URL keeps neither its query nor its fragment`() {
            assertEquals(
                "/chapter/slug-1",
                Paths.normalise("https://novtales.com/chapter/slug-1?page=2#top"),
            )
        }

        @Test
        fun `a fragment alone is stripped`() {
            assertEquals("/novel/slug", Paths.normalise("/novel/slug#top"))
        }

        @Test
        fun `a slug of many hyphens is accepted`() {
            assertEquals("/novel/a-b-c-d-e", Paths.normalise("/novel/a-b-c-d-e"))
        }

        @Test
        fun `a hyphenated slug with a decimal chapter number is accepted`() {
            assertEquals("/chapter/a-b-c-12.75", Paths.normalise("/chapter/a-b-c-12.75"))
        }

        @Test
        fun `surrounding whitespace is trimmed rather than treated as part of the path`() {
            // A padded path is still the same path; trimming is what stops a plugin
            // sending " /novel/slug " from being treated as a different, invalid URL.
            assertEquals("/novel/slug", Paths.normalise("   /novel/slug   "))
        }

        @Test
        fun `a path at exactly the 200 character limit is accepted`() {
            val slug = "a-".repeat(96) + "a" // 193 characters
            val path = "/novel/$slug" // 200 characters in total
            assertEquals(200, path.length)
            assertEquals(path, Paths.normalise(path))
        }

        @Test
        fun `an uppercase path prefix is normalised but fails the novel classifier`() {
            // Real behaviour: PATH_CHARS allows A-Z, so normalise() hands "/NOVEL/slug"
            // through. Defence in depth is that isNovel() then rejects it - the two
            // checks are separate on purpose, so normalise() is not the only gate.
            assertEquals("/NOVEL/slug", Paths.normalise("/NOVEL/slug"))
            assertFalse(Paths.isNovel("/NOVEL/slug"))
        }

        @Test
        fun `an underscore in a slug is normalised but fails the novel classifier`() {
            // Same two-layer story as uppercase: PATH_CHARS allows "_", SLUG does not.
            assertEquals("/novel/a_b", Paths.normalise("/novel/a_b"))
            assertFalse(Paths.isNovel("/novel/a_b"))
            assertFalse(Paths.isSlug("a_b"))
        }
    }

    // =========================================================================
    // normalise - rejected (the attack surface)
    // =========================================================================

    class NormaliseRejects {

        @Test
        fun `a literal parent directory traversal is rejected`() {
            // Threat: walking out of the site root to read a local file:// resource.
            assertNull(Paths.normalise("/novel/../../etc/passwd"))
            assertNull(Paths.normalise("/../etc/passwd"))
            assertNull(Paths.normalise("/novel/a/../b"))
        }

        @Test
        fun `a percent encoded traversal is rejected`() {
            // Threat: the same traversal, hidden from a naive "does it contain .." check.
            assertNull(Paths.normalise("/novel/%2e%2e%2fetc"))
            assertNull(Paths.normalise("/novel/%2E%2E%2Fetc"))
            assertNull(Paths.normalise("/novel/%2e%2e%252fetc"))
        }

        @Test
        fun `a double encoded traversal is rejected`() {
            // Threat: one decode pass turns %252e into %2e and the WebView decodes the
            // rest. Paths decodes repeatedly, so this must never normalise to anything.
            assertNull(Paths.normalise("/novel/%252e%252e%252fetc"))
            assertNull(Paths.normalise("/novel/%25252e%25252e%25252fetc"))
        }

        @Test
        fun `a five times encoded traversal is rejected`() {
            // Deeper than the four decode passes in fullyDecode(); this only passes
            // because the result is decoded and re-checked after the query is removed.
            assertNull(Paths.normalise("/novel/%252525252e%252525252e%252525252fetc"))
        }

        @Test
        fun `a protocol relative URL is rejected`() {
            // Threat: //evil.com/... is an absolute URL to a browser even though it has
            // no scheme, so a "starts with /" check would wave it through.
            assertNull(Paths.normalise("//evil.com/novel/slug"))
            assertNull(Paths.normalise("//evil.com"))
        }

        @Test
        fun `a plaintext http site URL is rejected`() {
            // Threat: an http:// URL would be downgraded inside the WebView.
            assertNull(Paths.normalise("http://novtales.com/novel/slug"))
        }

        @Test
        fun `an https URL to a foreign host is rejected`() {
            // Threat: off-site navigation, which is the whole attack this guards.
            assertNull(Paths.normalise("https://evil.com/novel/slug"))
            assertNull(Paths.normalise("https://evil.com"))
        }

        @Test
        fun `an https URL that merely contains the allowed host as a path segment is rejected`() {
            // Threat: "https://evil.com/novtales.com/..." must not be mistaken for the
            // real site by a substring match on the host name.
            assertNull(Paths.normalise("https://evil.com/novtales.com/novel/slug"))
        }

        @Test
        fun `a host that merely starts with the allowed host is rejected`() {
            // Threat: novtales.com.attacker.net passing a startsWith("...novtales.com") check.
            assertNull(Paths.normalise("https://novtales.com.evil.com/novel/slug"))
            assertNull(Paths.normalise("https://novtales.com@evil.com/novel/slug"))
        }

        @Test
        fun `an uppercase host is rejected rather than treated as the real site`() {
            // Real behaviour: the prefix is matched case-insensitively but then removed
            // case-sensitively, so https://NOVTALES.com/... cannot find the host to
            // strip and is rejected. Failing closed here is the safe outcome.
            assertNull(Paths.normalise("https://NOVTALES.com/novel/slug"))
        }

        @Test
        fun `a bare scheme with no leading slash is rejected`() {
            // Threat: smuggling "javascript:" or "file:" past a prefix check on "/".
            assertNull(Paths.normalise("file:///etc/passwd"))
            assertNull(Paths.normalise("javascript:alert(1)"))
            assertNull(Paths.normalise("data:text/html,<script>1</script>"))
        }

        @Test
        fun `a query carrying a foreign URL is stripped rather than followed`() {
            // Real behaviour: the query is discarded, so the foreign URL in it can
            // never become the navigation target.
            assertEquals("/novel/slug", Paths.normalise("/novel/slug?next=https://evil.com"))
            assertEquals("/novel/slug", Paths.normalise("/novel/slug#https://evil.com"))
        }

        @Test
        fun `an embedded newline is rejected`() {
            // Threat: CRLF injection - smuggling a second request line into the
            // WebView navigation, or splitting a header the companion builds.
            assertNull(Paths.normalise("/novel/slug\n"))
            assertNull(Paths.normalise("/novel/slug\r\nHost: evil.com"))
            assertNull(Paths.normalise("/novel/sl\nug"))
        }

        @Test
        fun `an embedded NUL is rejected`() {
            // Threat: NUL truncation - "/novel/slug\0/../../etc" reading as a short
            // string in a C-backed API while reading as the full string here.
            assertNull(Paths.normalise("/novel/slug\u0000"))
            assertNull(Paths.normalise("/novel/slug\u0000/../../etc/passwd"))
        }

        @Test
        fun `an empty string is rejected`() {
            assertNull(Paths.normalise(""))
        }

        @Test
        fun `a whitespace only string is rejected`() {
            assertNull(Paths.normalise("   "))
        }

        @Test
        fun `a 5000 character string is rejected`() {
            // Threat: a memory-exhaustion payload in the request body.
            assertNull(Paths.normalise("x".repeat(5000)))
            assertNull(Paths.normalise("/novel/" + "a".repeat(4993)))
        }

        @Test
        fun `a path one character over the length limit is rejected`() {
            val path = "/novel/" + "a-".repeat(96) + "aa" // 201 characters
            assertEquals(201, path.length)
            assertNull(Paths.normalise(path))
        }

        @Test
        fun `a novel path with an empty slug is rejected`() {
            assertNull(Paths.normalise("/novel/"))
        }

        @Test
        fun `a bare collection path with no slug is normalised but fails the classifier`() {
            // Real behaviour: "/novel" and "/" are legal absolute paths, so normalise()
            // keeps them. The request is still refused because isNovel()/isChapter()
            // require a slug - the two checks are separate on purpose.
            assertEquals("/novel", Paths.normalise("/novel"))
            assertFalse(Paths.isNovel("/novel"))
            assertEquals("/chapter", Paths.normalise("/chapter"))
            assertFalse(Paths.isChapter("/chapter"))
            assertEquals("/", Paths.normalise("/"))
            assertFalse(Paths.isNovel("/"))
        }

        @Test
        fun `a slug containing a space is rejected`() {
            assertNull(Paths.normalise("/novel/sur viving the game"))
        }

        @Test
        fun `a slug containing a tilde is rejected`() {
            // Threat: "~" and "~user" are expansion sequences for some file APIs.
            assertNull(Paths.normalise("/novel/~/slug"))
            assertNull(Paths.normalise("/novel/a~b"))
        }

        @Test
        fun `a slug containing a character outside the allowed set is rejected`() {
            assertNull(Paths.normalise("/novel/slug%20"))
            assertNull(Paths.normalise("/novel/sl ug"))
            assertNull(Paths.normalise("/novel/slug:80"))
            assertNull(Paths.normalise("/novel/sl*ug"))
            assertNull(Paths.normalise("/novel/sl%ug"))
        }

        @Test
        fun `an encoded slash does not smuggle an extra path segment past the checks`() {
            // Real behaviour: %2F is decoded before the checks, so this is evaluated as
            // "/novel/a/b" - which still cannot become a traversal and still fails
            // isNovel(), so the decoded form is harmless here.
            assertEquals("/novel/a/b", Paths.normalise("/novel/a%2Fb"))
            assertFalse(Paths.isNovel("/novel/a/b"))
        }

        @Test
        fun `an encoded slash cannot be used to rebuild a traversal`() {
            // Threat: %2e%2e%2f%2e%2e%2f only becomes ".." after decoding, so the
            // traversal check has to run on the decoded value. It does.
            assertNull(Paths.normalise("/novel/a%2F..%2F..%2Fetc"))
            assertNull(Paths.normalise("/novel/a%2fb%2f..%2f..%2fetc"))
        }

        @Test
        fun `a relative path with no leading slash is rejected`() {
            assertNull(Paths.normalise("novel/slug"))
            assertNull(Paths.normalise("chapter/slug-1"))
        }

        @Test
        fun `the site origin with no path is rejected`() {
            assertNull(Paths.normalise("https://novtales.com"))
        }
    }

    // =========================================================================
    // Classification
    // =========================================================================

    class Classification {

        @Test
        fun `a novel path is a novel and not a chapter`() {
            assertTrue(Paths.isNovel("/novel/slug"))
            assertFalse(Paths.isChapter("/novel/slug"))
        }

        @Test
        fun `a numbered chapter path is a chapter`() {
            assertTrue(Paths.isChapter("/chapter/slug-1"))
            assertFalse(Paths.isNovel("/chapter/slug-1"))
        }

        @Test
        fun `a chapter path with no number is not a chapter`() {
            assertFalse(Paths.isChapter("/chapter/slug"))
        }

        @Test
        fun `a chapter path with a non-numeric number is not a chapter`() {
            assertFalse(Paths.isChapter("/chapter/slug-abc"))
            assertFalse(Paths.isChapter("/chapter/slug-1a"))
        }

        @Test
        fun `a chapter path with two decimal points is not a chapter`() {
            assertFalse(Paths.isChapter("/chapter/slug-1.2.3"))
        }

        @Test
        fun `a chapter path whose number has no digits before the point is not a chapter`() {
            // Real behaviour, and deliberate: keeping digits on both sides of the point is
            // what makes "slug-number" splittable on the LAST hyphen.
            assertFalse(Paths.isChapter("/chapter/slug-.5"))
            assertFalse(Paths.isChapter("/chapter/slug-1."))
        }

        @Test
        fun `a chapter path with an empty slug is not a chapter`() {
            assertFalse(Paths.isChapter("/chapter/-1"))
        }

        @Test
        fun `an uppercase slug is not a valid novel or chapter`() {
            assertFalse(Paths.isNovel("/novel/Slug"))
            assertFalse(Paths.isChapter("/chapter/Slug-1"))
        }

        @Test
        fun `a trailing slash makes a path invalid`() {
            assertFalse(Paths.isNovel("/novel/slug/"))
            assertFalse(Paths.isChapter("/chapter/slug-1/"))
        }

        @Test
        fun `a path with no leading slash is invalid`() {
            assertFalse(Paths.isNovel("novel/slug"))
            assertFalse(Paths.isChapter("chapter/slug-1"))
        }

        @Test
        fun `a chapter number of zero is valid`() {
            // Real behaviour: the regex is \d+ with no lower bound beyond zero digits.
            assertTrue(Paths.isChapter("/chapter/slug-0"))
            assertEquals("0", Paths.chapterNumber("/chapter/slug-0"))
        }

        @Test
        fun `a chapter number with a leading zero is accepted verbatim`() {
            // Real behaviour: "01" is not rewritten to "1", which keeps isSameChapter
            // comparing what the site actually sent.
            assertTrue(Paths.isChapter("/chapter/slug-01"))
            assertEquals("01", Paths.chapterNumber("/chapter/slug-01"))
        }

        @Test
        fun `a hyphenated slug is a valid slug but an invalid path prefix`() {
            assertTrue(Paths.isSlug("surviving-the-game-as-a-barbarian"))
            assertFalse(Paths.isSlug("-leading-hyphen"))
            assertFalse(Paths.isSlug("trailing-hyphen-"))
            assertFalse(Paths.isSlug("double--hyphen"))
            assertFalse(Paths.isSlug(""))
            assertFalse(Paths.isSlug("Upper-Case"))
        }

        @Test
        fun `a bare chapter number string is validated by its own rule`() {
            assertTrue(Paths.isChapterNumber("12"))
            assertTrue(Paths.isChapterNumber("12.5"))
            assertFalse(Paths.isChapterNumber("12."))
            assertFalse(Paths.isChapterNumber(".5"))
            assertFalse(Paths.isChapterNumber("-1"))
            assertFalse(Paths.isChapterNumber("abc"))
            assertFalse(Paths.isChapterNumber(""))
        }
    }

    // =========================================================================
    // Number and slug extraction
    // =========================================================================

    class NumberAndSlugExtraction {

        @Test
        fun `a decimal chapter number is returned exactly as the site wrote it`() {
            // The LNReader TypeScript side compares this string, so "944.50", "944.5 "
            // or a Double re-rendered as "944.5" would all be a contract break.
            assertEquals("944.5", Paths.chapterNumber("/chapter/surviving-the-game-as-a-barbarian-944.5"))
        }

        @Test
        fun `an integer chapter number is returned without a decimal point`() {
            assertEquals("12", Paths.chapterNumber("/chapter/slug-12"))
        }

        @Test
        fun `a trailing zero in the decimal is preserved rather than normalised away`() {
            // Real behaviour: "12.0" stays "12.0". isSameChapter treats it as equal to
            // "12", but the extraction contract is "give back what the site sent".
            assertEquals("12.0", Paths.chapterNumber("/chapter/slug-12.0"))
            assertEquals("12.50", Paths.chapterNumber("/chapter/slug-12.50"))
        }

        @Test
        fun `a chapter number is null for anything that is not a chapter path`() {
            assertNull(Paths.chapterNumber("/novel/slug"))
            assertNull(Paths.chapterNumber("/chapter/slug"))
            assertNull(Paths.chapterNumber("/chapter/slug-abc"))
            assertNull(Paths.chapterNumber(""))
        }

        @Test
        fun `a novel slug is extracted from a hyphenated novel path`() {
            assertEquals("a-b-c", Paths.novelSlug("/novel/a-b-c"))
        }

        @Test
        fun `a novel slug may itself end in digits`() {
            // Real behaviour: NOVEL_PATH has no number group, so nothing is stripped.
            assertEquals("slug-1", Paths.novelSlug("/novel/slug-1"))
        }

        @Test
        fun `a chapter slug is taken from before the LAST hyphen`() {
            // The chapter number is always the last hyphen-separated run, so a slug with
            // hyphens (or one that ends in a digit) is not truncated.
            assertEquals("a-b-c", Paths.chapterSlug("/chapter/a-b-c-12"))
            assertEquals("season-2", Paths.chapterSlug("/chapter/season-2-5"))
            assertEquals("surviving-the-game-as-a-barbarian", Paths.chapterSlug("/chapter/surviving-the-game-as-a-barbarian-944.5"))
        }

        @Test
        fun `a chapter slug is null for a novel path or a malformed chapter path`() {
            assertNull(Paths.chapterSlug("/novel/a-b-c"))
            assertNull(Paths.chapterSlug("/chapter/a-b-c"))
        }

        @Test
        fun `the chapter number is also available as a double for arithmetic`() {
            assertEquals(12.75, Paths.chapterNumberAsDouble("/chapter/a-b-c-12.75")!!, 0.0)
            assertEquals(944.5, Paths.chapterNumberAsDouble("/chapter/slug-944.5")!!, 0.0)
            assertNull(Paths.chapterNumberAsDouble("/novel/slug"))
        }
    }

    // =========================================================================
    // isSameChapter - the wrong-chapter-download guard
    // =========================================================================

    class SameChapter {

        @Test
        fun `an identical requested and delivered path is the same chapter`() {
            assertTrue(Paths.isSameChapter("/chapter/slug-1", "/chapter/slug-1"))
        }

        @Test
        fun `the same slug and the same number is the same chapter`() {
            assertTrue(
                Paths.isSameChapter(
                    "/chapter/surviving-the-game-as-a-barbarian-944.5",
                    "/chapter/surviving-the-game-as-a-barbarian-944.5",
                ),
            )
        }

        @Test
        fun `chapter 12 and chapter 12 point zero are treated as the same chapter`() {
            // Real behaviour, and it is the documented tolerance in isSameChapter: the
            // site may hand back "12.0" for a request of "12", and the plugin must not
            // raise WRONG_CHAPTER over a formatting difference. The numeric fallback
            // only runs after an exact string comparison has already failed.
            assertTrue(Paths.isSameChapter("/chapter/slug-12", "/chapter/slug-12.0"))
            assertTrue(Paths.isSameChapter("/chapter/slug-12.0", "/chapter/slug-12"))
        }

        // ============================ THE CRITICAL ONE ============================
        @Test
        fun `identical slug with chapter 1 versus 10 is not the same chapter`() {
            // This is the test that stops a prefix/partial match from completing the
            // WRONG chapter download. Chapter 1 and chapter 10 are different chapters
            // and must never collapse into one another.
            assertFalse(
                "chapter 1 must not be accepted as chapter 10",
                Paths.isSameChapter("/chapter/surviving-the-game-as-a-barbarian-1", "/chapter/surviving-the-game-as-a-barbarian-10"),
            )
            assertFalse(
                "the comparison must not depend on argument order",
                Paths.isSameChapter("/chapter/surviving-the-game-as-a-barbarian-10", "/chapter/surviving-the-game-as-a-barbarian-1"),
            )
            // Nearby traps in the same family.
            assertFalse(Paths.isSameChapter("/chapter/slug-1", "/chapter/slug-100"))
            assertFalse(Paths.isSameChapter("/chapter/slug-2.5", "/chapter/slug-25"))
            assertFalse(Paths.isSameChapter("/chapter/slug-1", "/chapter/slug-11"))
        }
        // =========================================================================

        @Test
        fun `a different slug with the same number is not the same chapter`() {
            assertFalse(Paths.isSameChapter("/chapter/slug-a-1", "/chapter/slug-b-1"))
        }

        @Test
        fun `a slug that is a prefix of the other slug is not the same chapter`() {
            // Guards the string-suffix trap: "a-b" vs "a" are different novels' chapters.
            assertFalse(Paths.isSameChapter("/chapter/a-b-1", "/chapter/a-1"))
            assertFalse(Paths.isSameChapter("/chapter/season-2-5", "/chapter/season-5"))
        }

        @Test
        fun `a malformed side is never the same chapter`() {
            assertFalse(Paths.isSameChapter("/novel/slug", "/novel/slug"))
            assertFalse(Paths.isSameChapter("/chapter/slug", "/chapter/slug-1"))
            assertFalse(Paths.isSameChapter("/chapter/slug-1", "/chapter/slug-abc"))
            assertFalse(Paths.isSameChapter("", ""))
            assertFalse(Paths.isSameChapter("/chapter/slug-1", ""))
            assertFalse(Paths.isSameChapter("/chapter/slug-1 ", "/chapter/slug-1"))
            assertFalse(Paths.isSameChapter("/CHAPTER/slug-1", "/CHAPTER/slug-1"))
            assertFalse(Paths.isSameChapter("https://novtales.com/chapter/slug-1", "/chapter/slug-1"))
        }

        @Test
        fun `chapter numbers differing only above double precision are not the same chapter`() {
            // The comparison is exact string arithmetic on the two decimal parts, never
            // a Double round-trip. Integers above 2^53 are not representable as
            // doubles, so a Double comparison would report these two DIFFERENT chapter
            // numbers as the same one and accept the wrong chapter.
            assertFalse(
                "differing chapter numbers must never be reported as the same chapter",
                Paths.isSameChapter(
                    "/chapter/slug-9007199254740993",
                    "/chapter/slug-9007199254740992",
                ),
            )
            assertFalse(
                Paths.isSameChapter(
                    "/chapter/slug-9007199254740993.0",
                    "/chapter/slug-9007199254740992.0",
                ),
            )
        }

        @Test
        fun `a decimal written with extra trailing zeros is the same chapter`() {
            // Real behaviour: the fractional part is compared with trailing zeros
            // dropped, so "12.50" and "12.5" agree - the same tolerance as "12" and
            // "12.0", one level deeper.
            assertTrue(Paths.isSameChapter("/chapter/slug-12.50", "/chapter/slug-12.5"))
            assertTrue(Paths.isSameChapter("/chapter/slug-12.5", "/chapter/slug-12.50"))
        }

        @Test
        fun `a leading zero in a chapter number is not a different chapter`() {
            // Real behaviour: leading zeros are stripped before the whole part is
            // compared, so "007" and "7" are one chapter.
            assertTrue(Paths.isSameChapter("/chapter/slug-007", "/chapter/slug-7"))
            assertTrue(Paths.isSameChapter("/chapter/slug-0", "/chapter/slug-00"))
        }

        @Test
        fun `a fraction beyond the trailing zeros is still a different chapter`() {
            // The zero-stripping tolerance must not creep past the decimal point.
            assertFalse(Paths.isSameChapter("/chapter/slug-12", "/chapter/slug-12.5"))
            assertFalse(Paths.isSameChapter("/chapter/slug-12.5", "/chapter/slug-12"))
            assertFalse(Paths.isSameChapter("/chapter/slug-1.0", "/chapter/slug-1.1"))
        }
    }
}
