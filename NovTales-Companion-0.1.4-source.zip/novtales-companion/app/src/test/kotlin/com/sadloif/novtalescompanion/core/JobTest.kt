package com.sadloif.novtalescompanion.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.experimental.runners.Enclosed
import java.util.UUID

/** A clock the test moves by hand. No test in this file ever sleeps. */
private class TestClock(var now: Long = 0L) {
    val read: () -> Long = { now }
    fun advance(ms: Long) {
        now += ms
    }
}

private val chapterRequest = JobRequest(Operation.CHAPTER, path = "/chapter/slug-1")

private fun newJob(
    id: String = "job-1",
    request: JobRequest = chapterRequest,
    createdAt: Long = 0L,
    clock: TestClock = TestClock(),
): Job = Job(id, request, createdAt, clock.read)

/** A job that has already finished, for the JobStore tests. */
private fun finishedJob(
    id: String,
    createdAt: Long,
    clock: TestClock,
    failed: Boolean = false,
): Job {
    val job = newJob(id = id, createdAt = createdAt, clock = clock)
    if (failed) job.fail(ApiError.of(ErrorCode.SITE_CHANGED, "gone")) else job.complete(jsonObject("ok" to true))
    return job
}

/**
 * Job state machine tests.
 *
 * Time is injected through `clock: () -> Long` and advanced by hand - nothing here
 * sleeps or polls, so the whole file runs in milliseconds and is not flaky on a
 * loaded CI box.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class JobTest {

    // =========================================================================
    // Lifecycle
    // =========================================================================

    class Lifecycle {

        @Test
        fun `a new job starts queued with nothing done yet`() {
            val job = newJob()
            assertEquals(JobState.QUEUED, job.state)
            assertEquals(0, job.attempt)
            assertNull(job.result)
            assertNull(job.error)
            assertNull(job.startedAt)
            assertEquals(1, job.waiterCount)
        }

        @Test
        fun `begin moves the job to loading and counts the attempt`() {
            val clock = TestClock()
            val job = newJob(clock = clock)

            assertTrue(job.begin())

            assertEquals(JobState.LOADING, job.state)
            assertEquals(1, job.attempt)
            assertEquals(0L, job.startedAt)
        }

        @Test
        fun `begin stamps the time work started rather than the time it was created`() {
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)
            clock.advance(5_000)

            job.begin()

            assertEquals(5_000L, job.startedAt)
        }

        @Test
        fun `begin returns false and changes nothing when the job is already loading`() {
            val clock = TestClock()
            val job = newJob(clock = clock)
            job.begin()
            clock.advance(1_000)

            assertFalse(job.begin())

            // The second attempt must not be counted and must not restart the clock:
            // a double-dispatched job would silently reset its deadline.
            assertEquals(JobState.LOADING, job.state)
            assertEquals(1, job.attempt)
            assertEquals(0L, job.startedAt)
        }

        @Test
        fun `begin returns false once the job has finished`() {
            val job = newJob()
            job.begin()
            job.complete(jsonObject("ok" to true))

            assertFalse(job.begin())

            assertEquals(JobState.COMPLETED, job.state)
            assertEquals(1, job.attempt)
        }

        @Test
        fun `begin returns false for a job waiting on the user`() {
            // Real behaviour: only QUEUED is claimable, so a job parked on needs_user
            // cannot be picked up again by a stale queue drain.
            val job = newJob()
            job.begin()
            job.transitionTo(JobState.NEEDS_USER)

            assertFalse(job.begin())

            assertEquals(JobState.NEEDS_USER, job.state)
            assertEquals(1, job.attempt)
        }

        @Test
        fun `complete stores the result and moves to completed`() {
            val job = newJob()
            job.begin()

            assertTrue(job.complete(jsonObject("slug" to "slug", "number" to 12)))

            assertEquals(JobState.COMPLETED, job.state)
            assertEquals(jsonObject("slug" to "slug", "number" to 12), job.result)
            assertNull(job.error)
        }

        @Test
        fun `a failure after a completion is rejected and the result survives`() {
            // Terminal states are final: a late callback from a timed-out attempt must
            // not be able to overwrite a result the plugin has already been handed.
            val job = newJob()
            job.begin()
            job.complete(jsonObject("ok" to true))

            assertFalse(job.fail(ApiError.of(ErrorCode.TIMEOUT, "late")))

            assertEquals(JobState.COMPLETED, job.state)
            assertEquals(jsonObject("ok" to true), job.result)
            assertNull(job.error)
        }

        @Test
        fun `a completion after a failure is rejected and the error survives`() {
            val job = newJob()
            job.begin()
            val failure = ApiError.of(ErrorCode.INCOMPLETE_CHAPTER, "cut off")
            job.fail(failure)

            assertFalse(job.complete(jsonObject("ok" to true)))

            assertEquals(JobState.FAILED, job.state)
            assertEquals(failure, job.error)
            assertNull(job.result)
        }

        @Test
        fun `cancel marks a queued job cancelled`() {
            val job = newJob()

            assertTrue(job.cancel())

            assertEquals(JobState.CANCELLED, job.state)
            assertNull(job.error)
        }

        @Test
        fun `cancel returns false on a job that has already completed`() {
            val job = newJob()
            job.begin()
            job.complete(jsonObject("ok" to true))
            assertFalse(job.cancel())
            assertEquals(JobState.COMPLETED, job.state)
        }

        @Test
        fun `cancel returns false on a job that has already failed`() {
            val job = newJob()
            job.begin()
            job.fail(ApiError.of(ErrorCode.SITE_CHANGED, "gone"))
            assertFalse(job.cancel())
            assertEquals(JobState.FAILED, job.state)
        }

        @Test
        fun `cancel returns false on a job that is already cancelled`() {
            val job = newJob()
            job.cancel()
            assertFalse(job.cancel())
        }

        @Test
        fun `cancel leaves no error behind for the poller`() {
            // Real behaviour: a cancel clears error, so a plugin polling a cancelled
            // job never sees a failure envelope for work nobody is waiting for.
            val job = newJob()
            job.begin()

            assertTrue(job.cancel())

            assertEquals(JobState.CANCELLED, job.state)
            assertNull(job.error)
            assertFalse(job.toResponse(1).has("error"))
        }

        @Test
        fun `transitionTo cannot move a finished job backwards`() {
            val job = newJob()
            job.begin()
            job.complete(jsonObject("ok" to true))

            for (next in JobState.entries) {
                assertFalse("must not move a COMPLETED job to $next", job.transitionTo(next))
            }

            assertEquals(JobState.COMPLETED, job.state)
        }

        @Test
        fun `only a job that is neither queued nor loading is terminal`() {
            assertFalse(JobState.QUEUED.isTerminal)
            assertFalse(JobState.LOADING.isTerminal)
            assertTrue(JobState.COMPLETED.isTerminal)
            assertTrue(JobState.FAILED.isTerminal)
            assertTrue(JobState.CANCELLED.isTerminal)
            // NEEDS_USER is terminal too - see the needs_user group for why.
            assertTrue(JobState.NEEDS_USER.isTerminal)
        }

        @Test
        fun `a queued job can be completed without ever starting`() {
            // Real behaviour: complete() only checks for a terminal state, so nothing
            // forces the LOADING state first. Harmless in practice (the service always
            // calls begin()), but it means the state machine is not fully enforced.
            val job = newJob()

            assertTrue(job.complete(jsonObject("ok" to true)))

            assertEquals(JobState.COMPLETED, job.state)
            assertNull(job.startedAt)
        }
    }

    // =========================================================================
    // The needs_user guard
    // =========================================================================

    class NeedsUserGuard {

        private fun jobInNeedsUser(): Job {
            val job = newJob()
            job.begin()
            job.transitionTo(JobState.NEEDS_USER)
            return job
        }

        @Test
        fun `a loading job can park on needs_user`() {
            val job = newJob()
            job.begin()

            assertTrue(job.transitionTo(JobState.NEEDS_USER))

            assertEquals(JobState.NEEDS_USER, job.state)
        }

        @Test
        fun `needs_user is treated as a finished state`() {
            // Real behaviour: NEEDS_USER counts as terminal. The site put up
            // something only the reader can resolve, so the job is finished and an
            // auto-retry would just re-run the browser against the same check. A retry
            // is a NEW POST /v1/jobs, never a transition of this one.
            assertTrue(JobState.NEEDS_USER.isTerminal)
        }

        @Test
        fun `needs_user cannot move straight to completed`() {
            // This is the guard: a needs_user job must not quietly finish on its own.
            val job = jobInNeedsUser()

            assertFalse(job.transitionTo(JobState.COMPLETED))

            assertEquals(JobState.NEEDS_USER, job.state)
        }

        @Test
        fun `needs_user cannot move straight to failed cancelled or queued`() {
            val job = jobInNeedsUser()

            assertFalse(job.transitionTo(JobState.FAILED))
            assertFalse(job.transitionTo(JobState.CANCELLED))
            assertFalse(job.transitionTo(JobState.QUEUED))

            assertEquals(JobState.NEEDS_USER, job.state)
        }

        @Test
        fun `needs_user cannot be re-asserted`() {
            // Real behaviour: the state is already finished, so even re-stating it is
            // refused. Callers that treat a false return as "something went wrong"
            // will log noise here.
            val job = jobInNeedsUser()

            assertFalse(job.transitionTo(JobState.NEEDS_USER))

            assertEquals(JobState.NEEDS_USER, job.state)
        }

        @Test
        fun `a needs_user job cannot be restarted in place - a retry is a new request`() {
            val job = jobInNeedsUser()

            assertFalse(job.transitionTo(JobState.LOADING))
            assertFalse(job.begin())

            assertEquals(JobState.NEEDS_USER, job.state)
            assertEquals(1, job.attempt)
        }

        @Test
        fun `a needs_user job cannot complete without a new attempt`() {
            val job = jobInNeedsUser()

            assertFalse(job.complete(jsonObject("ok" to true)))

            assertEquals(JobState.NEEDS_USER, job.state)
            assertNull(job.result)
        }

        @Test
        fun `a needs_user job cannot be cancelled`() {
            val job = jobInNeedsUser()

            assertFalse(job.cancel())

            assertEquals(JobState.NEEDS_USER, job.state)
            assertNull(job.error)
        }

        @Test
        fun `a needs_user job always carries the error that explains the wait`() {
            // needs_user is terminal, but it is the one terminal state that still has
            // to carry its error: that error is what tells the reader "sign in" or
            // "finish the verification" instead of "the companion broke".
            val job = jobInNeedsUser()

            assertTrue(job.fail(ApiError.of(ErrorCode.SIGN_IN_REQUIRED, "log in")))

            assertEquals(JobState.NEEDS_USER, job.state)
            assertEquals(ErrorCode.SIGN_IN_REQUIRED, job.error?.code)
            assertEquals("SIGN_IN_REQUIRED", job.toResponse(1).obj("error")?.str("code"))
            assertEquals("log in", job.toResponse(1).obj("error")?.str("message"))
        }

        @Test
        fun `a needs_user job can have its error replaced by a later attempt`() {
            // Real behaviour: fail() on a needs_user job does not change the state, so
            // a second failure still lands. The last error wins, which is the one the
            // reader is shown.
            val job = jobInNeedsUser()

            job.fail(ApiError.of(ErrorCode.VERIFICATION_REQUIRED, "captcha"))
            assertTrue(job.fail(ApiError.of(ErrorCode.SIGN_IN_REQUIRED, "log in")))

            assertEquals(JobState.NEEDS_USER, job.state)
            assertEquals("SIGN_IN_REQUIRED", job.toResponse(1).obj("error")?.str("code"))
        }

        @Test
        fun `a needs_user job still cannot be completed or cancelled`() {
            // The error is allowed; the state is not. Recording why must not turn the
            // job into a finished one.
            val job = jobInNeedsUser()
            job.fail(ApiError.of(ErrorCode.SIGN_IN_REQUIRED, "log in"))

            assertFalse(job.complete(jsonObject("ok" to true)))
            assertFalse(job.cancel())

            assertEquals(JobState.NEEDS_USER, job.state)
            assertNull(job.result)
        }
    }

    // =========================================================================
    // Wire response
    // =========================================================================

    class WireResponse {

        @Test
        fun `a queued job response carries the api version the job id and the state`() {
            val job = newJob(id = "job-1")

            assertEquals(
                """{"apiVersion":1,"jobId":"job-1","state":"queued"}""",
                job.toResponse(Config.API_VERSION).write(),
            )
        }

        @Test
        fun `the api version is written as an integer`() {
            // The TypeScript client compares this number exactly.
            assertEquals(
                """{"apiVersion":1,"jobId":"j","state":"queued"}""",
                newJob(id = "j").toResponse(1).write(),
            )
            assertEquals(1L, newJob().toResponse(Config.API_VERSION).long("apiVersion"))
        }

        @Test
        fun `a response includes the result only once there is one`() {
            val job = newJob()
            assertFalse(job.toResponse(1).has("result"))

            job.begin()
            job.complete(jsonObject("slug" to "slug"))

            val response = job.toResponse(1)
            assertTrue(response.has("result"))
            assertEquals("slug", response.obj("result")?.str("slug"))
        }

        @Test
        fun `a response includes the error only once there is one`() {
            val job = newJob()
            assertFalse(job.toResponse(1).has("error"))

            job.begin()
            job.fail(ApiError.of(ErrorCode.NOT_FOUND, "no such novel"))

            val response = job.toResponse(1)
            assertTrue(response.has("error"))
            assertFalse(response.has("result"))
            assertEquals(
                """{"apiVersion":1,"jobId":"job-1","state":"failed",""" +
                    """"error":{"code":"NOT_FOUND","message":"no such novel",""" +
                    """"retryable":false,"retryAfterMs":null}}""",
                response.write(),
            )
        }

        @Test
        fun `retryAfterMs is repeated at the top level only when the error carries one`() {
            val without = newJob(id = "j")
            without.begin()
            without.fail(ApiError.of(ErrorCode.QUEUE_FULL, "queue full"))
            assertFalse(without.toResponse(1).has("retryAfterMs"))

            val with = newJob(id = "j")
            with.begin()
            with.fail(ApiError.of(ErrorCode.RATE_LIMITED, "slow down", retryAfterMs = 3_000))
            assertEquals(
                """{"apiVersion":1,"jobId":"j","state":"failed",""" +
                    """"error":{"code":"RATE_LIMITED","message":"slow down",""" +
                    """"retryable":true,"retryAfterMs":3000},"retryAfterMs":3000}""",
                with.toResponse(1).write(),
            )
        }

        @Test
        fun `the state is written as its wire name`() {
            val job = newJob()
            job.begin()
            job.transitionTo(JobState.NEEDS_USER)
            assertEquals(
                """{"apiVersion":1,"jobId":"job-1","state":"needs_user"}""",
                job.toResponse(1).write(),
            )
        }

        @Test
        fun `the api version passed in is the one written`() {
            assertEquals(2L, newJob().toResponse(2).long("apiVersion"))
            assertEquals(7L, newJob().toResponse(7).long("apiVersion"))
        }
    }

    // =========================================================================
    // Queue wait and deadline, both driven by the injected clock
    // =========================================================================

    class TimeBounds {

        @Test
        fun `a queued job inside the wait window has not exceeded it`() {
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)

            clock.advance(19_999)

            assertFalse(job.hasExceededQueueWait(Config.MAX_QUEUE_WAIT_MS))
        }

        @Test
        fun `a queued job exactly at the limit has not exceeded it`() {
            // Real behaviour: the comparison is strictly greater than, so the plugin
            // gets the full MAX_QUEUE_WAIT_MS before it is told QUEUE_FULL.
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)

            clock.advance(Config.MAX_QUEUE_WAIT_MS)
            assertFalse(job.hasExceededQueueWait(Config.MAX_QUEUE_WAIT_MS))

            clock.advance(1)
            assertTrue(job.hasExceededQueueWait(Config.MAX_QUEUE_WAIT_MS))
        }

        @Test
        fun `a job that has started never exceeds the queue wait`() {
            // The queue wait only measures waiting; once work has started the deadline
            // takes over, so a long chapter must not be reported as queue overflow.
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)
            job.begin()

            clock.advance(10 * 60_000)

            assertFalse(job.hasExceededQueueWait(Config.MAX_QUEUE_WAIT_MS))
        }

        @Test
        fun `a job that has never started has not exceeded its deadline`() {
            // Real behaviour, and deliberate: the deadline is measured from when work
            // began, so a job still queued at the deadline limit is not a timeout.
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)

            clock.advance(10 * 60_000)

            assertFalse(job.hasExceededDeadline(Config.CHAPTER_DEADLINE_MS))
        }

        @Test
        fun `a started job exceeds its deadline only once the clock passes it`() {
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)
            clock.advance(30_000) // sat in the queue first
            job.begin()

            clock.advance(Config.CHAPTER_DEADLINE_MS)
            assertFalse(job.hasExceededDeadline(Config.CHAPTER_DEADLINE_MS))

            clock.advance(1)
            assertTrue(job.hasExceededDeadline(Config.CHAPTER_DEADLINE_MS))
        }

        @Test
        fun `the deadline is measured from the start of work and not from creation`() {
            val clock = TestClock()
            val job = newJob(createdAt = 0L, clock = clock)
            clock.advance(10 * 60_000)
            job.begin()

            // 10 minutes of queueing must not count against the 2 minute deadline.
            assertFalse(job.hasExceededDeadline(Config.CHAPTER_DEADLINE_MS))
        }

        @Test
        fun `a custom deadline is honoured`() {
            val clock = TestClock()
            val job = newJob(clock = clock)
            job.begin()

            clock.advance(5_000)
            assertFalse(job.hasExceededDeadline(5_000))
            clock.advance(1)
            assertTrue(job.hasExceededDeadline(5_000))
        }
    }

    // =========================================================================
    // Collapse keys - two callers asking for the same work share one job
    // =========================================================================

    class CollapseKeys {

        @Test
        fun `two identical requests produce the same key`() {
            val a = JobRequest(Operation.CHAPTER, path = "/chapter/slug-1")
            val b = JobRequest(Operation.CHAPTER, path = "/chapter/slug-1")
            assertEquals(a.collapseKey, b.collapseKey)
        }

        @Test
        fun `the key is built from the operation wire name`() {
            assertTrue(JobRequest(Operation.CHAPTER, path = "/chapter/slug-1").collapseKey.startsWith("chapter|"))
            assertTrue(JobRequest(Operation.SEARCH, path = "/search").collapseKey.startsWith("search|"))
        }

        @Test
        fun `a different operation produces a different key`() {
            // Without the operation in the key, a chapter fetch and a chapters listing
            // for the same path would collapse into one job and serve the wrong body.
            assertNotEquals(
                JobRequest(Operation.CHAPTER, path = "/novel/slug").collapseKey,
                JobRequest(Operation.CHAPTERS, path = "/novel/slug").collapseKey,
            )
            assertNotEquals(
                JobRequest(Operation.CATALOGUE).collapseKey,
                JobRequest(Operation.SEARCH).collapseKey,
            )
        }

        @Test
        fun `a different path produces a different key`() {
            assertNotEquals(
                JobRequest(Operation.NOVEL, path = "/novel/a").collapseKey,
                JobRequest(Operation.NOVEL, path = "/novel/b").collapseKey,
            )
        }

        @Test
        fun `page 1 and page 2 do not collapse together`() {
            // The paging fields are part of the key. If they were not, page 2 would be
            // served the page 1 body and the plugin would write chapters to the wrong
            // page of the catalogue.
            assertNotEquals(
                JobRequest(Operation.CHAPTERS, path = "/novel/slug", page = 1).collapseKey,
                JobRequest(Operation.CHAPTERS, path = "/novel/slug", page = 2).collapseKey,
            )
        }

        @Test
        fun `a different sort produces a different key`() {
            assertNotEquals(
                JobRequest(Operation.SEARCH, path = "/search", sort = "relevance").collapseKey,
                JobRequest(Operation.SEARCH, path = "/search", sort = "updated").collapseKey,
            )
        }

        @Test
        fun `a different query produces a different key`() {
            assertNotEquals(
                JobRequest(Operation.SEARCH, path = "/search", query = "dragon").collapseKey,
                JobRequest(Operation.SEARCH, path = "/search", query = "dungeon").collapseKey,
            )
        }

        @Test
        fun `a request that sets every field differs from one that sets none`() {
            // A single test that proves all five components take part in the key.
            assertNotEquals(
                JobRequest(Operation.CATALOGUE).collapseKey,
                JobRequest(
                    Operation.CHAPTER,
                    path = "/chapter/slug-1",
                    page = 3,
                    sort = "asc",
                    query = "q",
                ).collapseKey,
            )
        }

        @Test
        fun `changing one field at a time always changes the key`() {
            val base = JobRequest(Operation.CHAPTERS, path = "/novel/slug", page = 1, sort = "asc", query = "q")
            val variants = listOf(
                base.copy(operation = Operation.CHAPTER),
                base.copy(path = "/novel/other"),
                base.copy(page = 2),
                base.copy(sort = "desc"),
                base.copy(query = "other"),
            )
            for (variant in variants) {
                assertNotEquals(variant.toString(), base.collapseKey, variant.collapseKey)
            }
            assertEquals(base.collapseKey, base.copy().collapseKey)
        }

        @Test
        fun `a null page and page zero collapse together`() {
            // Real behaviour: a null page is written into the key as 0, so a request
            // for "page 0" and a request for no paging at all share one job. Harmless
            // while pages start at 1, but it is an aliasing the key does not make
            // explicit.
            assertEquals(
                JobRequest(Operation.CHAPTERS, path = "/novel/slug").collapseKey,
                JobRequest(Operation.CHAPTERS, path = "/novel/slug", page = 0).collapseKey,
            )
        }

        @Test
        fun `the key is the five request fields joined with pipes`() {
            assertEquals(
                "chapter|/chapter/slug-1|0||",
                JobRequest(Operation.CHAPTER, path = "/chapter/slug-1").collapseKey,
            )
            assertEquals(
                "search|/search|2|asc|q",
                JobRequest(Operation.SEARCH, path = "/search", page = 2, sort = "asc", query = "q").collapseKey,
            )
        }

        @Test
        fun `two different requests share a key if a field value contains the delimiter`() {
            // Real behaviour: the key joins fields with "|", so a value containing "|"
            // shifts the boundary between fields. Paths.normalise rejects "|" in a
            // path, so this cannot be reached through the API today - but sort and
            // query are not validated by Paths, so anything that feeds a caller-supplied
            // value in here would alias two different requests onto one job.
            assertEquals(
                JobRequest(Operation.NOVEL, path = "x", page = 1, sort = "|a", query = "b").collapseKey,
                JobRequest(Operation.NOVEL, path = "x", page = 1, sort = "", query = "a|b").collapseKey,
            )
        }
    }

    // =========================================================================
    // Change notification
    // =========================================================================

    class ChangeNotification {

        @Test
        fun `a listener is called when the state changes`() {
            val job = newJob()
            var calls = 0
            job.onChange { calls++ }

            job.begin()

            assertEquals(1, calls)
        }

        @Test
        fun `a listener is called once and then dropped`() {
            // A long-poll waiter must be woken exactly once; leaving it registered
            // would wake it again on every later state change.
            val job = newJob()
            var calls = 0
            job.onChange { calls++ }

            job.begin()
            job.complete(jsonObject("ok" to true))

            assertEquals(1, calls)
        }

        @Test
        fun `a listener registered on a finished job is called immediately`() {
            // The poller can arrive after the job already finished and must not hang.
            val job = newJob()
            job.complete(jsonObject("ok" to true))

            var calls = 0
            job.onChange { calls++ }

            assertEquals(1, calls)
        }

        @Test
        fun `two waiters are both woken`() {
            val job = newJob()
            var first = 0
            var second = 0
            job.onChange { first++ }
            job.onChange { second++ }

            job.begin()

            assertEquals(1, first)
            assertEquals(1, second)
            // Real behaviour: onChange does not maintain waiterCount, so the service
            // layer owns that counter. Pinning it here so nobody assumes the two are
            // the same thing - cancelling on one waiter must not cancel the other.
            assertEquals(1, job.waiterCount)
        }
    }

    // =========================================================================
    // JobStore
    // =========================================================================

    class Store {

        @Test
        fun `a stored job can be read back by id`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            val job = newJob(id = "job-1", clock = clock)

            assertSame(job, store.put(job))

            assertSame(job, store.get("job-1"))
            assertNull(store.get("missing"))
        }

        @Test
        fun `remove forgets the job and hands it back`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            val job = store.put(newJob(id = "job-1", clock = clock))

            assertSame(job, store.remove("job-1"))

            assertNull(store.get("job-1"))
            assertNull(store.remove("job-1"))
        }

        @Test
        fun `storing a job with the same id twice replaces it`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            store.put(newJob(id = "job-1", clock = clock))
            val replacement = newJob(id = "job-1", clock = clock)

            store.put(replacement)

            assertSame(replacement, store.get("job-1"))
            assertEquals(1, store.all().size)
        }

        @Test
        fun `sweep removes a finished job that is past the retention window`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            val done = finishedJob("done", createdAt = 0L, clock = clock)
            store.put(done)

            clock.advance(10_001)

            val swept = store.sweep(10_000)

            assertEquals(listOf(done), swept)
            assertNull(store.get("done"))
        }

        @Test
        fun `sweep keeps a finished job that is still inside the retention window`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            store.put(finishedJob("done", createdAt = 0L, clock = clock))

            clock.advance(9_999)

            assertTrue(store.sweep(10_000).isEmpty())
            assertNotNull(store.get("done"))
        }

        @Test
        fun `sweep leaves a queued job alone however old it is`() {
            // An uncollected queued job is still work; evicting it would strand the
            // caller that is polling for it.
            val clock = TestClock()
            val store = JobStore(clock.read)
            store.put(newJob(id = "waiting", createdAt = 0L, clock = clock))

            clock.advance(60 * 60_000)

            assertTrue(store.sweep(10_000).isEmpty())
            assertNotNull(store.get("waiting"))
        }

        @Test
        fun `sweep leaves a loading job alone however old it is`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            val running = newJob(id = "running", createdAt = 0L, clock = clock)
            running.begin()
            store.put(running)

            clock.advance(60 * 60_000)

            assertTrue(store.sweep(10_000).isEmpty())
            assertNotNull(store.get("running"))
        }

        @Test
        fun `sweep removes a failed job as well as a completed one`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            val failed = finishedJob("bad", createdAt = 0L, clock = clock, failed = true)
            store.put(failed)

            clock.advance(10_001)

            assertEquals(listOf(failed), store.sweep(10_000))
        }

        @Test
        fun `putting a job automatically sweeps the ones that have expired`() {
            // Real behaviour: put() sweeps with Config.JOB_RETENTION_MS, so an expired
            // job disappears when the next job arrives rather than waiting for the
            // service's periodic sweep tick.
            val clock = TestClock()
            val store = JobStore(clock.read)
            store.put(finishedJob("old", createdAt = 0L, clock = clock))

            clock.advance(Config.JOB_RETENTION_MS + 1)
            store.put(newJob(id = "new", clock = clock))

            assertNull(store.get("old"))
            assertNotNull(store.get("new"))
        }

        @Test
        fun `the count cap evicts the oldest finished jobs first`() {
            val clock = TestClock()
            val store = JobStore(clock.read, maxRetained = 3)
            store.put(finishedJob("a", createdAt = 1, clock = clock))
            store.put(finishedJob("b", createdAt = 2, clock = clock))
            store.put(finishedJob("c", createdAt = 3, clock = clock))
            assertEquals(3, store.all().size)

            store.put(finishedJob("d", createdAt = 4, clock = clock))

            assertNull("the oldest finished job goes first", store.get("a"))
            assertNotNull(store.get("b"))
            assertNotNull(store.get("c"))
            assertNotNull(store.get("d"))
            assertEquals(3, store.all().size)
        }

        @Test
        fun `the count cap never evicts a running job`() {
            // Real behaviour: the cap only ever removes terminal jobs, so a burst of
            // active work can push the store past maxRetained rather than dropping
            // work in flight.
            val clock = TestClock()
            val store = JobStore(clock.read, maxRetained = 2)
            val running = newJob(id = "running", createdAt = 1, clock = clock)
            running.begin()
            store.put(running)
            store.put(finishedJob("b", createdAt = 2, clock = clock))
            store.put(finishedJob("c", createdAt = 3, clock = clock))
            store.put(finishedJob("d", createdAt = 4, clock = clock))

            assertNotNull("active work must survive the cap", store.get("running"))
            assertNull(store.get("b"))
            assertEquals(2, store.all().size)
        }

        @Test
        fun `a store never grows past its cap once every job has finished`() {
            val clock = TestClock()
            val store = JobStore(clock.read, maxRetained = 5)
            for (i in 1..50) {
                store.put(finishedJob("job-$i", createdAt = i.toLong(), clock = clock))
                assertTrue(store.all().size <= 5)
            }
        }

        @Test
        fun `the state counts add up to the size of the store`() {
            val clock = TestClock()
            val store = JobStore(clock.read)
            store.put(newJob(id = "queued-1", clock = clock))
            store.put(newJob(id = "queued-2", clock = clock))
            val running = newJob(id = "running", clock = clock)
            running.begin()
            store.put(running)
            store.put(finishedJob("done", createdAt = 1, clock = clock))
            store.put(finishedJob("bad", createdAt = 2, clock = clock, failed = true))
            val cancelled = newJob(id = "cancelled", clock = clock)
            cancelled.cancel()
            store.put(cancelled)

            assertEquals(6, store.all().size)
            assertEquals(2, store.queuedCount())
            assertEquals(1, store.activeCount())
            assertEquals(3, store.terminalCount())
        }
    }

    // =========================================================================
    // Identity, operations and error envelopes
    // =========================================================================

    class IdentityAndErrors {

        @Test
        fun `every new job id is a distinct uuid`() {
            val ids = (1..200).map { Job.newId() }
            assertEquals(ids.size, ids.toSet().size)
            for (id in ids) {
                assertEquals(id, UUID.fromString(id).toString())
            }
        }

        @Test
        fun `an operation resolves from its wire name`() {
            assertEquals(Operation.CHAPTER, Operation.fromName("chapter"))
            assertEquals(Operation.CHAPTERS, Operation.fromName("CHAPTERS"))
            assertEquals(Operation.SEARCH, Operation.fromName(" search "))
            assertNull(Operation.fromName("delete"))
            assertNull(Operation.fromName(null))
        }

        @Test
        fun `an api error envelope carries the code message and retry hint`() {
            val envelope = ApiError.of(ErrorCode.QUEUE_FULL, "queue full", retryAfterMs = 3_000).toJson()
            assertEquals(
                """{"code":"QUEUE_FULL","message":"queue full",""" +
                    """"retryable":true,"retryAfterMs":3000}""",
                envelope.write(),
            )
        }

        @Test
        fun `an api error defaults retryable from its code`() {
            assertTrue(ApiError.of(ErrorCode.TIMEOUT, "slow").retryable)
            assertFalse(ApiError.of(ErrorCode.BAD_REQUEST, "no").retryable)
            // The value can still be overridden explicitly.
            assertFalse(ApiError(ErrorCode.TIMEOUT, "slow", retryable = false).retryable)
        }

        @Test
        fun `an api error built from an exception keeps its retry hint`() {
            val exception = CompanionException(ErrorCode.QUEUE_FULL, "busy", retryAfterMs = 1_500)
            val error = ApiError.from(exception)

            assertEquals(ErrorCode.QUEUE_FULL, error.code)
            assertEquals("busy", error.message)
            assertEquals(1_500L, error.retryAfterMs)
            assertTrue(error.retryable)
        }
    }
}
