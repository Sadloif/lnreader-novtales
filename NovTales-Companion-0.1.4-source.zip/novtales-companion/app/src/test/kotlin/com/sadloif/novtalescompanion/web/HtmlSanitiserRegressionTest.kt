package com.sadloif.novtalescompanion.web

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith

/**
 * Regression tests for the confirmed chapter-extraction bugs.
 *
 * These are all red-team findings reproduced as executable checks. Each group is
 * named after the failure it pins, and each one exists because the wrong
 * behaviour was *observed*, not imagined:
 *
 *  - [EntityDecoding]  - `&nbsp;` defeated the readable-text gate, so a body with
 *                        no words in it could be stored as a complete chapter.
 *  - [LinearEntityScan] - `appendText` was quadratic in `&`, turning a 48 KB body
 *                        into 26 s of uninterruptible CPU inside a 120 s deadline.
 *  - [NextImageEndpoint] - every `/_next/image` source was dropped, which on this
 *                        site is every illustration.
 *  - [SceneBreakLoss]  - a CSS class ending in `break` silently deleted prose,
 *                        and `data-scene-break="false"` deleted it too.
 *
 * Pure JVM on purpose: `HtmlSanitiser` has no `android.*` import, which is the
 * only reason these can run without Robolectric.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class HtmlSanitiserRegressionTest {

    // =========================================================================
    // REGRESSION: `&nbsp;` counted as prose.
    //
    // `appendText` rewrites `&nbsp;` to `&#160;`, so the character no longer
    // exists by the time `textOf` looks, and `textOf` never decoded entities -
    // the six literal characters `&#160;` were enough to pass `isNotBlank()`.
    // Observed: `hasReadableText(sanitise("<p> </p>"))` was false while
    // `hasReadableText(sanitise("<p>&nbsp;</p>"))` was true, for the same
    // character. `ChapterCompletion.evaluate` then returned `Complete` and stored
    // `<p>&#160;</p>` as a finished chapter.
    // =========================================================================

    class EntityDecoding {

        private fun readable(html: String): Boolean =
            HtmlSanitiser.hasReadableText(HtmlSanitiser.sanitise(html))

        @Test
        fun `a named nbsp paragraph is not readable text`() {
            assertFalse("&nbsp; is a space, not a word", readable("<p>&nbsp;</p>"))
        }

        @Test
        fun `a decimal nbsp entity paragraph is not readable text`() {
            assertFalse(readable("<p>&#160;</p>"))
        }

        @Test
        fun `a hexadecimal nbsp entity paragraph is not readable text`() {
            assertFalse(readable("<p>&#xA0;</p>"))
            assertFalse(readable("<p>&#xa0;</p>"))
        }

        @Test
        fun `an uppercase NBSP entity is decoded too`() {
            assertFalse(readable("<p>&NBSP;</p>"))
        }

        @Test
        fun `repeated nbsp is still not readable text`() {
            assertFalse(readable("<p>&nbsp;&nbsp;&nbsp;</p>"))
            assertFalse(readable("<p>&nbsp;</p><p>&nbsp;</p>"))
            assertFalse(readable("<p>&nbsp;</p><p> </p>"))
        }

        /**
         * The exact case from the red-team report. 200 `&nbsp;` paragraphs is a
         * placeholder, not a chapter, and it must not be reported as complete.
         */
        @Test
        fun `two hundred nbsp paragraphs are not readable text`() {
            assertFalse(readable("<p>&nbsp;</p>".repeat(200)))
        }

        /** The asymmetry that proved the bug: entity form must equal character form. */
        @Test
        fun `the entity form and the character form agree`() {
            val realSpace = readable("<p> </p>")
            val realNbsp = readable("<p>\u00A0</p>")
            val entityNbsp = readable("<p>&nbsp;</p>")
            assertEquals("a real space is not prose", false, realSpace)
            assertEquals("a real NBSP is not prose", false, realNbsp)
            assertEquals(
                "the entity form must give the same answer as the character",
                realNbsp,
                entityNbsp,
            )
        }

        /**
         * REGRESSION: `decodeCharacter` special-cased four *named* whitespace
         * entities and every other named entity was copied through verbatim, so
         * the literal characters `&zwj;` reached `isNotBlank()` and a body with
         * no words in it was stored as a complete chapter. The numeric twin
         * `&#8205;` was already refused by the same test below it.
         *
         * Every named reference that resolves to an invisible character must now
         * give the same answer as its numeric twin. This is the whole list the
         * decoder knows about, so a new one added there without a test shows up
         * here as a failure rather than as a bypass.
         */
        @Test
        fun `every named invisible entity matches its numeric twin`() {
            for ((name, code) in HtmlSanitiser.NAMED_INVISIBLE) {
                val named = "&$name;"
                val numeric = "&#${code};"
                assertFalse("$named is not readable text", readable("<p>$named</p>"))
                assertEquals(
                    "$named and $numeric must give the same answer",
                    readable("<p>$numeric</p>"),
                    readable("<p>$named</p>"),
                )
            }
        }

        /**
         * The sanitiser deliberately leaves entities in the stored HTML as the
         * entities they came in as - decoding `&amp;` there would change what the
         * reader sees. Decoding happens in [HtmlSanitiser.textOf], which is the
         * view the completion gate uses, so this is where the two must agree.
         */
        @Test
        fun `textOf sees the character, not the seven-letter name`() {
            for (name in HtmlSanitiser.NAMED_INVISIBLE.keys) {
                val seen = HtmlSanitiser.textOf("<p>&$name;</p>")
                assertFalse(
                    "&$name; must not reach the gate as the literal name, got '$seen'",
                    seen.contains("&$name;"),
                )
                assertTrue(
                    "&$name; must read as blank, got '$seen'",
                    seen.isBlank(),
                )
            }
        }

        /**
         * ...and the table must not be able to disagree with the predicate.
         *
         * `NAMED_INVISIBLE` maps a name to a code point and `isInvisible` decides
         * whether that code point counts as prose. When the two drifted, eight of
         * the names mapped to spacing characters that the predicate did not
         * cover, `isInvisible` said "visible", and the entry silently did nothing.
         * A code point is only *allowed* in the table if the predicate accepts
         * it; asserting that here is what stops the next one from slipping.
         */
        @Test
        fun `every code point in the named table is one the predicate calls invisible`() {
            // Both sides are the production declarations, not copies: a table
            // entry that the predicate rejects is dead code, and that is exactly
            // the bug this pins.
            val offending = HtmlSanitiser.NAMED_INVISIBLE
                .filterNot { entry -> HtmlSanitiser.isInvisible(entry.value) }
            assertTrue(
                "these named entities map to code points the predicate does not " +
                    "call invisible, so decoding them does nothing: " + offending.keys,
                offending.isEmpty(),
            )
        }

        /** The flip side: the predicate must not simply answer true for everything. */
        @Test
        fun `the predicate is not simply answering true`() {
            for (code in listOf('a'.code, 'Z'.code, '0'.code, 0x2E, 0x3001, 0x2010, 0x2016)) {
                assertFalse(
                    "U+%04X is visible".format(code),
                    HtmlSanitiser.isInvisible(code),
                )
            }
            for (code in listOf(0x20, 0xA0, 0x200B, 0xFEFF, 0x09)) {
                assertTrue("U+%04X is invisible".format(code), HtmlSanitiser.isInvisible(code))
            }
        }

        /** Other whitespace entities are whitespace too, not prose. */
        @Test
        fun `the other spacing entities are not readable text`() {
            for (name in listOf(
                "ensp", "emsp", "thinsp", "hairsp", "numsp", "puncsp", "nnbsp",
                "MediumSpace", "NoBreak", "shy", "zwj", "zwnj", "lrm", "rlm",
            )) {
                assertFalse("&$name; is not readable text", readable("<p>&$name;</p>"))
            }
            assertFalse(readable("<p>&#32;</p>"))
        }

        /**
         * Invisible characters are not prose either, and Kotlin's `isWhitespace`
         * does not know that. A body of zero-width spaces would otherwise pass.
         */
        @Test
        fun `invisible format characters are not readable text`() {
            assertFalse(readable("<p>&#8203;</p>"))   // zero width space
            assertFalse(readable("<p>&#8205;</p>"))   // zero width joiner
            assertFalse(readable("<p>&#8207;</p>"))   // right-to-left mark
            assertFalse(readable("<p>&#8238;</p>"))   // right-to-left override
            assertFalse(readable("<p>&#xFEFF;</p>"))  // BOM / zero width no-break space
        }

        /** Real prose must still pass, including when it is padded with nbsp. */
        @Test
        fun `real prose padded with nbsp is still readable`() {
            assertTrue(readable("<p>&nbsp;He drew his sword.&nbsp;</p>"))
        }

        @Test
        fun `textOf decodes the entity rather than echoing it`() {
            assertEquals("a b", HtmlSanitiser.textOf("<p>a&nbsp;b</p>"))
            assertEquals("a b", HtmlSanitiser.textOf("<p>a&#160;b</p>"))
        }

        /**
         * `&amp;` is deliberately copied through rather than decoded to `&`.
         *
         * The reader sees `&` on screen, so decoding it would make `textOf`
         * disagree with the renderer for the sake of tidiness. What matters is
         * that a paragraph of nothing but ampersands *is* prose - it is visible -
         * so this must not become a false rejection.
         */
        @Test
        fun `an ampersand is prose, not whitespace`() {
            assertTrue(readable("<p>&amp;</p>"))
            assertTrue(readable("<p>&amp;amp;</p>"))
            assertTrue(readable("<p>&copy;</p>"))
        }
    }

    // =========================================================================
    // REGRESSION: `appendText` was quadratic in `&`.
    //
    // `HTML_ENTITY.find(raw, index)` searches from `index` to the END of the
    // string, so every `&` that began no entity cost a full scan of everything
    // after it. Measured on a server JVM: 24 000 `&#` in 48 KB took 25.9 s. That
    // runs inside `withContext(io)` inside `ChapterCompletion.evaluate`, which is
    // not interruptible, so `withTimeout` could not cancel it: the job overran
    // its 120 s deadline instead of reporting a timeout.
    // =========================================================================

    class LinearEntityScan {

        /** Generous: the quadratic version took 25.9 s for this exact input. */
        private val budgetMillis = 8_000L

        @Test
        fun `24k ampersands in 48 KB sanitise well inside the deadline`() {
            val body = "<p>" + "&#".repeat(24_000) + "</p>"
            val started = System.nanoTime()
            val out = HtmlSanitiser.sanitise(body)
            val elapsedMillis = (System.nanoTime() - started) / 1_000_000

            // "<p>" + "&#" x 24 000 + "</p>": every `&` becomes `&amp;`, so 24 000 * 6
            // characters of output plus the 7 the tags take.
            assertEquals(144_007, out.length)
            assertTrue(
                "sanitising 24k ampersands took ${elapsedMillis}ms; " +
                    "the scan is quadratic again (it used to take 25,900ms)",
                elapsedMillis < budgetMillis,
            )
        }

        /**
         * The ratio is the actual claim, so it is asserted as one: a linear scan
         * grows 8x when the input grows 8x, a quadratic one grows ~64x.
         *
         * The absolute floor keeps this stable on a machine whose first call is
         * still being JIT-compiled.
         */
        @Test
        fun `doubling the ampersands does not quadruple the time`() {
            fun millisFor(repeat: Int): Long {
                val body = "<p>" + "&#".repeat(repeat) + "</p>"
                HtmlSanitiser.sanitise(body) // warm up
                val started = System.nanoTime()
                HtmlSanitiser.sanitise(body)
                return (System.nanoTime() - started) / 1_000_000
            }

            val small = millisFor(3_000)
            val large = millisFor(24_000)
            val ratio = (large + 50L).toDouble() / (small + 50L)

            assertTrue(
                "8x the input took ${ratio}x the time (${small}ms -> ${large}ms)",
                ratio < 16.0,
            )
        }

        @Test
        fun `bare ampersands in ordinary prose are still escaped correctly`() {
            assertEquals(
                "<p>R&amp;D and Q&amp;A and AT&amp;T</p>",
                HtmlSanitiser.sanitise("<p>R&D and Q&A and AT&T</p>"),
            )
        }

        @Test
        fun `entities at the end of a long text run are still recognised`() {
            // The reason the code searched from `index` rather than slicing: an
            // entity after the first character must still match, not be
            // double-escaped. `matchAt` must not reintroduce that.
            val long = "x".repeat(5000) + "&amp;tail"
            assertTrue(HtmlSanitiser.sanitise(long).endsWith("&amp;tail"))
            assertFalse(HtmlSanitiser.sanitise(long).contains("&amp;amp;"))
        }

        @Test
        fun `a long run of valid entities is still recognised and normalised`() {
            val out = HtmlSanitiser.sanitise("<p>" + "&nbsp;".repeat(20_000) + "</p>")
            assertEquals(20_000, Regex("&#160;").findAll(out).count())
        }
    }

    // =========================================================================
    // REGRESSION: every `/_next/image` source was dropped.
    //
    // `resolveImageSource` stripped the query before the extension check, leaving
    // the path `/_next/image` with no dot, so `dot < 0` returned null. The captured
    // chapter page carries 145 such sources, so this dropped every illustration.
    // =========================================================================

    class NextImageEndpoint {

        @Test
        fun `the measured NextJS image source resolves to its target`() {
            // Exactly the URL from the red-team report, which was DROPPED.
            assertEquals(
                "https://x.supabase.co/a.jpg",
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=https%3A%2F%2Fx.supabase.co%2Fa.jpg&w=800&q=75",
                ),
            )
        }

        @Test
        fun `a site-relative NextJS source resolves too`() {
            assertEquals(
                "https://x.supabase.co/a.jpg",
                HtmlSanitiser.resolveImageSource(
                    "/_next/image?url=https%3A%2F%2Fx.supabase.co%2Fa.jpg&w=1200&q=80",
                ),
            )
        }

        @Test
        fun `the endpoint's own width and quality parameters are dropped`() {
            assertEquals(
                "https://cdn.example/covers/one.png",
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?w=640&q=75&url=https%3A%2F%2Fcdn.example%2Fcovers%2Fone.png",
                ),
            )
        }

        @Test
        fun `an image in the sanitised output survives`() {
            assertEquals(
                "<img src=\"https://x.supabase.co/a.jpg\">",
                HtmlSanitiser.sanitise(
                    "<img src=\"https://novtales.com/_next/image?url=https%3A%2F%2Fx.supabase.co%2Fa.jpg&w=800&q=75\">",
                ),
            )
        }

        @Test
        fun `a proxied non-image target is still refused`() {
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=https%3A%2F%2Fx.example%2Fa.html&w=800",
                ),
            )
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=https%3A%2F%2Fx.example%2Fa.svg&w=800",
                ),
            )
        }

        /** The endpoint must not become a way to smuggle a scheme through. */
        @Test
        fun `a proxied javascript target is still refused`() {
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=javascript%3Aalert(1)",
                ),
            )
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=data%3Aimage%2Fpng%3Bbase64%2CAAAA",
                ),
            )
        }

        @Test
        fun `a proxied target with credentials is still refused`() {
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=https%3A%2F%2Fuser%3Apw%40x.example%2Fa.jpg",
                ),
            )
        }

        @Test
        fun `an endpoint with no url parameter is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://novtales.com/_next/image?w=800&q=75"))
            assertNull(HtmlSanitiser.resolveImageSource("https://novtales.com/_next/image"))
            assertNull(HtmlSanitiser.resolveImageSource("https://novtales.com/_next/image?url="))
        }

        /**
         * A site-relative proxied target resolves against the site origin, which
         * is what the endpoint itself would serve. It is still a same-site image
         * and nothing more - the endpoint cannot be used to reach a new scheme or
         * a new host, which is what the two tests above pin.
         */
        @Test
        fun `a relative proxied target resolves against the site origin`() {
            assertEquals(
                "https://novtales.com/a.jpg",
                HtmlSanitiser.resolveImageSource("https://novtales.com/_next/image?url=%2Fa.jpg"),
            )
        }

        /** An over-long proxied target is refused before it can be expanded. */
        @Test
        fun `an over long proxied target is refused`() {
            assertNull(
                HtmlSanitiser.resolveImageSource(
                    "https://novtales.com/_next/image?url=https%3A%2F%2Fx.example%2F" +
                        "a".repeat(3000) + ".jpg",
                ),
            )
        }

        /**
         * Path traversal in an ordinary source was accepted with the `..` intact.
         * Low severity on its own - the URL still points at the site - but the
         * endpoint path made it worth refusing outright.
         */
        @Test
        fun `a traversing path is refused`() {
            assertNull(HtmlSanitiser.resolveImageSource("https://novtales.com/a.png/../../b.png"))
            assertNull(HtmlSanitiser.resolveImageSource("/a.png/../b.png"))
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example/%2e%2e/b.png"))
        }

        /** The ordinary rules are unchanged for ordinary sources. */
        @Test
        fun `ordinary sources still behave exactly as before`() {
            assertEquals(
                "https://novtales.com/cover/a.jpg",
                HtmlSanitiser.resolveImageSource("/cover/a.jpg"),
            )
            assertNull(HtmlSanitiser.resolveImageSource("https://cdn.example"))
            assertNull(HtmlSanitiser.resolveImageSource("/cover/abc"))
            assertNull(HtmlSanitiser.resolveImageSource("javascript:alert(1)"))
        }
    }

    // =========================================================================
    // REGRESSION: `class="...break..."` silently deleted paragraphs.
    //
    // `SCENE_BREAK_CLASS` matched the bare token `break` after any hyphen or
    // underscore, and the branch ran before `KEEP_TAGS` and called
    // `skipSubtree`, so `<p class="text-break">prose</p>` became `<hr>` and the
    // prose was gone. The chapter was still reported complete.
    // =========================================================================

    class SceneBreakLoss {

        private val prose = "The next morning the caravan set out early."

        /**
         * Tailwind's `break-*` utilities, and every other class where `break`
         * appears as a fragment of a longer token. Each of these used to delete
         * its paragraph.
         */
        @Test
        fun `a break utility class does not delete a paragraph`() {
            for (className in listOf(
                "text-break", "word-break", "line-break", "chapter-break",
                "break", "no-break", "break-word", "break-words", "break-inside-avoid",
                "break-before", "break-after", "keep-with-next page-break",
                "underline break-through", "hyphen-break", "page-break-always",
            )) {
                assertEquals(
                    "class=\"$className\" must not delete its prose",
                    "<p>$prose</p>",
                    HtmlSanitiser.sanitise("<p class=\"$className\">$prose</p>"),
                )
            }
        }

        /** The chapter-level shape from the report, end to end. */
        @Test
        fun `a chapter body keeps every paragraph it was given`() {
            val input = "<p>Chapter 10 opened with a long description of the arena.</p>" +
                "<p class=\"text-break\">$prose</p>" +
                "<p class=\"chapter-break\">A different camp, a different mood entirely.</p>" +
                "<p>End of Chapter 10</p>"
            val out = HtmlSanitiser.sanitise(input)

            assertTrue(out, out.contains("The next morning the caravan set out early."))
            assertTrue(out, out.contains("A different camp, a different mood entirely."))
            assertEquals(4, Regex("<p>").findAll(out).count())
        }

        /** A genuine scene break is still the reader's `<hr>`. */
        @Test
        fun `a real scene break still becomes an hr`() {
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p class=\"scene-break\">* * *</p>"))
            assertEquals("<hr>", HtmlSanitiser.sanitise("<div class=\"scene-divider\"></div>"))
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p class=\"scene_break\"></p>"))
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p class=\"SCENE-BREAK\"></p>"))
        }

        /** A valueless `data-scene-break` is the conventional boolean spelling. */
        @Test
        fun `a valueless data-scene-break still becomes an hr`() {
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p data-scene-break></p>"))
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p data-scene-break=\"\"></p>"))
            assertEquals("<hr>", HtmlSanitiser.sanitise("<p data-scene-break=\"true\"></p>"))
        }

        /**
         * REGRESSION: `data-scene-break` matched on *presence*, so the attribute
         * said to turn it off and the sanitiser turned it on.
         */
        @Test
        fun `data-scene-break=false does not trigger`() {
            assertEquals(
                "<p>$prose</p>",
                HtmlSanitiser.sanitise("<p data-scene-break=\"false\">$prose</p>"),
            )
            for (off in listOf("false", "False", "FALSE", "0", "no", "off", "none", "null")) {
                assertEquals(
                    "data-scene-break=\"$off\" must not delete its prose",
                    "<p>$prose</p>",
                    HtmlSanitiser.sanitise("<p data-scene-break=\"$off\">$prose</p>"),
                )
            }
        }

        /**
         * REGRESSION: `<div class="scene-break">` swallowed its whole subtree,
         * paragraphs and images included. A scene break is a marker, not a
         * licence to delete a container.
         */
        @Test
        fun `a scene break cannot swallow a container of paragraphs and images`() {
            assertEquals(
                "<hr><p>a</p><p>b</p><img src=\"https://novtales.com/a.jpg\">",
                HtmlSanitiser.sanitise(
                    "<div class=\"scene-break\"><p>a</p><p>b</p><img src=\"/a.jpg\"></div>",
                ),
            )
        }

        @Test
        fun `a scene break cannot swallow a nested block`() {
            assertEquals(
                "<hr><h2>Later</h2><p>The chase began at dawn.</p>",
                HtmlSanitiser.sanitise(
                    "<section class=\"scene-break\"><h2>Later</h2><p>The chase began at dawn.</p></section>",
                ),
            )
        }

        /**
         * Inline markup inside a scene-break slot used to collapse it to a bare
         * `<hr>`; the text is now kept, because the rule is "a leaf of separator
         * glyphs", not "no block tags inside".
         *
         * This is the safe direction on purpose. `* * *` is still exactly
         * `<hr>`; what changes is that a slot whose content is *not* obviously a
         * marker is never silently emptied. A chapter that comes back shorter
         * than the page rendered, still reported as complete, with no signal that
         * anything was missing, is the failure this scanner may not produce.
         */
        @Test
        fun `inline markup inside a scene break keeps its text`() {
            assertEquals(
                "<hr><em>*</em> * *",
                HtmlSanitiser.sanitise("<p class=\"scene-break\"><em>*</em> * *</p>"),
            )
        }

        /**
         * Every shape the review measured losing its prose. Each was stored as a
         * bare `<hr>` before; each keeps its text now.
         */
        @Test
        fun `a scene break holding anything but glyphs keeps its text`() {
            for (body in listOf(
                "<div class=\"scene-break\"><span>One.</span><em>Two.</em></div>",
                "<table class=\"scene-break\"><tr><td>Chapter body in a cell.</td></tr></table>",
                "<thead class=\"scene-break\"><p>A chapter heading.</p></thead>",
                "<a class=\"scene-break\">Click through prose.</a>",
                "<p class=\"scene-break\">End of Chapter 12</p>",
            )) {
                val stored = HtmlSanitiser.sanitise(body)
                assertTrue("$body must keep its text, got $stored", stored.startsWith("<hr>"))
                assertTrue(
                    "$body must keep its text, got $stored",
                    stored.length > "<hr>".length,
                )
            }
        }

        /** A leaf of separator glyphs is still exactly the reader's `<hr>`. */
        @Test
        fun `a leaf of glyphs is still exactly an hr`() {
            for (body in listOf(
                "<p class=\"scene-break\">* * *</p>",
                "<p class=\"scene-break\">***</p>",
                "<p class=\"scene-break\">—</p>",
                "<p class=\"scene-break\">· · ·</p>",
                "<p class=\"scene-break\"></p>",
            )) {
                assertEquals("<hr>", HtmlSanitiser.sanitise(body))
            }
        }

        /** Nested same-named elements must not confuse the container probe. */
        @Test
        fun `nested same-named containers are handled`() {
            assertEquals(
                "<hr><div><p>kept</p></div>",
                HtmlSanitiser.sanitise("<div class=\"scene-break\"><div><p>kept</p></div></div>"),
            )
        }

        /** A body that is entirely scene-break containers is still no prose. */
        @Test
        fun `a body of empty scene breaks has no readable text`() {
            assertFalse(
                HtmlSanitiser.hasReadableText(
                    HtmlSanitiser.sanitise("<div class=\"scene-break\"><p></p></div>".repeat(50)),
                ),
            )
        }
    }

    // =========================================================================
    // REGRESSION: single code points could not be excluded at all.
    //
    // `decodeCharacter` matched its lone code points with `code in 0x00AD`, and
    // `in` in Kotlin needs a *range* on the right, never a scalar. That is not a
    // warning - it does not compile, so the whole app module was unbuildable and
    // none of these checks could run. The three characters below (soft hyphen,
    // Arabic letter mark, Mongolian vowel separator) are the ones that were
    // lost: each is invisible in a browser, so a body made only of them is not
    // prose and must not be stored as a finished chapter. They are equality
    // tests now, which is what the neighbouring ranges always were.
    // =========================================================================

    class SingleCodePointIgnorables {

        private fun readable(html: String): Boolean =
            HtmlSanitiser.hasReadableText(HtmlSanitiser.sanitise(html))

        @Test
        fun `a soft hyphen paragraph is not readable text`() {
            assertFalse(readable("<p>&#173;</p>"))
        }

        @Test
        fun `an Arabic letter mark paragraph is not readable text`() {
            assertFalse(readable("<p>&#1564;</p>"))
        }

        @Test
        fun `a Mongolian vowel separator paragraph is not readable text`() {
            assertFalse(readable("<p>&#6158;</p>"))
        }

        @Test
        fun `a paragraph of only invisible characters is not readable text`() {
            assertFalse(readable("<p>&#173;&#1564;&#6158;&#8291;</p>".repeat(50)))
        }

        /** Real prose either side of them is still prose. */
        @Test
        fun `an ignorable character does not hide the words around it`() {
            assertTrue(readable("<p>&#173;A chapter that actually reads.&#173;</p>"))
        }
    }
}