package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NovelPayloadReadinessTest {
    @Test fun `stream arriving after the novel reference is polled rather than failed`() {
        val initial = "1:[\"${'$'}\",\"component\",null,{\"novel\":\"${'$'}a\"}]\n"
        fun envelope(flight: String) = jsonObject(
            "ok" to Json.Bool(true), "value" to Json.Str("${'$'}a"), "flight" to Json.Str(flight))
        assertFalse(NovelPayloadReadiness.isReady(envelope(initial), "/novel/example"))
        val complete = initial + "a:{\"slug\":\"example\",\"title\":\"Example\",\"synopsis\":\"Synopsis\"}\n"
        assertTrue(NovelPayloadReadiness.isReady(envelope(complete), "/novel/example"))
    }

    @Test fun `native stream recognition works when adapter key search says not ready`() {
        val envelope = jsonObject("ok" to Json.Bool(false), "value" to Json.Null,
            "flight" to Json.Str("7:{\"slug\":\"example\",\"title\":\"Example\",\"synopsis\":\"Synopsis\"}\n"))
        assertTrue(NovelPayloadReadiness.isReady(envelope, "/novel/example"))
        assertFalse(NovelPayloadReadiness.isReady(envelope, "/novel/other"))
    }
}
