package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.Readiness
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.RejectedExecutionHandler
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * The companion's loopback HTTP API (spec sections 7 and 11).
 *
 * **This is not a proxy and never will be.** There is no `CONNECT`, no
 * forwarding, no user-supplied destination and no outbound socket anywhere in
 * this file or in anything it calls: the only thing a client can ask for is one
 * of five operations against novtales.com, validated before it reaches the
 * WebView. A request whose shape suggests proxying is refused by the parser
 * (absolute-form, authority-form and asterisk-form targets) and a method outside
 * the allowlist is refused with 405.
 *
 * **There is no TLS here.** The transport is plaintext because it never leaves
 * the device: the socket is bound to [Config.LOOPBACK_HOST] and the bind address
 * is asserted to be loopback before a single connection is accepted. The
 * website's own traffic stays HTTPS inside the WebView. Nothing in this package
 * installs a trust manager, an `SSLSocket` or an `onReceivedSslError`-style
 * "accept everything" handler, and nothing ever should.
 *
 * Threading: the acceptor and every connection run on daemon threads of a private
 * pool, never on the Android main thread. [start] and [stop] are safe to call
 * repeatedly and the server can be restarted without leaking a thread or a
 * socket.
 *
 * ### Holding the API hostage from the loopback interface
 *
 * Any app on the device can reach this port, and it does so **before** it has
 * presented the pairing key: the pairing key is in the headers, and headers have
 * to be read off the socket first. A peer that opens a connection, sends a
 * request line, and then stops therefore costs nothing to make and used to cost
 * a worker thread for fifteen seconds - four of those exhausted the pool, and a
 * correctly authenticated request then got nothing at all. No key required,
 * because the workers were stuck reading the head, before authentication.
 *
 * The defence is four bounds, all of them in the companion object below and in
 * [Config]:
 *
 *  1. [Config.HEAD_READ_DEADLINE_MS] caps how long one peer may occupy the thread
 *     that is reading it, counted from the first byte it sends and enforced
 *     around every read (see [DeadlineInput]) so that dribbling bytes does not
 *     reset it.
 *  2. A connection cap closes the overflow on the acceptor, without a worker,
 *     so neither the queue nor the kernel backlog can be monopolised.
 *  3. A bounded wait before refusing, so a full queue delays a legitimate reader
 *     rather than turning it into an instant error.
 *  4. Enough workers that a modest burst finds a free one instead of queueing
 *     behind peers that are doing nothing.
 *
 * **What this does not do.** It raises the bar; it does not remove the class.
 * A local peer that holds [WORKER_THREADS] sockets open, refreshing each head
 * inside the deadline, still delays a legitimate request - by up to
 * [Config.HEAD_READ_DEADLINE_MS], not for ever, and not with a key. Eliminating
 * that would need a resumable, event-driven head parser so that an unfinished
 * head costs no thread at all; that is a rewrite of [HttpConnection] and
 * [HttpRequestParser], not a change to this pool.
 *
 * There are no `android.*` imports in this package, so the whole server can be
 * exercised on the JVM with a fake gateway.
 *
 * @param pairingKey the key the plugin must present. It is primed into a
 *   `@Volatile` field by [start] and refreshed by [updatePairingKey] on
 *   rotation; it is never re-read from storage per request.
 * @param gateway the `BrowserGateway` created through
 *   `web.BrowserGatewayFactory.create(context)`, or null when the Android
 *   runtime is unavailable. Null is not "no auth": it means every job fails
 *   with `COMPANION_UNAVAILABLE` and `/v1/health` reports `STOPPED`.
 * @param log receives short operational lines only. It is never given the
 *   pairing key, a cookie, a header value, a request body or chapter text; the
 *   service wires it to `android.util.Log` if it wants one.
 */
class LocalApiServer(
    pairingKey: String,
    gateway: BrowserGateway? = null,
    private val bindHost: String = Config.LOOPBACK_HOST,
    private val port: Int = Config.PORT,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val log: ((String) -> Unit)? = null,
) {

    /**
     * The expected pairing key.
     *
     * `volatile` rather than a plain field so that a rotation made on one thread
     * is visible to every connection thread immediately, with no window in which
     * a request is checked against the previous key - and no window in which a
     * request is checked against nothing at all.
     */
    @Volatile
    private var expectedKey: String = pairingKey

    @Volatile
    private var gateway: BrowserGateway? = gateway

    @Volatile
    private var running: Boolean = false

    private val lifecycleLock = Any()
    private var serverSocket: ServerSocket? = null
    private var pool: ThreadPoolExecutor? = null
    private var acceptor: Thread? = null

    /**
     * The gateway is read lazily through the **property**, not the constructor
     * parameter.
     *
     * A bare `gateway` here would resolve to the constructor parameter captured at
     * initialisation time, so [setGateway] would update the field that `/v1/health`
     * reads while the job queue kept seeing the original — health and the queue
     * would silently disagree, and a server built with `gateway = null` could
     * never be brought to life. `this.gateway` is what makes the swap visible.
     */
    private val runner = JobRunner({ this.gateway }, clock)

    // Both lambdas are read lazily, per request: a rotation or a gateway swap
    // must be visible to the very next request, not to the next server start.
    private val router = ApiRouter(
        runner = runner,
        readiness = { this.readiness },
        pairingKey = { this.expectedKey },
    )

    val isRunning: Boolean get() = running

    /** The port actually bound, or -1 when stopped. Useful with port 0 in tests. */
    val boundPort: Int get() = serverSocket?.localPort ?: -1

    /** `STOPPED` whenever there is no gateway, whatever the transport is doing. */
    val readiness: Readiness get() = gateway?.readiness ?: Readiness.STOPPED

    /** The queue, for the service's own status display and for tests. */
    internal val jobs: JobRunner get() = runner

    private val live = AtomicInteger(0)

    internal val liveConnections: Int get() = live.get()

    /**
     * Binds the loopback socket, starts the worker and the acceptor.
     *
     * @throws IllegalStateException if the bind address is not loopback, if the
     *   socket is already in use, or if no usable pairing key was supplied. The
     *   server refuses to come up in an unauthenticated or publicly reachable
     *   state; failing loudly here is much better than serving.
     */
    fun start() {
        synchronized(lifecycleLock) {
            if (running) return

            val key = expectedKey
            check(key.isNotBlank()) {
                "LocalApiServer needs a pairing key. Refusing to start without one."
            }

            val address = InetAddress.getByName(bindHost)
            check(!address.isAnyLocalAddress && address.isLoopbackAddress) {
                "Refusing to bind $bindHost: the companion API is loopback only."
            }

            val socket = ServerSocket()
            try {
                socket.reuseAddress = true
                socket.bind(InetSocketAddress(address, port), BACKLOG)
            } catch (failure: IOException) {
                closeQuietly(socket)
                throw IllegalStateException(
                    "Could not bind ${Config.LOOPBACK_HOST}:$port (${failure.javaClass.simpleName}).",
                    failure,
                )
            }

            // Assert after binding, not before: this is the check that the
            // operating system actually gave us loopback and not a wildcard
            // address. `isAnyLocalAddress` is 0.0.0.0/::; a wildcard bind would
            // publish the pairing-key API to the whole network.
            val bound = socket.localSocketAddress as? InetSocketAddress
            check(bound != null && bound.address.isLoopbackAddress && !bound.address.isAnyLocalAddress) {
                closeQuietly(socket)
                "Refusing to serve: the socket is not bound to a loopback address."
            }

            val workers = ThreadPoolExecutor(
                WORKER_THREADS,
                WORKER_THREADS,
                30L,
                TimeUnit.SECONDS,
                ArrayBlockingQueue(ACCEPT_QUEUE),
                { runnable -> Thread(runnable, "novtales-api").apply { isDaemon = true } },
                RejectedExecutionHandler { task, executor ->
                    // Neither AbortPolicy (refuse a legitimate reader the instant
                    // the queue is full) nor CallerRunsPolicy (put a hostile
                    // client's head read on the acceptor). Offer it, briefly.
                    if (!executor.isShutdown &&
                        executor.queue.offer(task, ACCEPT_QUEUE_WAIT_MS, TimeUnit.MILLISECONDS)
                    ) {
                        return@RejectedExecutionHandler
                    }
                    throw RejectedExecutionException("the companion API is at its connection limit")
                },
            )

            serverSocket = socket
            pool = workers
            running = true
            runner.start()

            acceptor = Thread({ acceptLoop(socket, workers) }, "novtales-api-accept").apply {
                isDaemon = true
                start()
            }
            log?.invoke("listening on ${Config.LOOPBACK_HOST}:${socket.localPort}")
        }
    }

    /**
     * Stops accepting, closes the listening socket, interrupts the pool and
     * fails every unfinished job with `COMPANION_UNAVAILABLE`. Idempotent.
     */
    fun stop() {
        synchronized(lifecycleLock) {
            if (!running) return
            running = false

            // Fail the jobs before anything else so a client that polls during
            // shutdown gets a real error instead of a job stuck in `loading`.
            runner.stop()

            val socket = serverSocket
            serverSocket = null
            closeQuietly(socket)

            val workers = pool
            pool = null
            workers?.shutdownNow()

            // `shutdownNow` drops whatever was still queued, so those sockets are
            // closed without their `serve` ever running and without the counter
            // ever being decremented. Clearing it here keeps a restart honest;
            // the in-flight workers that do return will decrement against this.
            live.set(0)

            val thread = acceptor
            acceptor = null
            thread?.interrupt()
        }
    }

    /**
     * Installs a freshly rotated pairing key. Called after
     * `PairingKey.rotate(context)`; the next request is checked against the new
     * key. A blank key is ignored rather than installed, because a server that
     * forgot its key must not start behaving like one that requires none.
     */
    fun updatePairingKey(key: String) {
        if (key.isBlank()) {
            log?.invoke("refused to install a blank pairing key")
            return
        }
        expectedKey = key
    }

    /**
     * Replaces the gateway. Null is legal and means "the companion cannot do
     * browser work right now": `/v1/health` reports `STOPPED` and new jobs fail
     * with `COMPANION_UNAVAILABLE`.
     */
    fun setGateway(gateway: BrowserGateway?) {
        this.gateway = gateway
    }

    // ---- Connection handling ------------------------------------------------

    private fun acceptLoop(socket: ServerSocket, workers: ThreadPoolExecutor) {
        while (running && !socket.isClosed) {
            val client = try {
                socket.accept()
            } catch (closed: SocketException) {
                // The expected wake-up on stop().
                if (!running) break
                continue
            } catch (_: IOException) {
                if (!running) break
                continue
            }

            // The hard ceiling on what this server will hold open, sockets and
            // threads alike. Beyond it the connection is closed here, on the
            // acceptor, without a worker ever being involved: an over-limit peer
            // costs one close() and nothing else. This is what stops the accept
            // queue (and the kernel backlog behind it) from being monopolised by
            // connection count alone.
            if (live.incrementAndGet() > MAX_CONNECTIONS) {
                live.decrementAndGet()
                closeQuietly(client)
                continue
            }

            try {
                workers.execute { serve(client) }
            } catch (_: RuntimeException) {
                live.decrementAndGet()
                closeQuietly(client)
            }
        }
    }

    private fun serve(client: Socket) {
        HttpConnection.quietly(log) {
            try {
                client.tcpNoDelay = true
                // The socket's own timeout is only the granularity at which the
                // deadline below is noticed; it is re-armed per read and is never
                // the bound itself. See DeadlineInput.
                client.soTimeout = Config.SOCKET_READ_POLL_MS.toInt()
                val input = DeadlineInput(
                    source = BufferedInputStream(client.getInputStream(), SOCKET_BUFFER_BYTES),
                    clock = clock,
                    retime = { millis -> client.soTimeout = millis },
                )
                val output = BufferedOutputStream(client.getOutputStream(), SOCKET_BUFFER_BYTES)
                HttpConnection(
                    input = input,
                    output = output,
                    clock = clock,
                    onLog = log,
                    handler = RequestHandler { request -> router.handle(request) },
                    readDeadline = input,
                ).serve(clock() + CONNECTION_LIFETIME_MS)
            } finally {
                live.decrementAndGet()
                closeQuietly(client)
            }
        }
    }

    private fun closeQuietly(socket: Socket?) {
        try {
            socket?.close()
        } catch (_: IOException) {
            // Nothing useful to do; the connection is being abandoned anyway.
        }
    }

    private fun closeQuietly(socket: ServerSocket?) {
        try {
            socket?.close()
        } catch (_: IOException) {
            // As above.
        }
    }

    companion object {
        /**
         * Kernel accept backlog. Sized above [MAX_CONNECTIONS] so that the
         * backlog is not the thing that refuses a legitimate connection: the
         * server's own accounting does that, slowly and on purpose.
         */
        private const val BACKLOG = 128

        /**
         * Hard ceiling on connections this server holds open at once.
         *
         * Everything past it is closed by the acceptor without a worker. Chosen
         * to sit above [WORKER_THREADS] + [ACCEPT_QUEUE] so the accept queue can
         * actually fill - a queue that can never fill is a queue that refuses
         * legitimate readers by accident - while the total stays small enough to
         * be a non-event on a phone.
         */
        internal const val MAX_CONNECTIONS = 96

        /**
         * Connection workers.
         *
         * This is the number of peers that can be reading a request head at any
         * one time, and therefore the number an attacker has to exceed before a
         * legitimate request is made to wait. It used to be 4, which eight idle
         * sockets could exhaust; it is sized so that a burst of connections
         * arriving together - a plugin reconnecting while the phone wakes up -
         * still finds a free worker, while a sustained flood has to supply many
         * more sockets than it does threads to make progress, and each socket it
         * supplies is released again after [Config.HEAD_READ_DEADLINE_MS].
         */
        internal const val WORKER_THREADS = 16

        /**
         * Accepted-but-not-yet-served connections. Overflow waits
         * [ACCEPT_QUEUE_WAIT_MS] before being refused rather than being refused
         * on arrival.
         */
        private const val ACCEPT_QUEUE = 64

        /**
         * How long the acceptor will offer a connection to a full queue before
         * giving up on it.
         *
         * The alternative is [ThreadPoolExecutor.AbortPolicy], which refuses a
         * perfectly good connection the instant the queue is full - the "closed
         * in 2 ms" behaviour, where a burst of anything turned a legitimate
         * request into an error with no way to retry in time. Caller-runs is
         * equally wrong: the acceptor would then be blocked reading a hostile
         * client's head, which is the one thread that must never stop
         * accepting. A short bounded offer is the compromise: it delays the
         * acceptor by at most this long, only when the server is already
         * saturated, and it rides out the transient case it exists for.
         */
        private const val ACCEPT_QUEUE_WAIT_MS = 250L

        /** Total wall-clock life of one keep-alive connection. */
        private const val CONNECTION_LIFETIME_MS = 60_000L

        private const val SOCKET_BUFFER_BYTES = 8 * 1024
    }
}