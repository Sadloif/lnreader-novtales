package com.sadloif.novtalescompanion.state

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.sadloif.novtalescompanion.R
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Operation
import com.sadloif.novtalescompanion.core.Paths
import java.util.concurrent.CopyOnWriteArrayList

/**
 * The five states the status screen shows (spec section 5), spelled out rather
 * than collapsed: "Ready", "Loading" and "Needs your attention" mean different
 * things to the reader and must never be merged.
 */
enum class CompanionPhase {
    STOPPED,
    STARTING,
    READY,
    LOADING,
    NEEDS_ATTENTION,
    ERROR,
}

/**
 * Why a running companion stopped. Recorded on disk so the status screen can
 * explain itself on the next launch - after a force-stop, a crash or an Android
 * background limit, the process is gone and nothing else would know.
 */
enum class StopReason {
    /** The user pressed Stop, or the notification's Stop action. */
    USER,

    /** Android ended the dataSync foreground service (the onTimeout callback). */
    TIMEOUT,

    /** The service never came up: port in use, or no WebView available. */
    START_FAILED,

    /** Process death, crash or a system kill. Nothing was asked and nothing ran. */
    UNEXPECTED,
}

/**
 * One immutable view of everything the status screen and the notification show.
 *
 * Every user-facing string in [detail] and [errorMessage] has already been
 * resolved from `strings.xml` by whoever produced the update, so no UI code ever
 * has to build a sentence itself.
 */
data class CompanionSnapshot(
    val phase: CompanionPhase = CompanionPhase.STOPPED,
    val running: Boolean = false,
    val port: Int = Config.PORT,
    val operation: Operation? = null,
    val chapterNumber: String? = null,
    val detail: String? = null,
    val errorCode: ErrorCode? = null,
    val errorMessage: String? = null,
    val networkAvailable: Boolean = true,
    val stopReason: StopReason? = null,
    val stoppedAtMillis: Long = 0L,
    val webViewAttached: Boolean = false,
) {
    /** True while exactly one WebView operation is in flight. */
    val busy: Boolean get() = phase == CompanionPhase.LOADING
}

/**
 * Process-wide, thread-safe holder shared by [com.sadloif.novtalescompanion.service.CompanionService]
 * and [com.sadloif.novtalescompanion.ui.MainActivity].
 *
 * A singleton is deliberate: the Activity must be able to render a truthful
 * status screen while the service is *not* running (the plugin cannot start it,
 * so the screen is often the only place the problem can be reported), and the
 * two run in one process. It is never persisted across process death - a fresh
 * process starts at [CompanionPhase.STOPPED], which is exactly right, because a
 * killed process cannot have a running companion.
 *
 * All mutations are funnelled through [update], which applies the transform and
 * notifies listeners on the main thread, so no view ever observes a half-written
 * snapshot and no listener is called off the main thread.
 */
class CompanionState private constructor() {

    private val lock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    private var current: CompanionSnapshot = CompanionSnapshot()

    /** Single callback shape; kept minimal so a lambda is enough. */
    fun interface Listener {
        fun onCompanionStateChanged(snapshot: CompanionSnapshot)
    }

    fun snapshot(): CompanionSnapshot = current

    /**
     * Registers [listener] and immediately replays the current snapshot, so a
     * screen that subscribes can never render its own placeholder first.
     * Delivery always happens on the main thread.
     */
    fun observe(listener: Listener) {
        listeners.addIfAbsent(listener)
        deliver(listener, current)
    }

    fun unobserve(listener: Listener) {
        listeners.remove(listener)
    }

    /**
     * Applies [transform] and publishes the result. Safe from any thread and
     * from a binder thread; the transform itself always runs under the same lock
     * so two racing updates cannot interleave.
     */
    fun update(transform: (CompanionSnapshot) -> CompanionSnapshot) {
        val published = synchronized(lock) {
            val next = transform(current)
            if (next == current) return
            current = next
            next
        }
        notifyListeners(published)
    }

    /** Convenience for the common "clear everything and stop" reset. */
    fun reset(reason: StopReason, atMillis: Long) {
        update {
            CompanionSnapshot(
                phase = CompanionPhase.STOPPED,
                running = false,
                port = it.port,
                networkAvailable = it.networkAvailable,
                stopReason = reason,
                stoppedAtMillis = atMillis,
            )
        }
    }

    /**
     * Restores the stop reason written by a previous process. Called by both the
     * Activity and the Service at startup; only has an effect while the companion
     * has never run in this process.
     */
    fun seedStopReasonFromDisk(context: Context) {
        if (current.phase != CompanionPhase.STOPPED || current.stopReason != null) return
        val (reason, at) = StopLog.read(context)
        if (reason == null) return
        update { it.copy(stopReason = reason, stoppedAtMillis = at) }
    }

    private fun deliver(listener: Listener, snapshot: CompanionSnapshot) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            listener.onCompanionStateChanged(snapshot)
        } else {
            mainHandler.post { listener.onCompanionStateChanged(current) }
        }
    }

    private fun notifyListeners(snapshot: CompanionSnapshot) {
        if (listeners.isEmpty()) return
        val notify = {
            listeners.forEach { listener ->
                runCatching { listener.onCompanionStateChanged(snapshot) }
            }
            Unit
        }
        if (Looper.myLooper() == Looper.getMainLooper()) notify() else mainHandler.post(notify)
    }

    companion object {
        @Volatile
        private var instance: CompanionState? = null

        fun get(): CompanionState = instance ?: synchronized(CompanionState::class) {
            instance ?: CompanionState().also { instance = it }
        }
    }
}

/**
 * The last stop reason, in ordinary app preferences.
 *
 * Deliberately *not* in [PairingKey]'s private preferences: this is not a secret,
 * and the whole point is that it survives the process that wrote it.
 */
object StopLog {

    private const val PREFS = "novtales_companion_status"
    private const val KEY_REASON = "stop_reason"
    private const val KEY_AT = "stopped_at"

    fun write(context: Context, reason: StopReason, atMillis: Long) {
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_REASON, reason.name)
            .putLong(KEY_AT, atMillis)
            .apply()
    }

    fun read(context: Context): Pair<StopReason?, Long> {
        val prefs = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val reason = prefs.getString(KEY_REASON, null)
            ?.let { name -> StopReason.entries.firstOrNull { it.name == name } }
        return reason to (if (reason == null) 0L else prefs.getLong(KEY_AT, 0L))
    }

    fun clear(context: Context) {
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_REASON)
            .remove(KEY_AT)
            .apply()
    }
}

/** Display name for the five operations, always from `strings.xml`. */
fun Operation.displayName(context: Context): String = context.getString(
    when (this) {
        Operation.CATALOGUE -> R.string.operation_catalogue
        Operation.SEARCH -> R.string.operation_search
        Operation.NOVEL -> R.string.operation_novel
        Operation.CHAPTERS -> R.string.operation_chapters
        Operation.CHAPTER -> R.string.operation_chapter
    },
)

/**
 * "Fetching chapter 12" style label for whatever the companion is doing right
 * now, or null when it is idle. Chapter numbers are passed through exactly as
 * [Paths.chapterNumber] produced them, so `12.5` never becomes `12` or `12.0`.
 */
fun currentWorkLabel(context: Context, operation: Operation?, chapterNumber: String?): String? {
    if (operation == null) return null
    return when (operation) {
        Operation.CHAPTER -> chapterNumber
            ?.let { context.getString(R.string.work_chapter, it) }
            ?: context.getString(R.string.work_any_chapter)
        Operation.CHAPTERS -> context.getString(R.string.work_chapters)
        else -> context.getString(R.string.work_generic, operation.displayName(context))
    }
}