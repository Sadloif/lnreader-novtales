package com.sadloif.novtalescompanion.ui

import android.content.Context
import com.sadloif.novtalescompanion.R
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.state.CompanionPhase
import com.sadloif.novtalescompanion.state.CompanionSnapshot
import com.sadloif.novtalescompanion.state.CompanionState
import com.sadloif.novtalescompanion.state.StopReason
import com.sadloif.novtalescompanion.state.currentWorkLabel
import java.util.Date
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Turns the raw [CompanionSnapshot] into everything the status screen draws:
 * resolved strings, a title, an icon, and which controls should be usable.
 *
 * ## Why this does not extend `androidx.lifecycle.ViewModel`
 *
 * The build file is fixed and declares `core-ktx`, `appcompat`,
 * `lifecycle-service` and `kotlinx-coroutines-android`. It does **not** declare
 * `lifecycle-viewmodel-ktx`, so the `by viewModels()` delegate and
 * `lifecycleScope` are simply not on the classpath, and adding them is not an
 * option. Rather than depend on a transitive classpath edge that may or may not
 * resolve, this is a plain class: the Activity keeps one instance, re-subscribes
 * it in `onStart`, unsubscribes it in `onStop`, and hands it back to the system
 * across a configuration change through `onRetainCustomNonConfigurationInstance`.
 * That gives the same behaviour with nothing extra on the classpath.
 *
 * It holds the **application** context, never the Activity, so retaining it
 * across a configuration change can never leak a window.
 */
class StatusViewModel(
    private val context: Context,
    private val state: CompanionState = CompanionState.get(),
) {

    /** Everything the screen needs, already resolved and ready to apply. */
    data class UiModel(
        val phase: CompanionPhase,
        val title: String,
        val detail: String,
        val iconRes: Int,
        val iconDescription: String,
        val iconTintRes: Int,
        val running: Boolean,
        val busy: Boolean,
        val workLabel: String?,
        val activitySummary: String,
        val errorMessage: String?,
        val networkWarning: String?,
        val stopNote: String?,
        val endpoint: String,
        val webViewAttached: Boolean,
        val websiteAvailable: Boolean,
        val startEnabled: Boolean,
        val stopEnabled: Boolean,
    )

    fun interface Listener {
        fun onStatusChanged(model: UiModel)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()

    private val stateListener = CompanionState.Listener { snapshot ->
        publish(snapshot)
    }

    /** Begins mirroring the service state. Safe to call more than once. */
    fun start() {
        state.observe(stateListener)
    }

    /** Stops mirroring. Called from `onStop`, so no listener outlives the screen. */
    fun stop() {
        state.unobserve(stateListener)
    }

    fun observe(listener: Listener) {
        listeners.addIfAbsent(listener)
        listener.onStatusChanged(buildModel(state.snapshot()))
    }

    fun unobserve(listener: Listener) {
        listeners.remove(listener)
    }

    /** Releases everything. Called from `onDestroy`. */
    fun clear() {
        stop()
        listeners.clear()
    }

    private fun publish(snapshot: CompanionSnapshot) {
        if (listeners.isEmpty()) return
        val next = buildModel(snapshot)
        listeners.forEach { listener ->
            runCatching { listener.onStatusChanged(next) }
        }
    }

    // ---- Derivation ---------------------------------------------------------

    private fun buildModel(snapshot: CompanionSnapshot): UiModel {
        val running = snapshot.running && snapshot.phase != CompanionPhase.STOPPED
        val work = currentWorkLabel(context, snapshot.operation, snapshot.chapterNumber)

        return UiModel(
            phase = snapshot.phase,
            title = context.getString(titleOf(snapshot.phase)),
            detail = context.getString(detailOf(snapshot.phase)),
            iconRes = iconOf(snapshot.phase),
            iconDescription = context.getString(R.string.status_icon_description),
            iconTintRes = tintOf(snapshot.phase),
            running = running,
            busy = snapshot.busy,
            workLabel = work,
            activitySummary = work ?: context.getString(R.string.work_idle),
            errorMessage = snapshot.errorMessage,
            networkWarning = if (snapshot.networkAvailable) {
                null
            } else {
                context.getString(R.string.warning_no_internet)
            },
            stopNote = stopNote(snapshot),
            endpoint = context.getString(
                R.string.endpoint_value,
                Config.LOOPBACK_HOST,
                if (snapshot.port > 0) snapshot.port else Config.PORT,
            ),
            webViewAttached = snapshot.webViewAttached,
            // The WebView belongs to the service, so the website only exists while
            // the service is up. Saying so plainly beats an empty screen.
            websiteAvailable = running,
            startEnabled = !running,
            stopEnabled = running,
        )
    }

    private fun titleOf(phase: CompanionPhase): Int = when (phase) {
        CompanionPhase.STOPPED -> R.string.status_stopped
        CompanionPhase.STARTING -> R.string.status_starting
        CompanionPhase.READY -> R.string.status_ready
        CompanionPhase.LOADING -> R.string.status_loading
        CompanionPhase.NEEDS_ATTENTION -> R.string.status_needs_attention
        CompanionPhase.ERROR -> R.string.status_error
    }

    private fun detailOf(phase: CompanionPhase): Int = when (phase) {
        CompanionPhase.STOPPED -> R.string.status_detail_stopped
        CompanionPhase.STARTING -> R.string.status_detail_starting
        CompanionPhase.READY -> R.string.status_detail_ready
        CompanionPhase.LOADING -> R.string.status_detail_loading
        CompanionPhase.NEEDS_ATTENTION -> R.string.status_detail_needs_attention
        CompanionPhase.ERROR -> R.string.status_detail_error
    }

    private fun iconOf(phase: CompanionPhase): Int = when (phase) {
        CompanionPhase.STOPPED -> R.drawable.ic_status_stopped
        CompanionPhase.STARTING -> R.drawable.ic_status_starting
        CompanionPhase.READY -> R.drawable.ic_status_ready
        CompanionPhase.LOADING -> R.drawable.ic_status_loading
        CompanionPhase.NEEDS_ATTENTION -> R.drawable.ic_status_needs_attention
        CompanionPhase.ERROR -> R.drawable.ic_status_error
    }

    private fun tintOf(phase: CompanionPhase): Int = when (phase) {
        CompanionPhase.STOPPED -> R.color.companion_status_stopped
        CompanionPhase.STARTING -> R.color.companion_status_loading
        CompanionPhase.READY -> R.color.companion_status_ready
        CompanionPhase.LOADING -> R.color.companion_status_loading
        CompanionPhase.NEEDS_ATTENTION -> R.color.companion_status_attention
        CompanionPhase.ERROR -> R.color.companion_status_error
    }

    /**
     * Explains a stop that the user did not ask for. A Stop from a previous
     * session is only interesting while it is still recent, so an old one is left
     * off the screen rather than cluttering it days later.
     */
    private fun stopNote(snapshot: CompanionSnapshot): String? {
        if (snapshot.phase != CompanionPhase.STOPPED) return null
        val reason = snapshot.stopReason ?: return null
        val at = snapshot.stoppedAtMillis
        if (at <= 0L) return null
        if (System.currentTimeMillis() - at > STOP_NOTE_WINDOW_MS) return null

        val time = android.text.format.DateFormat.getTimeFormat(context).format(Date(at))
        return context.getString(
            when (reason) {
                StopReason.USER -> R.string.stop_note_user
                StopReason.TIMEOUT -> R.string.stop_note_timeout
                StopReason.START_FAILED -> R.string.stop_note_start_failed
                StopReason.UNEXPECTED -> R.string.stop_note_unexpected
            },
            time,
        )
    }

    private companion object {
        /** Stop reasons older than this are history, not news. */
        const val STOP_NOTE_WINDOW_MS = 12L * 60L * 60L * 1000L
    }
}