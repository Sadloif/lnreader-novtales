package com.sadloif.novtalescompanion.web

import android.view.ViewGroup
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest

/**
 * The seam between the local API (subagent A) and the browser (subagent B).
 *
 * Defined exactly as CONTRACTS.md section 2 specifies it, so A can be written
 * and unit tested against this interface without a WebView existing. A must
 * construct an implementation through [BrowserGatewayFactory] and must never
 * reference a concrete WebView class.
 *
 * Implemented by [WebViewBrowserGateway].
 */
interface BrowserGateway {

    /** Readiness, shown on the status screen and returned by GET /v1/health. */
    val readiness: Readiness

    /**
     * Submits one operation and suspends until it settles.
     *
     * Implementations must:
     *  - verify the operation is one of the five and that its path is already
     *    normalised by Paths.normalise;
     *  - never return a partial result - only a complete one;
     *  - throw CompanionException with a specific ErrorCode on every failure;
     *  - return a `needs_user` outcome by throwing
     *    CompanionException(ErrorCode.VERIFICATION_REQUIRED | SIGN_IN_REQUIRED |
     *    MEMBERSHIP_REQUIRED, ...).
     */
    suspend fun execute(request: JobRequest, deadlineMs: Long): Json

    /** Cancels whatever is in flight. Pending jobs are failed by the caller. */
    fun cancelActive()

    /** Sign-out, session reset and account change must clear identity-sensitive state. */
    fun onSessionCleared()
}

/** Readiness as the user sees it. Reported by `/v1/health` and the status screen. */
enum class Readiness { STOPPED, READY, LOADING, NEEDS_ATTENTION, ERROR }

/**
 * The optional surface a gateway exposes when it owns a real browser surface.
 *
 * This is deliberately **not** on [BrowserGateway]: the API layer must not be
 * able to reach a View. The Activity that shows the website casts to this, and
 * [asBrowserSurface] does that cast for it.
 *
 * Both methods are idempotent and safe to call from any state - before the
 * WebView exists, while a job is running, twice in a row, and while the renderer
 * is gone.
 */
interface BrowserSurface {

    /**
     * Puts the service-owned WebView into [container] so the reader can look at
     * the site, sign in, or clear a verification challenge.
     *
     * The WebView is created if it does not exist yet, moved out of any previous
     * parent first, and otherwise left completely alone: no reload, no cookie
     * reset, no cache clear, no DOM rebuild, no session loss.
     */
    fun attachTo(container: ViewGroup)

    /**
     * Takes the WebView back out of whatever container holds it.
     *
     * Detaching never destroys the WebView and never touches cookies, cache, DOM
     * or the site session. In-flight work is not disturbed.
     */
    fun detach()

    /** True while the WebView is parented by a container. */
    val isAttached: Boolean

    /** Tears the WebView down for good. Call from the service's `onDestroy`. */
    fun shutdown()
}

/** Convenience for the Activity: the gateway as a view surface, or null. */
fun BrowserGateway.asBrowserSurface(): BrowserSurface? = this as? BrowserSurface
