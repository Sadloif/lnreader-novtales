package com.sadloif.novtalescompanion.web

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.MainThread
import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Operation
import com.sadloif.novtalescompanion.core.Paths
import com.sadloif.novtalescompanion.core.jsonObject
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.ref.WeakReference
import java.security.MessageDigest
import kotlinx.coroutines.CancellableContinuation
import kotlin.coroutines.resume

/**
 * The paging rule for the `chapters` operation, as pure functions.
 *
 * ## Why this exists
 *
 * Each `chapters` response must contain the requested ascending slice and the
 * count of the whole novel. `runChapters` fetches the site's descending index
 * pages overlapping that slice, then [NovTalesExtraction.chapterWindow] checks
 * their counts and extracts the requested window. These helpers also support
 * slicing an already complete list. A page beyond the end is an empty list.
 *
 * ## Why it is a separate object
 *
 * The gateway class itself carries `android.*` imports and cannot be constructed
 * off-device. These functions are pure and carry none, so the paging contract is
 * unit-testable on the JVM without a WebView - which is the only way a regression
 * here would ever be caught rather than discovered in the reader.
 *
 * The page size is **not** declared here. [WebViewBrowserGateway.CHAPTER_PAGE_SIZE]
 * is the one and only named page size in the app; `runChapters` passes it in, and
 * this object refuses to invent a default that could drift from it.
 */
internal object ChapterPaging {

    /**
     * The 1-based slice of [chapters] belonging to [page], at [pageSize] per page.
     *
     * Ascending order and the caller's de-duplication are preserved because this
     * only cuts the list - it never reorders or rebuilds it. A [page] below 1, a
     * [pageSize] below 1 and a [page] past the end all return an empty list: an
     * out-of-range page is a normal answer, not a failure.
     *
     * The arithmetic is done in [Long] because `page` is bounded by the validator
     * at 100,000 and an `Int` multiply would be the only place in the adapter where
     * a hostile number could wrap.
     */
    fun slice(chapters: List<Json>, page: Int, pageSize: Int): List<Json> {
        if (page < 1 || pageSize < 1) return emptyList()
        val start = (page.toLong() - 1L) * pageSize.toLong()
        if (start >= chapters.size.toLong()) return emptyList()
        val from = start.toInt()
        val to = minOf(chapters.size.toLong(), start + pageSize.toLong()).toInt()
        return chapters.subList(from, to)
    }

    /** `ceil(count / pageSize)`, never below 1 - an empty novel still has one page. */
    fun totalPages(count: Int, pageSize: Int): Int {
        if (pageSize < 1) return 1
        if (count <= 0) return 1
        return ((count.toLong() + pageSize.toLong() - 1L) / pageSize.toLong()).toInt()
    }

    /**
     * The wire result for one `chapters` page.
     *
     * `chapters` is the requested slice. `chapterCount` and `totalPages` describe
     * the **whole** novel at the same page size, and exist so a client can learn
     * how many pages there are from the first response instead of crawling every
     * page to find out. They are additive: a client that only reads `chapters` is
     * unaffected.
     */
    fun pageResult(chapters: Json, page: Int, pageSize: Int): Json {
        val list = chapters.arr("chapters")?.items ?: emptyList()
        return jsonObject(
            "chapters" to Json.Arr(slice(list, page, pageSize)),
            "chapterCount" to Json.Num(list.size.toDouble()),
            "totalPages" to Json.Num(totalPages(list.size, pageSize).toDouble()),
        )
    }
}

/** Validated source pages from one document, bounded to a first page and neighbours. */
internal class IndexPageSnapshot(
    val first: Json,
    private val pageSize: Int,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    val total: Int = NovTalesExtraction.validateIndexPage(first, 1, pageSize)
    private val createdAt = clock()
    private val pages = object : LinkedHashMap<Int, Json>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, Json>): Boolean = size > 7
    }

    fun isFresh(): Boolean = clock() - createdAt in 0L..300_000L
    fun page(index: Int): Json? = if (!isFresh()) null else if (index == 1) first else pages[index]
    fun remember(index: Int, body: Json) {
        NovTalesExtraction.validateIndexPage(body, index, pageSize, total)
        if (index != 1) pages[index] = body
    }
}

/**
 * The real browser worker: one long-lived WebView, owned by the service.
 *
 * ## Why the WebView outlives the Activity
 *
 * The reader switches between the companion and LNReader constantly, so the
 * WebView is created with the **application** context and is never given an
 * Activity context. [attachTo] moves that same instance into an Activity's
 * container and [detach] takes it back out; neither destroys it, neither reloads
 * it, and neither touches cookies, cache, DOM or the site session. That is the
 * entire point of the project: the sign-in and the challenge the user solved in
 * the companion are still there ten minutes later when a chapter is requested.
 *
 * ## Threading (spec section 1 and 6)
 *
 * Every WebView call happens inside `withContext(Dispatchers.Main)`; the instance
 * is created, used and destroyed on the main thread and nowhere else. Parsing,
 * sanitising and the Next.js payload walk run on the IO dispatcher. Waiting is
 * always `suspendCancellableCoroutine` driven by `WebViewClient` callbacks - no
 * latch is ever blocked on, so the main thread is never held up by the network.
 * [execute] is serialised by a [Mutex], so two simultaneous LNReader requests
 * can never fight over one page.
 *
 * ## Security (spec section 11)
 *
 * Only `https://novtales.com` and its subdomains plus `about:blank` may be
 * loaded; everything else is refused in `shouldOverrideUrlLoading` by returning
 * true. There is **no** `addJavascriptInterface`, **no** override of
 * `onReceivedSslError`, **no** trust-all TrustManager and Safe Browsing is left
 * on. Page data is read with `evaluateJavascript` and revalidated natively.
 */
class WebViewBrowserGateway private constructor(
    private val appContext: Context,
    private val pageAdapter: PageAdapter,
    private val io: CoroutineDispatcher,
    private val cache: ResultCache,
) : BrowserGateway, BrowserSurface {

    companion object {
        /** How often the growing chapter page is sampled, in milliseconds. */
        const val POLL_INTERVAL_CHAPTER_MS = 400L

        /** Metadata pages settle faster and are polled less often. */
        const val POLL_INTERVAL_METADATA_MS = 350L

        /**
         * Consecutive polls with no growth, no spinner and no load-more control
         * after which the page is declared stalled. Roughly eight seconds, which
         * is far longer than any observed gap between streamed parts.
         */
        const val STALL_POLLS = 20

        /** Polls before an unreadable metadata page is called a site change. */
        const val GIVE_UP_POLLS = 14

        /**
         * The one and only chapter page size in the app.
         *
         * It is asked of the public chapter index, and it is also the width of the
         * `chapters` slice the local API returns for `page: n`, so the site's page
         * and the reader's page cannot disagree. See [ChapterPaging].
         */
        const val CHAPTER_PAGE_SIZE = 50

        /** Bounded cache; see [ResultCache]. */
        const val MAX_CACHE_ENTRIES = 40

        /**
         * Builds a gateway, or returns null when there is no usable Android
         * runtime - which is what keeps the HTTP server unit-testable off-device.
         */
        fun create(context: Context): WebViewBrowserGateway? = try {
            val app = context.applicationContext
            WebViewBrowserGateway(
                appContext = app,
                pageAdapter = PageAdapter.fromContext(app),
                io = Dispatchers.IO,
                cache = ResultCache(MAX_CACHE_ENTRIES),
            )
        } catch (_: Throwable) {
            // A stubbed android.jar on the JVM throws here.
            null
        }
    }

    // ---- State --------------------------------------------------------------

    private val mainHandler = Handler(Looper.getMainLooper())
    private val renderHost = BrowserRenderHost(appContext)

    @Volatile
    private var currentReadiness: Readiness = Readiness.READY

    /** Main thread only for every read and write; volatile for cross-thread guards. */
    @Volatile
    private var webView: WebView? = null

    @Volatile
    private var attachedContainer = WeakReference<ViewGroup>(null)

    @Volatile
    private var activeSession: OperationSession? = null

    /** A validated snapshot for this document; the first page pins its total. */
    private class IndexContext(
        val view: WebView,
        val path: String,
        val identity: String,
        val snapshot: IndexPageSnapshot,
    )
    @Volatile private var indexContext: IndexContext? = null

    /** One operation at a time, no matter how many readers ask at once. */
    private val operationMutex = Mutex()

    /** Main thread only. */
    private var navigationWaiter: CancellableContinuation<NavOutcome>? = null

    @Volatile private var pendingAttention: CompanionException? = null
    private var pendingAttentionPath: String? = null

    /** Reset on every navigation; read by the poll loop. */
    @Volatile
    private var lastMainFrameStatus: Int? = null
    @Volatile
    private var challengeHeaderSeen = false
    @Volatile
    private var rateLimitedHeaderSeen = false
    @Volatile
    private var rendererGone = false

    /** Bumped by [onSessionCleared]; part of every cache key. */
    @Volatile
    private var identityEpoch = 0L

    override val readiness: Readiness get() = currentReadiness

    /** A human-readable reason for the current [Readiness.ERROR], for the status screen. */
    @Volatile
    var lastFailureMessage: String? = null
        private set

    override val isAttached: Boolean get() = attachedContainer.get() != null

    // ---- BrowserGateway -----------------------------------------------------

    override suspend fun execute(request: JobRequest, deadlineMs: Long): Json =
        operationMutex.withLock {
            pendingAttention?.let { previous ->
                if (AttentionPolicy.preserves(previous.code, pendingAttentionPath, request)) {
                    val view = webViewForWork()
                    // Keep the human's check on screen instead of navigating over it.
                    pageAdapter.inject(view)
                    if (attentionOrNull(view) != null) throw previous
                }
                pendingAttention = null
                pendingAttentionPath = null
            }
            val plan = plan(request)
            val identity = identity()
            cache.get(identity, plan.cacheKey)?.let { return@withLock it }

            val session = OperationSession()
            if (plan.operation != Operation.CHAPTERS) indexContext = null
            activeSession = session
            currentReadiness = Readiness.LOADING
            try {
                val result = try {
                    withTimeout(deadlineMs) { runPlan(plan, session) }
                } catch (_: TimeoutCancellationException) {
                    session.fail(
                        CompanionException.timeout("${plan.describe()} (${session.stage})")
                    )
                    throw if (plan.operation == Operation.CHAPTER) {
                        // Spec section 4: a chapter whose marker never appeared is
                        // INCOMPLETE_CHAPTER, and saying so is far more useful to
                        // the reader than a bare timeout.
                        CompanionException(
                            ErrorCode.INCOMPLETE_CHAPTER,
                            "NovTales never delivered the end of chapter ${plan.chapterNumber}. " +
                                "Nothing was saved, because an unfinished chapter is not a chapter.",
                        )
                    } else {
                        CompanionException.timeout("${plan.describe()} (${session.stage})")
                    }
                }
                checkCancelled(session)
                if (identity == identity()) cache.put(identity, plan.cacheKey, result)
                currentReadiness = Readiness.READY
                result
            } catch (error: CompanionException) {
                currentReadiness = when (error.code) {
                    ErrorCode.VERIFICATION_REQUIRED,
                    ErrorCode.SIGN_IN_REQUIRED,
                    ErrorCode.MEMBERSHIP_REQUIRED,
                    ErrorCode.READING_NOTICE_REQUIRED,
                    -> Readiness.NEEDS_ATTENTION
                    ErrorCode.SITE_CHANGED -> Readiness.ERROR
                    else -> Readiness.ERROR
                }
                if (currentReadiness == Readiness.NEEDS_ATTENTION) {
                    pendingAttention = error
                    pendingAttentionPath = request.path
                }
                lastFailureMessage = error.message
                if (error.code == ErrorCode.SITE_CHANGED && rendererGone) {
                    lastFailureMessage = error.message
                }
                throw error
            } finally {
                if (activeSession === session) activeSession = null
                val keepIndex = plan.operation == Operation.CHAPTERS && currentReadiness == Readiness.READY && indexContext != null
                if (!keepIndex) indexContext = null
                if (pendingAttention == null && currentReadiness != Readiness.ERROR && !keepIndex) resetPageQuietly()
            }
        }

    override fun cancelActive() {
        val session = activeSession
        if (session != null) {
            session.fail(CompanionException(ErrorCode.CANCELLED, "The companion cancelled this job."))
        }
        mainHandler.post {
            try {
                webView?.stopLoading()
            } catch (_: RuntimeException) {
                // A destroyed WebView throws here; nothing to stop.
            }
            failNavigation(CompanionException(ErrorCode.CANCELLED, "The companion cancelled this job."))
        }
    }

    /**
     * Sign-out, account change or a session reset.
     *
     * The epoch bump is what makes every cached entry unreachable, and the cache
     * is wiped outright, so one account's chapter content can never be served to
     * another as an access fallback. The WebView, its cookies and its session are
     * deliberately left alone: clearing the *site* session is [clearSiteSession].
     */
    override fun onSessionCleared() {
        cancelActive()
        indexContext = null
        pendingAttention = null
        pendingAttentionPath = null
        identityEpoch++
        cache.clear()
        currentReadiness = Readiness.READY
    }

    /**
     * Signs out of novtales.com in the WebView and wipes every cached result.
     *
     * Separate from [onSessionCleared] because the service may call the latter
     * for reasons that must not sign the user out of the website.
     */
    @MainThread
    fun clearSiteSession() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: RuntimeException) {
            // Nothing to clear.
        }
        onSessionCleared()
    }

    // ---- BrowserSurface -----------------------------------------------------

    /**
     * Parks the service-owned WebView in [container].
     *
     * Creates it if this is the first call, moves it out of any previous parent,
     * and otherwise touches nothing: same instance, same DOM, same cookies, same
     * cache, same scroll position. Calling it twice with the same container is a
     * no-op, and calling it while a job is running does not disturb the job.
     */
    @MainThread
    override fun attachTo(container: ViewGroup) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            // Called from the wrong thread: hop rather than touch a View illegally
            // or crash a UI the user is looking at.
            mainHandler.post { attachTo(container) }
            return
        }
        val view = webView ?: createWebView()
        val parent = view.parent
        if (parent === container) {
            attachedContainer = WeakReference(container)
            return
        }
        if (parent is ViewGroup) parent.removeView(view)
        // Always fresh params: reusing the previous parent's LayoutParams can be
        // the wrong type for the new container.
        container.addView(view, defaultLayoutParams())
        attachedContainer = WeakReference(container)
        if (activeSession == null && (view.url == null || view.url == "about:blank")) {
            resetNavigationSignals()
            view.loadUrl(Config.SITE_ORIGIN)
        }
    }

    /**
     * Takes the WebView back out of its container.
     *
     * Never destroys it and never resets cookies, cache, DOM or the session.
     * Safe to call when nothing is attached, twice in a row, or before the
     * WebView has ever been created.
     */
    @MainThread
    override fun detach() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { detach() }
            return
        }
        val view = webView
        (view?.parent as? ViewGroup)?.removeView(view)
        attachedContainer = WeakReference(null)
        if (view != null) renderHost.park(view)
    }

    /** Suspending form of [attachTo] for callers that are not on the main thread. */
    suspend fun attachToAsync(container: ViewGroup) = withContext(Dispatchers.Main) { attachTo(container) }

    /** Suspending form of [detach]. */
    suspend fun detachAsync() = withContext(Dispatchers.Main) { detach() }

    /** Destroys the WebView for good. Call from the service's `onDestroy`. */
    @MainThread
    override fun shutdown() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { shutdown() }
            return
        }
        cancelActive()
        val view = webView
        indexContext = null
        webView = null
        attachedContainer = WeakReference(null)
        navigationWaiter = null
        rendererGone = false
        currentReadiness = Readiness.STOPPED
        cache.clear()
        renderHost.close()
        if (view != null) {
            (view.parent as? ViewGroup)?.removeView(view)
            try {
                view.stopLoading()
                view.destroy()
            } catch (_: RuntimeException) {
                // Already torn down by the platform.
            }
        }
        try {
            CookieManager.getInstance().flush()
        } catch (_: RuntimeException) {
            // No cookie store on this platform.
        }
    }

    // ---- WebView lifecycle (main thread only) -------------------------------

    private fun createWebView(): WebView {
        val view = WebView(appContext)
        configure(view)
        webView = view
        rendererGone = false
        lastFailureMessage = null
        currentReadiness = Readiness.READY
        renderHost.park(view)
        return view
    }

    @Suppress("DEPRECATION")
    private fun configure(view: WebView) {
        view.setBackgroundColor(0xFF0B0B10.toInt())
        view.isVerticalScrollBarEnabled = true
        view.isHorizontalScrollBarEnabled = false

        val settings: WebSettings = view.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true

        // No file:// and no content://, ever, and no way for a file URL to reach
        // the network or the DOM.
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.setGeolocationEnabled(false)
        settings.setSupportMultipleWindows(false)
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.mediaPlaybackRequiresUserGesture = true
        settings.loadsImagesAutomatically = true

        // Set once, here, and never changed again: the user agent belongs to the
        // service lifetime, not to whatever page is currently loaded. Safe
        // Browsing is left at its default (enabled); nothing here disables it.
        // Note this is a static factory taking a Context, not an instance getter.
        settings.userAgentString = WebSettings.getDefaultUserAgent(appContext)

        view.webViewClient = BrowserClient()
        view.webChromeClient = object : WebChromeClient() {}

        try {
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(view, false)
        } catch (_: RuntimeException) {
            // Older platforms without a cookie store still browse fine.
        }
    }

    private fun defaultLayoutParams(): ViewGroup.LayoutParams =
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    /** Returns the live WebView, creating it if needed. Always called on main. */
    @MainThread
    private fun requireWebView(): WebView = webView ?: createWebView()

    private suspend fun webViewForWork(): WebView = withContext(Dispatchers.Main) {
        requireWebView().also { if (it.parent == null) renderHost.park(it) }
    }

    @MainThread
    private fun prepareViewport(view: WebView) {
        val metrics = appContext.resources.displayMetrics
        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(metrics.widthPixels, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(metrics.heightPixels, android.view.View.MeasureSpec.EXACTLY))
        view.layout(0, 0, metrics.widthPixels, metrics.heightPixels)
        view.onResume()
    }

    // ---- Navigation ---------------------------------------------------------

    private sealed interface NavOutcome {
        data class Loaded(val url: String) : NavOutcome
        data class Failed(val error: CompanionException) : NavOutcome
    }

    /**
     * Loads [url] and suspends until its main document commits, with no latch and no
     * main-thread block. A renderer crash or a cancelled job resumes the waiter
     * with a failure rather than leaving the job hanging.
     */
    private suspend fun navigate(url: String, session: OperationSession): String {
        indexContext = null
        session.stage = "opening the website page"
        val outcome = withContext(Dispatchers.Main) {
            val view = requireWebView()
            if (view.parent == null) prepareViewport(view)
            navigationWaiter = null
            resetNavigationSignals()
            // The explicit type argument matters: without it Kotlin infers
            // `NavOutcome?` from the assignment below and the `when` below stops
            // being exhaustive.
            suspendCancellableCoroutine<NavOutcome> { continuation ->

                navigationWaiter = continuation
                continuation.invokeOnCancellation {
                    mainHandler.post { if (navigationWaiter === continuation) navigationWaiter = null }
                }
                view.loadUrl(url)
            }
        }
        return when (outcome) {
            is NavOutcome.Loaded -> outcome.url
            is NavOutcome.Failed -> throw outcome.error
        }
    }

    /** Must run on the main thread. */
    private fun completeNavigation(outcome: NavOutcome) {
        val waiter = navigationWaiter ?: return
        navigationWaiter = null
        if (waiter.isActive) waiter.resume(outcome)
    }

    private fun failNavigation(error: CompanionException) = completeNavigation(NavOutcome.Failed(error))

    private fun resetNavigationSignals() {
        lastMainFrameStatus = null
        challengeHeaderSeen = false
        rateLimitedHeaderSeen = false
    }

    /**
     * Loads `about:blank` between document-extraction operations so the next one
     * cannot read a previous page's DOM. Validated index requests alone may keep
     * the same novel document and fetch explicit API URLs. Runs in a `finally`, including after a cancellation,
     * so a half-finished load is never inherited by the next job.
     *
     * This is deliberately *not* what [detach] does: detaching preserves the
     * page a user is looking at; this clears state between machine operations.
     */
    private suspend fun resetPageQuietly() {
        indexContext = null
        val view = webView ?: return
        // NonCancellable: this must still run after the caller's coroutine was
        // cancelled, or a half-finished page would be inherited by the next job.
        withContext(NonCancellable + Dispatchers.Main) {
            navigationWaiter = null
            try {
                view.loadUrl("about:blank")
                view.clearHistory()
                resetNavigationSignals()
            } catch (_: RuntimeException) {
                // Renderer gone or WebView destroyed; a new one is made on demand.
            }
        }
    }

    // ---- The WebViewClient --------------------------------------------------

    private inner class BrowserClient : WebViewClient() {

        /**
         * Navigation allow-list. Anything that is not `https://novtales.com`, a
         * subdomain of it, or `about:blank` is refused here by returning true,
         * which is what stops `file://`, `content://`, `intent://` and
         * `javascript:` from ever being followed.
         */
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            if (request.isForMainFrame) !isAllowed(request.url)
            else request.url.scheme != "https" && !isAllowed(request.url)

        /**
         * Belt and braces for the allow-list: a redirect that somehow reaches
         * the engine is stopped rather than followed.
         */
        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            if (view == null || view !== webView || url == null) return
            val allowed = try {
                isAllowed(Uri.parse(url))
            } catch (_: RuntimeException) {
                false
            }
            if (!allowed) {
                try {
                    view?.stopLoading()
                } catch (_: RuntimeException) {
                    // Already stopped.
                }
                failNavigation(
                    CompanionException(
                        ErrorCode.SITE_CHANGED,
                        "NovTales tried to navigate outside novtales.com and the companion blocked it.",
                    )
                )
            } else if (url != "about:blank" && activeSession == null && navigationWaiter == null) {
                indexContext = null
                // Reset when a human starts another navigation. A delayed
                // machine finish must not erase captured warning signals.
                resetNavigationSignals()
            }
        }

        override fun onPageCommitVisible(view: WebView?, url: String?) {
            if (view == null || view !== webView || url == null || url == "about:blank" || url != view.url) return
            // The new main document is available. Images and other resources
            // must not hold up metadata/index work. Payload and intervention
            // validation still run before any result is returned.
            completeNavigation(NavOutcome.Loaded(url))
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            if (view == null || view !== webView || url == null || url == "about:blank" || url != view.url) return
            completeNavigation(NavOutcome.Loaded(url))
        }

        /**
         * The only place a browser-verification verdict can come from, and only
         * from a **verified marker**: the `x-vercel-mitigated: challenge` or
         * `cf-mitigated: challenge` response header. A bare HTTP 429 sets
         * `rateLimitedHeaderSeen` and nothing else, so it can never be reported
         * as verification (spec section 10).
         */
        override fun onReceivedHttpError(
            view: WebView?,
            request: WebResourceRequest?,
            errorResponse: WebResourceResponse?,
        ) {
            if (request?.isForMainFrame != true) return
            val response = errorResponse ?: return
            lastMainFrameStatus = response.statusCode

            // A plain 429 is a rate limit and nothing else. Checked from the
            // status alone, outside the header loop, so a 429 that arrives with
            // no headers at all is still classified correctly.
            val headers = response.responseHeaders.orEmpty()
            for ((name, value) in headers) {
                if (value.isNullOrBlank()) continue
                when {
                    name.equals("x-vercel-mitigated", ignoreCase = true) &&
                        value.equals("challenge", ignoreCase = true) -> challengeHeaderSeen = true

                    name.equals("cf-mitigated", ignoreCase = true) &&
                        value.equals("challenge", ignoreCase = true) -> challengeHeaderSeen = true
                }
            }
            rateLimitedHeaderSeen = response.statusCode == 429 && !challengeHeaderSeen
        }

        /**
         * Network-level failure. The message says nothing about TLS, certificates
         * or anything else the companion did not actually observe.
         */
        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?,
        ) {
            if (request?.isForMainFrame != true) return
            failNavigation(
                CompanionException(
                    ErrorCode.COMPANION_UNAVAILABLE,
                    "NovTales' site could not be reached. Check the connection and try again.",
                )
            )
        }

        /**
         * The renderer died.
         *
         * This must never hang a job. The gateway goes to [Readiness.ERROR], the
         * in-flight operation is failed with [ErrorCode.SITE_CHANGED] and a
         * message telling the user to restart the companion, and the crashed
         * instance is dropped without calling `destroy()` on it - the platform
         * requires the app to leave a crashed WebView alone and remove it from
         * the hierarchy instead.
         *
         * Cookies live in [CookieManager], which is process-wide, so the site
         * session survives; a fresh WebView is built on the next operation.
         */
        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            indexContext = null
            rendererGone = true
            currentReadiness = Readiness.ERROR
            lastFailureMessage =
                "The companion's browser crashed. Reopen the companion to carry on."
            val crashed = view
            if (crashed != null) {
                (crashed.parent as? ViewGroup)?.removeView(crashed)
            }
            if (webView === view) webView = null
            try { crashed?.destroy() } catch (_: RuntimeException) { }
            attachedContainer = WeakReference(null)

            val error = CompanionException(
                ErrorCode.SITE_CHANGED,
                "The companion's browser process crashed while reading this page. " +
                    "Reopen the NovTales Companion to restart it, then try again.",
            )
            activeSession?.fail(error)
            failNavigation(error)
            return true
        }
    }

    /** `https://novtales.com` and its subdomains, or `about:blank`. Nothing else. */
    private fun isAllowed(uri: Uri?): Boolean {
        if (uri == null) return false
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "about") return (uri.toString() ?: "").equals("about:blank", ignoreCase = true)
        if (scheme != "https") return false
        val host = uri.host?.lowercase() ?: return false
        return host == Config.ALLOWED_HOST || host.endsWith(".${Config.ALLOWED_HOST}")
    }

    // ---- Operation plans ----------------------------------------------------

    private data class Plan(
        val operation: Operation,
        val path: String?,
        val page: Int,
        val sort: String?,
        val query: String?,
        val url: String,
        val payloadKey: String,
    ) {
        val chapterNumber: String? get() = path?.let { Paths.chapterNumber(it) }
        val cacheKey: String get() = "$operation|${path ?: ""}|$page|${sort ?: ""}|${query ?: ""}"
        fun describe(): String = when (operation) {
            Operation.CHAPTER -> "chapter ${chapterNumber ?: path}"
            Operation.NOVEL, Operation.CHAPTERS -> "the novel ${path ?: ""}"
            Operation.CATALOGUE -> "the catalogue"
            Operation.SEARCH -> "the search results"
        }
    }

    private fun plan(request: JobRequest): Plan {
        val page = (request.page ?: 1).coerceAtLeast(1)
        val path = request.path?.trim()?.takeIf { it.isNotEmpty() }?.let { raw ->
            Paths.normalise(raw) ?: throw CompanionException.badRequest("Not a NovTales path.")
        }

        return when (request.operation) {
            Operation.CATALOGUE -> Plan(
                operation = Operation.CATALOGUE,
                path = path,
                page = page,
                sort = request.sort,
                query = request.query,
                url = if (path != null) {
                    "${Config.SITE_ORIGIN}$path?page=$page"
                } else {
                    NovTalesExtraction.catalogueUrl(page)
                },
                payloadKey = "catalogue",
            )

            Operation.SEARCH -> Plan(
                operation = Operation.SEARCH,
                path = path,
                page = page,
                sort = request.sort,
                query = request.query,
                url = Config.SITE_ORIGIN + NovTalesExtraction.cataloguePath,
                payloadKey = "catalogue",
            )

            // The path is validated inside each branch, not up front: `isNovel`
            // and `isChapter` match mutually exclusive shapes, so computing both
            // before the branch would reject every request.
            Operation.NOVEL -> {
                val novelPath = path?.takeIf { Paths.isNovel(it) }
                    ?: throw CompanionException.badRequest("A novel path is required.")
                Plan(
                    operation = Operation.NOVEL,
                    path = novelPath,
                    page = page,
                    sort = request.sort,
                    query = request.query,
                    url = NovTalesExtraction.novelUrl(novelPath),
                    payloadKey = "novel",
                )
            }

            Operation.CHAPTERS -> {
                val novelPath = path?.takeIf { Paths.isNovel(it) }
                    ?: throw CompanionException.badRequest("A novel path is required.")
                Plan(
                    operation = Operation.CHAPTERS,
                    path = novelPath,
                    page = page,
                    sort = request.sort,
                    query = request.query,
                    url = NovTalesExtraction.novelUrl(novelPath),
                    payloadKey = "novel",
                )
            }

            Operation.CHAPTER -> {
                val chapterPath = path?.takeIf { Paths.isChapter(it) }
                    ?: throw CompanionException.badRequest("A chapter path is required.")
                Plan(
                    operation = Operation.CHAPTER,
                    path = chapterPath,
                    page = page,
                    sort = request.sort,
                    query = request.query,
                    url = Config.SITE_ORIGIN + chapterPath,
                    payloadKey = "chapter",
                )
            }
        }
    }

    // ---- Operation bodies ---------------------------------------------------

    private suspend fun runPlan(plan: Plan, session: OperationSession): Json = when (plan.operation) {
        Operation.CATALOGUE, Operation.SEARCH -> runListing(plan, session)
        Operation.NOVEL -> runNovel(plan, session)
        Operation.CHAPTERS -> runChapters(plan, session)
        Operation.CHAPTER -> runChapter(plan, session)
    }

    private suspend fun runListing(plan: Plan, session: OperationSession): Json {
        navigate(plan.url, session)
        val payload = awaitPayload(plan, session, POLL_INTERVAL_METADATA_MS)
        return withContext(io) {
            NovTalesExtraction.catalogue(payload, plan.page, plan.sort, plan.query)
        }
    }

    private suspend fun runNovel(plan: Plan, session: OperationSession): Json {
        navigate(plan.url, session)
        val payload = awaitPayload(plan, session, POLL_INTERVAL_METADATA_MS)
        val path = plan.path ?: throw CompanionException.badRequest("A novel path is required.")
        return withContext(io) { NovTalesExtraction.novel(payload, path) }
    }

    /**
     * The chapter index, read from the public JSON endpoint the site itself
     * uses, falling back to the novel page's own payload.
     *
     * The endpoint is asked for from inside the page, with the page's own
     * credentials, so nothing is exported and no auth header is forged. A
     * partial list is never returned: if the deadline arrives mid-index the
     * operation fails as a timeout rather than quietly truncating the novel.
     *
     * Only the site's index pages overlapping the requested ascending window
     * are fetched. Every response must agree on the whole-novel count and have
     * its expected number of entries before [NovTalesExtraction.chapterWindow]
     * returns that window. A partial window is never a successful result.
     */
    private suspend fun runChapters(plan: Plan, session: OperationSession): Json {
        val novelPath = plan.path ?: throw CompanionException.badRequest("A novel path is required.")
        val slug = Paths.novelSlug(novelPath)
            ?: throw CompanionException.badRequest("A novel path is required.")
        val url = NovTalesExtraction.novelUrl(novelPath)
        var view = webViewForWork()
        val previous = indexContext
        val reusable = previous != null && previous.view === view && previous.path == novelPath &&
            previous.snapshot.isFresh() && previous.identity == identity() && withContext(Dispatchers.Main) { view.url == url }
        if (!reusable) {
            navigate(url, session)
            view = webViewForWork()
        }
        session.stage = "reading the chapter index"
        pageAdapter.inject(view)

        attentionOrNull(view)?.let { throw it }
        val context = if (reusable) previous!! else {
            val contextIdentity = identity()
            val first = fetchIndexPage(view, slug, 1, session)
            IndexContext(view, novelPath, contextIdentity, IndexPageSnapshot(first, CHAPTER_PAGE_SIZE))
        }
        val total = context.snapshot.total
        val range = NovTalesExtraction.indexPages(total, plan.page, CHAPTER_PAGE_SIZE)
        val pages = ArrayList<Json>()
        for (index in range) {
            checkCancelled(session)
            val body = context.snapshot.page(index) ?: run {
                pause(session, POLL_INTERVAL_METADATA_MS)
                attentionOrNull(view)?.let { throw it }
                fetchIndexPage(view, slug, index, session, total).also {
                    context.snapshot.remember(index, it)
                }
            }
            NovTalesExtraction.validateIndexPage(body, index, CHAPTER_PAGE_SIZE, total)
            pages.add(body)
        }
        val result = withContext(io) {
            NovTalesExtraction.chapterWindow(pages, novelPath, total, plan.page, CHAPTER_PAGE_SIZE)
        }
        if (context.identity == identity() && withContext(Dispatchers.Main) { view === webView && view.url == url }) {
            indexContext = context
        } else {
            indexContext = null
        }
        return result
    }

    /** Retry one malformed successful response, never an HTTP refusal or intervention. */
    private suspend fun fetchIndexPage(
        view: WebView,
        slug: String,
        page: Int,
        session: OperationSession,
        expectedTotal: Int? = null,
    ): Json {
        val url = NovTalesExtraction.chapterListUrl(slug, page, CHAPTER_PAGE_SIZE)
        for (attempt in 0..1) {
            // HTTP errors are thrown by fetchJsonOnce outside the validation catch.
            val body = fetchJsonOnce(view, url, session)
                ?: throw CompanionException(ErrorCode.SITE_CHANGED, "NovTales did not return a readable chapter index.")
            try {
                NovTalesExtraction.validateIndexPage(body, page, CHAPTER_PAGE_SIZE, expectedTotal)
                return body
            } catch (error: CompanionException) {
                indexContext = null
                if (attempt == 1 || error.code != ErrorCode.SITE_CHANGED) throw error
                pause(session, 1_000L)
                attentionOrNull(view)?.let { throw it }
            }
        }
        error("Index attempts exhausted")
    }

    /**
     * The chapter loop, and the only place `complete: true` can ever be produced.
     *
     * Polls the cheap state every [POLL_INTERVAL_CHAPTER_MS] milliseconds and
     * scrolls whenever the body is still growing, until
     * [ChapterCompletion.evaluate] returns `Complete`, the user is needed, a
     * contradiction settles, the page stalls, or the deadline passes.
     */
    private suspend fun runChapter(plan: Plan, session: OperationSession): Json {
        val requested = plan.path ?: throw CompanionException.badRequest("A chapter path is required.")
        navigate(plan.url, session)
        val view = webViewForWork()
        pageAdapter.inject(view)
        attentionOrNull(view)?.let { throw it }

        var previousLength: Int? = null
        var stalled = 0
        var contradictions = 0
        var polls = 0

        while (true) {
            checkCancelled(session)
            polls++
            attentionOrNull(view)?.let { throw it }

            val cheap = mergeHttpSignals(pageAdapter.chapterState(view, includeBody = false))
            val length = cheap.int("bodyLength") ?: 0

            // The whole per-poll decision is [ChapterCompletion.decideState], and
            // it is there rather than inline so that it can be tested off-device.
            // Two things are decided there:
            //
            //  - The cheap read deliberately omits the body, so `evaluate` can
            //    never reach `Complete` from it - it returns NotReady(EMPTY_BODY)
            //    at the body rule, before any completion check. It is still the
            //    right state to evaluate for every reason that needs no body
            //    (sign-in, membership, contradictions, still-loading).
            //  - The end marker is the one signal the cheap pass does carry, and
            //    it only appears once the site has finished delivering. When it
            //    could change the answer, the one expensive read is spent on the
            //    real body. This used to be done inside the `Complete` branch,
            //    which made that branch unreachable: every poll returned NotReady
            //    and the loop ran to the stall deadline, so a fully delivered
            //    chapter was always reported as INCOMPLETE_CHAPTER. Spending it
            //    on *every* poll that merely has a marker is the opposite
            //    mistake - it shipped the whole chapter across the bridge nine
            //    times over a settle window to compute the same verdict - so the
            //    read is gated on the marker being worth it.
            val verdict = withContext(io) {
                ChapterCompletion.decideState(requested, cheap, contradictions) { includeBody ->
                    mergeHttpSignals(pageAdapter.chapterState(view, includeBody))
                }
            }

            when (verdict) {
                is ChapterCompletion.Verdict.Complete ->
                    return withContext(io) {
                        NovTalesExtraction.chapterResult(
                            verdict.path,
                            verdict.chapterNumber,
                            complete = true,
                            content = verdict.html,
                        )
                    }

                is ChapterCompletion.Verdict.NeedsUser, is ChapterCompletion.Verdict.Failed ->
                    throw ChapterCompletion.toException(verdict)

                ChapterCompletion.Verdict.StillLoading -> Unit

                is ChapterCompletion.Verdict.NotReady ->
                    if (verdict.reason == ChapterCompletion.Reason.CONTRADICTORY_SO_FAR) contradictions++ else contradictions = 0
            }

            val grew = ChapterCompletion.grew(previousLength, length)
            previousLength = length
            stalled = if (grew) 0 else stalled + 1

            val running = cheap.bool("stillLoading") == true
            val hasLoadMore = cheap.bool("hasLoadMore") == true

            if (!running && !hasLoadMore && stalled >= STALL_POLLS) {
                if (appContext.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE != 0) {
                    android.util.Log.d("NovTalesReview", "Chapter state: ${cheap.write()}")
                }
                throw CompanionException(
                    ErrorCode.INCOMPLETE_CHAPTER,
                    "NovTales stopped sending chapter ${plan.chapterNumber} before the end marker appeared. " +
                        "Nothing was saved, because a partial chapter is not a chapter.",
                )
            }

            // Scroll on every other poll, and always while the body is growing:
            // the site's loader only fires when the viewport reaches the end.
            if (running || hasLoadMore || grew || polls % 2 == 0) {
                pageAdapter.scrollForMore(view)
            }

            pause(session, POLL_INTERVAL_CHAPTER_MS)
        }
    }

    // ---- Polling helpers ----------------------------------------------------

    /**
     * Waits for a page payload, re-injecting the adapter whenever the page has
     * navigated under us (which wipes the globals), and giving up with
     * [ErrorCode.SITE_CHANGED] rather than burning the whole deadline on a page
     * the adapter cannot read.
     */
    private suspend fun awaitPayload(
        plan: Plan,
        session: OperationSession,
        pollMs: Long,
    ): Json {
        session.stage = "reading ${plan.payloadKey} data"
        var attempts = 0
        while (true) {
            checkCancelled(session)
            val view = webViewForWork()
            if (attempts == 0) pageAdapter.inject(view)
            var payload = pageAdapter.payload(view, plan.payloadKey)
            if (payload is Json.Null) {
                pageAdapter.inject(view)
                payload = pageAdapter.payload(view, plan.payloadKey)
            }
            attentionOrNull(view)?.let { throw it }
            val readable = if (plan.operation == Operation.NOVEL) {
                withContext(io) { NovelPayloadReadiness.isReady(payload, plan.path!!) }
            } else payload.bool("ok") == true
            if (readable) return payload

            attempts++
            // A committed document can still be streaming its referenced rows.
            // Give novel metadata 30 seconds, bounded by the outer 45s deadline.
            val limit = if (plan.operation == Operation.NOVEL) 86 else GIVE_UP_POLLS
            if (attempts >= limit) break
            pause(session, pollMs)
        }

        val view = webViewForWork()
        val dom = pageAdapter.domSnapshot(view, plan.payloadKey)
        val domReadable = if (plan.operation == Operation.NOVEL) {
            withContext(io) { NovelPayloadReadiness.isReady(dom, plan.path!!) }
        } else dom.bool("ok") == true
        if (domReadable) return dom

        throw CompanionException(
            ErrorCode.SITE_CHANGED,
            "NovTales' page layout changed and the companion could not read the ${plan.payloadKey} payload. " +
                "Nothing was returned rather than something guessed.",
        )
    }

    /**
     * One request/response round trip through the page, with the page doing the
     * fetching. Returns null when the endpoint refuses us, which sends the caller
     * to the SSR fallback.
     */
    private suspend fun fetchJsonOnce(view: WebView, url: String, session: OperationSession): Json? {
        pageAdapter.startJsonFetch(view, url)
        var waited = 0L
        while (waited < 6_000L) {
            checkCancelled(session)
            pause(session, POLL_INTERVAL_METADATA_MS)
            waited += POLL_INTERVAL_METADATA_MS
            val result = pageAdapter.asyncResult(view)
            if (result.str("url") != url) continue
            when (result.str("state")) {
                "done" -> {
                    val status = result.int("status") ?: 0
                    if (status == 429) throw CompanionException(ErrorCode.RATE_LIMITED, "NovTales limited chapter-list requests (HTTP 429). Wait before retrying.")
                    if (status == 401) throw CompanionException(ErrorCode.SIGN_IN_REQUIRED, "NovTales requested sign-in for its chapter index.")
                    if (status !in 200..299) throw CompanionException(ErrorCode.SITE_CHANGED, "NovTales refused its chapter index (HTTP $status).")
                    val body = result.str("body")
                    if (body.isNullOrBlank()) return null
                    val parsed = withContext(io) {
                        try {
                            Json.parse(body)
                        } catch (_: Exception) {
                            Json.Null
                        }
                    }
                    return if (parsed is Json.Null) null else parsed
                }
                "error" -> return null
            }
        }
        return null
    }

    /**
     * Re-reads the page for a "you need to do something" verdict.
     *
     * This is the shared path for metadata and chapters: the flags are DOM
     * markers plus the response-header markers recorded during navigation, and
     * an HTTP 429 on its own never becomes a verification verdict.
     */
    private suspend fun attentionOrNull(view: WebView): CompanionException? {
        val state = mergeHttpSignals(pageAdapter.chapterState(view, includeBody = false))
        val verification = state.bool("verificationRequired") == true || challengeHeaderSeen
        val signIn = state.bool("signInRequired") == true
        val membership = state.bool("membershipRequired") == true
        // The main frame's own status, used only where the status alone is the
        // evidence. A 403 is *not* read as verification unless a challenge header
        // said so: see onReceivedHttpError.
        val status = lastMainFrameStatus
        return when {
            verification -> CompanionException(
                ErrorCode.VERIFICATION_REQUIRED,
                "NovTales asked the companion to verify the browser. Open the companion's browser tab, " +
                    "finish the check, then retry.",
            )
            signIn || status == 401 -> CompanionException(
                ErrorCode.SIGN_IN_REQUIRED,
                "NovTales asked for a sign-in. Open the companion's browser tab and sign in, then retry.",
            )
            membership -> CompanionException(
                ErrorCode.MEMBERSHIP_REQUIRED,
                "NovTales reported this as locked. Unlock it on the site, then retry.",
            )
            state.bool("readingNoticeRequired") == true -> CompanionException(
                ErrorCode.READING_NOTICE_REQUIRED, "NovTales paused reading for a notice. Open the companion website and read the notice before retrying.")
            state.bool("rateLimited") == true || status == 429 -> CompanionException(
                ErrorCode.RATE_LIMITED, "NovTales limited this request (HTTP 429). Wait before retrying.")
            status != null && status >= 500 -> CompanionException(
                ErrorCode.COMPANION_UNAVAILABLE, "NovTales returned HTTP $status. Retry later.")
            status == 404 -> CompanionException(
                ErrorCode.NOT_FOUND,
                "NovTales has no such novel or chapter (HTTP 404).",
            )
            else -> null
        }
    }

    /**
     * Folds the HTTP-level markers observed during navigation into a DOM state
     * object, so the completion rule has one shape to reason about.
     */
    private fun mergeHttpSignals(state: Json): Json {
        if (state !is Json.Obj) return state
        if (!challengeHeaderSeen && !rateLimitedHeaderSeen) return state
        val fields = LinkedHashMap(state.fields)
        if (challengeHeaderSeen) fields["verificationRequired"] = Json.Bool(true)
        if (rateLimitedHeaderSeen) fields["rateLimited"] = Json.Bool(true)
        return Json.Obj(fields)
    }

    private fun checkCancelled(session: OperationSession) {
        if (session.signal.isCompleted) {
            throw session.failure
                ?: CompanionException(ErrorCode.CANCELLED, "The companion cancelled this job.")
        }
    }

    /**
     * Waits [ms], or returns early the moment the operation is cancelled or the
     * renderer dies. Implemented with `withTimeoutOrNull` rather than a latch,
     * so the main thread is never blocked and cancellation is immediate.
     */
    private suspend fun pause(session: OperationSession, ms: Long) {
        val interrupted = withTimeoutOrNull(ms) { session.signal.await(); true } ?: false
        if (interrupted) checkCancelled(session)
    }

    // ---- Cache and identity -------------------------------------------------

    /**
     * The browser identity every cache entry is filed under.
     *
     * It combines a process epoch - bumped by [onSessionCleared] and by a
     * renderer crash - with a digest of the site's cookie header. Signing in,
     * out or switching account changes the cookie header, so entries filed under
     * the previous identity become unreachable rather than being served to the
     * new account.
     *
     * The digest is one-way and only ever compared to itself; the cookie value
     * itself is never logged or returned anywhere.
     */
    private suspend fun identity(): String = withContext(Dispatchers.Main) {
        val cookies = try {
            CookieManager.getInstance().getCookie(Config.SITE_ORIGIN)
        } catch (_: RuntimeException) {
            null
        }
        val digest = if (cookies.isNullOrEmpty()) "none" else sha256Hex(cookies).take(16)
        "e$identityEpoch:$digest"
    }

    private fun sha256Hex(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        val out = StringBuilder(digest.size * 2)
        for (byte in digest) out.append("%02x".format(byte.toInt() and 0xFF))
        return out.toString()
    }

    /** A bounded, identity-keyed LRU. See [identity] for why it is keyed. */
    class ResultCache(private val maxEntries: Int = MAX_CACHE_ENTRIES) {
        private val storedAt = HashMap<String, Long>()
        private val entries = object : LinkedHashMap<String, Json>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Json>): Boolean =
                (size > maxEntries).also { if (it) storedAt.remove(eldest.key) }
        }

        @Synchronized
        fun get(identity: String, key: String): Json? {
            val id = "$identity|$key"
            if (System.currentTimeMillis() - (storedAt[id] ?: 0L) > 300_000L) {
                entries.remove(id)
                storedAt.remove(id)
                return null
            }
            return entries[id]
        }

        @Synchronized
        fun put(identity: String, key: String, value: Json) {
            // Avoid retaining multi-megabyte chapters in the browser worker.
            if (value.write().length > 512_000) return
            storedAt["$identity|$key"] = System.currentTimeMillis()
            entries["$identity|$key"] = value
        }

        @Synchronized
        fun clear() { entries.clear(); storedAt.clear() }

        @Synchronized
        fun size(): Int = entries.size
    }

    // ---- Operation bookkeeping ---------------------------------------------

    private class OperationSession {
        val signal = CompletableDeferred<Unit>()
        @Volatile var stage: String = "preparing the request"

        @Volatile
        var failure: CompanionException? = null

        fun fail(error: CompanionException) {
            failure = error
            signal.complete(Unit)
        }
    }
}
