package com.sadloif.novtalescompanion.web

import android.content.Context
import android.webkit.WebView
import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Loads the injected page script and runs it in the WebView.
 *
 * The one and only channel between the page and the companion. There is no
 * `addJavascriptInterface` anywhere in this app (CONTRACTS.md section 11), so
 * nothing the page says is trusted: the adapter returns a JSON *string*, that
 * string is decoded with [Json.parse], and the resulting structure is validated
 * again natively before it is allowed anywhere near a result.
 *
 * `evaluateJavascript` hands its result back already JSON-encoded, which means a
 * `"null"` from the page arrives as the four characters `"null"`. That, escaped
 * quotes inside a chapter title, and a null callback (what the WebView reports
 * when the page navigates mid-call) are all handled in [decode].
 *
 * The only thing that crosses into the page as a literal is a payload key, and
 * only after it has been checked against [PAYLOAD_KEYS].
 */
class PageAdapter(
    private val assets: AssetSource,
    private val io: CoroutineDispatcher = Dispatchers.IO,
) {

    /** Reads an APK asset. Injected rather than hard-coded so tests can fake it. */
    fun interface AssetSource {
        fun open(path: String): String?
    }

    companion object {
        const val ADAPTER_PATH = "adapter/novtales-adapter.js"

        /**
         * The only values ever interpolated into a page script. A key is checked
         * against this list before it is embedded, so no caller supplied string
         * can reach the page as code.
         */
        val PAYLOAD_KEYS: Set<String> = setOf("catalogue", "novel", "chapter")

        fun fromContext(context: Context, io: CoroutineDispatcher = Dispatchers.IO): PageAdapter {
            val assets = context.applicationContext.assets
            return PageAdapter(
                assets = { path ->
                    try {
                        assets.open(path).use { stream -> stream.readBytes().toString(Charsets.UTF_8) }
                    } catch (_: Exception) {
                        null
                    }
                },
                io = io,
            )
        }
    }

    /** Cached so the asset is read at most once for the life of the gateway. */
    @Volatile
    private var cachedScript: String? = null

    /**
     * The adapter source, read off the main thread on first use.
     *
     * A missing or truncated asset is reported as [ErrorCode.SITE_CHANGED] and
     * loudly: it is a packaging failure, and letting it degrade silently into
     * scraping nothing would be much harder to diagnose on a phone.
     */
    suspend fun script(): String {
        cachedScript?.let { return it }
        val source = withContext(io) { assets.open(ADAPTER_PATH) }
        if (source.isNullOrBlank() || source.length < 200) {
            throw CompanionException(
                ErrorCode.SITE_CHANGED,
                "The page adapter asset ($ADAPTER_PATH) is missing or truncated in the APK.",
            )
        }
        cachedScript = source
        return source
    }

    /**
     * Injects the adapter. Idempotent by construction: the script only assigns
     * functions and reads the DOM, so running it twice is harmless. Called again
     * after every page load, because a navigation wipes the previous globals.
     */
    suspend fun inject(webView: WebView) {
        evaluate(webView, script())
    }

    /** Reads a payload for [key], which must be one of [PAYLOAD_KEYS]. */
    suspend fun payload(webView: WebView, key: String): Json {
        require(key in PAYLOAD_KEYS) { "Unsupported payload key: $key" }
        return call(webView, "__novExtractPayload('$key')")
    }

    /** Cheap chapter poll: no body HTML is shipped while the chapter is growing. */
    suspend fun chapterState(webView: WebView, includeBody: Boolean): Json =
        call(webView, "__novChapterState(${if (includeBody) "true" else "false"})")

    /** Asks the page to scroll to the bottom so its own next-part loader fires. */
    suspend fun scrollForMore(webView: WebView): Json = call(webView, "__novScrollForMore()")

    /** DOM fallback, used only when the payload route produced nothing. */
    suspend fun domSnapshot(webView: WebView, key: String): Json {
        require(key in PAYLOAD_KEYS) { "Unsupported payload key: $key" }
        return call(webView, "__novDomSnapshot('$key')")
    }

    /**
     * Starts a JSON fetch from inside the page, using the page's own
     * credentials and cookies. Returns immediately; poll [asyncResult] for the
     * outcome.
     *
     * The URL is checked against the site origin first, so this can never be
     * used to make the companion's WebView fetch anything else, and it never
     * exports a cookie or a token anywhere.
     */
    suspend fun startJsonFetch(webView: WebView, absoluteUrl: String): Json {
        if (!absoluteUrl.startsWith("${Config.SITE_ORIGIN}/")) {
            throw CompanionException.badRequest("Refusing to fetch an off-site URL")
        }
        val quoted = absoluteUrl.replace("'", "")
        return call(webView, "__novFetchJson('$quoted')")
    }

    suspend fun asyncResult(webView: WebView): Json = call(webView, "__novAsyncResult()")

    /** Evaluates [script] on the main thread and unwraps the JSON-encoded result. */
    private suspend fun call(webView: WebView, script: String): Json =
        decode(evaluate(webView, script))

    private suspend fun evaluate(webView: WebView, script: String): String? =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { continuation ->
                try {
                    webView.evaluateJavascript(script) { raw ->
                        // The callback is already delivered on the main thread.
                        if (continuation.isActive) continuation.resume(raw)
                    }
                } catch (_: RuntimeException) {
                    // Calling a WebView off the main thread, or using one whose
                    // renderer has gone. Treated as "no answer" so the caller's
                    // own error mapping decides what it means.
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        }

    /**
     * Decodes one `evaluateJavascript` result.
     *
     * Three shapes arrive here and all three are legal:
     *  - `null` or `"null"` - the page returned nothing, usually because it
     *    navigated or the function is not defined yet;
     *  - a JSON string literal - the normal case, because the adapter returns a
     *    JSON string and the bridge encodes that once more;
     *  - any other JSON value - returned as-is.
     *
     * Anything unparseable becomes null rather than an exception, so a single bad
     * poll can never take an operation down.
     */
    fun decode(raw: String?): Json {
        if (raw == null) return Json.Null
        if (raw.isEmpty() || raw == "null") return Json.Null
        val outer = try {
            Json.parse(raw)
        } catch (_: Exception) {
            return Json.Null
        }
        if (outer is Json.Null) return Json.Null
        if (outer !is Json.Str) return outer
        val inner = outer.value
        if (inner.isEmpty() || inner == "null") return Json.Null
        return try {
            Json.parse(inner)
        } catch (_: Exception) {
            Json.Null
        }
    }
}
