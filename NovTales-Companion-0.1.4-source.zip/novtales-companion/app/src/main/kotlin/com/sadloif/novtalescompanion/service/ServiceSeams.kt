package com.sadloif.novtalescompanion.service

import com.sadloif.novtalescompanion.api.LocalApiServer
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.BrowserGatewayFactory
import com.sadloif.novtalescompanion.web.Readiness
import com.sadloif.novtalescompanion.web.WebViewBrowserGatewayFactory

/**
 * ## The one file that knows about `api/` and `web/`.
 *
 * `CONTRACTS.md` section 2 fixes the seam between the API, the WebView and this
 * package. Everything the rest of `service/` and `ui/` needs from those two
 * packages is funnelled through the functions below, so if a signature moves
 * during the parallel build this is the only file that has to change.
 *
 * ### The seam, as actually agreed
 *
 * - `LocalApiServer(pairingKey, gateway, bindHost, port, clock, log)` - it takes a
 *   ready-made gateway, not a factory. Only the first two arguments are passed;
 *   `bindHost`, `port` and `clock` keep their `core.Config` defaults, which is
 *   exactly what a production start wants.
 * - `LocalApiServer.updatePairingKey(key)` exists, so rotating the pairing key
 *   does **not** require tearing the server down. See
 *   [CompanionService.rotatePairingKey].
 * - `LocalApiServer.boundPort` is the live port (`-1` when stopped);
 *   `LocalApiServer.port` does not exist.
 * - `BrowserGateway` deliberately does **not** carry `attachTo` / `detach`. Those
 *   live on the separate `BrowserSurface` interface, reached through
 *   `web.asBrowserSurface()` so a gateway without a real browser surface (a test
 *   double) is simply null.
 * - `web.WebViewBrowserGatewayFactory` is the production `BrowserGatewayFactory`.
 *
 * Nothing else in `service/` or `ui/` imports `api.**` or `web.**`, apart from
 * `CompanionService` naming `Readiness` and the operation-tracking decorator
 * below, which implements exactly the four members CONTRACTS.md fixes.
 */
internal object ServiceSeams {

    /**
     * Creates the local API server.
     *
     * The server itself is pure JVM and never touches an Android API, so it gets
     * no Context at all; [log] is the only thing that needs one.
     */
    fun createServer(
        expectedPairingKey: String,
        gateway: BrowserGateway,
    ): LocalApiServer = LocalApiServer(
        pairingKey = expectedPairingKey,
        gateway = gateway,
        log = { line -> android.util.Log.d(LOG_TAG, line) },
    )

    /**
     * The production [BrowserGatewayFactory].
     *
     * `create` must return `null` when the Android WebView runtime is
     * unavailable; the service turns that into a readable error instead of a
     * silent failure.
     */
    fun browserGatewayFactory(): BrowserGatewayFactory = WebViewBrowserGatewayFactory

    /** Installs a freshly rotated key. Blank keys are refused by the server. */
    fun updatePairingKey(server: LocalApiServer, key: String) =
        server.updatePairingKey(key)

    /** Reads the server's readiness. Cheap, and safe from any thread. */
    fun readinessOf(server: LocalApiServer): Readiness = server.readiness

    /** The port actually bound, or a value <= 0 when the server is not listening. */
    fun portOf(server: LocalApiServer): Int = server.boundPort

    /**
     * Wraps a gateway so the service can see which operation is running.
     *
     * This is how the status screen and the notification learn the current
     * operation and chapter number: every request the plugin makes passes through
     * `execute`, so observing that single call is enough and no extra member is
     * needed on [LocalApiServer].
     *
     * Everything else is passed straight through, and a `CompanionException` - in
     * particular `VERIFICATION_REQUIRED`, `SIGN_IN_REQUIRED` and
     * `MEMBERSHIP_REQUIRED` - is never caught, wrapped or translated here, so the
     * plugin still sees the exact code the browser classified.
     */
    fun trackingGateway(
        delegate: BrowserGateway,
        onStarted: (JobRequest) -> Unit,
        onFinished: (JobRequest) -> Unit,
    ): BrowserGateway = OperationTrackingGateway(delegate, onStarted, onFinished)

    private class OperationTrackingGateway(
        private val delegate: BrowserGateway,
        private val onStarted: (JobRequest) -> Unit,
        private val onFinished: (JobRequest) -> Unit,
    ) : BrowserGateway {

        override val readiness: Readiness get() = delegate.readiness

        override suspend fun execute(request: JobRequest, deadlineMs: Long): Json {
            onStarted(request)
            try {
                // No catch: whatever the browser threw keeps its ErrorCode.
                return delegate.execute(request, deadlineMs)
            } finally {
                // Runs for success, failure, cancellation and timeout alike, so the
                // status screen can never be left claiming work is in progress.
                onFinished(request)
            }
        }

        override fun cancelActive() = delegate.cancelActive()

        override fun onSessionCleared() = delegate.onSessionCleared()
    }

    private const val LOG_TAG = "CompanionApi"
}