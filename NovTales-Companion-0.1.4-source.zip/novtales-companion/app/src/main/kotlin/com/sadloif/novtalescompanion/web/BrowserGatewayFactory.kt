package com.sadloif.novtalescompanion.web

import android.content.Context

/**
 * How the local API gets hold of a browser without ever naming a WebView class.
 *
 * Returns null when the Android runtime is unavailable, which is what keeps the
 * HTTP server unit-testable on a plain JVM: the tests inject a factory that
 * returns null or a fake, and nothing in the api package has to know that the
 * real implementation exists.
 *
 * Declared in its own file, as CONTRACTS.md section 2 specifies.
 */
fun interface BrowserGatewayFactory {

    /**
     * @param context the **application** context. The gateway must not retain an
     *   Activity context: its WebView outlives every Activity that shows it.
     * @return a gateway, or null when no browser can be created here.
     */
    fun create(context: Context): BrowserGateway?
}

/**
 * The production factory. Subagent C references this name directly, so it is a
 * concrete top-level object rather than an anonymous lambda.
 *
 * It hands the **application** context to the gateway, never the Activity that
 * happened to call it: the gateway's WebView has to outlive every Activity,
 * which is the whole reason the companion exists (spec section 6).
 */
object WebViewBrowserGatewayFactory : BrowserGatewayFactory {
    override fun create(context: Context): WebViewBrowserGateway? =
        WebViewBrowserGateway.create(context)
}
