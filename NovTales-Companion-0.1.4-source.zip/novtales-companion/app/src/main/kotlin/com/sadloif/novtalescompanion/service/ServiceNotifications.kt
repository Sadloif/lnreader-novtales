package com.sadloif.novtalescompanion.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.sadloif.novtalescompanion.CompanionApp
import com.sadloif.novtalescompanion.R
import com.sadloif.novtalescompanion.state.CompanionPhase
import com.sadloif.novtalescompanion.state.CompanionSnapshot
import com.sadloif.novtalescompanion.state.currentWorkLabel
import com.sadloif.novtalescompanion.ui.MainActivity

/**
 * Builds the companion's one and only notification (spec section 5).
 *
 * What it is allowed to contain:
 *  - the current state, and
 *  - the current operation or chapter *number*.
 *
 * What it must never contain:
 *  - the pairing key, in any form;
 *  - chapter text, a chapter title, or any content pulled off the website;
 *  - anything that would turn a status line into a reader notification. The
 *    channel is IMPORTANCE_LOW and the builder is silent, so nothing here ever
 *    makes a sound or takes over the shade.
 *
 * The notification is also the only way to stop the companion when the status
 * screen is not open, so it carries a Stop action and opens MainActivity when
 * tapped.
 */
internal object ServiceNotifications {

    const val NOTIFICATION_ID = 0x4E56 // "NV"

    private const val REQUEST_CONTENT = 0x01
    private const val REQUEST_STOP = 0x02

    /** Reuses the channel created once in `CompanionApp.onCreate`. */
    const val CHANNEL_ID = CompanionApp.CHANNEL_ID

    fun build(context: Context, snapshot: CompanionSnapshot): Notification {
        val label = statusLabel(context, snapshot.phase)
        val work = currentWorkLabel(context, snapshot.operation, snapshot.chapterNumber)

        val text = when {
            // An error is the most useful thing to show, but the state still leads
            // so "Error" is never the first word lost in a glance.
            !snapshot.errorMessage.isNullOrBlank() ->
                context.getString(R.string.notification_status_and_detail, label, snapshot.errorMessage)
            work != null -> context.getString(R.string.notification_status_and_detail, label, work)
            else -> label
        }

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_companion)
            .setContentTitle(context.getString(R.string.notification_title))
            .setContentText(text)
            .setSubText(context.getString(R.string.notification_subtext))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(contentIntent(context))
            .addAction(
                R.drawable.ic_notification_stop,
                context.getString(R.string.action_stop),
                stopIntent(context),
            )
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    /** Tapping the notification opens the status screen. */
    fun contentIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            REQUEST_CONTENT,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /**
     * The Stop action. This is a user action taken from the shade, which is one of
     * the few cases where a background app may legitimately start a service; the
     * service is already in the foreground at this point anyway.
     */
    fun stopIntent(context: Context): PendingIntent {
        val intent = Intent(context, CompanionService::class.java)
            .setAction(CompanionService.ACTION_STOP)
        return PendingIntent.getService(
            context,
            REQUEST_STOP,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** One word per state, for the notification and for the screen's headline. */
    fun statusLabel(context: Context, phase: CompanionPhase): String = context.getString(
        when (phase) {
            CompanionPhase.STOPPED -> R.string.status_stopped
            CompanionPhase.STARTING -> R.string.status_starting
            CompanionPhase.READY -> R.string.status_ready
            CompanionPhase.LOADING -> R.string.status_loading
            CompanionPhase.NEEDS_ATTENTION -> R.string.status_needs_attention
            CompanionPhase.ERROR -> R.string.status_error
        },
    )
}