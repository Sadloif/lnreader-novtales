package com.sadloif.novtalescompanion.core

/**
 * Validation and normalisation for the only two kinds of NovTales path the local
 * API accepts. Everything else is rejected before it reaches the WebView, so the
 * companion can never be steered to an arbitrary URL (spec sections 7 and 11).
 */
object Paths {

    private val SLUG = Regex("^[a-z0-9]+(?:-[a-z0-9]+)*$")

    /**
     * Chapter numbers on the site include decimals, e.g. `/chapter/surviving-the-game-as-a-barbarian-12.5`.
     * A decimal must have digits on both sides of the point to keep `slug-number`
     * unambiguously splittable.
     */
    private val CHAPTER_NUMBER = Regex("^\\d+(?:\\.\\d+)?$")

    /** A chapter path ends with `-<number>`; the slug may itself contain hyphens. */
    private val CHAPTER_PATH = Regex("^/chapter/([a-z0-9]+(?:-[a-z0-9]+)*)-(\\d+(?:\\.\\d+)?)$")

    private val NOVEL_PATH = Regex("^/novel/([a-z0-9]+(?:-[a-z0-9]+)*)$")

    /**
     * Percent-decoding is applied repeatedly on purpose so that a double-encoded
     * traversal attempt (`%252e%252e`) cannot survive one pass.
     */
    private fun fullyDecode(value: String): String {
        var current = value
        repeat(4) {
            val next = try {
                java.net.URLDecoder.decode(current, "UTF-8")
            } catch (_: Exception) {
                return current
            }
            if (next == current) return current
            current = next
        }
        return current
    }

    /**
     * Normalises a client-supplied path to a bare absolute path.
     *
     * Accepts an absolute site URL, a relative path, or a path with a query
     * string. Returns null when the value is not an accepted NovTales path.
     */
    fun normalise(input: String): String? {
        if (input.length !in 1..200) return null

        // Reject anything outside printable ASCII rather than letting `trim()`
        // silently absorb it. A path containing a tab, a NUL, a non-breaking
        // space or U+1680 is malformed input; quietly normalising it to a valid
        // path hides that from the caller and from anyone reading the logs.
        if (input.any { it.code < 0x20 || it.code > 0x7E }) return null

        var value = input.trim(' ')

        // Strip an absolute URL down to its path.
        val lower = value.lowercase()
        if (lower.startsWith("https://${Config.ALLOWED_HOST}")) {
            value = value.substringAfter(Config.ALLOWED_HOST)
        } else if (lower.startsWith("http://")) {
            return null // plaintext site URLs are not accepted
        } else if (lower.startsWith(Config.SITE_ORIGIN)) {
            value = value.removePrefix(Config.SITE_ORIGIN)
        }

        val decoded = fullyDecode(value)

        // Query and fragment are removed for the canonical form, but any remaining
        // '?' or '#' after decoding means an encoding trick was used.
        val withoutQuery = decoded.substringBefore('?').substringBefore('#')
        if (fullyDecode(withoutQuery) != withoutQuery) return null

        if (!withoutQuery.startsWith("/")) return null
        if (withoutQuery.contains("//")) return null
        if (withoutQuery.contains("..")) return null
        if (withoutQuery.length > 1 && withoutQuery.endsWith("/")) return null
        if (withoutQuery.any { it !in PATH_CHARS }) return null

        return withoutQuery
    }

    private val PATH_CHARS =
        ('a'..'z') + ('A'..'Z') + ('0'..'9') + listOf('-', '_', '.', '/')

    /** True when [input] is a well-formed `/novel/{slug}` path. */
    fun isNovel(path: String): Boolean = NOVEL_PATH.matches(path)

    /** True when [input] is a well-formed `/chapter/{slug}-{number}` path. */
    fun isChapter(path: String): Boolean = CHAPTER_PATH.matches(path)

    fun novelSlug(path: String): String? = NOVEL_PATH.matchEntire(path)?.groupValues?.get(1)

    /** Returns the novel slug a chapter path belongs to, or null if malformed. */
    fun chapterSlug(path: String): String? = CHAPTER_PATH.matchEntire(path)?.groupValues?.get(1)

    /**
     * Returns the requested chapter number. Decimals are preserved as the site's
     * own string so `12` never round-trips as `12.0`.
     */
    fun chapterNumber(path: String): String? = CHAPTER_PATH.matchEntire(path)?.groupValues?.get(2)

    fun chapterNumberAsDouble(path: String): Double? = chapterNumber(path)?.toDoubleOrNull()

    /**
     * Confirms a delivered chapter is the one that was asked for (spec section 8).
     * Both the slug and the number must match.
     */
    fun isSameChapter(requested: String, delivered: String): Boolean {
        val requestedSlug = chapterSlug(requested) ?: return false
        val deliveredSlug = chapterSlug(delivered) ?: return false
        if (requestedSlug != deliveredSlug) return false
        val requestedNumber = chapterNumber(requested) ?: return false
        val deliveredNumber = chapterNumber(delivered) ?: return false
        if (requestedNumber == deliveredNumber) return true
        // Tolerate a numerically equal decimal written differently ("12.0" vs "12").
        return decimalEquals(requestedNumber, deliveredNumber)
    }

    /**
     * True when two chapter-number strings denote the same number, so `12`, `12.0`
     * and `12.00` match while `12.5` and `12` do not.
     *
     * Public because the chapter-completion rule needs exactly this comparison
     * and must not reimplement it with [Double] — see the note on
     * [decimalEquals].
     */
    fun numbersEqual(a: String, b: String): Boolean = a == b || decimalEquals(a, b)

    /**
     * Compares two decimal strings exactly, without going through [Double].
     *
     * Double rounding makes distinct large chapter numbers collide - 2^53 and
     * 2^53+1 both round to the same value - which would let the wrong chapter be
     * accepted as the requested one. String comparison of the integer and
     * fractional parts has no such failure mode.
     */
    private fun decimalEquals(a: String, b: String): Boolean {
        // "007" and "7" agree on the whole part; "" is what both "0" and "00" reduce to.
        if (a.substringBefore('.').trimStart('0') != b.substringBefore('.').trimStart('0')) {
            return false
        }
        // A missing fraction is zero, so "12" matches "12.0" once trailing zeros
        // are dropped from "12.0" as well.
        return a.substringAfter('.', "").trimEnd('0') == b.substringAfter('.', "").trimEnd('0')
    }

    /** True for a plain hyphenated slug, used when validating extracted site data. */
    fun isSlug(value: String): Boolean = SLUG.matches(value)

    fun isChapterNumber(value: String): Boolean = CHAPTER_NUMBER.matches(value)
}