package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.Config

/**
 * A small, dependency-free HTML sanitiser.
 *
 * Pure JVM on purpose: it imports nothing from `android.*`, so it runs in the
 * unit-test source set with no Robolectric and no emulator. Everything here is
 * plain Kotlin plus [Config.SITE_ORIGIN], which is itself an Android-free
 * constant.
 *
 * What comes out is reader-ready chapter HTML. LNReader renders it and the
 * companion's TTS path reads it, so paragraph text must survive byte for byte:
 * the sanitiser never collapses whitespace, never re-wraps, and never re-orders
 * anything inside a `<p>`.
 *
 * There is deliberately no Jsoup (and no other dependency) here. The build file
 * is fixed, and a hand-written scanner is the only way to keep the allow-list
 * small and auditable.
 */
object HtmlSanitiser {

    /** Base used to resolve relative image sources. */
    const val ORIGIN: String = Config.SITE_ORIGIN

    // ---- Policy tables ------------------------------------------------------

    /**
     * Tags that survive. Everything else is either dropped with its subtree or
     * unwrapped (tag removed, children kept) so no prose is lost.
     */
    private val KEEP_TAGS = setOf(
        "p", "br", "em", "strong", "i", "b", "u", "blockquote",
        "h1", "h2", "h3", "h4", "h5", "h6",
        "ul", "ol", "li", "hr", "img", "span", "div", "figure", "figcaption",
        "sup", "sub", "small", "center",
    )

    /** Dropped together with everything inside them. */
    private val DROP_SUBTREE_TAGS = setOf(
        "script", "style", "noscript", "iframe", "object", "embed", "form",
        "input", "button", "select", "textarea", "template", "svg", "math",
        "canvas", "audio", "video", "head", "title", "meta", "link", "base",
        "applet", "frame", "frameset", "dialog",
    )

    /** Void elements: no closing tag exists, so "drop" only means drop the token. */
    private val VOID_TAGS = setOf(
        "br", "hr", "img", "input", "meta", "link", "source", "track", "wbr",
        "area", "base", "col", "embed", "param",
    )

    /**
     * Unwrapped: the tag itself disappears but the text inside it is preserved.
     * This is what keeps `<a>`, `<section>`, `<article>` and Next.js wrapper
     * divs from either leaking markup or eating paragraphs.
     */
    private val UNWRAP_TAGS = setOf(
        "a", "article", "section", "main", "header", "footer", "nav", "aside",
        "dl", "dt", "dd", "pre", "code", "label", "caption", "colgroup",
        "tbody", "thead", "tfoot", "tr", "table", "time", "mark", "q", "cite",
        "abbr", "address", "details", "summary", "picture", "body", "html",
    )

    /** Attributes that survive, per tag. Everything not listed is dropped. */
    private val ALLOWED_ATTRIBUTES = mapOf(
        "img" to setOf("src", "alt", "title", "width", "height"),
        "hr" to setOf("class"),
        "p" to setOf("class"),
        "div" to setOf("class"),
        "span" to setOf("class"),
    )

    /**
     * Only these class values are preserved, and only on tags that allow a
     * class. Scene-break markers are the reader's structural cue, so they are
     * normalised onto `<hr>`; every other class is chrome and is discarded.
     */
    /**
     * Class values that mark a scene break.
     *
     * Each alternative must be the **whole** whitespace-delimited token, so the
     * separators on both sides are `\s`/`$` only. An earlier version allowed
     * `-` and `_` as trailing separators, which matched the bare word `break`
     * inside Tailwind-style utilities: `<p class="break-words">` and
     * `<div class="underline break-through">` both matched, and because this
     * branch runs before [KEEP_TAGS] and discards the element's content, a whole
     * paragraph of real chapter prose was silently replaced with `<hr>`. That is
     * silent data loss in a delivered chapter, so the boundary is now strict.
     *
     * The bare token `break` was then removed as well. Even as a whole token it
     * matched `class="break"`, which is not how any real site spells a scene
     * break - Tailwind's utilities are `break-normal`, `break-words`,
     * `break-all`, `break-keep` - while the genuine markers all say `scene`
     * (`scene-break`, `scene break`, `scene_divider`). Keeping it could only ever
     * lose prose, never find a marker.
     */
    private val SCENE_BREAK_CLASS =
        Regex("(?i)(?:^|\\s)scene[-_ ]?(?:break|divider)(?:$|\\s)")

    /**
     * What a scene-break **marker** may consist of: separator glyphs, digits and
     * whitespace, and nothing else.
     *
     * `Parser.isLeafGlyphMarker` uses this to tell `* * *` from `Click through
     * the door.`, and the adapter mirrors the same expression so it knows which
     * of the two the sanitiser would have deleted. It deliberately contains no
     * letters: a scene-break slot holding letters is prose, and prose is kept.
     */
    private val SCENE_BREAK_GLYPHS = Regex("[\\s*+\\u00b7\\u2022\\u2027\\u2219\\u30fb\\u301c\\u203b\\u2010-\\u2015~_.,\\-0-9]*")

    private val DANGEROUS_SCHEME = Regex("(?i)^\\s*(?:javascript|data|vbscript|blob|file|about)\\s*:")

    /**
     * Deliberately **not** anchored with `^`, and never used with
     * `Regex.find(input, startIndex)`.
     *
     * `find(input, startIndex)` anchors `^` to the start of the whole document
     * rather than to `startIndex`, so every entity after the first character of a
     * text run would be missed and double-escaped into `&amp;amp;`. [appendText]
     * now avoids that by never calling `find` at all: it locates the next `&`
     * with `indexOf` and calls [HTML_ENTITY.matchAt] on that one position.
     * `matchAt` ignores the `^` flag entirely, so no anchor can reintroduce the
     * double escape, and a miss costs one bounded probe instead of a scan to the
     * end of the string - which is what made `appendText` quadratic in `&`.
     */
    /**
     * One HTML character reference.
     *
     * The digit budgets are deliberately generous. HTML5 numeric references take
     * *arbitrary* leading zeros (`&#0000000160;` is U+00A0), so a tight budget
     * meant an over-long reference was not recognised as an entity and was
     * escaped to **visible** text - the opposite of what a browser does with it,
     * and it let invisible characters slip past [decodeCharacter] as though they
     * were readable prose. The bound still exists so a pathological run of digits
     * cannot make the match expensive.
     */
    private val HTML_ENTITY = Regex("&(?:#[0-9]{1,16}|#[xX][0-9a-fA-F]{1,12}|[a-zA-Z][a-zA-Z0-9]{1,31});")

    /** U+00A0. Written as an escape so the source stays unambiguous. */
    private const val NBSP: String = "\u00A0"

    /**
     * The numeric no-break-space forms. Needed because `appendText` already
     * rewrote `&nbsp;` into `&#160;`, so by the time [textOf] runs the character
     * is gone and only its entity text is left to decode.
     */
    private val NBSP_ENTITY = Regex("&#(?:160|[xX][aA]0);")

    /** Three or more newlines collapse to a paragraph break, never to a wall of them. */
    private val BLANK_RUN = Regex("\n{3,}")

    /** Image extensions we will emit. `svg` is deliberately absent: it is scriptable. */
    private val IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "gif", "webp", "avif", "bmp", "ico", "jfif", "apng",
    )

    /** Next.js's built-in image optimiser, which proxies an absolute `url`. */
    private const val NEXT_IMAGE_ENDPOINT: String = "_next/image"

    /**
     * Tags that make a scene-break element a container rather than a marker.
     *
     * Kept because [Parser.isLeafGlyphMarker] documents why it is not enough on
     * its own, and because the adapter mirrors the scene-break rule; it is not
     * itself consulted by the scanner any more.
     */
    private val BLOCK_TAGS = setOf(
        "p", "div", "ul", "ol", "li", "blockquote", "figure", "figcaption",
        "table", "h1", "h2", "h3", "h4", "h5", "h6", "hr", "img",
        "section", "article", "pre", "dl", "center", "main",
    )

    // ---- Public API ---------------------------------------------------------

    /**
     * Sanitises a fragment of chapter HTML.
     *
     * Returns an empty string for null, blank, or fully-stripped input so callers
     * never have to null-check the result.
     */
    fun sanitise(html: String?): String {
        if (html.isNullOrEmpty()) return ""
        val parser = Parser(html)
        val out = StringBuilder(html.length.coerceAtLeast(64))
        try {
            parser.run(out)
        } catch (_: Exception) {
            // A malformed fragment must not take the whole download down. Whatever
            // was produced so far is still escaped text, so it is safe to return.
            return out.toString().trim()
        }
        return out.toString().trim()
    }

    /**
     * Plain text of a sanitised fragment, with block boundaries turned into
     * newlines. Used for the "body is not empty after sanitising" test so that a
     * lone `<p><img src="..."></p>` does not count as chapter text.
     *
     * **Entities are decoded.** This is not cosmetic: `appendText` rewrites
     * `&nbsp;` to `&#160;`, so the character that used to make this method
     * return "no text" no longer exists as a character by the time this runs.
     * Without decoding, the six literal characters `&#160;` counted as prose and
     * `<p>&nbsp;</p>` passed the readable-text gate, so a body with no words in
     * it at all could be stored as a complete chapter. Decoding here is what
     * makes `textOf` a real view of what a reader would see.
     */
    fun textOf(html: String?): String {
        val sanitised = sanitise(html)
        if (sanitised.isEmpty()) return ""
        val out = StringBuilder(sanitised.length)
        var index = 0
        while (index < sanitised.length) {
            val char = sanitised[index]
            if (char == '<') {
                val close = sanitised.indexOf('>', index)
                if (close < 0) break
                val tag = sanitised.substring(index + 1, close).trimStart('/').trimStart()
                val name = tag.takeWhile { it.isLetter() }.lowercase()
                if (name == "br" || name == "p" || name == "div" || name == "blockquote" ||
                    name == "h1" || name == "h2" || name == "h3" || name == "h4" ||
                    name == "h5" || name == "h6" || name == "li" || name == "hr"
                ) {
                    out.append('\n')
                }
                index = close + 1
            } else if (char == '&') {
                // Decoded, not copied: see the note on [textOf]. `decodeEntities`
                // consumes the whole run starting here, so `index` must be left
                // past it or the entity would be decoded twice.
                val amp = sanitised.indexOf('&', index)
                val end = decodeEntities(sanitised, amp, out)
                index = if (end > index) end else index + 1
            } else {
                out.append(char)
                index++
            }
        }
        return out.toString()
            .replace('\u00A0', ' ')
            .replace(NBSP_ENTITY, " ")
            .lines()
            .joinToString("\n") { it.trim() }
            .replace(BLANK_RUN, "\n\n")
            .trim()
    }

    /**
     * Decodes HTML entities from [at] into [out] and returns the index just past
     * the entity, or [at] itself when there is nothing decodable there.
     *
     * Only the characters that matter for the readable-text decision are mapped:
     * the three ways of writing a no-break space, plus the handful of named
     * whitespace entities. Anything else - `&amp;`, `&copy;`, `&#169;` - is
     * copied through verbatim. That is deliberate: this runs over the whole
     * chapter, and a full entity table would be an unbounded amount of code for
     * no change to the answer, while a *wrong* decode of `&amp;` would turn a
     * reader-visible character into text the gate reads differently from the
     * renderer.
     *
     * Control and format characters (C0, DEL, and the bidi/zero-width set) decode
     * to a space as well. They are invisible to the reader, so a paragraph made
     * only of them is exactly the "no prose" case this is meant to catch, but
     * they are not `isWhitespace()` in Kotlin, so they would otherwise sail
     * through `isNotBlank()`.
     *
     * Linear: [HTML_ENTITY] is a bounded pattern (at most 35 characters), so one
     * `matchAt` per `&` is O(1), not a scan of the remainder.
     */
    private fun decodeEntities(source: String, at: Int, out: StringBuilder): Int {
        val match = HTML_ENTITY.matchAt(source, at) ?: return at
        val entity = match.value
        val decoded = decodeCharacter(entity)
        if (decoded == null) {
            out.append(entity)
        } else {
            out.append(decoded)
        }
        return at + entity.length
    }

    /**
     * Named references that resolve to a character no reader can see.
     *
     * The numeric path already knew about every one of these code points, so
     * `&#8207;` was correctly read as "not prose". Their **named** twins were
     * not: the decoder only special-cased `&nbsp;`, `&ensp;`, `&emsp;` and
     * `&thinsp;`, so `&rlm;` was copied through as the seven literal characters
     * `&rlm;`, which is non-blank, which passed `hasReadableText`, which
     * completed a chapter whose body had no words in it. The two spellings of
     * the same character must give the same answer, so the named path now looks
     * the code point up here and hands it to the same [isInvisible] predicate the
     * numeric path uses.
     *
     * Only invisible characters are listed. Everything else - `&amp;`, `&copy;`,
     * `&#169;` - is still copied through verbatim, deliberately: this runs over
     * the whole chapter, and a wrong decode of `&amp;` would turn a
     * reader-visible character into text the gate reads differently from the
     * renderer. Names are lower-cased on lookup; HTML5 reference names are
     * case-sensitive, but the numeric-only matches below are what matter and
     * folding case here can only ever decode *more* invisible characters, never
     * a visible one.
     */
    internal val NAMED_INVISIBLE = mapOf(
        "tab" to 0x09,
        "newline" to 0x0A,
        "nbsp" to 0x00A0,
        "ensp" to 0x2002,
        "emsp" to 0x2003,
        "thinsp" to 0x2009,
        "hairsp" to 0x200A,
        "numsp" to 0x2007,
        "puncsp" to 0x2008,
        "nnbsp" to 0x202F,
        "mediumspace" to 0x205F,
        "shy" to 0x00AD,
        "zerowidthspace" to 0x200B,
        "verythinspace" to 0x200B,
        "negativeverythinspace" to 0x200B,
        "zwnj" to 0x200C,
        "zwj" to 0x200D,
        "lrm" to 0x200E,
        "rlm" to 0x200F,
        "nobreak" to 0x2060,
    )

    /**
     * The character [entity] stands for, or null when it is copied verbatim.
     *
     * Two entry points - numeric and named - and one [isInvisible] predicate
     * behind both, so `&#8207;` and `&rlm;` cannot disagree.
     */
    private fun decodeCharacter(entity: String): String? {
        val body = entity.substring(1, entity.length - 1)
        if (body.length > 1 && body[0] == '#') {
            val code = when {
                body[1] == 'x' || body[1] == 'X' -> body.substring(2).toIntOrNull(16)
                else -> body.substring(1).toIntOrNull(10)
            }
            return if (code != null && isInvisible(code)) " " else null
        }
        val named = NAMED_INVISIBLE[body.lowercase()] ?: return null
        return if (isInvisible(named)) " " else null
    }

    /**
     * True when the character at [code] renders as nothing the reader can see.
     *
     * Deliberately not `isLetterOrDigit`/`isWhitespace`: those let the format
     * characters through, which are exactly the ones that must not count as
     * prose. Control and format characters (C0, DEL, and every Unicode default
     * ignorable range that can reach a browser) read as a space, so a paragraph
     * made only of them is the "no prose" case this exists to catch.
     *
     * One predicate, two callers - the numeric path and the named path - so
     * `&#8207;` and its named twin `&rlm;` cannot disagree. The set was
     * previously half a list: it stopped at 0x2064, which excluded the bidi
     * **isolates** 0x2066..0x2069, so a body of nothing but LRI/RLI controls
     * counted as readable prose and could be stored as a complete chapter.
     *
     * The spacing ranges are here for the same reason and the same way. They
     * are Unicode `Zs`, which `isWhitespace()` already treats as blank - but
     * only once the character has been *decoded*, and the named references that
     * stand for them (`&ensp;`, `&emsp;`, `&thinsp;`, `&hairsp;`, `&numsp;`,
     * `&puncsp;`, `&nnbsp;`, `&MediumSpace;`) were copied through as seven
     * literal characters each, which is non-blank. Listing them here rather than
     * in [NAMED_INVISIBLE] means the table and the predicate cannot drift: a
     * code point either satisfies this or is not in the table, and
     * `HtmlSanitiserRegressionTest` asserts exactly that for every entry.
     */
    internal fun isInvisible(code: Int): Boolean = when {
        code < 0x20 || code == 0x7F -> true
        code == 0x20 -> true                      // SPACE: a space is not prose
        code == 0xA0 -> true                      // NO-BREAK SPACE
        code == 0x00AD -> true                    // soft hyphen
        code == 0x061C -> true                    // Arabic letter mark
        code == 0x1680 -> true                    // OGHAM SPACE MARK (Zs)
        code == 0x180E -> true                    // Mongolian vowel separator
        code in 0x2000..0x200A -> true            // EN QUAD..HAIR SPACE (Zs)
        code in 0x200B..0x200F -> true            // ZWSP..RLM
        code in 0x2028..0x202E -> true            // line sep..RLO
        code == 0x202F -> true                    // NARROW NO-BREAK SPACE (Zs)
        code == 0x205F -> true                    // MEDIUM MATH SPACE (Zs)
        code in 0x2060..0x206F -> true            // word joiner..bidi PDI
        code == 0x3000 -> true                    // IDEOGRAPHIC SPACE (Zs)
        code in 0xFFF9..0xFFFB -> true            // interlinear annotation
        code in 0x1D173..0x1D17A -> true          // musical formatting
        code in 0xE0020..0xE007F -> true          // tag characters
        code == 0xFEFF -> true                    // BOM / ZWNBSP
        else -> false
    }

    /**
     * True when a sanitised body actually contains readable text. Character
     * count alone is deliberately not used for completion; this is only the
     * "non-empty after sanitising" half of the contract's rule.
     */
    fun hasReadableText(html: String?): Boolean = textOf(html).isNotBlank()

    // ---- URL handling -------------------------------------------------------

    /**
     * Resolves an image source against [ORIGIN] and rejects anything that is not
     * a same-site (or plainly remote) `http(s)` image.
     *
     * Returns null when the image must be dropped: relative-after-resolution
     * sources, non-http(s) schemes, and non-image extensions.
     */
    fun resolveImageSource(raw: String?): String? {
        val value = raw?.trim()?.replace('\u00A0', ' ') ?: return null
        if (value.isEmpty() || value.length > 2048) return null
        if (DANGEROUS_SCHEME.containsMatchIn(value)) return null

        val absolute = when {
            value.startsWith("//") -> "https:$value"
            value.startsWith("/") -> ORIGIN + value
            value.startsWith("http://") || value.startsWith("https://") -> value
            else -> ORIGIN + "/" + value.trimStart('.', '/')
        }

        val lower = absolute.lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return null

        // Reject anything carrying credentials or a whitespace/control smuggled in.
        if (absolute.any { it.isWhitespace() || it.code < 0x20 }) return null
        val afterScheme = absolute.substringAfter("://", "")
        if (afterScheme.contains('@')) return null

        val withoutFragment = absolute.substringBefore('#')
        val withoutQuery = withoutFragment.substringBefore('?')

        // A bare host is not an image. Everything after the host must be a real
        // path segment, which the extension check below then validates.
        val path = withoutQuery.substringAfter("://").substringAfter('/', "")
        if (path.length < 3 || path.endsWith("/")) return null

        if (path.equals(NEXT_IMAGE_ENDPOINT, ignoreCase = true)) {
            return resolveNextImage(withoutFragment)
        }

        if (containsTraversal(path)) return null

        val lastSegment = path.substringAfterLast('/')
        val dot = lastSegment.lastIndexOf('.')
        if (dot < 0) return null
        val extension = lastSegment.substring(dot + 1).lowercase()
        if (extension !in IMAGE_EXTENSIONS) return null
        return withoutQuery
    }

    /**
     * Next.js's image endpoint, `/_next/image?url=<percent-encoded absolute url>`.
     *
     * The site serves its illustrations through it (145 such sources in the
     * captured chapter page), and because the real file name only exists inside
     * the `url` parameter, the ordinary path check would reject every one of
     * them: the path is `/_next/image`, which has no extension. So the endpoint is
     * recognised and the *parameter* is validated instead, under exactly the same
     * rules as any other source.
     *
     * @return the upstream image URL with the endpoint's own parameters removed,
     *   or null when it fails any of the ordinary checks.
     */
    private fun resolveNextImage(endpointUrl: String): String? {
        val query = endpointUrl.substringAfter('?', "")
        if (query.isEmpty()) return null
        val raw = query.split('&')
            .firstOrNull { part ->
                part.substringBefore('=', "").equals("url", ignoreCase = true)
            }
            ?: return null
        if (raw.length <= 3) return null
        val inner = raw.substring(raw.indexOf('=') + 1)
        if (inner.isEmpty() || inner.length > 2048) return null
        // `+` is a space in application/x-www-form-urlencoded, and a space in a
        // source is refused below, so it has to be restored rather than dropped.
        val decoded = percentDecode(inner.replace('+', ' '))
        // The result goes back through every ordinary rule - scheme, credentials,
        // traversal, extension - so a proxied `javascript:` or `data:` target
        // cannot be smuggled through the endpoint.
        return resolveImageSource(decoded)
    }

    /**
     * Percent-decoding for a query parameter, without the `%` semantics of
     * [java.net.URLDecoder]: `+` is already handled by the caller, and a lone
     * `%` or `%zz` is kept verbatim rather than throwing. The result is always
     * re-validated, so this is never the only thing standing between site data
     * and an emitted `src`.
     */
    private fun percentDecode(value: String): String {
        if (value.indexOf('%') < 0) return value
        val out = StringBuilder(value.length)
        var i = 0
        while (i < value.length) {
            val char = value[i]
            if (char == '%' && i + 2 < value.length) {
                val hex = value.substring(i + 1, i + 3)
                val code = hex.toIntOrNull(16)
                if (code != null) {
                    out.append(code.toChar())
                    i += 3
                    continue
                }
            }
            out.append(char)
            i++
        }
        return out.toString()
    }

    /**
     * True when any path segment is `.` or `..`, or when the path contains a
     * percent-encoded form of one.
     *
     * The path has been percent-decoded by the time it arrives from
     * `innerHTML`, so the literal form is the one to look for; the encoded form
     * is checked as well because a path is passed on verbatim and some HTTP
     * clients decode it a second time.
     */
    private fun containsTraversal(path: String): Boolean {
        if (path.contains("..")) return true
        val lower = path.lowercase()
        return lower.contains("%2e%2e") || lower.contains("%2e.") || lower.contains(".%2e")
    }

    // ---- Tokeniser ----------------------------------------------------------

    private class Parser(private val source: String) {

        private var pos = 0
        private val openStack = ArrayDeque<String>()

        fun run(out: StringBuilder) {
            while (pos < source.length) {
                val char = source[pos]
                if (char == '<') {
                    val next = if (pos + 1 < source.length) source[pos + 1] else '\u0000'
                    when {
                        next == '!' -> skipBang(out)
                        next == '/' -> readTag(out, closing = true)
                        next == '?' -> skipUntil('>')
                        next == '!' || next.isLetter() -> readTag(out, closing = false)
                        else -> {
                            // A bare "<" in prose is text, not a tag.
                            out.append("&lt;")
                            pos++
                        }
                    }
                } else {
                    readText(out)
                }
            }
            // Close anything the source left open so the serialiser is well formed.
            while (openStack.isNotEmpty()) {
                val name = openStack.removeLast()
                out.append("</").append(name).append('>')
            }
        }

        private fun skipBang(out: StringBuilder) {
            if (source.startsWith("<!--", pos)) {
                val end = source.indexOf("-->", pos + 4)
                pos = if (end < 0) source.length else end + 3
                return
            }
            if (source.startsWith("<![CDATA[", pos)) {
                val end = source.indexOf("]]>", pos + 9)
                val stop = if (end < 0) source.length else end
                appendText(out, source.substring(pos + 9, stop))
                pos = if (end < 0) source.length else end + 3
                return
            }
            // DOCTYPE and every other bang declaration are dropped.
            val end = source.indexOf('>', pos)
            pos = if (end < 0) source.length else end + 1
        }

        private fun skipUntil(marker: Char) {
            val end = source.indexOf(marker, pos)
            pos = if (end < 0) source.length else end + 1
        }

        private fun readText(out: StringBuilder) {
            val next = source.indexOf('<', pos)
            val stop = if (next < 0) source.length else next
            appendText(out, source.substring(pos, stop))
            pos = stop
        }

        private fun readTag(out: StringBuilder, closing: Boolean) {
            val start = pos
            var cursor = pos + if (closing) 2 else 1
            if (cursor >= source.length) { pos = source.length; return }
            while (cursor < source.length && !source[cursor].isWhitespace() && source[cursor] != '>' && source[cursor] != '/') {
                cursor++
            }
            val rawName = source.substring(pos + if (closing) 2 else 1, cursor)
            if (rawName.isEmpty()) {
                out.append("&lt;")
                pos = start + 1
                return
            }
            val name = rawName.lowercase()

            val tagEnd = findTagEnd(cursor)
            val inner = source.substring(cursor, tagEnd)
            val selfClosing = inner.trimEnd().endsWith("/")
            pos = if (tagEnd < source.length) tagEnd + 1 else source.length

            val attributes = if (closing) emptyList() else parseAttributes(inner)

            handleTag(name, attributes, selfClosing, closing, out)
        }

        private fun findTagEnd(from: Int): Int {
            var cursor = from
            var quote = '\u0000'
            while (cursor < source.length) {
                val char = source[cursor]
                when {
                    quote != '\u0000' -> if (char == quote) quote = '\u0000'
                    char == '"' || char == '\'' -> quote = char
                    char == '>' -> return cursor
                }
                cursor++
            }
            return source.length
        }

        private fun handleTag(
            name: String,
            attributes: List<Pair<String, String>>,
            selfClosing: Boolean,
            closing: Boolean,
            out: StringBuilder,
        ) {
            if (closing) {
                closeTag(name, out)
                return
            }
            if (name in DROP_SUBTREE_TAGS) {
                if (name in VOID_TAGS) return
                skipSubtree(name)
                return
            }
            if (name == "a" && isCanary(attributes)) {
                skipSubtree("a")
                return
            }
            if (isHidden(attributes)) {
                if (name in VOID_TAGS) return
                skipSubtree(name)
                return
            }
            if (name == "img") {
                writeImage(attributes, out)
                return
            }
            if (isSceneBreak(attributes)) {
                // Emitted as the reader's structural cue, but **never** at the
                // cost of content the reader can see. The previous version called
                // `skipSubtree(name)` for every scene break whose text was not
                // interrupted by a tag from a hard-coded block list, so
                // `<div class="scene-break"><span>One.</span><em>Two.</em></div>`,
                // `<table class="scene-break"><tr><td>Body in a cell.</td></tr>`,
                // `<thead class="scene-break">` and `<a class="scene-break">`
                // each lost their prose and were stored as a bare `<hr>`. A
                // chapter that comes back shorter than the page rendered, still
                // reported as complete, with no signal that anything was
                // missing, is the one failure this scanner may not produce.
                //
                // So the subtree is skipped only for a genuine **marker**: a leaf
                // whose text is nothing but scene-break glyphs, which is what
                // `<p class="scene-break">* * *</p>` is. Anything else is
                // unwrapped and its text survives. Erring towards keeping is the
                // only safe direction for a chapter reader: an extra `<hr>` is
                // cosmetic, deleted prose is not.
                out.append("<hr>")
                if (selfClosing || name in VOID_TAGS) return
                // The `<hr>` *replaces* the element, so it is not pushed onto the
                // stack: its own closing tag becomes a stray close, which
                // [closeTag] ignores. Pushing it would emit a `</div>` for a
                // `<div>` that was never opened.
                if (isLeafGlyphMarker(name)) skipSubtree(name)
                return
            }
            if (name in KEEP_TAGS) {
                out.append('<').append(name)
                writeClassAttribute(name, attributes, out)
                out.append('>')
                if (selfClosing || name in VOID_TAGS) return
                openStack.addLast(name)
                return
            }
            if (name in UNWRAP_TAGS) {
                if (selfClosing || name in VOID_TAGS) return
                openStack.addLast(name)
                return
            }
            // Unknown tag: unwrap so its prose survives.
            if (selfClosing || name in VOID_TAGS) return
            openStack.addLast(name)
        }

        private fun closeTag(name: String, out: StringBuilder) {
            val index = openStack.lastIndexOf(name)
            if (index < 0) return // stray close
            // Implicitly close anything left open inside it.
            while (openStack.size > index) {
                val open = openStack.removeLast()
                if (open in KEEP_TAGS) out.append("</").append(open).append('>')
            }
        }

        private fun skipSubtree(name: String) {
            var depth = 1
            while (pos < source.length && depth > 0) {
                val next = source.indexOf('<', pos)
                if (next < 0) { pos = source.length; return }
                val tagEnd = findTagEnd(next + 1)
                val slice = source.substring(next + 1, if (tagEnd < source.length) tagEnd else source.length)
                val tokenName = slice.trimStart('/').takeWhile { it.isLetter() }.lowercase()
                val closing = slice.startsWith("/") || slice.startsWith(" /")
                val selfClosing = slice.trimEnd().endsWith("/")
                pos = if (tagEnd < source.length) tagEnd + 1 else source.length
                if (tokenName == name) {
                    if (closing) depth-- else if (!selfClosing) depth++
                }
            }
        }

        private fun isCanary(attributes: List<Pair<String, String>>): Boolean =
            attributes.any { (key, value) ->
                key == "data-security-canary" ||
                    key == "href" && value.contains("data-security-canary", ignoreCase = true)
            }

        private fun isHidden(attributes: List<Pair<String, String>>): Boolean {
            for ((key, value) in attributes) {
                when (key) {
                    "hidden" -> return true
                    "aria-hidden" -> if (value.trim().equals("true", ignoreCase = true)) return true
                    // Whitespace-insensitive so "display : none" is caught too.
                    "style" -> {
                        val style = value.lowercase().filterNot { it.isWhitespace() }
                        if (style.contains("display:none") || style.contains("visibility:hidden")) return true
                    }
                }
            }
            return false
        }

        /**
         * A scene-break marker, which the reader uses as a structural cue.
         *
         * These are normalised onto a single `<hr>` so the reader's paragraph
         * rhythm survives even though every other class attribute is chrome and
         * is thrown away.
         *
         * `data-scene-break` is matched on its **value**, not on its presence.
         * `parseAttributes` yields `("data-scene-break", "")` for a valueless
         * attribute, so a presence-only test saw every one of these as a scene
         * break: `data-scene-break="false"`, `data-scene-break="0"` and
         * `data-scene-break="off"` all deleted the element's content, which is
         * the exact inverse of what they say.
         */
        private fun isSceneBreak(attributes: List<Pair<String, String>>): Boolean {
            for ((key, value) in attributes) {
                if (key == "class" && SCENE_BREAK_CLASS.containsMatchIn(value)) return true
                if (key == "data-scene-break" && isAffirmative(value)) return true
            }
            return false
        }

        /**
         * True when an attribute value states that something is on.
         *
         * An empty or absent value counts, because `parseAttributes` cannot tell
         * `<div data-scene-break>` from `<div data-scene-break="">` and both are
         * conventional ways of writing a boolean attribute.
         */
        private fun isAffirmative(value: String): Boolean {
            val trimmed = value.trim()
            if (trimmed.isEmpty()) return true
            if (trimmed.length > 20) return false
            return when (trimmed.lowercase()) {
                "false", "0", "no", "off", "none", "null", "undefined" -> false
                else -> true
            }
        }

        /**
         * True when the element being opened is a scene-break **marker**: a leaf
         * whose own text is nothing but separator glyphs, digits and whitespace.
         *
         * `<p class="scene-break">* * *</p>` is a marker, and turning it into a
         * bare `<hr>` is the documented behaviour. `<div class="scene-break">` is
         * not, and neither is `<span class="scene-break">One.</span>` or
         * `<a class="scene-break">Click through.</a>` - those are prose that
         * happened to carry the class, and deleting their text is silent data
         * loss in a delivered chapter.
         *
         * The test is exact rather than a list of "probably block" tags, which is
         * what the earlier version used: `table`, `thead`, `tr`, `td`, `span` and
         * `a` all missed it, so a wrapper that happened to carry the class ate
         * whatever was inside it.
         *
         * Any nested tag at all counts as content, whatever it is: the element is
         * then not a leaf, and a leaf is the only thing this answers about.
         *
         * Reads only: it never advances [pos], and it stops at this element's own
         * closing tag so nested same-named elements cannot confuse it.
         */
        private fun isLeafGlyphMarker(name: String): Boolean {
            var cursor = pos
            var depth = 1
            val text = StringBuilder()
            while (cursor < source.length && depth > 0) {
                val next = source.indexOf('<', cursor)
                if (next < 0) {
                    text.append(source, cursor, source.length)
                    break
                }
                text.append(source, cursor, next)
                val tagEnd = findTagEnd(next + 1)
                val slice = source.substring(
                    next + 1,
                    if (tagEnd < source.length) tagEnd else source.length,
                )
                val tokenName = slice.trimStart('/').takeWhile { it.isLetter() }.lowercase()
                val closing = slice.startsWith("/") || slice.startsWith(" /")
                val selfClosing = slice.trimEnd().endsWith("/")
                cursor = if (tagEnd < source.length) tagEnd + 1 else source.length
                if (tokenName == name) {
                    if (closing) depth-- else if (!selfClosing) depth++
                    continue
                }
                // Any other tag means this is not a leaf. It may be void, it may
                // be inline; either way its content or its absence is a decision
                // for the normal walk, not for this one.
                if (closing) continue
                return false
            }
            return SCENE_BREAK_GLYPHS.matches(text.toString())
        }

        /** A 1x1 (or 1xN) image is a tracking pixel, never chapter art. */
        private fun isTrackingPixel(attributes: List<Pair<String, String>>): Boolean {
            for ((key, value) in attributes) {
                if (key != "width" && key != "height") continue
                val number = value.trim().removeSuffix("px").trim().toDoubleOrNull() ?: continue
                if (number <= 1.0) return true
            }
            return false
        }

        private fun writeImage(attributes: List<Pair<String, String>>, out: StringBuilder) {
            if (isTrackingPixel(attributes)) return
            val src = resolveImageSource(attributes.firstOrNull { it.first == "src" }?.second)
            if (src == null) return
            out.append("<img src=\"").append(escapeAttribute(src)).append('"')
            val alt = attributes.firstOrNull { it.first == "alt" }?.second
            if (!alt.isNullOrEmpty()) out.append(" alt=\"").append(escapeAttribute(alt)).append('"')
            attributes.firstOrNull { it.first == "title" }?.second
                ?.takeIf { it.isNotEmpty() }
                ?.let { out.append(" title=\"").append(escapeAttribute(it)).append('"') }
            out.append('>')
        }

        private fun writeClassAttribute(
            name: String,
            attributes: List<Pair<String, String>>,
            out: StringBuilder,
        ) {
            val allowed = ALLOWED_ATTRIBUTES[name] ?: return
            val classes = attributes.firstOrNull { it.first == "class" }?.second ?: return
            if (!SCENE_BREAK_CLASS.containsMatchIn(classes)) return
            if ("class" !in allowed && name != "hr") return
            out.append(" class=\"").append(escapeAttribute("scene-break")).append('"')
        }

        private fun parseAttributes(inner: String): List<Pair<String, String>> {
            val result = ArrayList<Pair<String, String>>(8)
            var cursor = 0
            val text = inner.removeSuffix("/")
            while (cursor < text.length) {
                while (cursor < text.length && (text[cursor].isWhitespace() || text[cursor] == '/')) cursor++
                if (cursor >= text.length) break
                val nameStart = cursor
                while (cursor < text.length && !text[cursor].isWhitespace() && text[cursor] != '=') cursor++
                val name = text.substring(nameStart, cursor).lowercase()
                while (cursor < text.length && text[cursor].isWhitespace()) cursor++
                if (cursor < text.length && text[cursor] == '=') {
                    cursor++
                    while (cursor < text.length && text[cursor].isWhitespace()) cursor++
                    val value: String
                    if (cursor < text.length && (text[cursor] == '"' || text[cursor] == '\'')) {
                        val quote = text[cursor]
                        cursor++
                        val valueStart = cursor
                        while (cursor < text.length && text[cursor] != quote) cursor++
                        value = text.substring(valueStart, minOf(cursor, text.length))
                        if (cursor < text.length) cursor++
                    } else {
                        val valueStart = cursor
                        while (cursor < text.length && !text[cursor].isWhitespace()) cursor++
                        value = text.substring(valueStart, cursor)
                    }
                    result.add(name to value)
                } else {
                    result.add(name to "")
                }
                if (name.isEmpty()) break
            }
            return result
        }
    }

    // ---- Text helpers -------------------------------------------------------

    /**
     * Escapes text into [out], preserving every entity the source already
     * carries and re-escaping every bare `&`.
     *
     * **Linear, and this was not.** The previous version called
     * `HTML_ENTITY.find(raw, index)`, which searches from `index` to the *end* of
     * the string. A `&` that began no entity therefore cost a full scan of
     * everything after it, making the whole method O(n·m): 24 000 bare `&#` in a
     * 48 KB body took 25.9 s on a server JVM. That runs inside `withContext(io)`
     * inside `ChapterCompletion.evaluate`, which is not interruptible, so
     * `withTimeout` could not stop it and the job overran its 120 s deadline
     * instead of reporting a timeout.
     *
     * Now each `&` is probed with [HTML_ENTITY.matchAt] at exactly that
     * position, which is one bounded test (the entity pattern is at most 35
     * characters) instead of a scan of the remainder. `matchAt` has no `^`
     * semantics to get wrong either, so the old double-escape regression cannot
     * come back through this path.
     */
    private fun appendText(out: StringBuilder, raw: String) {
        var index = 0
        while (index < raw.length) {
            when (val char = raw[index]) {
                '&' -> {
                    val match = HTML_ENTITY.matchAt(raw, index)
                    if (match != null) {
                        val entity = match.value
                        out.append(
                            when {
                                entity.equals("&nbsp;", ignoreCase = true) -> "&#160;"
                                else -> entity
                            }
                        )
                        index += entity.length
                    } else {
                        // A bare `&` is escaped rather than allowed to swallow the
                        // next word: `Tom & Jerry` must not become `Tom &amp;Jerry`.
                        out.append("&amp;")
                        index++
                    }
                }
                '<' -> { out.append("&lt;"); index++ }
                '>' -> { out.append("&gt;"); index++ }
                else -> { out.append(char); index++ }
            }
        }
    }

    private fun escapeAttribute(value: String): String {
        val out = StringBuilder(value.length + 8)
        for (char in value) {
            when (char) {
                '"' -> out.append("&quot;")
                '<' -> out.append("&lt;")
                '>' -> out.append("&gt;")
                '&' -> out.append("&amp;")
                '\n' -> out.append("&#10;")
                '\r' -> out.append("&#13;")
                else -> if (char.code < 0x20) out.append("&#") else out.append(char)
            }
        }
        return out.toString()
    }
}
