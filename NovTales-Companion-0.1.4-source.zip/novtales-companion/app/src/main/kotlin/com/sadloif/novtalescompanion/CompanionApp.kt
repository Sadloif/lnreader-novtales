package com.sadloif.novtalescompanion

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class CompanionApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            // LOW importance: the notification is a persistent status line and a
            // way to stop the service, not an alert the reader must act on.
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = getString(R.string.channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "novtales_companion_status"
    }
}