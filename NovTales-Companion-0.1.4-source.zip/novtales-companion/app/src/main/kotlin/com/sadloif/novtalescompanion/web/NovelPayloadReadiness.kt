package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json

/** A stream is ready when the requested metadata resolves, not when a prop exists. */
internal object NovelPayloadReadiness {
    fun isReady(payload: Json, path: String): Boolean = try {
        NovTalesExtraction.novel(payload, path)
        true
    } catch (error: CompanionException) {
        if (error.code != ErrorCode.SITE_CHANGED) throw error
        false
    }
}
