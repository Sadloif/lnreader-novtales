package com.sadloif.novtalescompanion.core

/**
 * The error codes required by spec section 10. HTTP status, website HTTP
 * response and adapter error are kept distinct: an HTTP 429 is never reported
 * as browser verification unless a verified marker actually says so.
 */
enum class ErrorCode(val httpStatus: Int, val retryable: Boolean) {
    COMPANION_UNAVAILABLE(503, true),
    UNAUTHORIZED(401, false),
    VERIFICATION_REQUIRED(409, false),
    SIGN_IN_REQUIRED(409, false),
    MEMBERSHIP_REQUIRED(402, false),
    READING_NOTICE_REQUIRED(409, false),
    RATE_LIMITED(429, true),
    QUEUE_FULL(429, true),
    TIMEOUT(504, true),
    INCOMPLETE_CHAPTER(502, true),
    WRONG_CHAPTER(502, false),
    SITE_CHANGED(502, false),
    CANCELLED(499, true),
    BAD_REQUEST(400, false),
    NOT_FOUND(404, false),
    INTERNAL(500, false);

    companion object {
        fun fromName(name: String?): ErrorCode? =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) }
    }
}

/**
 * A failure that carries a structured code to the plugin. Anything thrown out of
 * a job becomes one of these; nothing else reaches the local API.
 */
class CompanionException(
    val code: ErrorCode,
    override val message: String,
    val retryAfterMs: Long? = null,
    cause: Throwable? = null,
) : Exception(message, cause) {

    val retryable: Boolean get() = code.retryable

    companion object {
        fun unavailable() = CompanionException(
            ErrorCode.COMPANION_UNAVAILABLE,
            "Open the NovTales Companion and press Start.",
        )

        fun badRequest(message: String) =
            CompanionException(ErrorCode.BAD_REQUEST, message)

        fun timeout(what: String) = CompanionException(
            ErrorCode.TIMEOUT,
            "NovTales took too long to deliver $what. Try again.",
        )
    }
}
