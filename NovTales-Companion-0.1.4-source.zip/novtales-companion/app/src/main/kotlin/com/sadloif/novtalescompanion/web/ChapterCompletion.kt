package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.Paths

/**
 * The chapter completion rule from CONTRACTS.md section 4, and nothing else.
 *
 * A chapter is complete only when **all three** hold:
 *  1. an exact `End of Chapter N` marker is present in the article, where `N`
 *     equals the requested number;
 *  2. the chapter metadata identifies the same slug and the same number;
 *  3. `.nv-chapter-body` is non-empty after sanitising.
 *
 * Character count, an HTTP 200, a spinner disappearing and a non-empty preview
 * are all explicitly insufficient, and none of them appear below. `complete` can
 * only ever come out of [Verdict.Complete], and [Verdict.Complete] is only
 * reachable through that three-way conjunction.
 *
 * Pure JVM: no `android.*` import, so it is unit-testable off-device.
 */
object ChapterCompletion {

    /**
     * How long a *contradictory* observation is allowed to persist before it is
     * believed.
     *
     * A chapter that arrives with the wrong path, or with someone else's
     * `End of Chapter 10` marker, is normally a transient state during a client
     * side transition or a streaming preview of the previous part. Treating the
     * first sighting as terminal would report a wrong chapter for a chapter that
     * was about to finish correctly, so a contradiction has to survive a short
     * settle window before it becomes a verdict.
     */
    const val SETTLE_POLLS: Int = 8

    /**
     * Exactly `End of Chapter N`, with nothing before or after it.
     *
     * Case-**insensitive**, deliberately, and this must stay identical to the
     * adapter's `/^end of chapter/i` test. They used to disagree: the adapter
     * matched `end of chapter 10` and `END OF CHAPTER 10`, then reported them
     * verbatim, and this case-sensitive regex rejected both. The result was a
     * chapter that was visibly complete on screen failing `INCOMPLETE_CHAPTER`
     * on every poll until the deadline - a liveness failure, not a safety one,
     * but one that loses real downloads.
     *
     * Case sensitivity bought nothing here. The pattern is `matchEntire`, so the
     * surrounding text is still pinned exactly; only the case of the three words
     * and the digits is free, and no body text can become a marker by being
     * re-cased. `(?i)` is the one place the two implementations meet, so it is
     * asserted on both sides rather than left to a comment.
     */
    private val END_MARKER =
        Regex("(?i)^\\s*End of Chapter\\s+(\\d+(?:\\.\\d+)?)\\s*$")

    /**
     * Every code point that counts as whitespace on the marker path, spelled out
     * one escape at a time.
     *
     * `\\s` in a Java regex is `[ \t\n\x0B\f\r]` and is **not** Unicode-aware,
     * while ECMAScript's `\s` - the one the adapter's `END_MARKER_COMPLETE` uses
     * - covers U+00A0, U+1680, U+2000..U+200A, U+2028, U+2029, U+202F, U+205F,
     * U+3000 and U+FEFF as well. Without this the two halves disagreed: a marker
     * set with a thin space (U+2009) between two words was found by the adapter,
     * reported verbatim, and then refused here, so a visibly complete chapter
     * failed `INCOMPLETE_CHAPTER` on every poll until the deadline. That is a
     * liveness bug rather than a safety one, but it loses real downloads, and it
     * is the third time these two implementations disagreed about what a marker
     * is.
     *
     * The class is spelled out rather than written as `\p{Z}` for one reason: it
     * has to be translatable, character for character, by a test that reads this
     * declaration out of this file and runs it in a JavaScript engine - and `\p{Z}`
     * means something *different* there (`p{Z}` as literals, without the `u`
     * flag), which would make the parity check compare two different things and
     * pass. `tools/js-tests/adapter.test.js` section 13 is that check, and it
     * refuses to translate a class it cannot read exactly.
     *
     * It cannot weaken the rule: only whitespace is rewritten, and [END_MARKER]
     * still pins the surrounding text exactly.
     */
    private val ANY_WHITESPACE = Regex(
        "[\\t\\n\\u000B\\f\\r \\u0085\\u00A0\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000\\uFEFF]+"
    )

    /** `Chapter 12`, `Chapter 12.5`, `Chapter 12: The Title`, `Chapter 12 - Title`. */
    private val HEADING_NUMBER = Regex("(?i)\\bchapter\\s+(\\d+(?:\\.\\d+)?)\\b")

    sealed interface Verdict {

        /**
         * All three rules passed. This is the only source of a delivered
         * chapter, and it is never constructed from a partial read.
         */
        data class Complete(
            val path: String,
            val chapterNumber: String,
            val html: String,
        ) : Verdict

        /** The page is telling the reader to do something; stop polling. */
        data class NeedsUser(val code: ErrorCode, val message: String) : Verdict

        /** Keep polling and keep scrolling: delivery is still in flight. */
        data object StillLoading : Verdict

        /**
         * Nothing is wrong and nothing is finished. [reason] exists so the poll
         * loop can report *why* it is still waiting, and so the caller can tell a
         * stalled page apart from a healthy one.
         */
        data class NotReady(val reason: Reason, val detail: String) : Verdict

        /** Terminal failure that must not be retried against the same page. */
        data class Failed(val code: ErrorCode, val message: String) : Verdict
    }

    enum class Reason {
        /** The body element does not exist yet, or is still completely empty. */
        EMPTY_BODY,

        /** A body exists but sanitising it produced no readable text. */
        NO_TEXT_AFTER_SANITISING,

        /** The page is still showing its loading section or a spinner. */
        DELIVERY_RUNNING,

        /** A verified browser-verification page is being shown. */
        VERIFICATION_PAGE,

        /** The site asked for a sign-in. */
        SIGN_IN_PAGE,

        /** The site showed a paid or locked notice. */
        MEMBERSHIP_PAGE,

        /** The site applied its own rate limit. */
        RATE_LIMITED,

        /** The requested chapter was requested but something else answered. */
        CONTRADICTORY_SO_FAR,

        /**
         * Real text arrived with no end marker at all: the preview case. Kept
         * separate from every other reason so it can never be confused with a
         * slow page or an empty one.
         */
        PREVIEW_WITHOUT_MARKER,
    }

    /**
     * Decides what a single observation of the page means.
     *
     * [state] is the decoded `__novChapterState()` envelope. [settled] is true
     * once a contradiction has persisted for [SETTLE_POLLS] polls.
     */
    fun evaluate(requestedPath: String, state: Json, settled: Boolean = false): Verdict {
        val requestedNumber = Paths.chapterNumber(requestedPath)
            ?: throw CompanionException.badRequest("Not a chapter path: $requestedPath")

        if (state.bool("verificationRequired") == true) {
            return Verdict.NotReady(
                Reason.VERIFICATION_PAGE,
                "NovTales showed a browser-verification page.",
            )
        }
        if (state.bool("signInRequired") == true) {
            return Verdict.NeedsUser(
                ErrorCode.SIGN_IN_REQUIRED,
                "NovTales asked for a sign-in. Open the companion's browser tab and sign in, then retry.",
            )
        }
        if (state.bool("membershipRequired") == true) {
            return Verdict.NeedsUser(
                ErrorCode.MEMBERSHIP_REQUIRED,
                "This chapter is behind NovTales' paid access. Unlock it on the site, then retry.",
            )
        }

        // ---- Rule 1: the exact end marker, for the number that was asked for --
        // A blank marker means "no marker", which is the preview case, not a
        // contradiction. The adapter reports "" when it finds nothing, so this
        // distinction matters: treating "" as an unrecognised marker would turn
        // every preview into a spurious contradiction and eventually into a
        // wrong-chapter failure.
        // Read through [ANY_WHITESPACE] first, so a marker is compared here the
        // same way the adapter's own pattern compares it. See that constant for
        // the Unicode-space divergence this closes.
        val markerText = state.str("endMarker")
            ?.replace(ANY_WHITESPACE, " ")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
        val markerNumber = markerText?.let { END_MARKER.matchEntire(it)?.groupValues?.get(1) }

        // A rate limit only matters while there is nothing to deliver. It is
        // checked here, *after* the marker is known, so a rate-limit signal can
        // never veto a chapter that has already satisfied the completion rule.
        if (state.bool("rateLimited") == true && markerNumber == null) {
            return Verdict.NotReady(
                Reason.RATE_LIMITED,
                "NovTales rate limited the companion. Waiting before trying again.",
            )
        }

        if (markerText != null && markerNumber == null) {
            // Something that claims to be an end marker but is not exactly one.
            // "End of Chapter 1 of 3" or "End of chapter preview" must not pass.
            if (!settled) {
                return Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "Unrecognised end marker.")
            }
        }

        // ---- Rule 2: the metadata must be the chapter that was requested ------
        val deliveredPath = state.str("path")?.let { normaliseChapterPath(it) }
        val pathMatches = deliveredPath != null && Paths.isSameChapter(requestedPath, deliveredPath)

        // A page that is definitively a different chapter is a wrong chapter, but
        // only once the contradiction has settled: during a transition the URL
        // and the body can briefly disagree.
        if (deliveredPath != null && !pathMatches) {
            return if (settled) {
                Verdict.Failed(
                    ErrorCode.WRONG_CHAPTER,
                    "NovTales delivered '$deliveredPath' instead of '$requestedPath'.",
                )
            } else {
                Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "Page is not the requested chapter yet.")
            }
        }
        if (deliveredPath == null) {
            return if (settled) {
                Verdict.Failed(
                    ErrorCode.SITE_CHANGED,
                    "The chapter page did not report which chapter it is.",
                )
            } else {
                Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "Chapter path is not known yet.")
            }
        }

        if (markerNumber != null && !numbersMatch(requestedNumber, markerNumber)) {
            return if (settled) {
                Verdict.Failed(
                    ErrorCode.WRONG_CHAPTER,
                    "The chapter ended at 'End of Chapter $markerNumber' but chapter $requestedNumber was requested.",
                )
            } else {
                Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "End marker does not match the request yet.")
            }
        }

        // ---- Rule 3: a body that survives sanitising --------------------------
        val bodyHtml = state.str("bodyHtml")
        if (bodyHtml.isNullOrBlank()) {
            return when {
                state.bool("stillLoading") == true -> Verdict.StillLoading
                else -> Verdict.NotReady(Reason.EMPTY_BODY, "The chapter body is empty.")
            }
        }

        val sanitised = HtmlSanitiser.sanitise(bodyHtml)
        if (!HtmlSanitiser.hasReadableText(sanitised)) {
            // A preview of nothing but images, or a body that sanitised away to
            // markup with no prose, is not a chapter.
            return if (state.bool("stillLoading") == true) {
                Verdict.StillLoading
            } else {
                Verdict.NotReady(Reason.NO_TEXT_AFTER_SANITISING, "The chapter body has no readable text.")
            }
        }

        // ---- All three hold ---------------------------------------------------
        if (markerNumber == null) {
            // Text is present and delivery has stopped, but there is no exact end
            // marker. This is precisely the preview case: a non-empty body is not
            // a finished chapter.
            return if (state.bool("stillLoading") == true) {
                Verdict.StillLoading
            } else {
                Verdict.NotReady(
                    Reason.PREVIEW_WITHOUT_MARKER,
                    "The chapter text arrived without an 'End of Chapter $requestedNumber' marker.",
                )
            }
        }

        // The three contract rules have all passed. `stillLoading` is a
        // diagnostic here and deliberately does not gate completion: the site
        // occasionally leaves a spinner in the chrome long after the last part
        // lands, and letting that veto a finished chapter would lose real
        // downloads. The exact marker is the authority, as spec section 9 says.
        val deliveredNumber = NovTalesExtraction.normaliseChapterNumber(state.str("chapterNumber"))
            ?: NovTalesExtraction.normaliseChapterNumber(Paths.chapterNumber(deliveredPath))
            ?: return Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "Chapter number is not known yet.")
        if (!numbersMatch(requestedNumber, deliveredNumber)) {
            return if (settled) {
                Verdict.Failed(
                    ErrorCode.WRONG_CHAPTER,
                    "The page reports chapter $deliveredNumber but $requestedNumber was requested.",
                )
            } else {
                Verdict.NotReady(Reason.CONTRADICTORY_SO_FAR, "Chapter number does not match the request yet.")
            }
        }

        return Verdict.Complete(
            path = "/chapter/${Paths.chapterSlug(deliveredPath)}-$deliveredNumber",
            chapterNumber = deliveredNumber,
            html = sanitised,
        )
    }

    /** True when [bodyLength] grew since the previous poll, i.e. more parts are arriving. */
    fun grew(previous: Int?, current: Int): Boolean = previous != null && current > previous

    /**
     * One poll of the chapter loop, and the whole of its decision.
     *
     * This exists as a function so that it can be tested off-device. The loop
     * itself lives in [WebViewBrowserGateway] and cannot be: it needs a WebView,
     * a `Looper` and the operation session. Before this was extracted, the
     * decision "does this poll need the body, and has the marker shown up yet?"
     * was three lines inline in `runChapter`, and **deleting them left every test
     * in the suite green** - 617 of them, none of which executed that code. The
     * bug they were written for (bug 16: the body re-read sat inside a `Complete`
     * branch no cheap poll could reach, so every chapter failed
     * `INCOMPLETE_CHAPTER`) lived exactly there, and the suite that claims to
     * cover it was exercising [evaluate] instead, which behaves identically with
     * or without the loop.
     *
     * [readFull] is the seam: the caller passes something that can ask the page
     * for the body. It is invoked **at most once per call**, and only when the
     * cheap state says the body could change the answer.
     *
     * Why the marker has to be worth the read: `evaluate` looks at the marker
     * *before* it looks at the body, so a marker for the wrong chapter is a
     * contradiction on the cheap state alone. Re-reading the whole body on every
     * one of those polls - which is what an unconditional "marker is present, so
     * spend the expensive read" does - ships the entire chapter across the
     * bridge nine times over a settle window to compute the same verdict.
     */
    suspend fun decideState(
        requestedPath: String,
        cheap: Json,
        contradictions: Int,
        readFull: suspend (includeBody: Boolean) -> Json,
    ): Verdict {
        val marker = cheap.str("endMarker")
        val state = if (worthTheBodyRead(requestedPath, marker)) readFull(true) else cheap
        return evaluate(requestedPath, state, settled = contradictions >= SETTLE_POLLS)
    }

    /**
     * True when this poll's cheap state says the body could change the verdict.
     *
     * Three cases, and only one of them needs the body:
     *
     *  - no marker at all: this is the preview case and no body will change it,
     *    because [evaluate] returns `EMPTY_BODY` from a cheap state before it
     *    ever reaches the marker rule;
     *  - a marker for **this** chapter, or one that cannot be parsed: the body is
     *    the only thing left to check, so read it;
     *  - a marker for a **different** chapter: a contradiction on its own, and
     *    `evaluate` reaches that verdict before the body rule, so the body is
     *    never consulted.
     */
    fun worthTheBodyRead(requestedPath: String, marker: String?): Boolean {
        val text = marker?.replace(ANY_WHITESPACE, " ")?.trim()
        if (text.isNullOrEmpty()) return false
        val requested = Paths.chapterNumber(requestedPath) ?: return true
        val delivered = headingNumber(text) ?: return true
        return numbersMatch(requested, delivered)
    }

    /** A failure verdict is terminal; everything else is worth another poll. */
    fun isTerminal(verdict: Verdict): Boolean =
        verdict is Verdict.Complete || verdict is Verdict.NeedsUser || verdict is Verdict.Failed

    fun toException(verdict: Verdict): CompanionException = when (verdict) {
        is Verdict.Complete -> throw IllegalStateException("A complete chapter is not a failure")
        is Verdict.NeedsUser -> CompanionException(verdict.code, verdict.message)
        is Verdict.Failed -> CompanionException(verdict.code, verdict.message)
        Verdict.StillLoading -> CompanionException.timeout("the chapter")
        is Verdict.NotReady -> CompanionException(ErrorCode.INCOMPLETE_CHAPTER, incompleteMessage(verdict))
    }

    private fun incompleteMessage(verdict: Verdict.NotReady): String = when (verdict.reason) {
        Reason.EMPTY_BODY ->
            "NovTales stopped sending chapter text before the 'End of Chapter' marker appeared. " +
                "Nothing was saved, because a partial chapter is not a chapter."
        Reason.NO_TEXT_AFTER_SANITISING ->
            "NovTales returned a chapter body with no readable text in it. Nothing was saved."
        Reason.DELIVERY_RUNNING ->
            "NovTales was still delivering the chapter when the deadline passed."
        Reason.VERIFICATION_PAGE ->
            "NovTales is asking the companion to verify the browser. Open the companion's browser tab and finish the check."
        Reason.SIGN_IN_PAGE ->
            "NovTales is asking for a sign-in. Open the companion's browser tab and sign in."
        Reason.MEMBERSHIP_PAGE ->
            "NovTales reported this chapter as locked. Unlock it on the site, then retry."
        Reason.RATE_LIMITED ->
            "NovTales rate limited the companion. Wait a moment and retry."
        Reason.PREVIEW_WITHOUT_MARKER ->
            "NovTales returned a chapter preview: real text, but no 'End of Chapter' marker. " +
                "Nothing was saved, because a partial chapter is not a chapter."
        Reason.CONTRADICTORY_SO_FAR ->
            "NovTales' chapter page never settled on the requested chapter. " +
                "Nothing was saved, because the text may belong to a different chapter."
    }

    /**
     * Compares two chapter numbers by value, so `12`, `12.0` and `12.00` are the
     * same number while `12.5` and `12` are not.
     *
     * Delegates to [Paths.numbersEqual] rather than converting to [Double]. A
     * local `Double` comparison was the second copy of this logic after the one in
     * [Paths.isSameChapter] had already been fixed for exactly that reason, and it
     * let two distinct chapter numbers that round to the same IEEE-754 double pass
     * as the same chapter — meaning a page for chapter `…992` could be accepted
     * as `Verdict.Complete` for a request for `…993`. This is the wrong-chapter
     * guard, so it has exactly one implementation now.
     */
    fun numbersMatch(requested: String, delivered: String): Boolean =
        Paths.numbersEqual(requested, delivered)

    /** Pulls the chapter number out of an article heading, if it has one. */
    fun headingNumber(heading: String?): String? {
        val text = heading?.trim()?.replace('\u00A0', ' ') ?: return null
        if (text.isEmpty() || text.length > 200) return null
        val match = HEADING_NUMBER.find(text) ?: return null
        return NovTalesExtraction.normaliseChapterNumber(match.groupValues[1])
    }

    private fun normaliseChapterPath(raw: String): String? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty() || trimmed.length > 512) return null
        val withoutQuery = trimmed.substringBefore('?').substringBefore('#')
        return if (Paths.isChapter(withoutQuery)) withoutQuery else null
    }
}
