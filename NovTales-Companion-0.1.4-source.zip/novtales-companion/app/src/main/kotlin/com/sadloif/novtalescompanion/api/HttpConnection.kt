package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.ApiError
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.jsonObject
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.SocketException
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Everything the router needs for one request, and nothing more.
 *
 * The body is *not* read when the context is constructed. A handler that fails
 * authentication, hits an unknown route or the wrong method never calls [body],
 * so an unauthenticated caller can make the companion read at most the header
 * budget before being disconnected (spec section 11).
 */
internal class RequestContext(
    val head: ParsedRequest,
    private val input: InputStream,
) {

    private var read = false

    /** True when there is nothing left on the wire that this handler did not consume. */
    val bodyConsumed: Boolean get() = read || head.contentLength == 0

    /**
     * Reads exactly `Content-Length` bytes and decodes them as UTF-8.
     *
     * @throws HttpParseException 400 when the client hangs up mid-body. The body
     *   is already bounded by the parser (413 above [Config.MAX_REQUEST_BODY_BYTES]),
     *   so this loop cannot run away.
     */
    fun body(): String {
        if (read) return ""
        val length = head.contentLength
        if (length <= 0) {
            read = true
            return ""
        }
        val bytes = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val count = input.read(bytes, offset, length - offset)
            if (count < 0) throw HttpParseException(400, "The request body ended unexpectedly.")
            offset += count
        }
        read = true
        return String(bytes, Charsets.UTF_8)
    }
}

/** Answers one request. Implemented by [ApiRouter]. */
internal fun interface RequestHandler {
    fun handle(request: RequestContext): ApiResponse
}

/**
 * A response ready to be written, still unserialised.
 *
 * `close` defaults to true for every non-2xx status. Closing after an error is
 * deliberate: once a request has been refused there is no reason to keep reading
 * from that socket, and closing removes any chance of a client smuggling a second
 * request into a connection whose head we have already thrown away.
 */
internal class ApiResponse(
    val status: Int,
    val body: String? = null,
    val contentType: String? = "application/json; charset=utf-8",
    val headers: List<Pair<String, String>> = emptyList(),
    val close: Boolean = status >= 400,
) {

    companion object {

        fun json(status: Int, payload: Json, headers: List<Pair<String, String>> = emptyList()) =
            ApiResponse(status, payload.write(), headers = headers)

        fun empty(status: Int, headers: List<Pair<String, String>> = emptyList()) =
            ApiResponse(status, null, contentType = null, headers = headers)

        /**
         * The structured error envelope from spec section 10. `retryAfterMs` is
         * repeated at the top level so a client can read it without walking into
         * `error`, which mirrors the shape `Job.toResponse` produces.
         */
        fun error(
            status: Int,
            error: ApiError,
            headers: List<Pair<String, String>> = emptyList(),
        ): ApiResponse {
            val payload = jsonObject(
                "apiVersion" to Config.API_VERSION,
                "error" to error.toJson(),
                "retryAfterMs" to error.retryAfterMs,
            )
            val allHeaders = if (error.retryAfterMs != null) {
                headers + ("Retry-After" to ((error.retryAfterMs + 999) / 1000).toString())
            } else {
                headers
            }
            return ApiResponse(status, payload.write(), headers = allHeaders, close = true)
        }
    }
}

/**
 * Serves one client connection: read a head, hand it to the router, write the
 * answer, and repeat while the client keeps the connection alive.
 *
 * There is no `android.*` import in this file, so the whole request/response
 * cycle can be exercised on the JVM against a `ByteArrayInputStream`.
 *
 * @param readDeadline how long this peer may keep the thread that is serving it
 *   while it says nothing. Optional because the pure-JVM tests drive this class
 *   against an in-memory stream with nothing to bound; over a socket the server
 *   always supplies one, because the alternative is a thread-per-connection
 *   that any local app can park indefinitely.
 */
internal class HttpConnection(
    private val input: InputStream,
    private val output: OutputStream,
    private val clock: () -> Long,
    private val onLog: ((String) -> Unit)?,
    private val handler: RequestHandler,
    private val readDeadline: ConnectionReadDeadline? = null,
) {

    /**
     * @param deadlineMs wall-clock time after which the connection is dropped
     *   regardless of what the client is doing. Keep-alive plus a client that
     *   never sends another request would otherwise hold a pool thread forever.
     */
    fun serve(deadlineMs: Long) {
        var firstOnConnection = true
        while (clock() < deadlineMs) {
            readDeadline?.awaitNextRequest(deadlineMs, firstOnConnection)
            firstOnConnection = false

            val head = try {
                HttpRequestParser.parseHead(input)
            } catch (failure: HttpParseException) {
                // 400/411/413/417/431/505 all mean "we are done with this socket".
                readDeadline?.finish()
                write(ApiResponse.error(failure.status, refusal(failure.status, failure.message)), close = true)
                return
            } catch (_: HttpReadTimeout) {
                // The peer stopped sending part way through a head. Nothing on the
                // wire was malformed, so there is no refusal to explain - just a
                // connection that is not going to finish.
                readDeadline?.finish()
                onLog?.invoke("408 head-read deadline")
                write(ApiResponse.error(408, SLOW_PEER), close = true)
                return
            }

            if (head == null) {
                // Peer closed cleanly between requests.
                readDeadline?.finish()
                return
            }

            val request = RequestContext(head, input)
            val response = try {
                handler.handle(request)
            } catch (_: HttpReadTimeout) {
                // An authenticated peer that started a body and then went away.
                readDeadline?.finish()
                return
            } catch (failure: HttpParseException) {
                ApiResponse.error(failure.status, refusal(failure.status, failure.message))
            } catch (_: Throwable) {
                // A bug in the router must not be able to kill the pool thread or
                // to answer with a stack trace.
                ApiResponse.error(500, ApiError.of(ErrorCode.INTERNAL, INTERNAL_MESSAGE))
            }

            val close = response.close ||
                !head.keepAlive ||
                !request.bodyConsumed ||
                clock() >= deadlineMs
            write(response, close)
            if (close) {
                readDeadline?.finish()
                return
            }
        }
        readDeadline?.finish()
    }

    /**
     * Serialises and writes one response.
     *
     * The whole response is measured against [Config.MAX_RESPONSE_BYTES] before
     * a single byte reaches the socket. A chapter result is the largest thing
     * this server ever returns, and it comes from the website rather than from
     * the companion, so the cap is enforced here as well as on the way in.
     */
    private fun write(response: ApiResponse, close: Boolean) {
        var payload = response.body?.toByteArray(Charsets.UTF_8) ?: ByteArray(0)
        var bytes = build(response, payload, close)
        var forcedClose = close
        if (bytes.size > Config.MAX_RESPONSE_BYTES) {
            // The result came from the website, not from us, so the size is
            // re-checked here. Replacing the response and dropping the
            // connection is the only safe answer: the client is otherwise left
            // waiting on a Content-Length that will never arrive.
            val replacement = ApiResponse.error(
                500,
                ApiError.of(
                    ErrorCode.INTERNAL,
                    "The result was too large to send. Try a smaller request.",
                ),
            )
            payload = replacement.body?.toByteArray(Charsets.UTF_8) ?: ByteArray(0)
            forcedClose = true
            bytes = build(replacement, payload, forcedClose)
            output.write(bytes)
            output.flush()
            onLog?.invoke("${replacement.status} response-too-large")
            return
        }

        output.write(bytes)
        output.flush()
        onLog?.invoke("${response.status} ${payload.size}b")
    }

    private fun build(response: ApiResponse, payload: ByteArray, close: Boolean): ByteArray {
        val head = StringBuilder(256)
        head.append("HTTP/1.1 ").append(response.status).append(' ')
            .append(reason(response.status)).append("\r\n")
        head.append("Date: ").append(httpDate(clock())).append("\r\n")
        head.append("Server: NovTales-Companion/").append(Config.COMPANION_VERSION).append("\r\n")
        // Results are per-session and the pairing key is the only auth; a cache
        // anywhere in the path would serve one caller's chapters to another.
        head.append("Cache-Control: no-store\r\n")
        // The API only ever returns JSON and never a browser-loadable document.
        head.append("X-Content-Type-Options: nosniff\r\n")
        head.append("Referrer-Policy: no-referrer\r\n")
        // Deliberately no CORS headers: this is not a browser origin. A web page
        // cannot reach 127.0.0.1 cross-origin, and no `Access-Control-Allow-*`
        // line is ever emitted, so a future one cannot be added by accident.
        response.contentType?.let { head.append("Content-Type: ").append(it).append("\r\n") }
        if (response.status != 204) head.append("Content-Length: ").append(payload.size).append("\r\n")
        for ((name, value) in response.headers) {
            head.append(name).append(": ").append(sanitiseHeader(value)).append("\r\n")
        }
        head.append("Connection: ").append(if (close) "close" else "keep-alive").append("\r\n")
        head.append("\r\n")

        val headBytes = head.toString().toByteArray(Charsets.ISO_8859_1)
        val out = ByteArray(headBytes.size + payload.size)
        System.arraycopy(headBytes, 0, out, 0, headBytes.size)
        System.arraycopy(payload, 0, out, headBytes.size, payload.size)
        return out
    }

    /**
     * Strips anything that could terminate a header line. Only fixed, developer
     * supplied header values ever reach this, but response splitting is cheap to
     * prevent and expensive to discover.
     */
    private fun sanitiseHeader(value: String): String =
        value.filter { it.code in 0x20..0x7E && it != '\r' && it != '\n' }

    private fun refusal(status: Int, message: String): ApiError =
        ApiError.of(codeFor(status), message)

    /**
     * The closest `ErrorCode` for a transport-level status.
     *
     * `ErrorCode` has no member for 405/411/413/417/431/505, so those reuse
     * `BAD_REQUEST` on the wire with the real status in the status line. See the
     * report: adding `METHOD_NOT_ALLOWED` and `PAYLOAD_TOO_LARGE` to
     * `core/Errors.kt` would let the client branch on `error.code` alone.
     */
    private fun codeFor(status: Int): ErrorCode = when (status) {
        401 -> ErrorCode.UNAUTHORIZED
        404 -> ErrorCode.NOT_FOUND
        else -> ErrorCode.BAD_REQUEST
    }

    companion object {

        const val INTERNAL_MESSAGE = "The companion could not complete this request."

        /**
         * Answered to a peer that started a request and then stopped sending.
         *
         * RFC 7231 408 is exactly this case. It is worth sending rather than
         * dropping silently: a plugin that hits the deadline should be able to
         * tell "you were too slow" from "the companion is gone", and the reply is
         * a few hundred bytes to a peer that has already proved it can read.
         */
        private val SLOW_PEER: ApiError = ApiError.of(
            ErrorCode.BAD_REQUEST,
            "The request was not finished within the time allowed.",
        )

        // Indexed by `Calendar.DAY_OF_WEEK`, which is 1-based (Sunday == 1), so the
// first slot is deliberately empty.
private val DAY_NAMES = arrayOf("", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        private val MONTH_NAMES = arrayOf(
            "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
        )

        fun reason(status: Int): String = when (status) {
            200 -> "OK"
            202 -> "Accepted"
            204 -> "No Content"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            409 -> "Conflict"
            411 -> "Length Required"
            413 -> "Content Too Large"
            417 -> "Expectation Failed"
            429 -> "Too Many Requests"
            431 -> "Request Header Fields Too Large"
            499 -> "Client Closed Request"
            500 -> "Internal Server Error"
            502 -> "Bad Gateway"
            503 -> "Service Unavailable"
            504 -> "Gateway Timeout"
            505 -> "HTTP Version Not Supported"
            else -> "Status $status"
        }

        /** RFC 7231 `Date`, in GMT. Never derived from anything the client sent. */
        fun httpDate(epochMillis: Long): String {
            val calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US)
            calendar.timeInMillis = epochMillis
            return buildString {
                append(DAY_NAMES[calendar.get(Calendar.DAY_OF_WEEK)]).append(',')
                append(' ')
                append(two(calendar.get(Calendar.DAY_OF_MONTH))).append(' ')
                append(MONTH_NAMES[calendar.get(Calendar.MONTH)]).append(' ')
                append(calendar.get(Calendar.YEAR)).append(' ')
                append(two(calendar.get(Calendar.HOUR_OF_DAY))).append(':')
                append(two(calendar.get(Calendar.MINUTE))).append(':')
                append(two(calendar.get(Calendar.SECOND))).append(" GMT")
            }
        }

        private fun two(value: Int): String = if (value < 10) "0$value" else value.toString()

        /** Wraps a connection loop so a client that vanishes costs nothing. */
        fun quietly(onLog: ((String) -> Unit)?, block: () -> Unit) {
            try {
                block()
            } catch (_: SocketException) {
                onLog?.invoke("socket closed")
            } catch (_: EOFException) {
                onLog?.invoke("eof")
            } catch (_: IOException) {
                onLog?.invoke("io error")
            } catch (failure: Throwable) {
                // Never let a single client kill a pool thread, and never put a
                // stack trace anywhere near a response or a log line.
                onLog?.invoke("unhandled: ${failure.javaClass.simpleName}")
            }
        }
    }
}