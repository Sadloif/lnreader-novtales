package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Config
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

/**
 * The only methods this server will ever route. The list is an allowlist, not a
 * hint: anything else is answered with 405 before a route is looked up, so there
 * is no code path in which `CONNECT`, `TRACE`, `PUT` or a WebDAV verb reaches
 * anything. There is no proxy here and there never will be one (spec section 11).
 */
internal enum class HttpMethod(val token: String) {
    GET("GET"),
    POST("POST"),
    DELETE("DELETE"),
    OPTIONS("OPTIONS");

    companion object {
        /** Exact, case-sensitive match: `get` is not `GET`. */
        fun fromToken(token: String): HttpMethod? = entries.firstOrNull { it.token == token }
    }
}

/**
 * A transport-level failure that already knows which HTTP status the client must
 * be told. Carrying the status on the exception keeps the reason-phrase and
 * header logic out of the parse path and makes every rejection unit-testable.
 */
internal class HttpParseException(
    val status: Int,
    override val message: String,
) : IOException(message)

/**
 * A parsed request *head*. The body is deliberately not part of this type: the
 * router authenticates first and only then asks the connection for the body, so
 * an unauthenticated caller can never make this server buffer a payload
 * (spec section 11).
 */
internal class ParsedRequest(
    /** Raw method token as sent. May be anything; [httpMethod] is null if not allowed. */
    val method: String,
    /** Raw request target, exactly as it appeared on the wire. */
    val target: String,
    /** Origin-form path with the query string removed. Never percent-decoded. */
    val path: String,
    /** Raw query string without the `?`, or null when there was none. Never parsed. */
    val query: String?,
    /** `HTTP/1.1` or `HTTP/1.0`. */
    val version: String,
    private val headers: Map<String, String>,
    /** Bytes of request line + headers, used only for diagnostics. */
    val headerBytes: Int,
    val headerLines: Int,
) {

    /** Null when the method is not on the allowlist. */
    val httpMethod: HttpMethod? get() = HttpMethod.fromToken(method)

    fun header(name: String): String? = headers[name.lowercase()]

    fun hasHeader(name: String): Boolean = headers.containsKey(name.lowercase())

    /** -1 when the header was absent, which is different from a declared zero. */
    val contentLength: Int get() = header("content-length")?.trim()?.toIntOrNull() ?: 0

    val keepAlive: Boolean
        get() {
            val tokens = header("connection")
                ?.split(',')
                ?.map { it.trim().lowercase() }
                ?: emptyList()
            if (tokens.contains("close")) return false
            return if (version == "HTTP/1.0") tokens.contains("keep-alive") else true
        }

    /** Never include the pairing key, cookies or a body in anything derived from this. */
    fun safeSummary(): String = "$method $path"
}

/**
 * Strict, bounded reader for the request line and headers.
 *
 * Every property of this parser is chosen so that an attacker on the loopback
 * socket cannot make the companion allocate without bound:
 *
 *  - The request line plus all headers share one budget of [Config.MAX_HEADER_BYTES].
 *    Exhausting it is 431, not a truncated read.
 *  - Individual lines are capped, so one 4 MB "header" is rejected after 8 KB
 *    rather than being buffered in full.
 *  - At most [MAX_HEADER_LINES] header lines are accepted.
 *  - `Transfer-Encoding` is refused outright. This server has no chunked
 *    decoder, and a request that is framed two different ways is the raw material
 *    of every request-smuggling bug ever found; refusing it removes the class.
 *  - Duplicate headers (including a second `Content-Length`) are refused.
 *  - Obsolete line folding is refused: a folded header is two interpretations
 *    depending on who is parsing, which is the same smuggling problem again.
 *  - The request target must be origin-form. `http://host/path` (absolute-form),
 *    `host:port` (authority-form, i.e. CONNECT) and `*` (asterisk-form) are all
 *    rejected, because accepting them is the first half of a proxy.
 *  - Percent-encoding is rejected in the target. Nothing in this API needs
 *    escaping (the only variable segment is a UUID job id), so an encoded
 *    target is either a mistake or an attempt at double-decoding tricks that
 *    `core/Paths` would then have to catch. Rejecting it here is cheaper and
 *    has one answer instead of two.
 *
 * There are no `android.*` imports in this file on purpose: the whole parser is
 * unit-testable on the JVM with a `ByteArrayInputStream`.
 */
internal object HttpRequestParser {

    /** Hard ceiling on header count, independent of the byte budget. */
    const val MAX_HEADER_LINES = 100

    /** Longest single request line. */
    const val MAX_REQUEST_LINE_BYTES = 4 * 1024

    /** Longest single header line. */
    const val MAX_LINE_BYTES = 8 * 1024

    /** RFC 7230 `tchar`. */
    private const val TOKEN_CHARS =
        "!#$%&'*+-.^_`|~0123456789" +
            "abcdefghijklmnopqrstuvwxyz" +
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    /**
     * Characters permitted in the path portion of a request target: unreserved
     * URI characters plus `/`. Everything else - including `%` - is refused.
     */
    private const val PATH_CHARS =
        "0123456789" +
            "abcdefghijklmnopqrstuvwxyz" +
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
            "-._~/"

    /**
     * Reads one request head.
     *
     * @return the parsed head, or null when the peer closed cleanly before
     *   sending anything (not an error: that is a client that hung up).
     * @throws HttpParseException for every malformed or oversized request, with
     *   the HTTP status the caller should send back.
     */
    fun parseHead(input: InputStream): ParsedRequest? {
        var budget = Config.MAX_HEADER_BYTES

        val requestLine = readLine(input, MAX_REQUEST_LINE_BYTES, budget)
            ?: return null
        budget -= requestLine.length + 2 // + CRLF
        if (budget <= 0) throw tooLarge("Request headers are too large.")

        val parsedLine = parseRequestLine(requestLine)

        val headers = LinkedHashMap<String, String>()
        var lines = 0
        while (true) {
            val line = readLine(input, MAX_LINE_BYTES, budget)
                ?: throw HttpParseException(400, "The request headers ended unexpectedly.")
            lines++
            if (lines > MAX_HEADER_LINES) {
                throw HttpParseException(431, "Too many request header lines.")
            }
            budget -= line.length + 2
            if (budget <= 0) throw tooLarge("Request headers are too large.")
            if (line.isEmpty()) break
            addHeader(headers, line)
        }

        val request = ParsedRequest(
            method = parsedLine.method,
            target = parsedLine.target,
            path = parsedLine.path,
            query = parsedLine.query,
            version = parsedLine.version,
            headers = headers,
            headerBytes = Config.MAX_HEADER_BYTES - budget,
            headerLines = lines,
        )

        validate(request, headers)
        return request
    }

    // ---- Request line -------------------------------------------------------

    private class RequestLine(
        val method: String,
        val target: String,
        val path: String,
        val query: String?,
        val version: String,
    )

    private fun parseRequestLine(line: String): RequestLine {
        val firstSpace = line.indexOf(' ')
        if (firstSpace <= 0) throw HttpParseException(400, "Malformed request line.")
        val secondSpace = line.indexOf(' ', firstSpace + 1)
        if (secondSpace <= firstSpace + 1) throw HttpParseException(400, "Malformed request line.")

        val method = line.substring(0, firstSpace)
        val target = line.substring(firstSpace + 1, secondSpace)
        val version = line.substring(secondSpace + 1)

        if (version.isEmpty() || version.contains(' ')) {
            throw HttpParseException(400, "Malformed request line.")
        }
        if (method.isEmpty() || method.any { it !in TOKEN_CHARS }) {
            throw HttpParseException(400, "Malformed request method.")
        }

        val (path, query) = splitTarget(target)

        return RequestLine(
            method = method,
            target = target,
            path = path,
            query = query,
            version = version,
        )
    }

    /**
     * Splits an origin-form target. Anything that is not origin-form is refused;
     * see the class KDoc for why that matters.
     */
    private fun splitTarget(target: String): Pair<String, String?> {
        if (target.isEmpty()) throw HttpParseException(400, "Empty request target.")
        if (target.startsWith("http://") || target.startsWith("https://")) {
            // absolute-form is a proxy request. This server has no forwarding
            // capability and never will (spec section 11).
            throw HttpParseException(400, "Absolute request targets are not supported.")
        }
        if (target == "*" || target.first().isLetter() || target.first() == ':') {
            // asterisk-form and authority-form (CONNECT) are refused for the same reason.
            throw HttpParseException(400, "This request target form is not supported.")
        }
        if (!target.startsWith("/")) throw HttpParseException(400, "Malformed request target.")

        val questionMark = target.indexOf('?')
        val path = if (questionMark >= 0) target.substring(0, questionMark) else target
        val query = if (questionMark >= 0) target.substring(questionMark + 1) else null

        if (path.any { it !in PATH_CHARS }) {
            throw HttpParseException(400, "Unsupported character in the request path.")
        }
        if (path.contains("//")) throw HttpParseException(400, "Malformed request path.")
        if (path.split('/').any { it == "." || it == ".." }) {
            throw HttpParseException(400, "Relative path segments are not allowed.")
        }
        return path to query
    }

    // ---- Headers ------------------------------------------------------------

    private fun addHeader(headers: MutableMap<String, String>, line: String) {
        if (line[0] == ' ' || line[0] == '\t') {
            // Obsolete line folding: refused because it gives the header two
            // different readings depending on who parses it.
            throw HttpParseException(400, "Folded header lines are not supported.")
        }
        val colon = line.indexOf(':')
        if (colon <= 0) throw HttpParseException(400, "Malformed header line.")

        val name = line.substring(0, colon)
        if (name.any { it !in TOKEN_CHARS }) {
            throw HttpParseException(400, "Malformed header name.")
        }
        val value = line.substring(colon + 1).trim(' ', '\t')
        if (value.any { it.code < 0x20 || it.code == 0x7F }) {
            throw HttpParseException(400, "Malformed header value.")
        }

        val lower = name.lowercase()
        if (headers.containsKey(lower)) {
            // A duplicated Content-Length is the classic smuggling primitive. No
            // header in this API is legitimately repeatable, so all are refused.
            throw HttpParseException(400, "Duplicate header '$name'.")
        }
        headers[lower] = value
    }

    private fun validate(request: ParsedRequest, headers: Map<String, String>) {
        if (request.version != "HTTP/1.1" && request.version != "HTTP/1.0") {
            throw HttpParseException(505, "Only HTTP/1.0 and HTTP/1.1 are supported.")
        }

        if (headers.containsKey("transfer-encoding")) {
            throw HttpParseException(400, "Transfer-Encoding is not supported.")
        }
        if (headers.containsKey("expect")) {
            // The client would wait for a 100 Continue before sending a body.
            // Refusing keeps the read path single-shot and predictable.
            throw HttpParseException(417, "Expect is not supported.")
        }

        val declaredLength = headers["content-length"]
        if (declaredLength != null) {
            if (declaredLength.isEmpty() || declaredLength.length > 10 ||
                declaredLength.any { it !in "0123456789" }
            ) {
                throw HttpParseException(400, "Malformed Content-Length.")
            }
            val length = declaredLength.toLong()
            if (length > Config.MAX_REQUEST_BODY_BYTES) {
                throw HttpParseException(413, "The request body is too large.")
            }
        }

        if (request.version == "HTTP/1.1" && !headers.containsKey("host")) {
            throw HttpParseException(400, "A Host header is required for HTTP/1.1.")
        }
    }

    // ---- Bounded line reader ------------------------------------------------

    /**
     * Reads one CRLF-terminated line, byte by byte, never buffering more than
     * [maxBytes] of it. Reading one byte at a time from a buffered stream is what
     * makes the bound real: a client that sends a header line with no newline
     * costs at most [maxBytes] before it is dropped.
     */
    private fun readLine(input: InputStream, maxBytes: Int, budget: Int): String? {
        // The per-line cap and the remaining byte budget both apply: whichever
        // is smaller wins, so no single line can eat the whole header budget.
        val limit = minOf(maxBytes, budget.coerceAtLeast(1))
        val buffer = ByteArrayOutputStream(64)
        var length = 0
        while (true) {
            val byte = input.read()
            if (byte < 0) {
                if (length == 0) return null // clean EOF between requests
                throw HttpParseException(400, "The request ended in the middle of a line.")
            }
            if (byte == '\n'.code) break
            length++
            if (length > limit) throw tooLarge("A request line is too long.")
            buffer.write(byte)
        }
        val bytes = buffer.toByteArray()
        val end = if (bytes.isNotEmpty() && bytes[bytes.size - 1] == CARRIAGE_RETURN) {
            bytes.size - 1
        } else {
            bytes.size
        }
        return String(bytes, 0, end, Charsets.ISO_8859_1)
    }

    private fun tooLarge(message: String) = HttpParseException(431, message)

    private const val CARRIAGE_RETURN: Byte = '\r'.code.toByte()
}