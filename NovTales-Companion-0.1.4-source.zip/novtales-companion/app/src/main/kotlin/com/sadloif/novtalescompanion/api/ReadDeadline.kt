package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.Config
import java.io.IOException
import java.io.InputStream
import java.net.SocketTimeoutException

/**
 * Thrown when a read gave up because the connection's absolute deadline passed.
 *
 * Deliberately neither an [HttpParseException] nor anything that carries an HTTP
 * status: nothing the peer sent is *wrong*, it simply stopped. The connection is
 * answered (where that is safe) and closed.
 */
internal class HttpReadTimeout : IOException("The peer stopped sending a request.")

/**
 * The read-side budget a [HttpConnection] drives, injected so that the parser,
 * the router and the transport all see the same deadline without any of them
 * having to know that a socket is involved.
 */
internal interface ConnectionReadDeadline {

    /**
     * Arms the wait for the next request head on this connection.
     *
     * @param connectionDeadlineMs absolute time at which the whole connection
     *   ends, keep-alive included.
     * @param firstOnConnection true while this is the head that arrives on a
     *   freshly accepted socket. That one gets the short
     *   [Config.HEAD_READ_DEADLINE_MS] even before a single byte has been seen:
     *   a peer that connects and says nothing must not be able to sit on a
     *   thread for the keep-alive window. Later waits on an established
     *   connection are governed by the connection deadline instead, because
     *   reaching one requires having already presented the pairing key.
     */
    fun awaitNextRequest(connectionDeadlineMs: Long, firstOnConnection: Boolean)

    /** Nothing further will be read from this socket. */
    fun finish()
}

/**
 * An input stream that bounds how long any one peer can occupy the thread that
 * is reading it.
 *
 * The socket's own read timeout cannot do this job. `SO_TIMEOUT` applies to a
 * single read, so a peer that sends one byte, waits, sends another, waits, ...
 * resets it on every call and holds its worker for as long as it likes. This
 * stream keeps an **absolute** deadline instead, re-armed from the first byte of
 * each request, and checks it around every read.
 *
 * Two properties matter for the callers:
 *
 *  - A poll interval elapsing is *not* a timeout. When the underlying read throws
 *    [SocketTimeoutException] and the absolute deadline has not passed, the read
 *    is retried. A legitimate client that pauses mid-head (a phone under load,
 *    a descheduled plugin) is delayed, never refused.
 *  - Nothing is lost when a poll elapses. This stream wraps - rather than is
 *    wrapped by - the buffered socket stream, and a `BufferedInputStream` whose
 *    fill timed out has not consumed anything, so the retry continues exactly
 *    where it left off.
 *
 * The deadline is **not** enforced on a per-byte basis by the parser: it is
 * enforced here, around the reads that actually wait for the socket.
 */
internal class DeadlineInput(
    private val source: InputStream,
    private val clock: () -> Long,
    private val retime: (Int) -> Unit,
    private val pollMs: Long = Config.SOCKET_READ_POLL_MS,
    private val requestMs: Long = Config.HEAD_READ_DEADLINE_MS,
) : InputStream(), ConnectionReadDeadline {

    /** Absolute time the current wait must finish by. */
    @Volatile
    private var armedUntil: Long = Long.MAX_VALUE

    /**
     * True while waiting for the *first byte* of a request. That byte is the
     * moment the request starts and the short deadline starts counting.
     */
    @Volatile
    private var awaitingFirstByte: Boolean = true

    /** The last value handed to [retime], so the common path writes nothing. */
    private var lastPoll: Int = -1

    override fun awaitNextRequest(connectionDeadlineMs: Long, firstOnConnection: Boolean) {
        awaitingFirstByte = true
        armedUntil = if (firstOnConnection) clock() + requestMs else connectionDeadlineMs
        lastPoll = -1
    }

    override fun finish() {
        awaitingFirstByte = false
        armedUntil = Long.MAX_VALUE
        lastPoll = -1
    }

    override fun read(): Int {
        val one = ByteArray(1)
        return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 0xFF
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        while (true) {
            val remaining = armedUntil - clock()
            if (remaining <= 0L) throw HttpReadTimeout()

            // Never block for longer than the deadline, and never for longer
            // than one poll, so that an absolute deadline is actually noticed.
            val slice = minOf(remaining, pollMs).toInt().coerceAtLeast(1)
            if (slice != lastPoll) {
                lastPoll = slice
                retime(slice)
            }

            val count = try {
                source.read(buffer, offset, length)
            } catch (polled: SocketTimeoutException) {
                // A poll interval elapsed with nothing to read. If the absolute
                // deadline is still in the future the peer is merely slow, so the
                // read is retried rather than turned into a refusal.
                if (clock() >= armedUntil) throw HttpReadTimeout()
                continue
            }

            if (count > 0 && awaitingFirstByte) {
                // The peer has spoken. From here the whole head - and any body it
                // declares - has to finish inside one short window.
                awaitingFirstByte = false
                armedUntil = clock() + requestMs
                lastPoll = -1
            }
            return count
        }
    }

    override fun available(): Int = source.available()

    override fun close() {
        try {
            source.close()
        } catch (_: IOException) {
            // The socket is being abandoned anyway; the owner closes it too.
        }
    }
}