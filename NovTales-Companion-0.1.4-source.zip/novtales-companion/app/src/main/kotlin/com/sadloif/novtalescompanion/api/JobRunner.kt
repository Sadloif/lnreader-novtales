package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.ApiError
import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Job
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.JobState
import com.sadloif.novtalescompanion.core.JobStore
import com.sadloif.novtalescompanion.core.Operation
import com.sadloif.novtalescompanion.web.BrowserGateway
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns the job store, the bounded queue and the single worker that drains it.
 *
 * Invariants this class is responsible for (spec sections 7, 10 and 11):
 *
 *  - **One at a time.** Exactly one coroutine starts work and it runs on a
 *    dedicated single-threaded dispatcher, so at most one job can ever be
 *    LOADING. That is what makes the WebView's "one operation at a time" rule
 *    structural rather than a matter of discipline.
 *  - **Bounded.** `queuedCount() >= MAX_WAITING_JOBS` is a 429 carrying
 *    `QUEUE_FULL` and `retryAfterMs = QUEUE_FULL_RETRY_AFTER_MS`.
 *  - **Collapsed.** A second caller asking for identical work joins the job
 *    that is already queued or loading and is told the existing id, instead of
 *    being given a second browser operation for the same chapter.
 *  - **Per-caller cancellation.** `DELETE` releases one waiter. Only the release
 *    that takes the waiter count to zero cancels the job, and only a job that
 *    really was LOADING calls `gateway.cancelActive()`.
 *  - **Identity-checked completion.** Every async write re-checks the job id and
 *    `Job.attempt` before it touches anything, so a late result from a previous
 *    chapter can never complete the next job.
 *
 * No `android.*` import appears here: the gateway arrives through a provider
 * lambda, so the whole queue can be driven by a fake on the JVM.
 */
internal class JobRunner(
    private val gatewayProvider: () -> BrowserGateway?,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val maxWaitingJobs: Int = Config.MAX_WAITING_JOBS,
    private val maxQueueWaitMs: Long = Config.MAX_QUEUE_WAIT_MS,
    private val sweepIntervalMs: Long = Config.JOB_SWEEP_INTERVAL_MS,
    private val retentionMs: Long = Config.JOB_RETENTION_MS,
) {

    /** Exposed so `GET /v1/jobs/{id}` can read a job back. */
    val store: JobStore = JobStore(clock)

    /** Guards [queue], [active] and [worker]. Never held while calling out. */
    private val lock = Any()
    private val queue = ArrayDeque<Job>()
    private var active: Job? = null

    private val wakeup = Channel<Unit>(Channel.CONFLATED)

    private var worker: Worker? = null

    private class Worker(
        val scope: CoroutineScope,
        val executor: ExecutorService,
        val dispatcher: ExecutorCoroutineDispatcher,
        val maintenance: CoroutineScope,
    )

    // ---- Public surface ----------------------------------------------------

    sealed interface SubmitOutcome {
        /** [collapsed] is true when this request joined an existing job. */
        data class Accepted(val job: Job, val collapsed: Boolean) : SubmitOutcome
        data class Rejected(val error: ApiError) : SubmitOutcome
    }

    sealed interface ReleaseOutcome {
        /** The job this caller's DELETE acted on, in whatever state it is now. */
        val job: Job

        /**
         * No caller is left. [cancelled] is false when the job had already
         * finished - a `needs_user` job is terminal, so `Job.cancel()` correctly
         * refuses it. Either way the caller that asked to stop has stopped.
         */
        data class Released(override val job: Job, val cancelled: Boolean) : ReleaseOutcome

        /** Another caller still wants this job; it keeps running. */
        data class Shared(override val job: Job) : ReleaseOutcome
    }

    fun start() {
        synchronized(lock) {
            if (worker != null) return
            val executor = Executors.newSingleThreadExecutor { runnable ->
                Thread(runnable, "novtales-jobs").apply { isDaemon = true }
            }
            val dispatcher = executor.asCoroutineDispatcher()
            val scope = CoroutineScope(
                SupervisorJob() + dispatcher + CoroutineName("novtales-job-queue"),
            )
            // The sweeper is a safety net - it is what expires a job that has
            // waited too long and what reclaims memory - so it deliberately does
            // NOT share the single worker thread. A gateway that ever blocks
            // instead of suspending would otherwise starve it and leave callers
            // waiting past MAX_QUEUE_WAIT_MS for ever. Everything the sweeper
            // touches is guarded by `lock` or is a concurrent collection, so
            // running it elsewhere is safe.
            val maintenance = CoroutineScope(
                SupervisorJob() + Dispatchers.Default + CoroutineName("novtales-job-sweeper"),
            )
            worker = Worker(scope, executor, dispatcher, maintenance)
            scope.launch {
                for (ignored in wakeup) drain()
            }
            maintenance.launch {
                while (isActive) {
                    delay(sweepIntervalMs)
                    sweep()
                }
            }
        }
    }

    /**
     * Fails everything that has not settled with [ErrorCode.COMPANION_UNAVAILABLE]
     * and tears the worker thread down. Idempotent, and safe to call from
     * `onDestroy`.
     */
    fun stop(reason: String = "The companion stopped before this request finished.") {
        val current = synchronized(lock) {
            val existing = worker ?: return@synchronized null
            worker = null
            queue.clear()
            active = null
            existing
        } ?: return

        // Fail the work before cancelling the scope: a client polling straight
        // after `stop()` must get a real error rather than a job that sits in
        // `loading` for ever.
        store.all().forEach { job ->
            if (!job.state.isTerminal) {
                job.fail(ApiError.of(ErrorCode.COMPANION_UNAVAILABLE, reason))
            }
        }
        gatewayProvider()?.cancelActive()

        current.scope.cancel(CancellationException("novtales job runner stopping"))
        current.maintenance.cancel(CancellationException("novtales job sweeper stopping"))
        current.executor.shutdownNow()
        current.dispatcher.close()
    }

    fun submit(request: JobRequest): SubmitOutcome = synchronized(lock) {
        val key = request.collapseKey
        val twin = store.all().firstOrNull {
            it.request.collapseKey == key &&
                (it.state == JobState.QUEUED || it.state == JobState.LOADING)
        }
        if (twin != null) {
            // Collapsing is checked before the queue bound: an identical request
            // adds no browser work, so refusing it would only make the client do
            // the same work twice.
            if (twin.waiterCount >= MAX_WAITERS_PER_JOB) {
                return@synchronized SubmitOutcome.Rejected(queueFull())
            }
            twin.waiterCount = twin.waiterCount + 1
            return@synchronized SubmitOutcome.Accepted(twin, collapsed = true)
        }

        if (store.queuedCount() >= maxWaitingJobs) return@synchronized SubmitOutcome.Rejected(queueFull())

        val job = Job(Job.newId(), request, clock(), clock)
        store.put(job)
        queue.addLast(job)
        wakeup.trySend(Unit)
        SubmitOutcome.Accepted(job, collapsed = false)
    }

    /** Releases one caller's interest in [jobId]. Null when the id is unknown. */
    fun release(jobId: String): ReleaseOutcome? {
        val job = store.get(jobId) ?: return null

        // Synchronise on the job itself so two simultaneous DELETEs cannot both
        // observe a waiter count of 1 and both cancel.
        synchronized(job) {
            if (job.waiterCount > 1) {
                job.waiterCount = job.waiterCount - 1
                return ReleaseOutcome.Shared(job)
            }
            job.waiterCount = 0
        }

        val wasLoading = synchronized(lock) {
            queue.remove(job)
            active === job
        }

        // `cancel()` returns false for a job that had already settled - notably a
        // needs_user job, which is terminal. That is not an error: the job is
        // finished, the caller has still stopped waiting, and nothing is left to
        // interrupt in the browser.
        val cancelled = job.cancel()
        // The held needs_user error is deliberately kept: it belongs to the job,
        // not to the caller, and the caller may well poll once more. It is
        // reclaimed in `sweep()` when the job leaves the store.
        if (wasLoading && cancelled) gatewayProvider()?.cancelActive()
        return ReleaseOutcome.Released(job, cancelled)
    }

    fun job(jobId: String): Job? = store.get(jobId)

    // ---- Worker ------------------------------------------------------------

    /**
     * Takes the next runnable job, or null when the queue is empty. Queue wait
     * is enforced here rather than in the caller so that a job which has already
     * waited longer than [Config.MAX_QUEUE_WAIT_MS] fails instead of starting.
     */
    private fun takeNext(): Job? = synchronized(lock) {
        val iterator = queue.iterator()
        while (iterator.hasNext()) {
            val head = iterator.next()
            iterator.remove()
            when {
                head.state != JobState.QUEUED -> Unit // cancelled while waiting
                head.waiterCount <= 0 -> head.cancel()
                head.hasExceededQueueWait(maxQueueWaitMs) -> head.fail(queueWaitTimeoutError())
                !head.begin() -> Unit
                else -> {
                    active = head
                    return@synchronized head
                }
            }
        }
        active = null
        null
    }

    private suspend fun drain() {
        while (true) {
            val job = takeNext() ?: return
            runJob(job)
            synchronized(lock) { if (active === job) active = null }
        }
    }

    private suspend fun runJob(job: Job) {
        val attempt = job.attempt // identity token, captured immediately after begin()
        val gateway = gatewayProvider()
        if (gateway == null) {
            if (isCurrent(job, attempt)) {
                job.fail(
                    ApiError.of(
                        ErrorCode.COMPANION_UNAVAILABLE,
                        "Open the NovTales Companion and press Start.",
                    ),
                )
            }
            return
        }

        val deadlineMs = deadlineFor(job.request.operation)
        try {
            // The gateway owns the deadline and is expected to honour
            // `deadlineMs`; this timeout is the backstop for a gateway that does
            // not, and it is what guarantees the companion frees the WebView even
            // if the site simply stops responding.
            val result = withTimeout(deadlineMs + TIMEOUT_GRACE_MS) {
                gateway.execute(job.request, deadlineMs)
            }
            if (!isCurrent(job, attempt)) return
            job.complete(result)
        } catch (_: TimeoutCancellationException) {
            if (!isCurrent(job, attempt)) return
            job.fail(timeoutError())
            gateway.cancelActive()
        } catch (failure: CompanionException) {
            if (!isCurrent(job, attempt)) return
            val error = ApiError.from(failure)
            if (failure.code in NEEDS_USER_CODES) {
                // needs_user is terminal, so the worker can never pick this job up
                // again and only a fresh POST - the explicit retry spec section 7
                // asks for - re-runs it. `Job.fail()` records the structured error
                // on a NEEDS_USER job and leaves the state alone, so the plugin
                // gets `needs_user` *with* the reason attached.
                job.transitionTo(JobState.NEEDS_USER)
                job.fail(error)
                return
            }
            job.fail(error)
        } catch (cancellation: CancellationException) {
            // Only this class's own scope cancels a job, and `stop()` has already
            // written COMPANION_UNAVAILABLE. Rethrow so the worker really stops.
            throw cancellation
        } catch (_: Throwable) {
            if (!isCurrent(job, attempt)) return
            // Nothing from the throwable is used: its message can carry website
            // HTML, a cookie header, or the pairing key if a future gateway is
            // careless. The caller gets a fixed string and nothing else.
            job.fail(ApiError.of(ErrorCode.INTERNAL, HttpConnection.INTERNAL_MESSAGE))
        }
    }

    /**
     * A late callback may only write to the job it was started for: the same
     * object, the same `attempt`, not already terminal, and still the job the
     * worker is on. A chapter that arrives after the caller cancelled, after a
     * timeout, or after a restart belongs to nothing and is discarded.
     */
    private fun isCurrent(job: Job, attempt: Int): Boolean {
        if (store.get(job.id) !== job) return false
        if (job.attempt != attempt) return false
        if (job.state.isTerminal) return false
        return synchronized(lock) { active === job }
    }

    // ---- Sweep -------------------------------------------------------------

    private fun sweep() {
        val timedOut = mutableListOf<Job>()
        synchronized(lock) {
            val iterator = queue.iterator()
            while (iterator.hasNext()) {
                val job = iterator.next()
                if (job.hasExceededQueueWait(maxQueueWaitMs)) {
                    iterator.remove()
                    timedOut += job
                }
            }
        }
        timedOut.forEach { it.fail(queueWaitTimeoutError()) }

        // One eviction rule only. `JobState.isTerminal` covers needs_user, so
        // `JobStore.sweep` already drops those jobs on retention.
        store.sweep(retentionMs)
    }

    // ---- Helpers -----------------------------------------------------------

    private fun queueFull() = ApiError.of(
        ErrorCode.QUEUE_FULL,
        "The companion is busy with other chapters. Try again shortly.",
        Config.QUEUE_FULL_RETRY_AFTER_MS,
    )

    /**
     * A job that waited longer than [Config.MAX_QUEUE_WAIT_MS] fails with the
     * same back-off hint as QUEUE_FULL, because the cause is identical: the queue
     * is under pressure, and retrying in three seconds is the right advice.
     */
    private fun queueWaitTimeoutError() = ApiError.of(
        ErrorCode.TIMEOUT,
        "The companion was too busy to start this request in time. Try again shortly.",
        Config.QUEUE_FULL_RETRY_AFTER_MS,
    )

    private fun timeoutError() = ApiError.of(
        ErrorCode.TIMEOUT,
        "NovTales took too long to deliver this request. Try again.",
    )

    private fun deadlineFor(operation: Operation): Long = when (operation) {
        Operation.CHAPTER -> Config.CHAPTER_DEADLINE_MS
        else -> Config.METADATA_DEADLINE_MS
    }

    companion object {

        /**
         * Slack added on top of the operation deadline before the backstop
         * timeout fires, so a gateway that honours `deadlineMs` and raises
         * TIMEOUT itself always gets to produce the nicer error.
         */
        const val TIMEOUT_GRACE_MS = 2_000L

        /**
         * Ceiling on the callers that may share one collapsed job. Collapsing is
         * otherwise free, so without a cap a caller could inflate `waiterCount`
         * for ever and keep alive a job it never reads.
         */
        const val MAX_WAITERS_PER_JOB = 32

        /** Outcomes only the user can resolve. They never auto-retry (spec section 7). */
        val NEEDS_USER_CODES: Set<ErrorCode> = setOf(
            ErrorCode.VERIFICATION_REQUIRED,
            ErrorCode.SIGN_IN_REQUIRED,
            ErrorCode.MEMBERSHIP_REQUIRED,
            ErrorCode.READING_NOTICE_REQUIRED,
        )
    }
}
