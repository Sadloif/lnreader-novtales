package com.sadloif.novtalescompanion.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.sadloif.novtalescompanion.core.PairingKey

/**
 * The status screen's only route to the service.
 *
 * Two jobs, deliberately kept apart:
 *
 *  1. **Binding**, so the screen can watch live state and hand the service-owned
 *     WebView a container. It binds *without* `BIND_AUTO_CREATE`: the companion
 *     must only ever be created by a deliberate user action, and a bind that
 *     silently created a foreground-capable service would break that rule and
 *     leave a service running that nobody asked for. A failed bind simply means
 *     "Stopped", which is the truthful answer.
 *  2. **The start/stop verbs**, which go through [start] and [requestStop].
 *
 * Everything is reference-counted by the Activity's `onStart` / `onStop` pair, so
 * the connection is released exactly when the screen stops being visible and a
 * late `onServiceConnected` can never resurrect a dead controller.
 */
class ServiceController(
    context: Context,
    private val listener: Listener,
) {

    interface Listener {
        fun onServiceConnected(controller: ServiceController)

        fun onServiceDisconnected(controller: ServiceController)
    }

    private val appContext: Context = context.applicationContext

    private var binding = false
    private var connected = false
    private var localBinder: CompanionService.LocalBinder? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            // A callback can still be queued when unbind() runs; a controller that
            // is no longer binding must ignore it rather than hand out a dead
            // binder.
            if (!binding) return
            val local = service as? CompanionService.LocalBinder ?: return
            localBinder = local
            connected = true
            listener.onServiceConnected(this@ServiceController)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            val wasConnected = connected
            localBinder = null
            connected = false
            if (wasConnected) listener.onServiceDisconnected(this@ServiceController)
        }
    }

    /** True while a live binder is held. */
    val isConnected: Boolean get() = connected

    /** The service, or null when it is not running. */
    val service: CompanionService? get() = localBinder?.service

    /** True when the service is bound *and* its local API server is up. */
    fun isRunning(): Boolean = service?.isRunning() == true

    fun bind() {
        if (binding) return
        binding = true
        val intent = Intent(appContext, CompanionService::class.java)
        val accepted = try {
            // 0 == no BIND_AUTO_CREATE: never create the service just because a
            // screen is looking at it.
            appContext.bindService(intent, connection, 0)
        } catch (t: Throwable) {
            Log.w(TAG, "the service could not be bound", t)
            false
        }
        if (!accepted) binding = false
    }

    fun unbind() {
        if (!binding) return
        binding = false
        connected = false
        localBinder = null
        try {
            appContext.unbindService(connection)
        } catch (_: IllegalArgumentException) {
            // Already gone. Nothing to release.
        }
    }

    /**
     * Starts the companion. Only ever call this from a user action while the
     * status screen is in front of the user; the service calls `startForeground`
     * immediately, so the platform's few-seconds window is never at risk.
     */
    fun start() {
        val intent = Intent(appContext, CompanionService::class.java)
            .setAction(CompanionService.ACTION_START)
        try {
            ContextCompat.startForegroundService(appContext, intent)
        } catch (t: Throwable) {
            Log.w(TAG, "the companion could not be started", t)
        }
    }

    /**
     * Asks the companion to stop. Safe to call whether or not it is bound: the
     * intent is delivered to the service itself, and the service is the thing
     * that knows what to tear down.
     *
     * `startForegroundService` is used rather than `startService` so this works
     * from the notification as well as from the screen. It is safe here because
     * `CompanionService.onStartCommand` calls `startForeground` on *every* start,
     * including this one, before it does anything else.
     */
    fun requestStop() {
        val intent = Intent(appContext, CompanionService::class.java)
            .setAction(CompanionService.ACTION_STOP)
        try {
            ContextCompat.startForegroundService(appContext, intent)
        } catch (t: Throwable) {
            // Android refused a background start (API 34+ can do this even from a
            // notification action). Nothing is lost: Stop is also on the screen.
            Log.w(TAG, "the companion could not be asked to stop", t)
        }
    }

    /** Shows the service-owned WebView inside [container] without resetting it. */
    fun attachBrowser(container: ViewGroup) {
        service?.attachBrowser(container)
    }

    /** Takes the service-owned WebView back out. Safe to call more than once. */
    fun detachBrowser() {
        service?.detachBrowser()
    }

    /**
     * Rotates the pairing key. When the service is running it is told first, so
     * the key it enforces never lags behind the stored one. Either way the website
     * session is left completely alone.
     */
    fun rotatePairingKey(): String {
        val running = service
        return if (running != null) running.rotatePairingKey() else PairingKey.rotate(appContext)
    }

    /**
     * Wipes the NovTales session. Needs a running service, because the session
     * lives in the service-owned WebView; [clearWebsiteSession] reports false when
     * there is nothing to clear.
     */
    fun clearWebsiteSession(onResult: (Boolean) -> Unit) {
        val running = service
        if (running == null) {
            onResult(false)
        } else {
            running.clearWebsiteSession(onResult)
        }
    }

    /** The key the running service is enforcing, or the stored one. */
    fun currentPairingKey(): String =
        service?.currentPairingKey() ?: PairingKey.getOrCreate(appContext)

    private companion object {
        const val TAG = "ServiceController"
    }
}