package com.sadloif.novtalescompanion.core

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.SecureRandom

/**
 * The local pairing key. This authorises access to the companion's loopback API.
 * It is **not** a NovTales account token and never leaves this device except
 * when the user explicitly copies it into LNReader's plugin settings.
 *
 * Stored in private app storage. The manifest disables backup for this app, so
 * the key is never written to a cloud backup or to the device-transfer file.
 */
object PairingKey {

    private const val PREFS_NAME = "novtales_companion_private"
    private const val KEY_PAIRING = "pairing_key_v1"
    private const val KEY_CREATED = "pairing_created_at"
    private const val KEY_ROTATIONS = "pairing_rotations"

    /** 256 bits of entropy, base64url without padding. */
    private const val KEY_BYTES = 32
    private const val ENCODING = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    private val random = SecureRandom()

    /**
     * Length-independent, constant-time comparison. `MessageDigest.isEqual` is
     * used rather than `String.equals`, which short-circuits on the first
     * differing byte and leaks key length information through timing.
     */
    fun constantTimeEquals(a: String, b: String): Boolean {
        val left = a.toByteArray(Charsets.UTF_8)
        val right = b.toByteArray(Charsets.UTF_8)
        return java.security.MessageDigest.isEqual(left, right)
    }

    fun generate(): String {
        val bytes = ByteArray(KEY_BYTES)
        random.nextBytes(bytes)
        return Base64.encodeToString(bytes, ENCODING)
    }

    fun preferences(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Returns the existing key, creating one on first use. Never returns an empty
     * string: an absent key is generated rather than treated as "no auth".
     */
    fun getOrCreate(context: Context): String {
        val prefs = preferences(context)
        prefs.getString(KEY_PAIRING, null)?.let { existing ->
            if (existing.isNotBlank()) return existing
        }
        return install(context, PairingKey.generate())
    }

    /**
     * Replaces the stored key with a fresh one. This is deliberately separate from
     * clearing the website session: rotating the pairing key must never sign the
     * user out of NovTales (spec section 5).
     */
    fun rotate(context: Context): String {
        val prefs = preferences(context)
        val rotations = prefs.getInt(KEY_ROTATIONS, 0) + 1
        prefs.edit()
            .putInt(KEY_ROTATIONS, rotations)
            .apply()
        return install(context, PairingKey.generate())
    }

    private fun install(context: Context, key: String): String {
        preferences(context).edit()
            .putString(KEY_PAIRING, key)
            .putLong(KEY_CREATED, System.currentTimeMillis())
            .apply()
        return key
    }

    fun createdAt(context: Context): Long =
        preferences(context).getLong(KEY_CREATED, 0L)

    fun rotationCount(context: Context): Int =
        preferences(context).getInt(KEY_ROTATIONS, 0)

    /**
     * Validates a key supplied by the plugin against the key the running service
     * holds. Returns the error the plugin should receive, or null when it matches.
     *
     * The expected key is passed in by the caller (which primes it once at service
     * start and refreshes it on rotate) rather than read from a global, so there
     * is no window in which this can compare against a stale or missing value.
     */
    fun verify(expected: String, supplied: String?): CompanionException? = when {
        supplied.isNullOrBlank() -> CompanionException(
            ErrorCode.UNAUTHORIZED,
            "No pairing key supplied. Copy it from the NovTales Companion into the plugin settings.",
        )
        !constantTimeEquals(supplied, expected) -> CompanionException(
            ErrorCode.UNAUTHORIZED,
            "The pairing key does not match. Copy it again from the NovTales Companion.",
        )
        else -> null
    }
}