package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.ApiError
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Operation
import com.sadloif.novtalescompanion.core.Paths

/**
 * Turns a `POST /v1/jobs` body into a [JobRequest] or into a 400.
 *
 * This is the last place a client-supplied string can become something the
 * WebView will act on, so it is deliberately strict (spec sections 7 and 11):
 *
 *  - `operation` must name one of the five operations. Anything else is 400.
 *  - `path` must survive [Paths.normalise] - which already refuses absolute
 *    non-NovTales URLs, plaintext URLs, traversal, double encoding and query or
 *    fragment tricks - and must then match the shape the operation needs.
 *  - A field that makes no sense for an operation (`path` on `catalogue`,
 *    `query` on `chapter`, `page` on `chapter`) is refused rather than silently
 *    dropped. Silently dropping is how a client ends up paginating nothing and
 *    debugging it for an afternoon.
 *  - `page` must be a whole, finite number in 1..[MAX_PAGE]. `NaN`, `Infinity`
 *    and `1.5` are all 400. Note the JSON reader already refuses the literals
 *    `NaN`/`Infinity`; the finite check here catches the same value arriving as
 *    `1e400`.
 *  - `sort` must be on [SORT_ALLOWLIST]. It is canonicalised to lower case and
 *    never reaches anything as a free string.
 *  - `query` is trimmed to [MAX_QUERY_CHARS] and must contain no control
 *    characters, so it cannot forge a header or a log line downstream.
 *
 * Every rejection is a [ErrorCode.BAD_REQUEST] 400 with a message naming the
 * offending field. No rejection message ever echoes the pairing key, a cookie or
 * a chapter body, because none of those can be in the body at all.
 */
internal object JobRequestValidator {

    /** Case-sensitive on the wire, canonicalised to lower case here. */
    val SORT_ALLOWLIST: Set<String> = setOf("popular", "latest", "title", "rating", "updated")

    const val MAX_QUERY_CHARS = 200
    const val MIN_PAGE = 1
    const val MAX_PAGE = 100_000

    sealed interface Result {
        data class Valid(val request: JobRequest) : Result
        data class Invalid(val error: ApiError) : Result
    }

    fun validate(body: String): Result {
        val parsed = try {
            Json.parse(body)
        } catch (_: IllegalArgumentException) {
            return invalid("The request body is not valid JSON.")
        }
        val root = parsed as? Json.Obj ?: return invalid("The request body must be a JSON object.")

        // 1. operation --------------------------------------------------------
        val operationField = root.fields["operation"] ?: return invalid("\"operation\" is required.")
        val operationName = (operationField as? Json.Str)?.value
            ?: return invalid("\"operation\" must be a string.")
        val operation = Operation.fromName(operationName)
            ?: return invalid(
                "\"operation\" must be one of catalogue, search, novel, chapters, chapter.",
            )

        // 2. path -------------------------------------------------------------
        val pathField = root.fields["path"]
        val path: String? = when {
            pathField == null || pathField is Json.Null -> null
            pathField is Json.Str -> Paths.normalise(pathField.value)
                ?: return invalid("\"path\" is not a NovTales novel or chapter path.")
            else -> return invalid("\"path\" must be a string.")
        }
        if (path != null) {
            when (operation) {
                Operation.NOVEL, Operation.CHAPTERS ->
                    if (!Paths.isNovel(path)) {
                        return invalid("\"path\" must be /novel/{slug} for \"${operation.wireName}\".")
                    }
                Operation.CHAPTER ->
                    if (!Paths.isChapter(path)) {
                        return invalid(
                            "\"path\" must be /chapter/{slug}-{number} for \"${operation.wireName}\".",
                        )
                    }
                Operation.CATALOGUE, Operation.SEARCH ->
                    return invalid("\"path\" is not accepted for \"${operation.wireName}\".")
            }
        }

        // 3, 6. page ----------------------------------------------------------
        val pageField = root.fields["page"]
        val page: Int? = when {
            pageField == null || pageField is Json.Null -> null
            pageField is Json.Num -> {
                val value = pageField.value
                if (!value.isFinite()) return invalid("\"page\" must be a finite whole number.")
                if (value != Math.floor(value)) return invalid("\"page\" must be a whole number.")
                if (value < MIN_PAGE || value > MAX_PAGE) {
                    return invalid("\"page\" must be between $MIN_PAGE and $MAX_PAGE.")
                }
                value.toInt()
            }
            else -> return invalid("\"page\" must be a number.")
        }
        when (operation) {
            Operation.CATALOGUE, Operation.CHAPTERS ->
                if (page == null) return invalid("\"page\" is required for \"${operation.wireName}\".")
            Operation.NOVEL, Operation.CHAPTER ->
                if (page != null) {
                    return invalid("\"page\" is not accepted for \"${operation.wireName}\".")
                }
            Operation.SEARCH -> Unit // optional; a search may be the first page
        }

        // 4, 5. query and required paths -------------------------------------
        val queryField = root.fields["query"]
        val query: String? = when {
            queryField == null || queryField is Json.Null -> null
            queryField is Json.Str -> {
                val raw = queryField.value
                if (raw.any { it.code < 0x20 || it.code == 0x7F }) {
                    return invalid("\"query\" must not contain control characters.")
                }
                raw.trim().take(MAX_QUERY_CHARS).ifEmpty { null }
            }
            else -> return invalid("\"query\" must be a string.")
        }
        if (operation == Operation.SEARCH && query == null) {
            return invalid("\"query\" is required for \"search\" and must not be blank.")
        }
        if (operation != Operation.SEARCH && query != null) {
            return invalid("\"query\" is not accepted for \"${operation.wireName}\".")
        }
        // novel, chapters and chapter all address one specific page on the site, so a
        // missing path is a client error here - not something to discover further
        // downstream with a less useful message. `catalogue` and `search` are
        // site-wide and legitimately carry no path.
        if (path == null && operation in PATH_REQUIRED) {
            return invalid("\"path\" is required for \"${operation.wireName}\".")
        }

        // 7. sort -------------------------------------------------------------
        val sortField = root.fields["sort"]
        val sort: String? = when {
            sortField == null || sortField is Json.Null -> null
            sortField is Json.Str ->
                sortField.value.trim().lowercase().takeIf { it in SORT_ALLOWLIST }
                    ?: return invalid(
                        "\"sort\" must be one of ${SORT_ALLOWLIST.sorted().joinToString(", ")}.",
                    )
            else -> return invalid("\"sort\" must be a string.")
        }
        if (operation == Operation.CHAPTER && sort != null) {
            return invalid("\"sort\" is not accepted for \"chapter\".")
        }

        return Result.Valid(
            JobRequest(
                operation = operation,
                path = path,
                page = page,
                sort = sort,
                query = query,
            ),
        )
    }

    private fun invalid(message: String): Result =
        Result.Invalid(ApiError.of(ErrorCode.BAD_REQUEST, message))

    /**
     * The operations that name one specific page on the site and therefore cannot
     * be requested without a path. `catalogue` and `search` are site-wide.
     */
    private val PATH_REQUIRED = setOf(Operation.NOVEL, Operation.CHAPTERS, Operation.CHAPTER)
}