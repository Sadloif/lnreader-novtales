package com.sadloif.novtalescompanion.core

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

/** The five operations the local API accepts. Anything else is rejected. */
enum class Operation(val wireName: String) {
    CATALOGUE("catalogue"),
    SEARCH("search"),
    NOVEL("novel"),
    CHAPTERS("chapters"),
    CHAPTER("chapter");

    companion object {
        fun fromName(name: String?): Operation? =
            entries.firstOrNull { it.wireName == name?.trim()?.lowercase() }
    }
}

/** Job states from spec section 7. */
enum class JobState(val wireName: String) {
    QUEUED("queued"),
    LOADING("loading"),
    NEEDS_USER("needs_user"),
    COMPLETED("completed"),
    FAILED("failed"),
    CANCELLED("cancelled");

    /**
     * True when no further transition is allowed.
     *
     * `NEEDS_USER` counts as terminal. The website presented something only the
     * user can resolve — verification, sign-in, a membership requirement — so
     * that job is finished. Auto-retry would re-run the browser against a check
     * the reader has not dealt with yet, which spec section 7 forbids. A retry
     * means a **fresh** POST /v1/jobs, not a transition of this one.
     */
    val isTerminal: Boolean
        get() = this != QUEUED && this != LOADING
}

/** One validated unit of browser work. */
data class JobRequest(
    val operation: Operation,
    val path: String? = null,
    val page: Int? = null,
    val sort: String? = null,
    val query: String? = null,
) {
    /** Identical work can share one browser operation; the path decides identity. */
    val collapseKey: String
        get() = buildString {
            append(operation.wireName)
            append('|').append(path ?: "")
            append('|').append(page ?: 0)
            append('|').append(sort ?: "")
            append('|').append(query ?: "")
        }
}

/**
 * Mutable job record. State transitions are only ever applied through
 * [transitionTo] so a late callback can never move a job backwards or from a
 * terminal state (spec section 10).
 */
class Job(
    val id: String,
    val request: JobRequest,
    val createdAt: Long,
    private val clock: () -> Long,
) {
    private val stateRef = AtomicReference(JobState.QUEUED)
    private val subscribers = mutableListOf<() -> Unit>()

    @Volatile var result: Json? = null
        private set

    @Volatile var error: ApiError? = null
        private set

    /** Identity token for the current attempt; async callbacks must match it. */
    @Volatile var attempt: Int = 0
        private set

    @Volatile var startedAt: Long? = null
        private set

    val state: JobState get() = stateRef.get()

    /** Every waiter that shares this job, so cancelling one caller cannot cancel another. */
    @Volatile var waiterCount: Int = 1

    fun begin(): Boolean {
        synchronized(this) {
            if (stateRef.get() != JobState.QUEUED) return false
            attempt++
            startedAt = clock()
            stateRef.set(JobState.LOADING)
            notifySubscribers()
            return true
        }
    }

    fun transitionTo(next: JobState): Boolean {
        synchronized(this) {
            val current = stateRef.get()
            if (current.isTerminal) return false
            stateRef.set(next)
            notifySubscribers()
            return true
        }
    }

    fun complete(value: Json): Boolean {
        synchronized(this) {
            if (stateRef.get().isTerminal) return false
            result = value
            error = null
            stateRef.set(JobState.COMPLETED)
            notifySubscribers()
            return true
        }
    }

    /**
     * Records a structured failure.
     *
     * `needs_user` is terminal, but it is the one terminal state that still has
     * to carry its error: that error is what tells the reader "sign in" or
     * "finish the verification" instead of "the companion broke". So it is
     * recorded before the terminal guard, and the state is left alone.
     */
    fun fail(failure: ApiError): Boolean {
        synchronized(this) {
            val current = stateRef.get()
            if (current == JobState.NEEDS_USER) {
                error = failure
                notifySubscribers()
                return true
            }
            if (current.isTerminal) return false
            error = failure
            stateRef.set(JobState.FAILED)
            notifySubscribers()
            return true
        }
    }

    fun cancel(): Boolean {
        synchronized(this) {
            if (stateRef.get().isTerminal) return false
            stateRef.set(JobState.CANCELLED)
            error = null
            notifySubscribers()
            return true
        }
    }

    /** True once the job has been queued longer than the queue wait ceiling. */
    fun hasExceededQueueWait(maxWaitMs: Long): Boolean =
        startedAt == null && clock() - createdAt > maxWaitMs

    /** True once the operation-specific deadline has passed since work began. */
    fun hasExceededDeadline(deadlineMs: Long): Boolean {
        val start = startedAt ?: return false
        return clock() - start > deadlineMs
    }

    fun onChange(listener: () -> Unit) {
        synchronized(this) {
            if (state.isTerminal) listener() else subscribers.add(listener)
        }
    }

    /**
     * Notifies every waiter, one bad listener at a time.
     *
     * Listeners are typically long-poll waiters writing to a socket, and a client
     * that has already hung up will throw. If one throw were allowed to escape,
     * it would abort the remaining listeners - every other caller sharing this
     * job would wait for its full timeout - and it would also propagate out of
     * [complete] or [fail] *after* the terminal state was already committed, so
     * the caller would see an exception for an operation that in fact succeeded.
     */
    private fun notifySubscribers() {
        val snapshot = synchronized(this) { subscribers.toList() }
        subscribers.clear()
        for (listener in snapshot) {
            try {
                listener()
            } catch (_: Throwable) {
                // A dead waiter must not affect the job or its other waiters.
            }
        }
    }

    /** Serialises the job exactly as GET /v1/jobs/{id} returns it. */
    fun toResponse(apiVersion: Int): Json {
        val fields = LinkedHashMap<String, Json>()
        fields["apiVersion"] = Json.Num(apiVersion.toDouble())
        fields["jobId"] = Json.Str(id)
        fields["state"] = Json.Str(state.wireName)
        result?.let { fields["result"] = it }
        error?.let { fields["error"] = it.toJson() }
        error?.retryAfterMs?.let { fields["retryAfterMs"] = Json.Num(it.toDouble()) }
        return Json.Obj(fields)
    }

    companion object {
        fun newId(): String = UUID.randomUUID().toString()
    }
}

/** The structured error envelope from spec section 10. */
data class ApiError(
    val code: ErrorCode,
    val message: String,
    val retryable: Boolean = code.retryable,
    val retryAfterMs: Long? = null,
) {
    fun toJson(): Json = jsonObject(
        "code" to code.name,
        "message" to message,
        "retryable" to retryable,
        "retryAfterMs" to retryAfterMs,
    )

    companion object {
        fun from(exception: CompanionException): ApiError = ApiError(
            exception.code,
            exception.message,
            exception.retryable,
            exception.retryAfterMs,
        )

        fun of(code: ErrorCode, message: String, retryAfterMs: Long? = null): ApiError =
            ApiError(code, message, code.retryable, retryAfterMs)
    }
}

/**
 * Bounded store of jobs. Capped by count so a client that never collects results
 * cannot grow the companion's memory without limit.
 */
class JobStore(
    private val clock: () -> Long,
    private val maxRetained: Int = 64,
) {
    private val jobs = ConcurrentHashMap<String, Job>()

    fun put(job: Job): Job {
        jobs[job.id] = job
        sweep(Config.JOB_RETENTION_MS)
        return job
    }

    fun get(id: String): Job? = jobs[id]

    fun remove(id: String): Job? = jobs.remove(id)

    fun all(): Collection<Job> = jobs.values

    fun queuedCount(): Int = jobs.values.count { it.state == JobState.QUEUED }

    fun activeCount(): Int = jobs.values.count { it.state == JobState.LOADING }

    fun terminalCount(): Int = jobs.values.count { it.state.isTerminal }

    /** Drops finished jobs past the retention window, oldest first. */
    fun sweep(retentionMs: Long): List<Job> {
        val now = clock()
        val expired = jobs.values.filter { job ->
            job.state.isTerminal && now - job.createdAt > retentionMs
        }
        expired.forEach { jobs.remove(it.id) }
        if (jobs.size > maxRetained) {
            jobs.values
                .filter { it.state.isTerminal }
                .sortedBy { it.createdAt }
                .take(jobs.size - maxRetained)
                .forEach { jobs.remove(it.id) }
        }
        return expired
    }
}