package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.Operation

/** Membership belongs to one chapter; browser verification belongs to the session. */
internal object AttentionPolicy {
    fun preserves(code: ErrorCode, blockedPath: String?, next: JobRequest): Boolean =
        code != ErrorCode.MEMBERSHIP_REQUIRED ||
            (next.operation == Operation.CHAPTER && next.path == blockedPath)
}
