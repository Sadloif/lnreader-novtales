package com.sadloif.novtalescompanion.net

import android.content.Context
import com.sadloif.novtalescompanion.core.PairingKey
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.BrowserGatewayFactory

/**
 * The one place in Subagent A's code that is allowed to know about Android.
 *
 * `api/` is deliberately free of `android.*` imports so that the HTTP parser,
 * the router and the whole job queue can be unit tested on the JVM (spec
 * section 11). That means the `Context`-taking calls - creating the gateway
 * through the platform factory and reading the pairing key out of private
 * storage - cannot live there, so they live here, in a three-line shim with no
 * logic of its own.
 *
 * Wiring, from the foreground service:
 *
 * ```kotlin
 * // service start
 * GatewayBootstrap.start(this, serverFactory = LocalApiServer::new)  // or inline
 *
 * val gateway = GatewayBootstrap.createGateway(gatewayFactory, this)
 * val server = LocalApiServer(
 *     pairingKey = GatewayBootstrap.pairingKey(this),
 *     gateway = gateway,
 * ).also { it.start() }
 *
 * // when the user rotates the key
 * server.updatePairingKey(GatewayBootstrap.rotatePairingKey(this))
 *
 * // when the WebView is rebuilt
 * server.setGateway(GatewayBootstrap.createGateway(gatewayFactory, this))
 *
 * // on destroy
 * server.stop()
 * ```
 *
 * Note the order in the last case: `stop()` fails every unfinished job with
 * `COMPANION_UNAVAILABLE` and cancels the active WebView operation, so the
 * gateway must outlive the call that triggers the rebuild.
 */
object GatewayBootstrap {

    /**
     * Creates the gateway through the injected factory. Returns null when the
     * Android runtime is unavailable, which is what keeps the HTTP server
     * unit-testable on the JVM and what makes `/v1/health` report `STOPPED`.
     */
    fun createGateway(factory: BrowserGatewayFactory, context: Context): BrowserGateway? =
        factory.create(context.applicationContext)

    /** The stored pairing key, generated on first use. Never logged. */
    fun pairingKey(context: Context): String = PairingKey.getOrCreate(context)

    /**
     * Rotates the stored key. Pass the result straight to
     * `LocalApiServer.updatePairingKey`; rotating the pairing key deliberately
     * does **not** sign the user out of NovTales (spec section 5).
     */
    fun rotatePairingKey(context: Context): String = PairingKey.rotate(context)
}