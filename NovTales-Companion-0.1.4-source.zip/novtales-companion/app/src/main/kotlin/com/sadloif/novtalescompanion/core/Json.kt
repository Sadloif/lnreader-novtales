package com.sadloif.novtalescompanion.core

/**
 * A small strict JSON reader/writer.
 *
 * This deliberately does not use `org.json`. That class is stubbed out on the JVM
 * (so it cannot be unit tested off-device), it silently coerces types, and it is
 * far more permissive than anything that has to sit behind a pairing key. Here an
 * unexpected token is a hard error instead of a best guess.
 *
 * Values map to: JsonObject (LinkedHashMap), JsonArray (List), String, Double,
 * Long, Boolean and null.
 */
/**
 * 2^63 as a Double: the first magnitude [Long.toLong] cannot represent.
 *
 * Top-level and `private` because interface bodies cannot hold property
 * initialisers and cannot have private members.
 */
private const val TWO_POW_63 = 9.223372036854776E18

sealed interface Json {

    data object Null : Json
    data class Bool(val value: Boolean) : Json
    data class Num(val value: Double) : Json
    data class Str(val value: String) : Json
    data class Arr(val items: List<Json>) : Json
    data class Obj(val fields: Map<String, Json>) : Json

    // ---- Convenience readers ------------------------------------------------

    fun obj(key: String): Json.Obj? = (this as? Json.Obj)?.fields?.get(key) as? Json.Obj
    fun arr(key: String): Json.Arr? = (this as? Json.Obj)?.fields?.get(key) as? Json.Arr
    fun str(key: String): String? = ((this as? Json.Obj)?.fields?.get(key) as? Json.Str)?.value
    fun num(key: String): Double? = ((this as? Json.Obj)?.fields?.get(key) as? Json.Num)?.value

    /**
     * Returns the value only when it is a finite whole number inside [Long]
     * range, otherwise null.
     *
     * Truncating is deliberately refused: `12.75` silently becoming `12` would let
     * a malformed page or a hostile payload pass a wrong chapter number. So is
     * saturation - a value out of range returns null rather than clamping.
     *
     * The bounds are written as the exact doubles for 2^63 and -2^63 rather than
     * as `Long.MAX_VALUE.toDouble()`. `Long.MAX_VALUE.toDouble()` rounds *up* to
     * exactly 2^63, so a `<= Long.MAX_VALUE.toDouble()` guard admits 2^63 itself
     * and `toLong()` then clamps it to `Long.MAX_VALUE`. That silently returned
     * `Long.MAX_VALUE` for `{"n":9223372036854775808}`, contradicting this
     * function's own contract. The comparisons are strict for the same reason.
     */
    fun long(key: String): Long? = num(key)?.let {
        if (it.isFinite() && it == Math.floor(it) && it > -TWO_POW_63 && it < TWO_POW_63) {
            it.toLong()
        } else {
            null
        }
    }

    /** As [long], additionally constrained to [Int] range. */
    fun int(key: String): Int? = num(key)?.let {
        if (it.isFinite() && it == Math.floor(it) &&
            it >= Int.MIN_VALUE.toDouble() && it <= Int.MAX_VALUE.toDouble()
        ) it.toInt() else null
    }
    fun bool(key: String): Boolean? =
        ((this as? Json.Obj)?.fields?.get(key) as? Json.Bool)?.value
    fun isNull(key: String): Boolean = (this as? Json.Obj)?.fields?.get(key) is Json.Null

    /** `true` when the key is present and not null. Used to tell "absent" from "empty". */
    fun has(key: String): Boolean = (this as? Json.Obj)?.fields?.containsKey(key) == true

    // ---- Writing ------------------------------------------------------------

    fun write(): String = buildString { writeJson(this, this@Json) }

    companion object {
        fun of(value: String?): Json = if (value == null) Null else Str(value)
        fun of(value: Long?): Json = if (value == null) Null else Num(value.toDouble())
        fun of(value: Int?): Json = if (value == null) Null else Num(value.toDouble())
        fun of(value: Boolean?): Json = if (value == null) Null else Bool(value)

        fun obj(vararg pairs: Pair<String, Json>): Json.Obj =
            Json.Obj(linkedMapOf(*pairs))

        fun arr(items: List<Json>): Json.Arr = Json.Arr(items)

        fun arrOf(items: List<String>): Json.Arr = Json.Arr(items.map { Str(it) })

        fun parse(text: String): Json = Reader(text).parseDocument()
    }
}

/** Builds a JSON object from typed values without every call site naming `Json.Str`. */
fun jsonObject(vararg pairs: Pair<String, Any?>): Json.Obj {
    val fields = LinkedHashMap<String, Json>()
    for ((key, value) in pairs) {
        fields[key] = when (value) {
            null -> Json.Null
            is Json -> value
            is String -> Json.Str(value)
            is Boolean -> Json.Bool(value)
            is Int -> Json.Num(value.toDouble())
            is Long -> Json.Num(value.toDouble())
            is Double -> Json.Num(value)
            is List<*> -> Json.Arr(value.map { element ->
                when (element) {
                    null -> Json.Null
                    is Json -> element
                    is String -> Json.Str(element)
                    is Boolean -> Json.Bool(element)
                    is Int -> Json.Num(element.toDouble())
                    is Long -> Json.Num(element.toDouble())
                    is Double -> Json.Num(element)
                    else -> throw IllegalArgumentException("Unsupported JSON value: $element")
                }
            })
            else -> throw IllegalArgumentException("Unsupported JSON value: $value")
        }
    }
    return Json.Obj(fields)
}

internal fun writeJson(out: StringBuilder, value: Json) {
    when (value) {
        is Json.Null -> out.append("null")
        is Json.Bool -> out.append(if (value.value) "true" else "false")
        is Json.Num -> out.append(formatNumber(value.value))
        is Json.Str -> writeJsonString(out, value.value)
        is Json.Arr -> {
            out.append('[')
            value.items.forEachIndexed { index, item ->
                if (index > 0) out.append(',')
                writeJson(out, item)
            }
            out.append(']')
        }
        is Json.Obj -> {
            out.append('{')
            var first = true
            for ((key, field) in value.fields) {
                if (!first) out.append(',')
                first = false
                writeJsonString(out, key)
                out.append(':')
                writeJson(out, field)
            }
            out.append('}')
        }
    }
}

private fun formatNumber(value: Double): String {
    if (!value.isFinite()) return "null"
    // Emit whole values without a trailing ".0" so chapter numbers and counts stay
    // integers in the wire format, which is what LNReader's TypeScript expects.
    return if (value == Math.floor(value) && Math.abs(value) < 1e15) {
        value.toLong().toString()
    } else {
        value.toString()
    }
}

private fun writeJsonString(out: StringBuilder, value: String) {
    out.append('"')
    for (char in value) {
        when (char) {
            '"' -> out.append("\\\"")
            '\\' -> out.append("\\\\")
            '\n' -> out.append("\\n")
            '\r' -> out.append("\\r")
            '\t' -> out.append("\\t")
            '\b' -> out.append("\\b")
            '\u000C' -> out.append("\\f")
            else -> if (char < ' ') {
                out.append("\\u").append("%04x".format(char.code))
            } else {
                out.append(char)
            }
        }
    }
    out.append('"')
}

private class Reader(private val text: String) {
    private var pos = 0

    fun parseDocument(): Json {
        skipWhitespace()
        val value = parseValue(0)
        skipWhitespace()
        if (pos != text.length) fail("Trailing content after JSON value")
        return value
    }

    private fun parseValue(depth: Int): Json {
        if (depth > 64) fail("JSON nested too deeply")
        skipWhitespace()
        if (pos >= text.length) fail("Unexpected end of JSON")
        return when (text[pos]) {
            '{' -> parseObject(depth)
            '[' -> parseArray(depth)
            '"' -> Json.Str(parseString())
            't' -> literal("true", Json.Bool(true))
            'f' -> literal("false", Json.Bool(false))
            'n' -> literal("null", Json.Null)
            else -> if (text[pos] == '-' || text[pos].isDigit()) parseNumber() else fail("Unexpected '${text[pos]}'")
        }
    }

    private fun parseObject(depth: Int): Json.Obj {
        expect('{')
        val fields = LinkedHashMap<String, Json>()
        skipWhitespace()
        if (peek() == '}') { pos++; return Json.Obj(fields) }
        while (true) {
            skipWhitespace()
            if (peek() != '"') fail("Expected object key")
            val key = parseString()
            skipWhitespace()
            expect(':')
            fields[key] = parseValue(depth + 1)
            skipWhitespace()
            when (peek()) {
                ',' -> pos++
                '}' -> { pos++; return Json.Obj(fields) }
                else -> fail("Expected ',' or '}'")
            }
        }
    }

    private fun parseArray(depth: Int): Json.Arr {
        expect('[')
        val items = ArrayList<Json>()
        skipWhitespace()
        if (peek() == ']') { pos++; return Json.Arr(items) }
        while (true) {
            items.add(parseValue(depth + 1))
            skipWhitespace()
            when (peek()) {
                ',' -> pos++
                ']' -> { pos++; return Json.Arr(items) }
                else -> fail("Expected ',' or ']'")
            }
        }
    }

    private fun parseString(): String {
        expect('"')
        val out = StringBuilder()
        while (true) {
            if (pos >= text.length) fail("Unterminated string")
            when (val char = text[pos++]) {
                '"' -> return out.toString()
                '\\' -> {
                    if (pos >= text.length) fail("Unterminated escape")
                    when (val escape = text[pos++]) {
                        '"' -> out.append('"')
                        '\\' -> out.append('\\')
                        '/' -> out.append('/')
                        'b' -> out.append('\b')
                        'f' -> out.append('\u000C')
                        'n' -> out.append('\n')
                        'r' -> out.append('\r')
                        't' -> out.append('\t')
                        'u' -> {
                            if (pos + 4 > text.length) fail("Truncated \\u escape")
                            val hex = text.substring(pos, pos + 4)
                            val code = hex.toIntOrNull(16) ?: fail("Bad \\u escape '$hex'")
                            out.append(code.toChar())
                            pos += 4
                        }
                        else -> fail("Bad escape '\\$escape'")
                    }
                }
                else -> {
                    if (char < ' ') fail("Unescaped control character in string")
                    out.append(char)
                }
            }
        }
    }

    private fun parseNumber(): Json.Num {
        val start = pos
        if (peek() == '-') pos++
        while (pos < text.length && text[pos].isDigit()) pos++
        if (pos < text.length && text[pos] == '.') {
            pos++
            while (pos < text.length && text[pos].isDigit()) pos++
        }
        if (pos < text.length && (text[pos] == 'e' || text[pos] == 'E')) {
            pos++
            if (pos < text.length && (text[pos] == '+' || text[pos] == '-')) pos++
            while (pos < text.length && text[pos].isDigit()) pos++
        }
        val slice = text.substring(start, pos)
        val value = slice.toDoubleOrNull() ?: fail("Bad number '$slice'")
        return Json.Num(value)
    }

    private fun literal(word: String, value: Json): Json {
        if (!text.startsWith(word, pos)) fail("Expected '$word'")
        pos += word.length
        return value
    }

    private fun skipWhitespace() {
        while (pos < text.length && (text[pos] == ' ' || text[pos] == '\t' ||
                text[pos] == '\n' || text[pos] == '\r')
        ) pos++
    }

    private fun peek(): Char = if (pos < text.length) text[pos] else fail("Unexpected end of JSON")

    private fun expect(char: Char) {
        if (peek() != char) fail("Expected '$char'")
        pos++
    }

    private fun fail(message: String): Nothing =
        throw IllegalArgumentException("Invalid JSON at offset $pos: $message")
}
