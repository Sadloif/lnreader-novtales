package com.sadloif.novtalescompanion.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.sadloif.novtalescompanion.R
import com.sadloif.novtalescompanion.service.ServiceController
import com.sadloif.novtalescompanion.state.CompanionState

/**
 * The status screen (spec section 5).
 *
 * It shows five things and never hides any of them:
 *  - the state, spelled out: Stopped, Starting, Ready, Loading, Needs your
 *    attention, or Error;
 *  - what the companion is doing right now, and the chapter number it is on;
 *  - the local pairing key, with Copy and Reset;
 *  - the website, for signing in or clearing a browser-verification challenge;
 *  - a separate, confirmed "Clear website session" that is nothing like a
 *    pairing-key reset.
 *
 * ### It observes, it does not own
 *
 * Nothing here creates a WebView, a socket or a pairing key. The service owns
 * all three and lives in the application process; the screen binds to it through
 * [ServiceController] and reads [CompanionState] for live state. That is what
 * lets the screen stay correct when the service is dead - which is most of the
 * time, because the reader plugin cannot start it. In that case the screen says
 * so in plain words instead of looking broken.
 *
 * ### The website
 *
 * "Open website" hands a container to the service-owned WebView and takes it back
 * when the user is done. The WebView is never created here and never sees this
 * Activity's context, so closing the screen, rotating the device or backgrounding
 * the app cannot cost the user their NovTales sign-in.
 */
class MainActivity : AppCompatActivity(), ServiceController.Listener, StatusViewModel.Listener {

    private lateinit var viewModel: StatusViewModel
    private lateinit var controller: ServiceController

    private lateinit var statusIcon: ImageView
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var activityCaption: TextView
    private lateinit var activityValue: TextView
    private lateinit var errorLabel: TextView
    private lateinit var warningLabel: TextView
    private lateinit var stopNoteLabel: TextView
    private lateinit var endpointLabel: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var websiteButton: Button
    private lateinit var clearSessionButton: Button
    private lateinit var webOverlay: View
    private lateinit var webContainer: FrameLayout
    private lateinit var webNote: TextView

    private var websiteOpen = false
    private var latest: StatusViewModel.UiModel? = null

    /**
     * Asked for only when the reader presses Start, and never as a gate: a denial
     * means no status notification, not a companion that will not run. On Android
     * 13 and later the system shows its own confirmation, so no Toast is added on
     * top of it.
     */
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(this, R.string.permission_notifications_denied, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        // Android 15+ enforces edge-to-edge. Keep the status and browser controls
        // inside the actual system/keyboard insets instead of under system bars.
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_root)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val keyboard = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboard.bottom))
            insets
        }
        ViewCompat.requestApplyInsets(findViewById(R.id.main_root))
        val light = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK != Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }

        // A framework-free holder: see StatusViewModel for why this is not an
        // androidx ViewModel. It is handed back across a configuration change.
        val retained = getLastCustomNonConfigurationInstance() as? StatusViewModel
        viewModel = retained ?: StatusViewModel(applicationContext)

        controller = ServiceController(this, this)

        bindViews()
        wireClicks()
        installBackHandling()

        websiteOpen = savedInstanceState?.getBoolean(STATE_WEBSITE_OPEN, false) == true
        webOverlay.visibility = if (websiteOpen) View.VISIBLE else View.GONE

        // Pick up a stop reason left by a previous process - a crash, a force-stop,
        // or an Android time limit - so the screen can explain itself.
        CompanionState.get().seedStopReasonFromDisk(applicationContext)
    }

    override fun onStart() {
        super.onStart()
        viewModel.start()
        viewModel.observe(this)
        // Bound without BIND_AUTO_CREATE, so this never starts the companion; it
        // only succeeds if the companion is already up.
        controller.bind()
    }

    override fun onStop() {
        viewModel.unobserve(this)
        viewModel.stop()
        super.onStop()
    }

    override fun onDestroy() {
        // The WebView leaves the window before this screen's views go away, and
        // the connection is released in the same breath - never leaked.
        if (websiteOpen) controller.detachBrowser()
        controller.unbind()
        viewModel.clear()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_WEBSITE_OPEN, websiteOpen)
    }

    /** Kept across a configuration change alongside the status state. */
    override fun onRetainCustomNonConfigurationInstance(): Any = viewModel

    // ---- Wiring -------------------------------------------------------------

    private fun bindViews() {
        statusIcon = findViewById(R.id.status_icon)
        statusTitle = findViewById(R.id.status_title)
        statusDetail = findViewById(R.id.status_detail)
        activityCaption = findViewById(R.id.activity_caption)
        activityValue = findViewById(R.id.activity_value)
        errorLabel = findViewById(R.id.error_label)
        warningLabel = findViewById(R.id.warning_label)
        stopNoteLabel = findViewById(R.id.stop_note_label)
        endpointLabel = findViewById(R.id.endpoint_label)
        startButton = findViewById(R.id.button_start)
        stopButton = findViewById(R.id.button_stop)
        websiteButton = findViewById(R.id.button_open_website)
        clearSessionButton = findViewById(R.id.button_clear_session)
        webOverlay = findViewById(R.id.web_overlay)
        webContainer = findViewById(R.id.webview_container)
        webNote = findViewById(R.id.webview_note)
    }

    private fun wireClicks() {
        startButton.setOnClickListener { onStartPressed() }
        stopButton.setOnClickListener { onStopPressed() }
        websiteButton.setOnClickListener { onOpenWebsite() }
        clearSessionButton.setOnClickListener { confirmClearWebsiteSession() }
        // Explicit type arguments: findViewById has no expected type here.
        findViewById<Button>(R.id.button_copy_key).setOnClickListener { onCopyPairingKey() }
        findViewById<Button>(R.id.button_reset_key).setOnClickListener { confirmResetPairingKey() }
        findViewById<Button>(R.id.button_close_website).setOnClickListener { closeWebsite() }
    }

    private fun installBackHandling() {
        onBackPressedDispatcher.addCallback(object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back closes the website first; the WebView itself is untouched.
                if (websiteOpen) closeWebsite() else finish()
            }
        })
    }

    // ---- Actions ------------------------------------------------------------

    /**
     * The only place the companion is ever started. Called from a button press
     * while this screen is in the foreground, which is what the platform requires
     * before a foreground service may start.
     */
    private fun onStartPressed() {
        requestNotificationPermissionIfNeeded()
        controller.start()
    }

    private fun onStopPressed() {
        if (websiteOpen) closeWebsite()
        controller.requestStop()
    }

    private fun onOpenWebsite() {
        if (!websiteAvailable()) {
            // The WebView belongs to the service, so there is genuinely nothing to
            // show until it is running. Say why, and offer the fix.
            AlertDialog.Builder(this)
                .setTitle(R.string.website_unavailable_title)
                .setMessage(R.string.website_unavailable_message)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton(R.string.action_start) { _, _ -> onStartPressed() }
                .show()
            return
        }
        if (websiteOpen) return
        websiteOpen = true
        webOverlay.visibility = View.VISIBLE
        controller.attachBrowser(webContainer)
        renderWebNote()
    }

    private fun closeWebsite() {
        if (!websiteOpen) return
        websiteOpen = false
        webOverlay.visibility = View.GONE
        controller.detachBrowser()
    }

    private fun onCopyPairingKey() {
        val key = try {
            controller.currentPairingKey()
        } catch (t: Throwable) {
            Toast.makeText(this, R.string.pairing_key_unavailable, Toast.LENGTH_LONG).show()
            return
        }
        copySensitive(getString(R.string.pairing_clip_label), key)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            Toast.makeText(this, R.string.pairing_key_copied, Toast.LENGTH_SHORT).show()
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.pairing_copied_title)
            .setMessage(R.string.pairing_steps)
            .setNegativeButton(R.string.action_stay_here, null)
            .setPositiveButton(R.string.action_open_lnreader) { _, _ ->
                val launch = packageManager.getLaunchIntentForPackage("com.rajarsheechatterjee.LNReader")
                if (launch != null) {
                    startActivity(launch)
                } else {
                    Toast.makeText(this, R.string.lnreader_not_installed, Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    /**
     * Rotating the key is confirmed, and the confirmation says out loud what it
     * does *not* do: it never signs the reader out of NovTales.
     */
    private fun confirmResetPairingKey() {
        AlertDialog.Builder(this)
            .setTitle(R.string.reset_key_confirm_title)
            .setMessage(R.string.reset_key_confirm_message)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_reset_pairing_key) { _, _ ->
                try {
                    controller.rotatePairingKey()
                    Toast.makeText(this, R.string.pairing_key_reset, Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    Toast.makeText(this, R.string.pairing_key_unavailable, Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    /**
     * Deliberately separate from a pairing-key reset, and never a surprise: the
     * reader is told exactly what will be lost before anything is wiped.
     */
    private fun confirmClearWebsiteSession() {
        if (!websiteAvailable()) {
            Toast.makeText(this, R.string.session_needs_service, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_session_confirm_title)
            .setMessage(R.string.clear_session_confirm_message)
            .setNegativeButton(R.string.action_cancel, null)
            .setPositiveButton(R.string.action_clear_website_session) { _, _ ->
                controller.clearWebsiteSession { cleared ->
                    Toast.makeText(
                        this,
                        if (cleared) R.string.session_cleared else R.string.session_clear_failed,
                        Toast.LENGTH_LONG,
                    ).show()
                }
            }
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            // Fire and forget: the companion starts either way.
            try {
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (_: Throwable) {
                // No launcher available on this build; the service still starts.
            }
        }
    }

    /**
     * Copies to the clipboard and marks the clip sensitive where the platform
     * supports it, so the key is not offered in the clipboard history preview.
     */
    private fun copySensitive(label: String, value: String) {
        val clipboard = getSystemService(ClipboardManager::class.java) ?: return
        val clip = ClipData.newPlainText(label, value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        clipboard.setPrimaryClip(clip)
    }

    private fun websiteAvailable(): Boolean = latest?.websiteAvailable == true

    // ---- Rendering ----------------------------------------------------------

    override fun onStatusChanged(model: StatusViewModel.UiModel) {
        latest = model

        statusIcon.setImageResource(model.iconRes)
        statusIcon.imageTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, model.iconTintRes),
        )
        statusIcon.contentDescription = model.iconDescription
        statusTitle.text = model.title
        statusDetail.text = model.detail

        activityCaption.text = getString(R.string.label_current_work)
        activityValue.text = model.activitySummary

        errorLabel.text = model.errorMessage
        errorLabel.visibility = if (model.errorMessage.isNullOrBlank()) View.GONE else View.VISIBLE

        warningLabel.text = model.networkWarning
        warningLabel.visibility = if (model.networkWarning == null) View.GONE else View.VISIBLE

        stopNoteLabel.text = model.stopNote
        stopNoteLabel.visibility = if (model.stopNote == null) View.GONE else View.VISIBLE

        endpointLabel.text = model.endpoint

        startButton.isEnabled = model.startEnabled
        stopButton.isEnabled = model.stopEnabled
        websiteButton.isEnabled = model.websiteAvailable
        clearSessionButton.isEnabled = model.websiteAvailable

        // If the companion stopped while the website was open, the panel has
        // nothing left to show; close it rather than leaving a blank rectangle.
        if (websiteOpen && !model.websiteAvailable) {
            websiteOpen = false
            webOverlay.visibility = View.GONE
        }
        renderWebNote()
    }

    private fun renderWebNote() {
        if (!websiteOpen) return
        webNote.text = getString(
            if (latest?.webViewAttached == true) {
                R.string.website_note_attached
            } else {
                R.string.website_note_opening
            },
        )
    }

    // ---- Service binding ----------------------------------------------------

    override fun onServiceConnected(source: ServiceController) {
        if (websiteOpen) controller.attachBrowser(webContainer)
    }

    override fun onServiceDisconnected(source: ServiceController) {
        // Live state comes from CompanionState, so there is nothing to re-query.
    }

    private companion object {
        const val STATE_WEBSITE_OPEN = "website_open"
    }
}
