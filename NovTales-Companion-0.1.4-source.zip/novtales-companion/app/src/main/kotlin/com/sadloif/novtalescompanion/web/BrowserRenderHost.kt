package com.sadloif.novtalescompanion.web

import android.app.Presentation
import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout

/**
 * A private, app-owned rendering surface. A detached WebView has no compositor
 * frames, so React animation frames and IntersectionObserver may never run.
 * This gives the service's browser a real window without an overlay permission
 * or a visible window over LNReader. It contains only this app's browser and
 * never captures the phone's screen. All calls are made on the main thread.
 */
internal class BrowserRenderHost(private val context: Context) {
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var presentation: Presentation? = null
    private var container: FrameLayout? = null

    fun park(view: WebView) {
        if (container == null) create()
        (view.parent as? ViewGroup)?.removeView(view)
        container!!.addView(view, ViewGroup.LayoutParams(-1, -1))
        view.onResume()
    }

    private fun create() {
        val metrics = context.resources.displayMetrics
        val width = minOf(metrics.widthPixels, 720)
        val height = (metrics.heightPixels.toLong() * width / metrics.widthPixels).toInt()
        val density = (metrics.densityDpi.toLong() * width / metrics.widthPixels).toInt().coerceAtLeast(120)
        val images = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = images
        images.setOnImageAvailableListener({ source -> source.acquireLatestImage()?.close() }, Handler(Looper.getMainLooper()))
        val manager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        try {
            val virtual = manager.createVirtualDisplay("NovTales browser", width, height, density, images.surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION)
                ?: error("Android could not create the browser rendering surface")
            display = virtual
            val window = Presentation(context, virtual.display)
            val frame = FrameLayout(window.context)
            window.setContentView(frame)
            window.show()
            presentation = window
            container = frame
        } catch (error: Exception) {
            close()
            throw error
        }
    }

    fun close() {
        container?.removeAllViews()
        container = null
        presentation?.dismiss()
        presentation = null
        display?.release()
        display = null
        reader?.close()
        reader = null
    }
}
