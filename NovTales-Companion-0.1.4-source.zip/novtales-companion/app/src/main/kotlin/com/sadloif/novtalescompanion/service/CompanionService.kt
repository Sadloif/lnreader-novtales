package com.sadloif.novtalescompanion.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebStorage
import com.sadloif.novtalescompanion.R
import com.sadloif.novtalescompanion.api.LocalApiServer
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.PairingKey
import com.sadloif.novtalescompanion.core.Paths
import com.sadloif.novtalescompanion.state.CompanionPhase
import com.sadloif.novtalescompanion.state.CompanionSnapshot
import com.sadloif.novtalescompanion.state.CompanionState
import com.sadloif.novtalescompanion.state.StopLog
import com.sadloif.novtalescompanion.state.StopReason
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.Readiness
import com.sadloif.novtalescompanion.web.asBrowserSurface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * ## What this is
 *
 * The foreground service that owns everything with a lifetime longer than a
 * screen: the WebView, its cookies, and the loopback API the reader plugin talks
 * to. The status screen only ever *looks* at it; nothing here depends on the UI
 * existing, so a force-stop, a crash or Android ending the service all leave the
 * plugin with a closed socket rather than a half-alive companion.
 *
 * ## Why `dataSync`, and why it stays `dataSync`
 *
 * The manifest declares `android:foregroundServiceType="dataSync"`, and that is
 * the honest description of what this process does: on the reader's behalf it
 * fetches website pages, extracts data from them and hands the data back over a
 * loopback HTTP server. That is data synchronisation between a user agent and a
 * remote service, which is what the type is for.
 *
 * The alternatives were considered and rejected:
 *
 *  - `specialUse` would be a choice made purely to dodge the `dataSync` time
 *    limit. That is exactly what the platform documentation says not to do, and
 *    it needs a declared justification that would not be true here.
 *  - `mediaPlayback`, `mediaProjection`, `location`, `phoneCall` and the rest
 *    would be a straightforward misclassification. This app plays no media,
 *    captures no screen, has no location and places no calls; claiming any of
 *    those would be a lie told to the user's battery.
 *
 * What this means in practice, and what the code does about it: recent Android
 * versions cap how long a `dataSync` service may run (six hours in twenty-four on
 * Android 15). That is an acceptable trade for an honest declaration, so the
 * service handles the cap instead of trying to escape it - see [onTimeout]. It
 * does not hold a wake lock, does not request battery-exemption, and does not
 * pretend it can restart itself after a force-stop.
 *
 * ## Lifecycle contract
 *
 *  - It is started only by an explicit user action while `MainActivity` is
 *    visible, and [startForegroundCompat] is called before anything else so the
 *    system never sees a `ForegroundServiceDidNotStartInTimeException`.
 *  - `START_NOT_STICKY`: the companion does not come back by itself. After a
 *    reboot, a force-stop or a kill, the status screen simply says Stopped.
 *  - Every exit path - user Stop, timeout, unexpected teardown - runs through
 *    [stopWith], which stops the local API server so that every job still queued
 *    fails with `COMPANION_UNAVAILABLE` rather than hanging.
 *  - The WebView is created, driven and released on the main thread only. Socket
 *    work happens on [Dispatchers.IO]; nothing here ever blocks the main thread.
 */
class CompanionService : Service() {

    /** Handed to `MainActivity` through `ServiceController`. */
    inner class LocalBinder : Binder() {
        val service: CompanionService get() = this@CompanionService
    }

    private val binder = LocalBinder()

    private val state = CompanionState.get()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var scope: CoroutineScope? = null

    private var apiServer: LocalApiServer? = null
    private var gateway: BrowserGateway? = null
    private var pairingKey: String = ""
    private var starting = false
    private var stopping = false
    private var attachedContainer: ViewGroup? = null
    private var activeRequest: JobRequest? = null
    private var networkCallbackRegistered = false

    private val stateListener = CompanionState.Listener { refreshNotification() }

    // ---- Service lifecycle --------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        state.seedStopReasonFromDisk(applicationContext)
        state.observe(stateListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Foreground first, everything else second. The system allows a few
        // seconds from startForegroundService() to startForeground(), and it
        // applies to *every* start including a Stop delivered from the shade -
        // a stale Stop PendingIntent after a process restart would otherwise
        // create the service with no foreground notification at all.
        val next = state.snapshot().let { snapshot ->
            if (snapshot.running) {
                snapshot
            } else {
                snapshot.copy(
                    phase = CompanionPhase.STARTING,
                    running = true,
                    errorCode = null,
                    errorMessage = null,
                    stopReason = null,
                    stoppedAtMillis = 0L,
                )
            }
        }
        startForegroundCompat(ServiceNotifications.build(this, next))
        state.update { next }

        if (intent?.action == ACTION_STOP) {
            stopWith(StopReason.USER)
            return START_NOT_STICKY
        }

        ensureStarted()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        state.unobserve(stateListener)
        if (apiServer != null || starting) {
            // Tearing down without being asked: a crash, a system kill, or the
            // process simply going away. Say so honestly rather than claiming the
            // user stopped it.
            stopWith(StopReason.UNEXPECTED)
        }
        detachFromContainer()
        releaseBrowser()
        scope?.cancel()
        scope = null
        gateway = null
        apiServer = null
        super.onDestroy()
    }

    /**
     * Android 14 (API 34) onwards: the platform ended this `dataSync` service
     * because it ran past its budget. [Service.onTimeout] is only called on
     * versions that have it; on earlier versions the equivalent event is a plain
     * process kill, which `onDestroy` handles the same way.
     */
    @Suppress("NewApi")
    override fun onTimeout(startId: Int, fgsType: Int) {
        super.onTimeout(startId, fgsType)
        stopWith(
            StopReason.TIMEOUT,
            errorCode = ErrorCode.COMPANION_UNAVAILABLE,
            errorMessage = getString(R.string.error_service_timeout),
        )
    }

    // ---- Starting -----------------------------------------------------------

    private fun ensureStarted() {
        if (starting || apiServer != null) return
        starting = true

        state.update { it.copy(networkAvailable = hasInternet()) }

        val key = try {
            PairingKey.getOrCreate(applicationContext)
        } catch (t: Throwable) {
            Log.w(TAG, "pairing key could not be read", t)
            failStart(getString(R.string.error_pairing_key_unavailable))
            return
        }
        pairingKey = key

        // The WebView must be created on the main thread, so this call stays here
        // rather than moving into the background start-up below.
        val created = try {
            ServiceSeams.browserGatewayFactory().create(applicationContext)
        } catch (t: Throwable) {
            Log.w(TAG, "browser gateway could not be created", t)
            null
        }
        if (created == null) {
            failStart(getString(R.string.error_browser_unavailable))
            return
        }
        gateway = created

        startApiServer(key)
        mainHandler.postDelayed(readinessTick, READINESS_POLL_MS)
    }

    /**
     * Builds and starts the loopback API server.
     *
     * The server is handed an operation-tracking decorator around [gateway] rather
     * than the gateway itself. That is how the status screen and the notification
     * learn the current operation and chapter number without `LocalApiServer`
     * having to grow a member for it.
     *
     * `start()` opens a socket, so it runs on IO and is never awaited on the main
     * thread; readiness is picked up by [readinessTick].
     */
    private fun startApiServer(expectedPairingKey: String) {
        val real = gateway ?: return
        val tracked = ServiceSeams.trackingGateway(
            delegate = real,
            onStarted = ::onOperationStarted,
            onFinished = ::onOperationFinished,
        )
        val server = try {
            ServiceSeams.createServer(expectedPairingKey, tracked)
        } catch (t: Throwable) {
            Log.w(TAG, "local API server could not be created", t)
            failStart(getString(R.string.error_server_unavailable))
            return
        }

        apiServer = server
        registerNetworkCallback()

        val scope = scope ?: return
        scope.launch(Dispatchers.IO) {
            try {
                server.start()
            } catch (t: Throwable) {
                Log.w(TAG, "local API server did not start", t)
                mainHandler.post { failStart(describeStartFailure(t)) }
            }
        }
    }

    private fun onOperationStarted(request: JobRequest) {
        activeRequest = request
        state.update {
            it.copy(operation = request.operation, chapterNumber = request.path?.let(Paths::chapterNumber))
        }
    }

    private fun onOperationFinished(request: JobRequest) {
        // Only the request that is still current may clear the display, so a late
        // callback from a cancelled attempt cannot blank a newer one.
        if (activeRequest !== request) return
        activeRequest = null
        state.update { it.copy(operation = null, chapterNumber = null) }
    }

    private val readinessTick = object : Runnable {
        override fun run() {
            if (stopping || apiServer == null) return
            applyReadiness()
            mainHandler.postDelayed(this, READINESS_POLL_MS)
        }
    }

    private fun applyReadiness() {
        val server = apiServer ?: return
        val readiness = try {
            ServiceSeams.readinessOf(server)
        } catch (t: Throwable) {
            Log.w(TAG, "server readiness could not be read", t)
            Readiness.ERROR
        }
        val port = try {
            ServiceSeams.portOf(server)
        } catch (t: Throwable) {
            0
        }
        val phase = when (readiness) {
            // The server reports STOPPED before it has finished binding, which is
            // still "we are on our way up" from the reader's point of view.
            Readiness.STOPPED -> CompanionPhase.STARTING
            Readiness.READY -> CompanionPhase.READY
            Readiness.LOADING -> CompanionPhase.LOADING
            Readiness.NEEDS_ATTENTION -> CompanionPhase.NEEDS_ATTENTION
            Readiness.ERROR -> CompanionPhase.ERROR
        }
        state.update { snapshot ->
            snapshot.copy(
                phase = phase,
                running = true,
                port = if (port > 0) port else snapshot.port,
                errorCode = if (phase == CompanionPhase.ERROR) ErrorCode.INTERNAL else null,
                errorMessage = if (phase == CompanionPhase.ERROR) {
                    snapshot.errorMessage ?: getString(R.string.error_generic)
                } else {
                    null
                },
            )
        }
    }

    /**
     * Turns a failed `LocalApiServer.start()` into something a reader can act on.
     *
     * The server wraps the bind failure in an `IllegalStateException`, so the
     * cause chain is walked rather than the top-level type being matched.
     */
    private fun describeStartFailure(t: Throwable): String {
        var cause: Throwable? = t
        var depth = 0
        while (cause != null && depth < MAX_CAUSE_DEPTH) {
            if (cause is java.net.BindException) {
                return getString(R.string.error_port_in_use, Config.PORT)
            }
            cause = cause.cause
            depth++
        }
        return getString(R.string.error_server_unavailable)
    }

    // ---- Stopping -----------------------------------------------------------

    /**
     * The only way this service stops. Everything is torn down here so that no
     * path can leave a socket open, a job hanging, or a WebView half-attached.
     */
    private fun stopWith(
        reason: StopReason,
        errorCode: ErrorCode? = null,
        errorMessage: String? = null,
    ) {
        if (stopping) return
        stopping = true

        val stoppedAt = System.currentTimeMillis()
        mainHandler.removeCallbacks(readinessTick)
        unregisterNetworkCallback()

        val server = apiServer
        apiServer = null
        if (server != null) {
            // Closing the listener must not block the main thread, and must not be
            // cancelled by onDestroy() racing in behind stopSelf(). Its own scope.
            CoroutineScope(Job() + Dispatchers.IO).launch {
                try {
                    // Fails every job still queued or running with COMPANION_UNAVAILABLE.
                    server.stop()
                } catch (t: Throwable) {
                    Log.w(TAG, "local API server did not stop cleanly", t)
                }
                // Only once the server is quiet is it safe to destroy the WebView
                // it was driving, so the teardown is sequenced after the stop. It
                // re-reads the field, so this is a no-op if onDestroy() already
                // released the browser.
                mainHandler.post { releaseBrowser() }
            }
        }

        runOnMainThread {
            try {
                gateway?.cancelActive()
            } catch (t: Throwable) {
                Log.w(TAG, "in-flight work could not be cancelled", t)
            }
            // The WebView leaves the window first and is destroyed afterwards, so
            // it is never torn down while still parented to a live view hierarchy.
            // A later Start builds a fresh WebView; the sign-in survives because
            // cookies live outside the WebView instance.
            detachFromContainer()
            if (server == null) releaseBrowser()
            pairingKey = ""
            activeRequest = null
            starting = false

            stopForeground(STOP_FOREGROUND_REMOVE)

            state.update { snapshot ->
                CompanionSnapshot(
                    phase = CompanionPhase.STOPPED,
                    running = false,
                    port = snapshot.port,
                    networkAvailable = snapshot.networkAvailable,
                    stopReason = reason,
                    stoppedAtMillis = stoppedAt,
                    errorCode = errorCode,
                    errorMessage = errorMessage,
                )
            }
            StopLog.write(this, reason, stoppedAt)
            stopping = false
            stopSelf()
        }
    }

    private fun failStart(message: String) {
        stopWith(
            reason = StopReason.START_FAILED,
            errorCode = ErrorCode.COMPANION_UNAVAILABLE,
            errorMessage = message,
        )
    }

    // ---- Binder API, used by the status screen ------------------------------

    fun isRunning(): Boolean = state.snapshot().running && gateway != null

    /** The key the running server is currently enforcing. Never logged. */
    fun currentPairingKey(): String =
        pairingKey.ifEmpty { PairingKey.getOrCreate(applicationContext) }

    /**
     * Puts the service-owned WebView into [container].
     *
     * Called on a binder thread, marshalled to the main thread. `attachTo` only
     * reparents the existing view: no reload, no new WebView, no cookie, cache or
     * DOM change, so opening and closing the website never costs the user a
     * sign-in. A gateway without a browser surface (a test double, or a device
     * with no WebView) is reported as "not attached" rather than crashing.
     */
    fun attachBrowser(container: ViewGroup) {
        runOnMainThread {
            val surface = gateway?.asBrowserSurface()
            if (surface == null) {
                attachedContainer = null
                state.update { it.copy(webViewAttached = false) }
                return@runOnMainThread
            }
            attachedContainer = container
            try {
                surface.attachTo(container)
                state.update { it.copy(webViewAttached = surface.isAttached) }
            } catch (t: Throwable) {
                Log.w(TAG, "the website could not be attached to the screen", t)
                attachedContainer = null
                state.update { it.copy(webViewAttached = false) }
            }
        }
    }

    /** Takes the WebView back out of whatever container it is in. Always safe. */
    fun detachBrowser() {
        runOnMainThread {
            detachFromContainer()
            state.update { it.copy(webViewAttached = false) }
        }
    }

    private fun detachFromContainer() {
        if (attachedContainer == null) return
        attachedContainer = null
        try {
            gateway?.asBrowserSurface()?.detach()
        } catch (t: Throwable) {
            Log.w(TAG, "the website could not be detached", t)
        }
    }

    /**
     * Destroys the WebView for good. Main thread only, and always after the WebView
     * has left any container, so it is never torn down while still parented to a
     * live view hierarchy.
     *
     * Cookies live in the process-wide cookie store, not in the WebView instance,
     * so shutting the browser down does **not** sign the reader out.
     */
    private fun releaseBrowser(target: BrowserGateway? = gateway) {
        val browser = target ?: return
        try {
            browser.asBrowserSurface()?.shutdown()
        } catch (t: Throwable) {
            Log.w(TAG, "the browser surface could not be shut down", t)
        } finally {
            // The reference is dropped only once the WebView really is gone, so a
            // teardown that is still in flight can never be mistaken for a live one.
            if (gateway === browser) gateway = null
        }
    }

    /**
     * Rotates the pairing key.
     *
     * This must **not** sign the reader out (spec section 5), so the WebView and
     * every cookie it holds are left completely alone. Only the key the HTTP
     * server enforces changes, and `updatePairingKey` applies it to the very next
     * request - the socket stays open, so nothing in flight is interrupted.
     */
    fun rotatePairingKey(): String {
        val key = try {
            PairingKey.rotate(applicationContext)
        } catch (t: Throwable) {
            Log.w(TAG, "pairing key could not be rotated", t)
            return currentPairingKey()
        }
        pairingKey = key
        apiServer?.let { server ->
            runOnMainThread { ServiceSeams.updatePairingKey(server, key) }
        }
        return key
    }

    /**
     * Wipes the NovTales session held by the WebView: the gateway's own
     * identity-sensitive state first, then cookies and web storage.
     *
     * Deliberately separate from rotating the pairing key, and always confirmed
     * with the user on the status screen before it is called.
     */
    fun clearWebsiteSession(onResult: (Boolean) -> Unit) {
        runOnMainThread {
            val browser = gateway
            if (browser == null) {
                onResult(false)
                return@runOnMainThread
            }
            val cleared = try {
                browser.onSessionCleared()
                CookieManager.getInstance().removeAllCookies { }
                WebStorage.getInstance().deleteAllData()
                // Make sure the deletions reach disk before the process might die.
                CookieManager.getInstance().flush()
                true
            } catch (t: Throwable) {
                Log.w(TAG, "the website session could not be cleared", t)
                false
            }
            onResult(cleared)
        }
    }

    // ---- Notifications ------------------------------------------------------

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                ServiceNotifications.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            startForeground(ServiceNotifications.NOTIFICATION_ID, notification)
        }
    }

    private fun refreshNotification() {
        val snapshot = state.snapshot()
        if (!snapshot.running) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.notify(
            ServiceNotifications.NOTIFICATION_ID,
            ServiceNotifications.build(this, snapshot),
        )
    }

    // ---- Connectivity -------------------------------------------------------

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = updateNetworkAvailability(true)

        override fun onLost(network: Network) = updateNetworkAvailability(hasInternet())

        override fun onCapabilitiesChanged(
            network: Network,
            capabilities: NetworkCapabilities,
        ) = updateNetworkAvailability(hasInternet())
    }

    private fun updateNetworkAvailability(available: Boolean) {
        state.update { it.copy(networkAvailable = available) }
    }

    private fun hasInternet(): Boolean {
        val manager = getSystemService(ConnectivityManager::class.java) ?: return true
        val active = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(active) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkCallback() {
        if (networkCallbackRegistered) return
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        try {
            manager.registerNetworkCallback(request, networkCallback)
            networkCallbackRegistered = true
        } catch (t: Throwable) {
            Log.w(TAG, "connectivity could not be watched", t)
        }
    }

    private fun unregisterNetworkCallback() {
        if (!networkCallbackRegistered) return
        networkCallbackRegistered = false
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        try {
            manager.unregisterNetworkCallback(networkCallback)
        } catch (t: Throwable) {
            Log.w(TAG, "connectivity watcher could not be removed", t)
        }
    }

    // ---- Helpers ------------------------------------------------------------

    /**
     * Binder calls arrive on a binder thread, while the WebView contract says the
     * main thread only. Everything that touches the gateway goes through here.
     */
    private fun runOnMainThread(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    companion object {
        private const val TAG = "CompanionService"

        /** How often the server's readiness is sampled for the status screen. */
        private const val READINESS_POLL_MS = 500L

        /** Guard on the cause walk in [describeStartFailure]. */
        private const val MAX_CAUSE_DEPTH = 8

        const val ACTION_START = "com.sadloif.novtalescompanion.action.START"
        const val ACTION_STOP = "com.sadloif.novtalescompanion.action.STOP"
    }
}