package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.ApiError
import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.PairingKey
import com.sadloif.novtalescompanion.core.jsonObject
import com.sadloif.novtalescompanion.web.Readiness

/**
 * The route table, the authentication check and nothing else. It owns no socket
 * and no thread, so every branch below is reachable from a unit test.
 *
 * Route table - anything not listed is 404:
 *
 * | Method   | Path                | Success                                   |
 * |----------|---------------------|-------------------------------------------|
 * | `GET`    | `/v1/health`        | 200 `{apiVersion, companionVersion, state}` |
 * | `POST`   | `/v1/jobs`          | 202 `{apiVersion, jobId, state}`          |
 * | `GET`    | `/v1/jobs/{jobId}`  | 200 `Job.toResponse(apiVersion)`           |
 * | `DELETE` | `/v1/jobs/{jobId}`  | 200 `Job.toResponse(apiVersion)`           |
 * | `OPTIONS`| any of the above    | 204, CORS-free                            |
 *
 * A known path with the wrong method is 405 with an `Allow` header; an unknown
 * path is 404. Authentication runs first, so an unauthenticated caller cannot
 * tell the two apart and cannot learn whether a job id exists (spec section 11).
 */
internal class ApiRouter(
    private val runner: JobRunner,
    private val readiness: () -> Readiness,
    private val pairingKey: () -> String?,
) {

    private sealed interface Route {
        val allow: String

        data object Health : Route {
            override val allow: String = "GET, OPTIONS"
        }

        data object Jobs : Route {
            override val allow: String = "POST, OPTIONS"
        }

        data class JobDetail(val jobId: String) : Route {
            override val allow: String = "GET, DELETE, OPTIONS"
        }
    }

    /** Ids come from `Job.newId()`; this also keeps a crafted id out of the store. */
    private val jobIdPattern = Regex("^[A-Za-z0-9_-]{1,64}$")

    fun handle(request: RequestContext): ApiResponse {
        val head = request.head

        // Resolve the route first, but say nothing about it: the result is only
        // used after the pairing key has been checked, so a caller without the
        // key cannot map the API surface.
        val route = resolve(head.path)

        val authFailure = authenticate(head)
        if (authFailure != null) {
            return ApiResponse.error(
                status = authFailure.code.httpStatus,
                error = ApiError.from(authFailure),
                headers = listOf("WWW-Authenticate" to BEARER_CHALLENGE),
            )
        }

        if (route == null) return notFound()
        val method = head.httpMethod ?: return methodNotAllowed(route)
        if (!accepts(route, method)) return methodNotAllowed(route)

        return when (route) {
            is Route.Health -> health(method)
            is Route.Jobs -> createJob(request)
            is Route.JobDetail -> jobDetail(method, route.jobId)
        }
    }

    // ---- Authentication ----------------------------------------------------

    /**
     * Every endpoint, including `/v1/health`, requires
     * `Authorization: Bearer <pairing key>`.
     *
     * The expected key comes from the volatile field the server primes at
     * `start()` and refreshes on rotation - it is never read from storage per
     * request, so a request can never race a write. The comparison itself is
     * [PairingKey.verify], which is `MessageDigest.isEqual` and therefore does
     * not leak the key length or a matching prefix through timing.
     *
     * A key sent any other way - as a query parameter, a cookie, a form field -
     * is not a key. Query strings end up in proxy logs and this server has no
     * reason to accept one, so only the `Authorization` header is read.
     */
    private fun authenticate(head: ParsedRequest): CompanionException? {
        val expected = pairingKey()
        if (expected.isNullOrBlank()) {
            // Fail closed. A server with no key must never behave like a server
            // that does not require one.
            return CompanionException(
                ErrorCode.COMPANION_UNAVAILABLE,
                "The companion is not ready to accept requests.",
            )
        }
        return PairingKey.verify(expected, bearerToken(head))
    }

    private fun bearerToken(head: ParsedRequest): String? {
        val header = head.header("authorization") ?: return null
        val space = header.indexOf(' ')
        if (space <= 0) return null
        // This is an auth *scheme* name, not a secret: case-insensitive
        // comparison is what RFC 7235 asks for and leaks nothing.
        if (!header.substring(0, space).equals("Bearer", ignoreCase = true)) return null
        val token = header.substring(space + 1).trim()
        if (token.isEmpty()) return null
        if (token.any { it.code < 0x21 || it.code > 0x7E }) return null
        return token
    }

    // ---- Handlers ----------------------------------------------------------

    private fun health(method: HttpMethod): ApiResponse {
        if (method == HttpMethod.OPTIONS) return options(Route.Health)
        return ApiResponse.json(
            200,
            jsonObject(
                "apiVersion" to Config.API_VERSION,
                "companionVersion" to Config.COMPANION_VERSION,
                "state" to readiness().name,
            ),
        )
    }

    private fun createJob(request: RequestContext): ApiResponse {
        if (request.head.httpMethod == HttpMethod.OPTIONS) return options(Route.Jobs)
        if (!request.head.hasHeader("content-length")) {
            return ApiResponse.error(
                411,
                ApiError.of(ErrorCode.BAD_REQUEST, "Content-Length is required for POST /v1/jobs."),
            )
        }

        val body = request.body()
        if (body.isBlank()) {
            return ApiResponse.error(
                400,
                ApiError.of(ErrorCode.BAD_REQUEST, "A JSON body is required."),
            )
        }

        val validation = JobRequestValidator.validate(body)
        val jobRequest = when (validation) {
            is JobRequestValidator.Result.Invalid -> return ApiResponse.error(400, validation.error)
            is JobRequestValidator.Result.Valid -> validation.request
        }

        return when (val outcome = runner.submit(jobRequest)) {
            is JobRunner.SubmitOutcome.Rejected -> ApiResponse.error(
                status = outcome.error.code.httpStatus,
                error = outcome.error,
            )
            // A freshly queued job always answers exactly
            // {"apiVersion":1,"jobId":...,"state":"queued"} as the contract
            // specifies, so the body is deterministic even if the worker has
            // already picked the job up.
            //
            // A collapsed request instead reports the state the shared job is
            // really in: claiming "queued" for work that is already loading or
            // finished would be a lie the caller can act on.
            is JobRunner.SubmitOutcome.Accepted -> ApiResponse.json(
                202,
                jsonObject(
                    "apiVersion" to Config.API_VERSION,
                    "jobId" to outcome.job.id,
                    "state" to if (outcome.collapsed) {
                        outcome.job.state.wireName
                    } else {
                        "queued"
                    },
                ),
            )
        }
    }

    private fun jobDetail(method: HttpMethod, jobId: String): ApiResponse {
        if (method == HttpMethod.OPTIONS) {
            return options(Route.JobDetail(jobId))
        }
        val job = runner.job(jobId) ?: return notFound()
        return when (method) {
            HttpMethod.DELETE -> {
                // Another caller may still be waiting on a shared job, so one
                // DELETE removes one caller and never the shared work. Both
                // outcomes answer 200 with the state as it stands.
                runner.release(jobId) ?: return notFound()
                ApiResponse.json(200, job.toResponse(Config.API_VERSION))
            }
            else -> ApiResponse.json(200, job.toResponse(Config.API_VERSION))
        }
    }

    // ---- Routing -----------------------------------------------------------

    private fun resolve(path: String): Route? = when {
        path == "/v1/health" -> Route.Health
        path == "/v1/jobs" -> Route.Jobs
        path.startsWith(JOB_PREFIX) -> {
            val id = path.substring(JOB_PREFIX.length)
            if (jobIdPattern.matches(id)) Route.JobDetail(id) else null
        }
        else -> null
    }

    private fun accepts(route: Route, method: HttpMethod): Boolean = when (method) {
        HttpMethod.GET -> route is Route.Health || route is Route.JobDetail
        HttpMethod.POST -> route is Route.Jobs
        HttpMethod.DELETE -> route is Route.JobDetail
        HttpMethod.OPTIONS -> true
    }

    private fun methodNotAllowed(route: Route) = ApiResponse.error(
        status = 405,
        error = ApiError.of(
            ErrorCode.BAD_REQUEST,
            "That method is not supported on this endpoint.",
        ),
        headers = listOf("Allow" to route.allow),
    )

    private fun notFound() = ApiResponse.error(
        status = 404,
        error = ApiError.of(ErrorCode.NOT_FOUND, "No such endpoint."),
    )

    /**
     * A minimal, CORS-free OPTIONS answer.
     *
     * No `Access-Control-Allow-Origin` is emitted, and none should ever be: the
     * plugin is not a browser origin, and a wildcard here would let any page the
     * user has open in the system WebView talk to this port - which is the one
     * place where the pairing key would be the only thing standing between it
     * and a chapter scraper.
     */
    private fun options(route: Route) = ApiResponse.empty(
        status = 204,
        headers = listOf("Allow" to route.allow),
    )

    companion object {
        private const val JOB_PREFIX = "/v1/jobs/"
        private const val BEARER_CHALLENGE = "Bearer realm=\"novtales-companion\""
    }
}