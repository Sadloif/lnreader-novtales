import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Release signing identity. Credentials live in keystore.properties, which is
// git-ignored; the keystore itself is provided by the maintainer and must
// never be published.
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties().apply {
    if (keystorePropertiesFile.exists()) {
        keystorePropertiesFile.inputStream().use { load(it) }
    }
}
val hasReleaseSigning = keystoreProperties.getProperty("storeFile")?.let {
    rootProject.file(it).exists()
} == true

// A release build that quietly falls back to the debug key produces an APK that
// "Verifies" with apksigner, has the correct package name and version, and still
// reports BUILD SUCCESSFUL - but it is signed `CN=Android Debug` and therefore
// CANNOT update an existing installation. The user would have to uninstall,
// losing the app's data, with nothing in the output to warn them. Failing loudly
// is the only safe behaviour for an artefact that is meant to be distributed.
//
// The check is against the **resolved task graph**, not the names typed on the
// command line. An earlier version matched `startParameter.taskNames` for the
// string "Release", which was defeated by the two most ordinary commands there
// are: `gradlew assemble` and `gradlew build` contain no "Release", yet both pull
// `packageRelease` into the graph and both produced a debug-signed release APK
// with BUILD SUCCESSFUL and no warning. Conversely that string match wrongly
// blocked `lintVitalRelease`, which needs no signing key at all.
//
// The guard is attached to the packaging task itself, not to the names typed on
// the command line. An earlier version matched `startParameter.taskNames` for the
// string "Release", which was defeated by the two most ordinary commands there
// are: `gradlew assemble` and `gradlew build` contain no "Release", yet both pull
// `packageRelease` into the graph and both produced a debug-signed release APK
// with BUILD SUCCESSFUL and no warning at all. Conversely that string match
// wrongly blocked `lintVitalRelease`, `lintRelease` and `compileReleaseKotlin`,
// none of which need a signing key.
//
// Hooking `doFirst` on the task that actually produces the artefact is exact in
// both directions: anything that packages the release APK is blocked, and
// nothing else is touched. `tasks.matching` is lazy, so a debug-only build pays
// nothing for the check.
//
// Both packaging tasks are listed. An earlier revision matched only
// `packageRelease`, which left `gradlew bundleRelease` happily producing a
// debug-signed AAB with BUILD SUCCESSFUL — a different upload key, same trap.
//
// (`Gradle.taskGraph.whenReady` would be the other option, but it only exposes a
// Groovy `Closure` overload, which does not compile cleanly in a Kotlin DSL
// build script.)
tasks.matching { it.name == "packageRelease" || it.name == "packageReleaseBundle" }.configureEach {
    doFirst {
        if (!hasReleaseSigning) {
            throw GradleException(
                """
                |Refusing to package a release artefact: no signing identity.
                |
                |This build reached :app:packageRelease, but keystore.properties
                |is missing or the keystore it points at does not exist. Without it
                |the APK would be signed with the DEBUG key, which cannot update an
                |installed copy - it would force an uninstall and lose the user's
                |app data - and nothing in a normal-looking successful build would
                |say so.
                |
                |Create the identity once (see docs/BUILD.md):
                |  keytool -genkeypair -v -keystore novtales-release.jks -alias novtales \
                |          -keyalg RSA -keysize 4096 -validity 10950
                |then write keystore.properties with storeFile, storePassword, keyAlias
                |and keyPassword. Note PKCS12 ignores a separate key password, so
                |keyPassword must equal storePassword.
                |
                |For a local build that is not for distribution, run: gradlew assembleDebug
                |To confirm you did not ship a debug-signed APK, compare the certificate
                |digest - not `apksigner verify`'s exit code, which passes either way:
                |  apksigner verify --print-certs app-release.apk
                """.trimMargin()
            )
        }
    }
}

android {
    namespace = "com.sadloif.novtalescompanion"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sadloif.novtalescompanion"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.1.4"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = rootProject.file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
                // Stable signing identity is required so later APK updates
                // install over the previous build.
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (hasReleaseSigning) {
                signingConfigs.getByName("release")
            } else {
                // Only reachable for a debug-only task graph; the guard at the top
                // of this file fails the build before any release task can run.
                signingConfigs.getByName("debug")
            }
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE*",
            "META-INF/NOTICE*",
            "META-INF/*.kotlin_module"
        )
    }

    lint {
        abortOnError = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // No embedded HTTP server dependency on purpose. See docs/DEVIATIONS.md:
    // org.nanohttpd:nanohttpd has not been released since 2016-08-12 and
    // would sit directly on the pairing-key authentication boundary.

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}
