# Verifies that this machine has the toolchain the build needs, and prints the
# environment the build expects. Run this before the first build.
#
# On a normal developer machine none of the redirection below is required; see
# docs/BUILD.md.

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent (Split-Path -Parent $PSCommandPath)   # novtales-companion
$repo = Split-Path -Parent $root                                 # repository root
$work = Join-Path $repo "_working"

# ---------------------------------------------------------------------------
# Resolve the toolchain rather than assuming one machine's paths. Each entry is
# a candidate; the first that actually holds the tool wins. This build machine
# keeps a JDK and SDK under the Linksi toolchain; other machines use Adoptium,
# Android Studio, or plain environment variables.
# ---------------------------------------------------------------------------
function Find-Tool([string[]]$candidates, [string]$probe) {
    foreach ($c in ($candidates | Where-Object { $_ })) {
        if (Test-Path (Join-Path $c $probe)) { return $c }
        # Versioned install directories: Adoptium\temurin-17.0.20.1, jbr, ...
        if (Test-Path $c -PathType Container) {
            $sub = Get-ChildItem $c -Directory -ErrorAction SilentlyContinue |
                   Where-Object { Test-Path (Join-Path $_.FullName $probe) } |
                   Sort-Object Name -Descending | Select-Object -First 1
            if ($sub) { return $sub.FullName }
        }
    }
    return $null
}

$sdkFromEnv = $env:ANDROID_HOME
if (-not $sdkFromEnv) { $sdkFromEnv = $env:ANDROID_SDK_ROOT }

$sdkDirProp = $null
$localProps = Join-Path $root "local.properties"
if (Test-Path $localProps) {
    $line = Select-String -Path $localProps -Pattern '^\s*sdk\.dir\s*=\s*(.+?)\s*$' | Select-Object -First 1
    if ($line) { $sdkDirProp = ($line.Matches[0].Groups[1].Value -replace '\\:', ':' -replace '\\\\', '\') }
}

$jdkCandidates = @()
if ($env:JAVA_HOME)                       { $jdkCandidates += $env:JAVA_HOME }
$jdkCandidates += "E:\Deepseek\Linksi\toolchain\jdk-17"
$pf = ${env:ProgramFiles}
$lf = ${env:LOCALAPPDATA}
if ($pf) {
    $jdkCandidates += (Join-Path $pf "Eclipse Adoptium")
    $jdkCandidates += (Join-Path $pf "Android\Android Studio\jbr")
}
if ($lf) { $jdkCandidates += (Join-Path $lf "Programs\Android Studio\jbr") }

$sdkCandidates = @()
if ($sdkFromEnv)  { $sdkCandidates += $sdkFromEnv }
if ($sdkDirProp)  { $sdkCandidates += $sdkDirProp }
$sdkCandidates += "E:\Deepseek\Linksi\toolchain\android-sdk"
if ($lf)          { $sdkCandidates += (Join-Path $lf "Android\Sdk") }

$jdk = Find-Tool $jdkCandidates "bin\java.exe"
$sdk = Find-Tool $sdkCandidates "platforms"

function Test-Tool($label, $path) {
    if ($path -and (Test-Path $path)) {
        Write-Host ("  OK    {0,-16} {1}" -f $label, $path) -ForegroundColor Green
        return $true
    }
    Write-Host ("  MISS  {0,-16} {1}" -f $label, $(if ($path) { $path } else { "(not found)" })) -ForegroundColor Yellow
    return $false
}

Write-Host "NovTales Companion - toolchain check" -ForegroundColor Cyan
Write-Host ""

$ok = $true
$ok = (Test-Tool "JDK 17" $jdk) -and $ok

if ($ok) {
    # `java -version` writes to stderr; relax the preference so it is not
    # mistaken for a failure.
    $relaxed = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $version = & "$jdk\bin\java.exe" -version 2>&1 | Select-Object -First 1
    $ErrorActionPreference = $relaxed
    Write-Host ("        {0}" -f $version)
}

$ok = (Test-Tool "Android SDK" $sdk) -and $ok
if ($sdk) {
    $platforms = Get-ChildItem (Join-Path $sdk "platforms") -Directory -ErrorAction SilentlyContinue |
                 Where-Object { $_.Name -match '^android-35$' }
    if ($platforms) {
        Write-Host "  OK    Platform       android-35" -ForegroundColor Green
    } else {
        Write-Host "  MISS  Platform       android-35" -ForegroundColor Yellow
        $ok = $false
    }

    $bt = Get-ChildItem (Join-Path $sdk "build-tools") -Directory -ErrorAction SilentlyContinue |
          Sort-Object Name -Descending | Select-Object -First 1
    if ($bt -and $bt.Name -eq '35.0.0') {
        Write-Host "  OK    Build tools    35.0.0" -ForegroundColor Green
    } elseif ($bt) {
        Write-Host ("  WARN  Build tools    {0} (expected 35.0.0)" -f $bt.Name) -ForegroundColor Yellow
    } else {
        Write-Host "  MISS  Build tools    35.0.0" -ForegroundColor Yellow
        $ok = $false
    }
}

$hasWrapper = Test-Path (Join-Path $root "gradlew.bat")
Write-Host ("  {0}  Gradle wrapper {1}" -f $(if ($hasWrapper) { "OK   " } else { "MISS " }),
    (Join-Path $root "gradlew.bat")) -ForegroundColor $(if ($hasWrapper) { "Green" } else { "Yellow" })
$hasWrapperJar = Test-Path (Join-Path $root "gradle\wrapper\gradle-wrapper.jar")
Write-Host ("  {0}  Wrapper jar    {1}" -f $(if ($hasWrapperJar) { "OK   " } else { "MISS " }),
    (Join-Path $root "gradle\wrapper\gradle-wrapper.jar")) -ForegroundColor $(if ($hasWrapperJar) { "Green" } else { "Yellow" })

$hasKeystore = Test-Path (Join-Path $root "keystore.properties")
Write-Host ("  {0}  Signing key    {1}" -f $(if ($hasKeystore) { "OK   " } else { "MISS " }),
    (Join-Path $root "keystore.properties")) -ForegroundColor $(if ($hasKeystore) { "Green" } else { "Yellow" })

if (-not $hasKeystore) {
    Write-Host ""
    Write-Host "  No release signing identity." -ForegroundColor Yellow
    Write-Host "  This is EXPECTED in the delivered tree: the keystore is deliberately" -ForegroundColor Yellow
    Write-Host "  not published. assembleRelease will now FAIL rather than silently" -ForegroundColor Yellow
    Write-Host "  fall back to the debug key, because a debug-signed APK passes every" -ForegroundColor Yellow
    Write-Host "  automated check and still cannot update an installed copy." -ForegroundColor Yellow
    Write-Host "  For a local build use: gradlew.bat assembleDebug" -ForegroundColor Yellow
    Write-Host "  See docs/BUILD.md before distributing anything." -ForegroundColor Yellow
}

if (-not (Test-Path $localProps)) {
    Write-Host ""
    Write-Host "  No local.properties. Point Gradle at the SDK with ANDROID_HOME, or" -ForegroundColor Yellow
    Write-Host "  write sdk.dir=<path> into novtales-companion\local.properties." -ForegroundColor Yellow
    Write-Host "  local.properties is git-ignored and never shipped - it holds an" -ForegroundColor Yellow
    Write-Host "  absolute path that means nothing on another machine." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Environment for a build:"
Write-Host "  JAVA_HOME        = $(if ($jdk) { $jdk } else { '(not found)' })"
Write-Host "  sdk.dir          = $(if ($sdk) { $sdk } else { '(not found)' })"
Write-Host "  GRADLE_USER_HOME = $(Join-Path $work 'gradle-home')   (build.ps1 only)"
Write-Host "  TEMP / TMP       = $(Join-Path $work 'tmp')   (build.ps1 only)"
Write-Host "  ANDROID_USER_HOME= $(Join-Path $work 'android-home')   (build.ps1 only)"
Write-Host ""

if (-not $ok) {
    Write-Host "Toolchain incomplete." -ForegroundColor Red
    exit 1
}
Write-Host "Toolchain OK." -ForegroundColor Green
Write-Host "Gradle comes from the committed wrapper (gradlew.bat); build.ps1 uses it." -ForegroundColor Cyan
exit 0