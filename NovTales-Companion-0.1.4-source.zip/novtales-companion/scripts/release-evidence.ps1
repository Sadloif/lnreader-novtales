# Produces the release evidence required by spec section 13:
#   - APK SHA-256 checksum
#   - signing-certificate SHA-256 fingerprint
#   - APK signature scheme verification (v1 / v2 / v3)
#
# Run after `gradlew.bat assembleRelease` (or build.ps1).
#
# NOTE ON v1: `apksigner verify` takes its min-SDK from the APK manifest. At
# minSdk 26 the v1/JAR scheme is unnecessary, so apksigner reports
# "Verified using v1 scheme: false" whether or not v1 was actually applied. This
# script runs apksigner a second time with --min-sdk-version 23, which forces the
# JAR check and reports the truth. Both outputs are printed.

param(
    [string]$Apk,
    [string]$BuildTools,
    # Escape hatch: print the digests but stamp them UNVERIFIED instead of
    # failing. The default is to fail loudly - an unverified digest pasted into
    # docs/TEST_REPORT.md is exactly the defect this script exists to prevent.
    [switch]$AllowUnverified
)

$ErrorActionPreference = "Continue"

$repoRoot  = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSCommandPath))
$project   = Split-Path -Parent (Split-Path -Parent $PSCommandPath)

# ---------------------------------------------------------------------------
# JDK - resolve rather than assume. apksigner needs JAVA_HOME or it cannot
# start a JVM.
# ---------------------------------------------------------------------------
function Find-Jdk {
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\java.exe"))) {
        return $env:JAVA_HOME
    }
    $candidates = @("E:\Deepseek\Linksi\toolchain\jdk-17")
    $pf = ${env:ProgramFiles}
    if ($pf) {
        $candidates += (Join-Path $pf "Eclipse Adoptium")
        $candidates += (Join-Path $pf "Android\Android Studio\jbr")
    }
    foreach ($c in $candidates) {
        if (Test-Path (Join-Path $c "bin\java.exe")) { return $c }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Locate the APK. The shipped artefact is dist\, because sync-to-app.ps1
# excludes app\build\. Prefer that; fall back to the raw Gradle output.
# ---------------------------------------------------------------------------
if (-not $Apk) {
    $candidates = @(
        (Join-Path $repoRoot "dist\NovTales-Companion-0.1.0.apk"),
        (Join-Path $project  "app\build\outputs\apk\release\app-release.apk")
    )
    $Apk = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
}

if (-not $Apk -or -not (Test-Path $Apk)) {
    Write-Host "APK not found. Looked for:" -ForegroundColor Red
    Write-Host "  dist\NovTales-Companion-0.1.0.apk                        (shipped artefact)" -ForegroundColor Red
    Write-Host "  novtales-companion\app\build\outputs\apk\release\app-release.apk  (raw build output)" -ForegroundColor Red
    Write-Host "Run build.ps1 -Task assembleRelease first, or pass -Apk <path>." -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------------------
# Locate apksigner. Order: explicit argument, $env:ANDROID_HOME,
# $env:ANDROID_SDK_ROOT, local.properties sdk.dir, then this build machine.
# ---------------------------------------------------------------------------
if (-not $BuildTools) {
    $sdkCandidates = @()
    if ($env:ANDROID_HOME)     { $sdkCandidates += $env:ANDROID_HOME }
    if ($env:ANDROID_SDK_ROOT) { $sdkCandidates += $env:ANDROID_SDK_ROOT }
    $localProps = Join-Path $project "local.properties"
    if (Test-Path $localProps) {
        $line = Select-String -Path $localProps -Pattern '^\s*sdk\.dir\s*=\s*(.+?)\s*$' |
                Select-Object -First 1
        if ($line) { $sdkCandidates += ($line.Matches[0].Groups[1].Value -replace '\\:', ':' -replace '\\\\', '\') }
    }
    $sdkCandidates += "E:\Deepseek\Linksi\toolchain\android-sdk"

    foreach ($sdk in ($sdkCandidates | Where-Object { $_ } | Select-Object -Unique)) {
        # Highest installed build-tools version wins.
        $bt = Get-ChildItem (Join-Path $sdk "build-tools") -Directory -ErrorAction SilentlyContinue |
              Sort-Object Name -Descending | Select-Object -First 1
        if ($bt) { $BuildTools = $bt.FullName; break }
    }
}

$apksigner = if ($BuildTools) { Join-Path $BuildTools "apksigner.bat" } else { $null }

$jdk = Find-Jdk
if ($jdk) { $env:JAVA_HOME = $jdk }

$size = (Get-Item $Apk).Length
$sha  = (Get-FileHash $Apk -Algorithm SHA256).Hash

Write-Host ""
Write-Host "Release evidence" -ForegroundColor Cyan
Write-Host "----------------"
Write-Host ("APK        {0}" -f $Apk)
Write-Host ("Size       {0:N0} bytes ({1:N2} MB)" -f $size, ($size / 1MB))
Write-Host ("SHA-256    {0}" -f $sha)

# ---------------------------------------------------------------------------
# Signature verification. This is mandatory evidence: a report that lists a
# certificate digest with no verification behind it is not evidence.
# ---------------------------------------------------------------------------
$missing = @()
if (-not $apksigner -or -not (Test-Path $apksigner)) { $missing += "apksigner" }
if (-not $jdk)                                       { $missing += "JDK 17 (JAVA_HOME)" }

if ($missing.Count -gt 0) {
    Write-Host ""
    Write-Host ("UNVERIFIED - signature evidence NOT collected. Missing: {0}" -f ($missing -join ", ")) -ForegroundColor Red
    if (-not $BuildTools) {
        Write-Host "Set ANDROID_HOME or -BuildTools <sdk>\build-tools\35.0.0 (or pass -BuildTools)." -ForegroundColor Red
    }
    Write-Host "Do NOT paste the digests above into docs/TEST_REPORT.md as verified." -ForegroundColor Red
    if ($AllowUnverified) {
        Write-Host "-AllowUnverified was passed: continuing, and every line above is UNVERIFIED." -ForegroundColor Yellow
        exit 0
    }
    Write-Host "Pass -AllowUnverified only if you intend to mark the result unverified." -ForegroundColor Red
    exit 2
}

Write-Host ""
Write-Host "Signature verification" -ForegroundColor Cyan

# First pass: apksigner's own min-SDK (from the manifest). At minSdk 26 the v1
# scheme is not required, so a `false` here means "not needed", not "not applied".
Write-Host "  apksigner verify --verbose (min-SDK from manifest, i.e. 26):" -ForegroundColor Cyan
& $apksigner verify --verbose --print-certs $Apk 2>&1 |
    Where-Object { $_ -match 'Verif|certificate SHA-256|signer #1 certificate DN|Number of signers|key size' } |
    ForEach-Object { Write-Host ("    {0}" -f $_) }

# Second pass: force the JAR check by claiming an API 23 min-SDK. This is what
# actually proves whether v1 was applied.
Write-Host ""
Write-Host "  apksigner verify --verbose --min-sdk-version 23 (forces the JAR/v1 check):" -ForegroundColor Cyan
$v1 = & $apksigner verify --verbose --min-sdk-version 23 $Apk 2>&1
$v1code = $LASTEXITCODE
$v1 | Where-Object { $_ -match 'Verif' } | ForEach-Object { Write-Host ("    {0}" -f $_) }

if ($v1code -ne 0) {
    Write-Host ""
    Write-Host "Signature verification FAILED with --min-sdk-version 23 (exit $v1code)." -ForegroundColor Red
    exit 3
}

$v1Applied = ($v1 | Where-Object { $_ -match 'Verified using v1 scheme.*:\s*true' }).Count -gt 0
if ($v1Applied) {
    Write-Host ""
    Write-Host "v1/JAR signing IS applied to this APK. The manifest-min-SDK run above" -ForegroundColor Green
    Write-Host "reports it as unnecessary only because minSdk is 26." -ForegroundColor Green
}

Write-Host ""
Write-Host "Paste the two digests into docs/TEST_REPORT.md and the release notes." -ForegroundColor Cyan
exit 0