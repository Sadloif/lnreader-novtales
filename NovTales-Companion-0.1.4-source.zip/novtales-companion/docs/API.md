# NovTales Companion — local API

Versioned independently of the website adapter. The current version is **1**.

* Base URL: `http://127.0.0.1:5301` (loopback only)
* Transport: HTTP/1.1, plaintext on loopback. Website traffic stays HTTPS inside
  the WebView.
* The server **never** opens an outbound socket and has no proxy capability.

---

## Authentication

Every endpoint, including `/v1/health`, requires the pairing key:

```http
Authorization: Bearer <local pairing key>
Content-Type: application/json
```

The key is 256 bits of entropy, base64url, generated on first use by the
companion and copied by the user into the NovTales plugin settings in LNReader.

This key authorises **access to the local companion only**. It is not a NovTales
account token and grants no access to the website.

* It is stored in private app storage with cloud backup and device transfer
  disabled, so it never leaves the device.
* It is never placed in a URL, a log, a crash report, or a repository file.
* Comparison is constant-time (`MessageDigest.isEqual`).
* `POST /v1/jobs` authenticates **before** the body is parsed, so an
  unauthenticated caller cannot probe job ids.
* **Rotating the key does not sign the user out of NovTales.** Clearing the
  website session is a separate, deliberate action.

---

## Operations

`catalogue`, `search`, `novel`, `chapters`, `chapter`. Anything else is rejected
with `BAD_REQUEST`.

| Operation | Required fields | Optional |
|---|---|---|
| `catalogue` | `page` (**required**, 1-based) | `sort` |
| `search` | `query` (non-blank) | `page`, `sort` |
| `novel` | `path` = `/novel/{slug}` | — |
| `chapters` | `path` = `/novel/{slug}`, `page` (**required**, 1-based) | — |
| `chapter` | `path` = `/chapter/{slug}-{number}` | — |

`sort` is restricted to an allowlist of lowercase words (`popular`, `latest`,
`title`, `rating`, `updated`).

Paths are normalised and validated before anything else happens. Traversal, query
strings, fragments, repeated percent-encoding, non-`https` schemes and absolute
URLs to any host other than `novtales.com` are all rejected.

### Chapter pages are 50 wide

`chapters` is paginated at a fixed **50 chapters per page**, page 1 first and
oldest chapter first. That is the same 50 the companion asks the website's
public chapter index for, so reader page *n* and site page *n* are the same
chapter range and no translation happens between them.

The companion always reads the **whole** index before answering - a partial index
is never returned, because that would silently truncate the novel - and then
slices out the page that was asked for. A `page` beyond the end of the novel is a
**successful response with an empty `chapters` array**, not an error.

Two extra fields describe the novel as a whole so a client can size itself from
the first response instead of walking every page to find out:

* `chapterCount` — how many chapters the novel has.
* `totalPages` — `ceil(chapterCount / 50)`, never below 1.

Note that this is **not** the same as the website's own `chapterTotalPages`,
which is reported by `novel` and partitions the same novel into 12-per-page
groups. Clients that page by `chapters.totalPages` are paging at 50; clients that
page by `novel.totalPages` are paging at 12.

---

## Endpoints

### `GET /v1/health`

```json
{
  "apiVersion": 1,
  "companionVersion": "0.1.0",
  "state": "READY"
}
```

`state` is one of `STOPPED`, `READY`, `LOADING`, `NEEDS_ATTENTION`, `ERROR`.

### `POST /v1/jobs`

Request:

```json
{"operation":"chapter","path":"/chapter/surviving-the-game-as-a-barbarian-1"}
```

Accepted — **HTTP 202**:

```json
{"apiVersion":1,"jobId":"6f1c...","state":"queued"}
```

An identical in-flight request is **collapsed** into the existing job and returns
the same `jobId`.

`GET /v1/jobs/{jobId}` — **HTTP 200**, the current state:

```json
{"apiVersion":1,"jobId":"6f1c...","state":"loading"}
{"apiVersion":1,"jobId":"6f1c...","state":"completed","result":{ ... }}
{"apiVersion":1,"jobId":"6f1c...","state":"failed","error":{ ... }}
```

`DELETE /v1/jobs/{jobId}` — cancels. Caller cancellation is independent: several
pollers may share one collapsed job, and one cancelling does not cancel the
others. Unknown id returns **404**.

---

## States

`queued` → `loading` → one of `completed`, `failed`, `cancelled`, or
`needs_user`.

`needs_user` is **not** an automatic-retry state. It means the website presented
something the user must handle — verification, sign-in, or a membership
requirement. The plugin must tell the reader to open the companion and must not
retry by itself.

---

## Errors

### The envelope

Every HTTP-level failure — a 4xx, a 5xx, a refused method, an oversized body —
carries the **same nested envelope**, produced by `ApiResponse.error` in
`api/HttpConnection.kt`:

```json
{
  "apiVersion": 1,
  "error": {
    "code": "VERIFICATION_REQUIRED",
    "message": "Open the companion to finish the website check.",
    "retryable": false,
    "retryAfterMs": null
  },
  "retryAfterMs": null
}
```

Read `error.code`, `error.message`, `error.retryable` and `error.retryAfterMs`.
The structured error is **nested under `error`**; `retryAfterMs` is repeated at
the top level only so a client can read the wait without walking in. When
`retryAfterMs` is set, the same value also appears as a `Retry-After` header in
whole seconds.

> The flat shape `{"apiVersion":1,"code":"…","message":"…"}` is **not** what
> this server sends. It is documented here only because a client is free to
> tolerate it for forward compatibility, and the NovTales plugin does read
> `error.code` first and a flat `code` second. Anything that only reads a flat
> `code` will see every failure as `INTERNAL`.

### Job failures use the same nesting

A job that fails is still **HTTP 200**. `GET /v1/jobs/{jobId}` reports it in the
`state` field, with the identical error object under `error`:

```json
{"apiVersion":1,"jobId":"6f1c...","state":"failed",
 "error":{"code":"TIMEOUT","message":"…","retryable":true,"retryAfterMs":null},
 "retryAfterMs":null}
```

`needs_user` uses exactly the same shape. A client therefore has one place to
read an error code from — `body.error.code` — whether the failure arrived as an
HTTP status or as a finished job.

`retryable` defaults per code; `retryAfterMs` is present when the companion knows
how long to wait.

| Code | HTTP | Handling |
|---|---|---|
| `COMPANION_UNAVAILABLE` | 503 | Ask the user to open and start the companion |
| `UNAUTHORIZED` | 401 | The pairing key must be copied again |
| `VERIFICATION_REQUIRED` | 409 | User completes the check in the visible browser; **no auto-retry** |
| `SIGN_IN_REQUIRED` | 409 | Same; public chapters must still work signed out |
| `MEMBERSHIP_REQUIRED` | 402 | Report the requirement; **never return a preview** |
| `RATE_LIMITED` | 429 | Respect `retryAfterMs` |
| `QUEUE_FULL` | 429 | Wait `retryAfterMs`, retry a bounded number of times |
| `TIMEOUT` | 504 | Fail the download; preserve a retry path |
| `INCOMPLETE_CHAPTER` | 502 | Fail; **never store partial content** |
| `WRONG_CHAPTER` | 502 | Reject and surface the diagnostic |
| `SITE_CHANGED` | 502 | Reject; the adapter needs updating |
| `BAD_REQUEST` | 400 | Fix the request |
| `NOT_FOUND` | 404 | Unknown route or job id |
| `CANCELLED` | 499 | The caller cancelled |
| `INTERNAL` | 500 | Companion fault; never leaks internals |

### Three distinct failure layers

A local API failure, a website HTTP response and an adapter error are kept
separate on purpose. **An HTTP 429 alone is never reported as browser
verification** unless a verified marker in the response actually identifies that
condition, and the companion never claims a TLS cause without evidence.

---

## Result shapes

```jsonc
// catalogue / search
{"items":[{"name":"Title","path":"/novel/slug","cover":"https://…"}],"page":1,"hasNext":true}

// novel
// (totalPages here is the WEBSITE's chapterTotalPages - a 12-per-page count,
//  which is NOT the width `chapters` pages at)
{"name":"…","path":"/novel/slug","cover":"https://…","summary":"…","author":"…",
 "genres":"Action, Drama","status":"Ongoing","rating":4.5,"chapters":[],"totalPages":81}

// chapters  (one 50-wide page, ascending; page 1 holds chapters 1..50)
// {"chapters":[{"name":"…","path":"/chapter/slug-1","chapterNumber":1,"releaseTime":"…"}],
//  "chapterCount":944,"totalPages":19}
// A `page` past the end is a 200 with "chapters":[] and the same two counts.

// chapter  (complete:true ONLY when the End of Chapter N marker was seen)
{"path":"/chapter/slug-1","chapterNumber":1,"complete":true,"content":"<p>…</p>"}
```

`genres` is a comma-separated **string**. `status` is one of `Ongoing`,
`Completed`, `OnHiatus`, `Cancelled`, `Unknown`. Decimal chapter numbers are
preserved exactly (`12.5`, never `12.50`). Chapters are ascending and
de-duplicated by path. Fields the site does not expose are omitted, never guessed.

`chapters` is a **page**, not the whole novel. `chapterCount` and `totalPages`
describe the whole novel at the same 50-per-page width; `novel.totalPages` is a
different number (see *Chapter pages are 50 wide*).

### Chapter completion

A chapter is complete only when **all three** hold:

1. an exact `End of Chapter N` marker is present, where `N` equals the requested
   number;
2. the chapter metadata identifies the same slug and number;
3. `.nv-chapter-body` contains readable text after sanitising.

**The `Loading chapter` placeholder is deliberately *not* a fourth condition.**
It looks like an obvious extra gate, and an earlier draft of this document said
so. It would be wrong: the site occasionally leaves a spinner in its own chrome
long after the last part has landed, and letting that veto a finished chapter
loses real downloads. The exact marker is the authority. `stillLoading` is
consulted only *after* a chapter has failed the rule, to decide whether to keep
scrolling for more parts or give up.

Character count, a 200 response, a spinner disappearing or a non-empty preview are
all insufficient. `complete: true` is never set to make a download look
successful.

---

## Limits

| Limit | Value |
|---|---|
| Waiting jobs | 4 |
| Max queue wait | 20 s |
| Metadata deadline | 45 s |
| Chapter deadline | 120 s |
| Request line + headers | 16 KiB |
| Request body | 16 KiB |
| Response | 8 MiB |
| Finished jobs retained | 120 s |

These are measured starting points for the Oppo Reno 15, not website guarantees.

---

## Polling

Poll `GET /v1/jobs/{jobId}` once per second initially, backing off to once every
two seconds. Bound the total wait; do not poll forever.