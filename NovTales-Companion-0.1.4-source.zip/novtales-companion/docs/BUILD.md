# Building the NovTales Companion APK

## Requirements

| Component | Version used |
|---|---|
| JDK | 17 (Temurin 17.0.20.1 was used here) |
| Android SDK Platform | 35 |
| Android SDK Build Tools | 35.0.0 |
| Gradle | 8.9 — supplied by the committed wrapper, no separate install needed |
| Android Gradle Plugin | 8.7.3 |
| Kotlin | 2.0.21 |

`JAVA_HOME` must point at a JDK 17 installation. Point Gradle at the SDK either
with the `ANDROID_HOME` environment variable or by writing
`sdk.dir=/path/to/android-sdk` into `local.properties`.

> **`local.properties` is not shipped.** It is git-ignored and excluded from both
> the delivery and the source ZIP, because it holds an absolute path from the
> build machine (`sdk.dir=E:\Deepseek\Linksi\toolchain\android-sdk`) that means
> nothing on your machine. A reviewer on a different machine would get a build
> failure pointing at a directory that does not exist for them. Write your own.

## Build

```sh
./gradlew assembleRelease
```

On Windows:

```bat
gradlew.bat assembleRelease
```

The APK is written to:

```
app/build/outputs/apk/release/app-release.apk
```

**That path is not in the delivery.** `app/build/` is a build cache and
`sync-to-app.ps1` excludes it, so the shipped artefact is the staged copy at
`dist/NovTales-Companion-0.1.0.apk` (one level up, at the repository root). Copy
it there after a build:

```powershell
Copy-Item app\build\outputs\apk\release\app-release.apk ..\dist\NovTales-Companion-0.1.0.apk
```

Other useful tasks:

```sh
./gradlew test          # JVM unit tests
./gradlew lint          # Android Lint - see the caveat below
./gradlew clean
```

### A caveat about `lint`

`lint { abortOnError = false }` is set in `app/build.gradle.kts`, so **lint can
never fail this build**. Treat a green `assembleRelease` as saying nothing about
lint.

Only `lintVitalRelease` runs automatically, and only because `assembleRelease`
triggers it — that is the fatal-severity subset, not full lint. Running
`./gradlew lint` produces `app/build/reports/lint-results-release.html`.

## Release signing

### The delivered tree has no release keystore — on purpose

`novtales-release.jks` and `keystore.properties` are **not** in this delivery,
in the source ZIP, or in the repository. That is deliberate: the private key must
never be published, and the certificate digest in `docs/TEST_REPORT.md` is the
only thing a reviewer needs in order to verify who signed the shipped APK.

**Consequence: on a clean checkout, `assembleRelease` now FAILS.** That is
intended, and the failure is loud. `app/build.gradle.kts` throws a
`GradleException` naming the missing file and printing the `keytool` command to
create one.

### Why it fails instead of falling back

This is worth understanding, because it was a real defect. The build used to
fall back to the debug signing config when `keystore.properties` was absent, so
that "a build always succeeds". An audit of the delivered tree reproduced what
that produced:

* `assembleRelease` → `BUILD SUCCESSFUL`
* `apksigner verify` → `Verifies`
* `aapt2 dump badging` → correct package, version and SDK levels
* the signing certificate → **`CN=Android Debug`, `752e16af…`** instead of the
  release `b8643bc4…`

Every signal available to an automated check said the APK was fine. It is not:
a debug-signed APK **cannot update an existing installation**. Installing it over
a real release requires an uninstall first, which loses the user's app data, and
nothing in the output says so. Failing loudly is the only safe behaviour for an
artefact meant to be distributed.

### What to do instead

| You want | Run | Result |
|---|---|---|
| A build you can install and test locally | `gradlew assembleDebug` | Works without any keystore. **Never distribute it.** |
| A distributable release APK | create the identity below first, then `gradlew assembleRelease` | Signed with the stable release identity |
| The already-built release APK | use `dist/NovTales-Companion-0.1.0.apk` | Signed `b8643bc4…`, verified in `docs/TEST_REPORT.md` §2 |

### Creating a new identity

```sh
keytool -genkeypair -v -keystore novtales-release.jks -alias novtales \
        -keyalg RSA -keysize 4096 -validity 10950
```

then write `keystore.properties`:

```properties
storeFile=novtales-release.jks
storePassword=…
keyAlias=novtales
keyPassword=…
```

Note: PKCS12 keystores ignore a separate key password. Set `keyPassword` equal to
`storePassword`.

**Keep the keystore.** Without it, a later APK cannot update an installed copy.

### Checking you did not ship a debug-signed APK

The failure above produced a build that *verified*. Check the certificate
digest, not the exit code:

```sh
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --print-certs <apk>
# Signer #1 certificate SHA-256 digest: b8643bc425e4d4f3d387e91af74c0c940a9a6a14fb8eb7344d69a6b83ac38890
```

Any other digest means it is not the release identity.

## Building in a sandboxed environment

`build.ps1` at the **repository root** (one level above this file) is a
convenience wrapper for the sandbox this was developed in, where `%TEMP%`,
`%USERPROFILE%` and the Android user home are not writable. It redirects
`GRADLE_USER_HOME`, `TEMP`/`TMP` and `ANDROID_USER_HOME` into `_working/`, and
resolves a JDK rather than assuming one.

It runs the **committed wrapper** — `novtales-companion\gradlew.bat` — exactly as
this document recommends. Only if that wrapper is missing does it fall back to
the downloaded distribution under `tools/gradle-dist/gradle-8.9\bin\gradle.bat`,
and it prints a loud warning when it does. That fallback directory is **not** in
the delivery, so the fallback cannot work on a clean checkout.

On a normal developer machine use `gradlew.bat` directly; none of the
redirection is required. Pass `-NoRedirect` to `build.ps1` to keep the ambient
environment instead.

`gradle.properties` also sets `org.gradle.vfs.watch=false`, because Gradle's
native file watcher cannot open a thread there.

## Repository layout

```
novtales-companion/
├── app/src/main/kotlin/com/sadloif/novtalescompanion/
│   ├── core/       shared primitives: Config, Errors, Json, Paths, Job, PairingKey
│   ├── api/        loopback HTTP server, routing, job runner
│   ├── web/        WebView worker, page adapter, chapter completion, sanitising
│   ├── service/    foreground service, notification, service controller
│   ├── state/      shared observable state
│   └── ui/         status screen
├── app/src/main/assets/adapter/   injected page script
├── app/src/test/   JVM unit tests
├── docs/           API.md, BUILD.md, TEST_REPORT.md, DEVIATIONS.md
└── gradle/wrapper/ committed Gradle 8.9 wrapper
```

`core/` is the shared spine that every other package depends on. Reviewing
`core/Paths.kt` and `core/PairingKey.kt` is the fastest way to understand what the
companion will and will not accept.

## Verifying a build

```sh
./gradlew test assembleRelease

# stage the shipped artefact
cp app/build/outputs/apk/release/app-release.apk ../dist/NovTales-Companion-0.1.0.apk

$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose --print-certs \
    ../dist/NovTales-Companion-0.1.0.apk
```

Expect:

```
Verified using v1 scheme (JAR signing): false
Verified using v2 scheme (APK Signature Scheme v2): true
Verified using v3 scheme (APK Signature Scheme v3): true
```

### The v1 line is not what it looks like

`apksigner` takes its min-SDK from the APK manifest. At **minSdk 26** the v1/JAR
scheme is unnecessary, so apksigner **skips the check** and prints `false` —
whether or not v1 was actually applied. Read it as *"not required"*, never as
*"not present"*.

This build sets `enableV1Signing = true` in `app/build.gradle.kts`, and the APK
does contain `META-INF/MANIFEST.MF`, `META-INF/CERT.SF` and `META-INF/CERT.RSA`.
To actually prove it, force the check by claiming an older min-SDK:

```sh
apksigner verify --verbose --min-sdk-version 23 ../dist/NovTales-Companion-0.1.0.apk
#   Verified using v1 scheme (JAR signing): true
```

`scripts/release-evidence.ps1` performs both runs and reports which applies.

### The published digest is NOT re-derivable by rebuilding

This matters for anyone auditing the artefact, so it is worth being precise.

Three consecutive rebuilds from the delivered tree produced an **identical**
SHA-256, and a byte-level comparison found that **all 385 zip entries are
identical** — `classes.dex`, `resources.arsc`, the manifest, the assets, and the
v1 JAR signature. The v2 and v3 signature blocks are identical too.

The **only** differing bytes are 3,018 of them, inside one auxiliary
signing-block pair (`0x504b4453`, "PKDS" — the APK Signing Block's source-stamp
region). That region is not part of the signed content.

So the build is:

* **content-reproducible** — every entry in the archive is byte-identical;
* **cryptographically equivalent** — the v1/v2/v3 signatures are identical;
* **but not bit-reproducible** — the overall ZIP digest therefore cannot be
  re-derived by rebuilding from source.

`docs/TEST_REPORT.md` records the digest of the **shipped** APK. To verify that
one artefact, hash the file you were given. Do not expect a rebuild to produce
the same digest, and do not treat a differing digest as evidence of tampering
without first comparing the 385 entries entry by entry.

Record the APK SHA-256 and the certificate SHA-256 digest in the release notes:

```sh
shasum -a 256 ../dist/NovTales-Companion-0.1.0.apk
```

### 385 entries, not 382 — a false alarm to ignore

The APK contains `res/9N.9.png` and `res/9n.9.png`. They look like a duplicate
pair. They are not: they are **case-differing names**, and there are **385
distinct entries** in the archive.

PowerShell's `Group-Object` is case-insensitive, so piping the entry list
through it reports these two as duplicates and implies a packaging fault. It is
a measurement artefact, not a defect.

## Rebuilding the source ZIP

There is no `.git` in this tree, so the source archive is the source deliverable
required by spec section 13. From the repository root:

```powershell
.\make-source-zip.ps1 -Force
```

It writes `dist/NovTales-Companion-<version>-source.zip`, excluding `_working/`,
`tools/gradle-dist/`, `node_modules/`, every `build/` directory,
`local.properties`, and the signing keystore. It aborts if a `.jks` or
`keystore.properties` ever reaches the staging tree.

## No embedded HTTP server

This project deliberately implements its loopback HTTP server on
`java.net.ServerSocket` with no HTTP dependency. `docs/DEVIATIONS.md` §1 records
the maintenance check that led there — NanoHTTPD 2.3.1, last published
2016-08-12, against Ktor 3.6.0, last published 2026-09-16.