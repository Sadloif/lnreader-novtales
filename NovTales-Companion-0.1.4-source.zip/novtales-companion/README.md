# NovTales Companion

An Android companion app plus an LNReader source plugin for **NovTales**
(`novtales.com`), built to the
[NovTales Android Companion Build Specification](../spec/NovTales_Android_Companion_Build_Specification.md).

LNReader remains the reading app. The companion supplies the browser session and
the data; LNReader keeps its library, downloads, progress, themes and TTS.

> **Current release: companion 0.1.3, plugin 2.1.0.**
> See [the current browsing repair and device report](docs/COMPANION_0.1.3.md).
> Earlier TEST_REPORT.md records describe the initial build; later phone reviews supersede those limits where explicitly verified.

---

## Why this exists

The published NovTales plugin v1.0.4 reports browser verification with HTTP 429,
and retrying from LNReader's own source WebView does not clear it. A public first
chapter loads completely in a normal browser while signed out. The gap is that
the plugin's native requests are not accepted, while a real browser session is.

The companion puts a real Android System WebView in front of the site, on the same
phone, and exposes a small authenticated loopback API. The plugin asks the
companion for data; the companion returns completed results or an explicit error.

```
Official LNReader
  -> NovTales plugin
  -> authenticated API at http://127.0.0.1:5301
  -> companion request queue
  -> companion Android WebView
  -> NovTales website and its own reader scripts
  -> completed data, or an explicit access error
  -> plugin result
  -> LNReader reading view or downloaded chapter storage
```

`127.0.0.1` is the phone itself. No PC, no remote server, no modified LNReader,
no root, no accessibility service, no public scraping proxy.

---

## What is in here

Paths are relative to the **repository root**, one level above this file.

| Path | What it is |
|---|---|
| `novtales-companion/` | Android companion app source (Kotlin) |
| `dist/NovTales-Companion-0.1.0.apk` | **The signed installable APK** |
| `dist/NovTales-Companion-0.1.0-source.zip` | **The source archive** — no `.git` exists (see `docs/DEVIATIONS.md` §7) |
| `lnreader-plugin/` | LNReader TypeScript plugin + compiled JavaScript + manifest |
| `novtales-companion/docs/API.md` | Local API reference |
| `novtales-companion/docs/BUILD.md` | Build and signing instructions |
| `novtales-companion/docs/TEST_REPORT.md` | What was tested, and what was not |
| `novtales-companion/docs/DEVIATIONS.md` | Every departure from the spec, with evidence |
| `CONTRACTS.md` | Internal interfaces, written before parallel implementation |

> Gradle writes the APK to
> `novtales-companion/app/build/outputs/apk/release/app-release.apk`. That path is
> **not** in the delivery — `build/` is a build cache excluded by
> `sync-to-app.ps1`. Install from `dist/` instead.

> ### Rebuilding from this tree
>
> **The delivered tree has no release keystore.** `novtales-release.jks` and
> `keystore.properties` are deliberately not published — the private key must
> never leave the build machine — so **`assembleRelease` fails here, by design.**
>
> That matters because the previous behaviour (silently fall back to the debug
> key) produced an APK that passed every automated check: `BUILD SUCCESSFUL`,
> `apksigner verify` → `Verifies`, correct package name and version. It was signed
> `CN=Android Debug`, and such an APK **cannot update an existing installation** —
> installing it forces an uninstall and loses the user's app data, with nothing
> warning them. The build now throws instead.
>
> * `gradlew.bat assembleDebug` — a local build, no keystore needed. **Never
>   distribute it.**
> * A distributable release requires creating the identity first; see
>   [`docs/BUILD.md`](./docs/BUILD.md).
> * The real release APK is `dist/NovTales-Companion-0.1.0.apk`. Verify the
>   **certificate digest** (`b8643bc4…`), not merely that `apksigner verify`
>   succeeded.
>
> The build is content-reproducible — all 385 zip entries and the v1/v2/v3
> signatures are byte-identical on a rebuild — but not bit-reproducible, so the
> published SHA-256 is not re-derivable by rebuilding.

---

## Setup

1. Install `dist/NovTales-Companion-0.1.0.apk` **alongside** the official
   LNReader app. It does not replace it and does not touch its data.
2. Open **NovTales Companion** and press **Start**. This creates the private
   browser session and the local service.
3. Let NovTales load. If the website shows a verification page, complete it in the
   visible companion browser.
4. Press **Copy pairing key**.
5. In LNReader, open the NovTales plugin settings and paste the key.
6. Open the catalogue and fetch a public chapter.

The companion must be running while **new** content is fetched. It is not needed
to read chapters already saved in LNReader — those open in airplane mode with the
companion stopped.

The local API is plaintext on loopback by design; website traffic stays HTTPS.
Do not bind the companion to a LAN address.

---

## Operating the companion

**Start** / **Stop** · **Open website** · **Copy pairing key** ·
**Reset pairing key** · **Clear website session**

States shown: **Stopped**, **Ready**, **Loading**, **Needs your attention**,
**Error**.

Resetting the pairing key does **not** sign you out of NovTales. Clearing the
website session is a separate, deliberate action.

A persistent notification shows the current state and offers Stop.

### Limits worth knowing

Android 15 caps `dataSync` foreground services (6 hours per 24-hour window). When
that cap is reached the companion stops and pending requests fail with a clear
message rather than hanging. The app is never classified as media playback or any
other unrelated service type, and `specialUse` is deliberately **not** used to
avoid the cap — the reasoning is in [`docs/DEVIATIONS.md`](./docs/DEVIATIONS.md).

ColourOS background restrictions on Oppo devices may stop the companion while
LNReader is in the foreground. This has not yet been measured on the phone and is
an outstanding item in the test report.

---

## Privacy

* Chapter text, cookies, Supabase tokens and browser storage stay inside the
  companion's WebView and are never exported to LNReader.
* The pairing key is stored in private app storage with backup and device transfer
  disabled. It is never written to a URL, a log, or this repository.
* The local API binds to loopback only, requires the key on every endpoint, and
  has no proxy capability whatsoever.

---

## Reviewing this

Spec section 13 suggests an order, and it is a good one:

1. **Local transport** — `api/HttpRequestParser.kt`, `api/LocalApiServer.kt`,
   `core/PairingKey.kt`, `core/Paths.kt`
2. **Foreground service and WebView lifecycle** — `service/CompanionService.kt`,
   `web/WebViewBrowserGateway.kt`
3. **Job isolation and completion checks** — `api/JobRunner.kt`,
   `web/ChapterCompletion.kt`
4. **HTML cleanup** — `web/HtmlSanitiser.kt`
5. **Plugin compatibility** — `lnreader-plugin/plugins/english/novtales.ts`

The final release gate is a successful download and offline reopen in official
LNReader on the user's phone. **That gate has not been passed yet.**