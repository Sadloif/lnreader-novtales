/*
 * A tiny fake DOM with a real (if small) CSS selector engine.
 *
 * `novtales-adapter.js` is plain JavaScript injected into the WebView, so it can
 * be exercised on Node against this instead of a browser. It supports exactly
 * what the adapter uses: `querySelector` / `querySelectorAll` with descendant
 * combinators, comma groups, tag / `#id` / `.class` / `[attr]` /
 * `[attr="v"]` / `[attr*="v"]` / `[attr^="v"]` / `[attr$="v"]` selectors, a
 * `TreeWalker` that honours a `NodeFilter`, and `innerHTML` / `textContent`.
 *
 * Split out of the scratch harness so the tests themselves read as tests.
 * Extracted verbatim from _working/b-harness/adapter-check.js; nothing here was
 * rewritten, so the selector semantics the adapter is tested against are
 * unchanged.
 */
'use strict';

function El(tag, opts) {
  opts = opts || {};
  this.tag = (tag || '').toLowerCase();
  this.attrs = Object.assign({}, opts.attrs);
  this.children = opts.children || [];
  this.text = opts.text || '';
  this.innerHTMLOverride = opts.innerHTML;
  this.parent = null;
  this.children.forEach(function (c) { c.parent = this; }, this);
}
El.prototype.getAttribute = function (n) { return this.attrs[n] === undefined ? null : this.attrs[n]; };
El.prototype.hasAttribute = function (n) { return this.attrs[n] !== undefined; };
El.prototype.getBoundingClientRect = function () { return { width: 100, height: 100 }; };
El.prototype.contains = function (other) {
  if (other === this) return true;
  for (let i = 0; i < this.children.length; i++) if (this.children[i].contains(other)) return true;
  return false;
};
El.prototype.closest = function () { return null; };
El.prototype.click = function () { this.clicked = true; };
Object.defineProperty(El.prototype, 'innerHTML', {
  get: function () {
    if (this.innerHTMLOverride !== undefined) return this.innerHTMLOverride;
    return this.children.map(function (c) { return '<' + c.tag + '>' + (c.text || '') + '</' + c.tag + '>'; }).join('');
  }
});
Object.defineProperty(El.prototype, 'textContent', {
  get: function () {
    return (this.text || '') + this.children.map(function (c) { return c.textContent; }).join('');
  }
});
El.prototype.getElementsByTagName = function (tag) {
  const out = [];
  (function walk(node) {
    node.children.forEach(function (c) {
      if (c.tag === tag.toLowerCase()) out.push(c);
      walk(c);
    });
  })(this);
  return out;
};

/* ---- mini CSS selector engine -------------------------------------------- */

function parseSimple(text) {
  // e.g. 'section[aria-label="Loading chapter"]' or '.nv-chapter-body'
  const out = { tag: null, id: null, classes: [], attrs: [] };
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '#') { i++; let s = i; while (i < text.length && /[\w-]/.test(text[i])) i++; out.id = text.slice(s, i); }
    else if (c === '.') { i++; let s = i; while (i < text.length && /[\w-]/.test(text[i])) i++; out.classes.push(text.slice(s, i)); }
    else if (c === '[') {
      i++; let s = i;
      while (i < text.length && text[i] !== ']') i++;
      const body = text.slice(s, i); i++;
      const eq = body.indexOf('=');
      if (eq < 0) out.attrs.push({ name: body.trim(), op: null, value: null });
      else {
        const name = body.slice(0, eq).trim();
        let op = '=', value = body.slice(eq + 1).trim();
        if (value.startsWith('*=')) { op = '*='; value = value.slice(2); }
        else if (value.startsWith('^=')) { op = '^='; value = value.slice(2); }
        else if (value.startsWith('$=')) { op = '$='; value = value.slice(2); }
        out.attrs.push({ name: name, op: op, value: value.replace(/^["']|["']$/g, '') });
      }
    } else if (/[\w*]/.test(c)) { let s = i; while (i < text.length && /[\w-]/.test(text[i])) i++; out.tag = text.slice(s, i).toLowerCase(); }
    else i++;
  }
  return out;
}

function matchesSimple(el, simple) {
  if (simple.tag && simple.tag !== '*' && el.tag !== simple.tag) return false;
  if (simple.id && el.getAttribute('id') !== simple.id) return false;
  for (const cls of simple.classes) {
    const value = el.getAttribute('class') || '';
    if (value.split(/\s+/).indexOf(cls) < 0) return false;
  }
  for (const a of simple.attrs) {
    const value = el.getAttribute(a.name);
    if (value === null) return false;
    if (a.op === null) continue;
    if (a.op === '=' && value !== a.value) return false;
    if (a.op === '*=' && value.indexOf(a.value) < 0) return false;
    if (a.op === '^=' && value.indexOf(a.value) !== 0) return false;
    if (a.op === '$=' && !value.endsWith(a.value)) return false;
  }
  return true;
}

function descendants(root) {
  const out = [];
  (function walk(node) {
    node.children.forEach(function (c) { out.push(c); walk(c); });
  })(root);
  return out;
}

function splitSelector(selector) {
  // Split on whitespace, but not inside [...] or quotes, so that
  // section[aria-label="Loading chapter"] survives intact.
  const parts = [];
  let current = '';
  let depth = 0;
  let quote = null;
  for (const ch of selector) {
    if (quote) { current += ch; if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'") { quote = ch; current += ch; continue; }
    if (ch === '[') depth++;
    if (ch === ']') depth--;
    if (/\s/.test(ch) && depth === 0) { if (current) { parts.push(current); current = ''; } continue; }
    current += ch;
  }
  if (current) parts.push(current);
  return parts;
}

function matchesSelector(el, selector) {
  const groups = selector.split(',').map(function (s) { return s.trim(); });
  return groups.some(function (group) {
    const parts = splitSelector(group).map(parseSimple);
    let current = [el];
    for (let i = parts.length - 1; i >= 0; i--) {
      const next = [];
      current.forEach(function (node) {
        if (matchesSimple(node, parts[i])) next.push(node);
      });
      if (i === 0) return next.length > 0;
      const ancestors = [];
      current.forEach(function (node) {
        let p = node.parent;
        while (p) { if (ancestors.indexOf(p) < 0) ancestors.push(p); p = p.parent; }
      });
      current = ancestors;
    }
    return current.length > 0;
  });
}

function makeDocument(root, title) {
  return {
    title: title || '',
    body: new El('body', { children: [root] }),
    querySelector: function (sel) { return this.querySelectorAll(sel)[0] || null; },
    querySelectorAll: function (sel) {
      return descendants(root).filter(function (el) {
        try { return matchesSelector(el, sel); } catch (e) { return false; }
      });
    },
    createTreeWalker: function (r, what, filter) {
      const nodes = [];
      (function walk(node) {
        if (node.text) nodes.push({ nodeValue: node.text, parentNode: node });
        node.children.forEach(walk);
      })(r);
      // Honour a NodeFilter the way a real browser would.
      const accepted = filter && typeof filter.acceptNode === 'function'
        ? nodes.filter(function (n) { return filter.acceptNode(n) !== 2 /* REJECT */; })
        : nodes;
      let i = -1;
      return { nextNode: function () { i++; return i < accepted.length ? accepted[i] : null; } };
    }
  };
}

module.exports = {
  El: El,
  descendants: descendants,
  matchesSelector: matchesSelector,
  matchesSimple: matchesSimple,
  parseSimple: parseSimple,
  makeDocument: makeDocument
};