# JavaScript tests for the injected WebView adapter

`app/src/main/assets/adapter/novtales-adapter.js` is plain JavaScript that the
companion injects into the WebView. It cannot be reached from the Gradle unit
test source set, so it is tested here on Node instead.

## Running

```sh
node adapter.test.js
```

No install step and no dependencies - Node's standard library only. The script
exits `0` when every check passes and `1` otherwise, so it drops straight into
CI.

Expected output ends with:

```
80 passed, 0 failed
```

## What is here

| File | Purpose |
|------|---------|
| `adapter.test.js` | The checks against the real `novtales-adapter.js`. |
| `mini-dom.js` | A small fake DOM plus a CSS selector engine, enough for what the adapter uses (`querySelector`, descendant combinators, `[attr*="v"]`, `TreeWalker` + `NodeFilter`, `innerHTML`, `textContent`). |

## What is covered

1. `__novExtractPayload` - payload extraction from the Next.js flight stream:
   key match, structural fallback, the inline `<script>` `push()` path, decimal
   chapter numbers, and the empty case.
2. `__novChapterState` on a finished chapter - path, heading, chapter number,
   exact end marker, cheap vs. full poll, body length.
3. Negative markers - browser verification, plain 429 copy, sign-in prompt,
   pay wall, and the guarantee that chapter *prose* can never fake any of them.
4. Marker matching - `End of Chapter 10` must never be truncated to
   `End of Chapter 1`.
5. Still loading.
6. The end marker is never read from a subtree the sanitiser deletes, nor from a
   hidden one.
7. The two copies of the drop-subtree rule -
   `SANITISER_DROP_TAGS` here and `DROP_SUBTREE_TAGS` in `HtmlSanitiser.kt` -
   declare the same tags. They are kept in step by hand, so section 8 compares
   the two declarations and pins that the comparison can actually fail.

## Regressions these pin

- **`scanBalanced` double-advance.** The balanced-value scanner advanced twice
  on a boundary, so the extracted value came back one token late. Pinned by
  *"the scan stopped at the novel object, not one brace late"* and *"braces
  inside the synopsis did not end the value early"*.
- **Marker number truncation.** `End of Chapter 10` was matched as chapter `1`.
  Pinned in section 4.
- **Marker inside a deleted subtree.** A preview whose only end marker sat in a
  `<script>`/hidden container was stored as a complete chapter. Pinned in
  sections 6 and 8.

Both fixes live in `main/`, so the adapter itself is not covered by
`./gradlew test`; these Node checks are the only regression net for it.