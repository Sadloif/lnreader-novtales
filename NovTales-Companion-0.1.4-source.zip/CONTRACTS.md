# NovTales Companion — internal contracts

**This is the contract, not a suggestion.** Five subagents work in parallel against
this file. Anything not fixed here is theirs to design; anything fixed here must
be used exactly as written or the pieces will not compose.

Project root: `E:\Deepseek\Builds\NovTales-Companion\novtales-companion`
Package root: `com.sadloif.novtalescompanion`
Source root: `app/src/main/kotlin/com/sadloif/novtalescompanion/`

---

## 0. Already written — DO NOT REWRITE

These files exist and are final. Read them, use them, extend around them.

| File | Provides |
|---|---|
| `core/Config.kt` | `Config` object: port, deadlines, queue bounds, size caps, host |
| `core/Errors.kt` | `ErrorCode` enum, `CompanionException` |
| `core/Json.kt` | `Json` sealed interface, `jsonObject(...)`, `Json.parse/write` |
| `core/Paths.kt` | `Paths.normalise/isNovel/isChapter/novelSlug/chapterNumber/isSameChapter` |
| `core/Job.kt` | `Operation`, `JobState`, `JobRequest`, `Job`, `ApiError`, `JobStore` |
| `core/PairingKey.kt` | `PairingKey.generate/rotate/getOrCreate/verify` |

### Key signatures you must code against

```kotlin
// core/Paths.kt
object Paths {
    fun normalise(input: String): String?        // null == reject. Absolute URL, path, or path+query.
    fun isNovel(path: String): Boolean           // "/novel/{slug}"
    fun isChapter(path: String): Boolean         // "/chapter/{slug}-{number}", decimals allowed
    fun novelSlug(path: String): String?
    fun chapterSlug(path: String): String?
    fun chapterNumber(path: String): String?     // "12" or "12.5" - never "12.0"
    fun isSameChapter(requested: String, delivered: String): Boolean
}

// core/Job.kt
enum class Operation(val wireName: String) { CATALOGUE, SEARCH, NOVEL, CHAPTERS, CHAPTER }

data class JobRequest(
    val operation: Operation,
    val path: String? = null,
    val page: Int? = null,
    val sort: String? = null,
    val query: String? = null,
) { val collapseKey: String }

class Job(val id: String, val request: JobRequest, val createdAt: Long, clock: () -> Long) {
    val state: JobState
    var result: Json?          private set
    var error: ApiError?       private set
    var attempt: Int           private set   // identity token for async callbacks
    var waiterCount: Int
    fun begin(): Boolean                      // QUEUED -> LOADING, bumps attempt
    fun transitionTo(JobState): Boolean
    fun complete(Json): Boolean
    fun fail(ApiError): Boolean
    fun cancel(): Boolean
    fun hasExceededQueueWait(maxWaitMs: Long): Boolean
    fun hasExceededDeadline(deadlineMs: Long): Boolean
    fun onChange(() -> Unit)
    fun toResponse(apiVersion: Int): Json
}

data class ApiError(
    val code: ErrorCode, val message: String,
    val retryable: Boolean = code.retryable, val retryAfterMs: Long? = null,
) {
    fun toJson(): Json
    companion object {
        fun from(CompanionException): ApiError
        fun of(code: ErrorCode, message: String, retryAfterMs: Long? = null): ApiError
    }
}

class JobStore(clock: () -> Long, maxRetained: Int = 64) {
    fun put(Job): Job
    fun get(id: String): Job?
    fun remove(id: String): Job?
    fun all(): Collection<Job>
    fun queuedCount(): Int
    fun activeCount(): Int
    fun sweep(retentionMs: Long): List<Job>
}

// core/PairingKey.kt
object PairingKey {
    fun generate(): String
    fun getOrCreate(context: Context): String
    fun rotate(context: Context): String
    fun verify(expected: String, supplied: String?): CompanionException?  // null == OK
    fun constantTimeEquals(a: String, b: String): Boolean
}

// core/Json.kt
sealed interface Json { ... }
fun jsonObject(vararg pairs: Pair<String, Any?>): Json.Obj
```

`jsonObject` accepts `null`, `Json`, `String`, `Boolean`, `Int`, `Long`, `Double`,
`List<*>`. Whole numbers serialise without a `.0`.

---

## 1. Threading rules (applies to everyone)

- The `WebView` is created, used and destroyed **on the Android main thread only**.
- Socket handling, JSON parsing of responses, HTML sanitising and the job queue run
  **off** the main thread.
- Exactly one `WebView` operation is active at a time. Everything else waits in a
  bounded queue.
- Never block the main thread on a socket, a job, or a latch.

---

## 2. Ownership map

Subagent **A** owns `api/**` and `net/**`.
Subagent **B** owns `web/**` and `app/src/main/assets/adapter/**`.
Subagent **C** owns `ui/**`, `service/**`, `state/**`, `app/src/main/res/layout/**`,
`app/src/main/res/drawable/**` (non-launcher).
Subagent **E** owns `app/src/test/**`.
Nobody edits `core/**` — if you need a change there, report it instead.

### The seam between A, B and C

```kotlin
// core-owned? No - DEFINED HERE, IMPLEMENTED BY B, CONSUMED BY A.
// File: web/BrowserGateway.kt   (Subagent B writes this file)

interface BrowserGateway {

    /** Readiness, shown on the status screen and returned by GET /v1/health. */
    val readiness: Readiness

    /**
     * Submits one operation and suspends until it settles.
     *
     * Implementations must:
     *  - verify the operation is one of the five and that its path is already
     *    normalised by Paths.normalise;
     *  - never return a partial result - only a complete one;
     *  - throw CompanionException with a specific ErrorCode on every failure;
     *  - return a `needs_user` outcome by throwing
     *    CompanionException(ErrorCode.VERIFICATION_REQUIRED | SIGN_IN_REQUIRED |
     *    MEMBERSHIP_REQUIRED, ...).
     */
    suspend fun execute(request: JobRequest, deadlineMs: Long): Json

    /** Cancels whatever is in flight. Pending jobs are failed by the caller. */
    fun cancelActive()

    /** Sign-out, session reset and account change must clear identity-sensitive state. */
    fun onSessionCleared()
}

enum class Readiness { STOPPED, READY, LOADING, NEEDS_ATTENTION, ERROR }

// File: web/BrowserGatewayFactory.kt  (Subagent B writes this file)
// Returns null when the Android runtime is unavailable, which keeps the HTTP
// server unit-testable on the JVM.
fun interface BrowserGatewayFactory {
    fun create(context: Context): BrowserGateway?
}
```

Subagent **A** depends only on the `BrowserGateway` interface above, so A can be
written and tested before B is finished. A must construct it through an injected
`BrowserGatewayFactory` and must never reference a concrete WebView class.

---

## 3. Result shapes (Subagent B produces, Subagent A and the plugin consume)

Spec section 8. These are the exact JSON shapes returned inside `result`.

```jsonc
// operation "catalogue" and "search"
{
  "items": [ { "name": "Title", "path": "/novel/slug", "cover": "https://..." } ],
  "page": 1,
  "hasNext": true
}

// operation "novel"
{
  "name": "Title", "path": "/novel/slug", "cover": "https://...",
  "summary": "...", "author": "...", "genres": "Action, Drama",
  "status": "Ongoing", "rating": 4.5,
  "chapters": [], "totalPages": 12
}

// operation "chapters"
{ "chapters": [ { "name": "...", "path": "/chapter/slug-1", "chapterNumber": 1,
                  "releaseTime": "..." } ] }

// operation "chapter"
{
  "path": "/chapter/surviving-the-game-as-a-barbarian-1",
  "chapterNumber": 1,
  "complete": true,
  "content": "<p>Complete example chapter text.</p>"
}
```

Rules that are not negotiable:

- `chapters` is **ascending** by `chapterNumber` (the website paginates
  newest-first; the adapter translates).
- Paths are relative (`/novel/...`, `/chapter/...`), never absolute URLs.
- Decimal chapter numbers keep their exact form: `12.5`, never `12.50`, never `12`.
- Chapters are de-duplicated by `path`.
- `genres` is a comma-separated **string**, not an array.
- `rating` is a number out of five, or omitted when the site does not give one.
- `status` is one of `Ongoing`, `Completed`, `OnHiatus`, `Cancelled`, `Unknown`.
- Nothing is invented. If the site does not expose it, omit it — do not guess a
  popularity score, a rating, or a release date.

---

## 4. Completion rule for chapters (spec section 9)

A chapter is complete **only** when all of these hold:

1. An exact `End of Chapter N` marker is present in the article, where `N` equals
   the requested number.
2. The chapter metadata identifies the same slug and number that was requested.
3. `.nv-chapter-body` is non-empty after sanitising.

Character count, a 200 response, a spinner disappearing, or a non-empty preview are
**all insufficient**. If the marker is missing, fail with
`ErrorCode.INCOMPLETE_CHAPTER`. Never set `complete: true` to make a download look
successful.

---

## 5. Error mapping (Subagent B classifies, A serialises)

| Situation | ErrorCode |
|---|---|
| Site showed a browser-verification page (verified marker only) | `VERIFICATION_REQUIRED` |
| Site demanded an account | `SIGN_IN_REQUIRED` |
| Site reported a paid/locked delivery | `MEMBERSHIP_REQUIRED` |
| Genuine HTTP 429, or the site's own rate signal | `RATE_LIMITED` |
| Deadline elapsed | `TIMEOUT` |
| Rendering finished but no completion marker | `INCOMPLETE_CHAPTER` |
| Delivered chapter is not the one requested | `WRONG_CHAPTER` |
| Parsers found nothing the adapter recognises | `SITE_CHANGED` |

An HTTP 429 **alone** is never `VERIFICATION_REQUIRED` (spec section 10). Do not
claim a TLS cause.

---

## 6. HTML sanitising (Subagent B, in `web/HtmlSanitiser.kt`)

Remove: `script`, `style`, `noscript`, `iframe`, `object`, `embed`, `form`,
`input`, `button`, `select`, `textarea`, every `on*` attribute, every `href`/`src`
with a `javascript:`/`data:`/`vbscript:` scheme, hidden elements
(`hidden`, `aria-hidden="true"`, `display:none`, `visibility:hidden`), tracking
pixels (`width`/`height` <= 1), and `data-security-canary` links.

Keep: `p`, `br`, `em`, `strong`, `i`, `b`, `u`, `blockquote`, `h1`-`h6`, `ul`,
`ol`, `li`, `hr`, `img`, `span`, `div`, and the scene-break markers the reader
needs.

Resolve relative `img` sources against `https://novtales.com` and drop any that
remain relative, are not `http(s)`, or are not `img`-like extensions.

---

## 7. Security invariants (Subagent A — spec section 11)

- `ServerSocket` must be bound to `Config.LOOPBACK_HOST` **only**. Never
  `0.0.0.0`. Assert the bind address before accepting.
- `POST /v1/jobs` authenticates **before** validating or enqueuing anything.
- `MessageDigest.isEqual` for key comparison, via `PairingKey.verify`.
- Request line + headers <= `Config.MAX_HEADER_BYTES`. Body <=
  `Config.MAX_REQUEST_BODY_BYTES`. Response <= `Config.MAX_RESPONSE_BYTES`.
  Exceed any of them and answer 413/431 and close; never buffer unbounded input.
- Only the five operations. Only `Paths.normalise`d paths. No query, fragment,
  traversal, double encoding, or absolute non-novtales URL may reach the worker.
- There is no proxy behaviour of any kind: no CONNECT, no forwarding, no
  user-supplied destination. The server never opens an outbound socket.
- Never log the pairing key, cookies, or chapter text.

---

## 8. Plugin contract (Subagent D, separate deliverable)

The plugin lives outside the APK at
`E:\Deepseek\Builds\NovTales-Companion\lnreader-plugin\`, in the shape the official
plugin repository expects.

- Plugin id stays `novtales`.
- `resolveUrl` points at `https://novtales.com` so the globe action still works.
- It talks to `http://127.0.0.1:5301` with
  `Authorization: Bearer <pairing key>`.
- Only `@libs/fetch`, `@libs/storage`, `@libs/defaultCover`, `@libs/novelStatus`
  and `cheerio` may be imported. **Never invent `@libs/browser`.**
- Never compile a user's key into the plugin; read it from plugin storage at call
  time, because `searchNovels`, `parseNovel`, `parsePage` and `parseChapter` do not
  receive filter options.
- Polls `GET /v1/jobs/{id}` once per second, backing off to two seconds, with a
  bounded total wait.