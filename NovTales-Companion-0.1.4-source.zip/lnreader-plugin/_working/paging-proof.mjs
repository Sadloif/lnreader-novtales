/**
 * Concrete proof that `parsePage(1)` and `parsePage(2)` now return DIFFERENT
 * chapter lists, and that `parseNovel`'s `totalPages` is `ceil(n / 50)`.
 *
 * Loads the committed `plugins/english/novtales.js` through the same
 * `Function('require','module',...)` wrapper the runtime uses, and points it at a
 * fake companion that behaves like the real one: the companion slices the chapter
 * index it crawled to the `page` that was asked for.
 *
 * Run from `lnreader-plugin/`:   node _working/paging-proof.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const code = fs.readFileSync(
  path.join(here, '..', 'plugins', 'english', 'novtales.js'),
  'utf8',
);

const CHAPTER_PAGE_SIZE = 50;
const SLUG = 'surviving-the-game-as-a-barbarian';
const TOTAL = 944; // the verified live novel

const PREFIX = 'novtales_DB_';
const storageMap = new Map([
  [PREFIX + 'companionPairingKey', JSON.stringify({ value: 'proof-key' })],
]);
const storage = {
  set: (k, v) => storageMap.set(PREFIX + k, JSON.stringify({ value: v })),
  get: k => {
    const raw = storageMap.get(PREFIX + k);
    return raw ? JSON.parse(raw).value : undefined;
  },
};

const requests = [];
const fullIndex = Array.from({ length: TOTAL }, (_, i) => {
  const n = i + 1;
  return {
    name: 'Chapter ' + n,
    path: `/chapter/${SLUG}-${n}`,
    chapterNumber: n,
  };
});

/** What `WebViewBrowserGateway.runChapters` returns for `page`. */
const servePage = page => {
  const from = (page - 1) * CHAPTER_PAGE_SIZE;
  return {
    ok: true,
    status: 200,
    json: async () => ({
      apiVersion: 1,
      jobId: 'proof',
      state: 'completed',
      result: {
        chapters: fullIndex.slice(from, from + CHAPTER_PAGE_SIZE),
        chapterCount: fullIndex.length,
        totalPages: Math.ceil(fullIndex.length / CHAPTER_PAGE_SIZE),
      },
    }),
  };
};

const lastBody = () => {
  const posts = requests.filter(r => r.method === 'POST');
  return JSON.parse(posts[posts.length - 1].body);
};

const fetchApi = async (url, init) => {
  requests.push({ url, method: (init && init.method) || 'GET', body: init && init.body });
  if ((init && init.method) === 'POST') {
    return { ok: true, status: 202, json: async () => ({ apiVersion: 1, jobId: 'proof', state: 'queued' }) };
  }
  const body = lastBody();
  if (body.operation === 'chapters') return servePage(body.page);
  if (body.operation === 'novel') {
    return {
      ok: true,
      status: 200,
      json: async () => ({
        apiVersion: 1,
        jobId: 'proof',
        state: 'completed',
        result: {
          name: 'Surviving the Game as a Barbarian',
          path: `/novel/${SLUG}`,
          status: 'OnHiatus',
          rating: 4.42,
          // The WEBSITE's own 12-per-page partition. The plugin must not use it.
          totalPages: 81,
          chapters: [],
        },
      }),
    };
  }
  return { ok: true, status: 200, json: async () => ({ apiVersion: 1, jobId: 'proof', state: 'completed', result: {} }) };
};

const packages = {
  '@libs/fetch': { fetchApi },
  '@libs/defaultCover': { defaultCover: 'cover' },
  '@libs/novelStatus': {
    NovelStatus: { Unknown: 'Unknown', Ongoing: 'Ongoing', Completed: 'Completed', Cancelled: 'Cancelled', OnHiatus: 'On Hiatus' },
  },
  '@libs/filterInputs': { FilterTypes: { TextInput: 'Text' } },
};

const plugin = Function('require', 'module', `const exports = module.exports = {};\n${code}\nreturn exports.default;`)(
  name => (name === '@libs/storage' ? { storage, localStorage: {}, sessionStorage: {} } : packages[name]),
  {},
);

const novelPath = `/novel/${SLUG}`;
const chaptersOf = page => plugin.parsePage(novelPath, page).then(r => r.chapters);

const novel = await plugin.parseNovel(novelPath);
console.log(`novel: ${novel.name}`);
console.log(`totalPages          = ${novel.totalPages}   (ceil(${TOTAL} / ${CHAPTER_PAGE_SIZE}) = ${Math.ceil(TOTAL / CHAPTER_PAGE_SIZE)})`);
console.log(`site said totalPages= 81 (12-per-page) - NOT used`);
console.log('');

const rows = [];
for (const page of ['1', '2', '3', '19']) {
  const list = await chaptersOf(page);
  rows.push({ page, count: list.length, first: list[0].path, last: list[list.length - 1].path });
}
console.log('page  chapters  first chapter                       last chapter');
for (const r of rows) {
  console.log(
    String(r.page).padEnd(5) +
      String(r.count).padEnd(10) +
      String(r.first).padEnd(37) +
      r.last,
  );
}

const p1 = await chaptersOf('1');
const p2 = await chaptersOf('2');
const j1 = JSON.stringify(p1.map(c => c.path));
const j2 = JSON.stringify(p2.map(c => c.path));

console.log('');
console.log('parsePage(1) length =', p1.length, ' parsePage(2) length =', p2.length);
console.log('identical lists?     =', j1 === j2, ' <-- the bug made this true');
console.log('overlap              =', p1.filter(c => p2.some(d => d.path === c.path)).length, 'chapters');
console.log('page 20 (past end)   =', JSON.stringify(await chaptersOf('20')));

const failed = !(novel.totalPages === Math.ceil(TOTAL / CHAPTER_PAGE_SIZE)) || j1 === j2;
console.log('');
console.log(failed ? 'PROOF FAILED' : 'PROOF OK: pages differ, and totalPages = ceil(n / 50)');
process.exitCode = failed ? 1 : 0;