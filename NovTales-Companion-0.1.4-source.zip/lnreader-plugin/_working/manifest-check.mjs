import fs from 'node:fs';

const pretty = fs.readFileSync('plugins.json', 'utf8');
const entries = JSON.parse(pretty);

// Exactly what scripts/build-plugin-manifest.js writes:
//   fs.writeFileSync(jsonMinPath, JSON.stringify(json));
//   fs.writeFileSync(jsonPath,   JSON.stringify(json, null, '\t'));
fs.writeFileSync('plugins.min.json', JSON.stringify(entries));

const raw = fs.readFileSync('plugins.min.json', 'utf8');
const prettyAgain = JSON.stringify(JSON.parse(pretty), null, '\t');
const checks = [
  ['min round-trips to the same data', JSON.stringify(JSON.parse(raw)) === JSON.stringify(entries)],
  ['pretty file is tab-indented', prettyAgain === pretty.trimEnd()],
  ['min has no indentation', !/[\n\t]/.test(raw)],
  ['single entry', entries.length === 1],
  ['key order matches the manifest builder', Object.keys(entries[0]).join(',') === 'id,name,site,lang,version,url,iconUrl'],
  ['id is novtales', entries[0].id === 'novtales'],
  ['version is 2.0.0', entries[0].version === '2.0.0'],
  ['lang is English', entries[0].lang === 'English'],
  ['site is the real website', entries[0].site === 'https://novtales.com'],
  ['url points at the compiled plugin', entries[0].url.endsWith('/plugins/english/novtales.js')],
  ['iconUrl points at the icon', entries[0].iconUrl.endsWith('/icon.png')],
  ['no customJS/customCSS keys (builder omits undefined)', !('customJS' in entries[0]) && !('customCSS' in entries[0])],
];

let failed = 0;
for (const [name, ok] of checks) {
  if (!ok) failed++;
  console.log((ok ? '  ok   ' : '  FAIL ') + name);
}
console.log('\nplugins.min.json:');
console.log(raw);
process.exitCode = failed ? 1 : 0;