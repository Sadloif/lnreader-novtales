// ---------------------------------------------------------------------------
// VERBATIM COPY of E:\Deepseek\Builds\NovTales-Companion\_working\contract2\probe.mjs
// (the independent auditor's 127-assertion probe). The ONLY edit is the one line
// below, which repoints PLUGIN_JS at the plugin this folder ships, instead of the
// E:\CodexData\APP copy. No assertion, mock or threshold has been changed, so its
// 127 passed / 0 failed figure is still the auditor's, not the author's.
// Run: node _working/auditor-probe.mjs
// ---------------------------------------------------------------------------

/**
 * contract2 - independent re-audit of the NovTales Companion <-> LNReader plugin seam.
 *
 * METHOD NOTE: nothing in this file is copied from the plugin author's smoke.mjs.
 * Every mock is generated from the Kotlin server source:
 *
 *   api/HttpConnection.kt  ApiResponse.error  -> the HTTP-level error envelope
 *   core/Job.kt            ApiError.toJson + Job.toResponse -> the job envelope
 *   core/Json.kt           jsonObject/writeJson -> nulls are WRITTEN as `null`,
 *                          whole numbers lose their `.0`
 *   core/Errors.kt         ErrorCode.httpStatus / retryable
 *   web/WebViewBrowserGateway.kt  ChapterPaging.slice/totalPages/pageResult,
 *                          CHAPTER_PAGE_SIZE
 *   api/JobRequestValidator.kt    SORT_ALLOWLIST
 *   core/Config.kt                deadlines, queue bounds, page-adjacent constants
 *   api/JobRunner.kt              TIMEOUT_GRACE_MS, QUEUE_FULL_RETRY_AFTER_MS use
 *
 * The compiled plugins/english/novtales.js is loaded through the same
 * Function('require','module',...) wrapper src/plugins/pluginManager.ts uses,
 * with that file's `packages` map.
 */
import fs from 'node:fs';
import path from 'node:path';

const HERE = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const SERVER = 'E:\\CodexData\\APP\\novtales-companion\\app\\src\\main\\kotlin\\com\\sadloif\\novtalescompanion';
const PLUGIN_JS = 'E:\\Deepseek\\Builds\\NovTales-Companion\\lnreader-plugin\\plugins\\english\\novtales.js';

const code = fs.readFileSync(PLUGIN_JS, 'utf8');
const kotlin = f => fs.readFileSync(path.join(SERVER, f), 'utf8');

/* ========================================================================== */
/* 1. Constants lifted straight out of the Kotlin source                      */
/* ========================================================================== */

const configKt = kotlin('core\\Config.kt');
const jobRunnerKt = kotlin('api\\JobRunner.kt');
const gatewayKt = kotlin('web\\WebViewBrowserGateway.kt');
const errorsKt = kotlin('core\\Errors.kt');
const validatorKt = kotlin('api\\JobRequestValidator.kt');
const httpKt = kotlin('api\\HttpConnection.kt');
const jobKt = kotlin('core\\Job.kt');

const kotlinConst = (src, name) => {
  const m = new RegExp(`const val ${name}\\s*(?::\\s*\\w+)?\\s*=\\s*([0-9_]+)L?`).exec(src);
  if (!m) throw new Error('no Kotlin constant ' + name);
  return Number(m[1].replace(/_/g, ''));
};

const K = {
  PORT: kotlinConst(configKt, 'PORT'),
  API_VERSION: kotlinConst(configKt, 'API_VERSION'),
  MAX_WAITING_JOBS: kotlinConst(configKt, 'MAX_WAITING_JOBS'),
  MAX_QUEUE_WAIT_MS: kotlinConst(configKt, 'MAX_QUEUE_WAIT_MS'),
  METADATA_DEADLINE_MS: kotlinConst(configKt, 'METADATA_DEADLINE_MS'),
  CHAPTER_DEADLINE_MS: kotlinConst(configKt, 'CHAPTER_DEADLINE_MS'),
  QUEUE_FULL_RETRY_AFTER_MS: kotlinConst(configKt, 'QUEUE_FULL_RETRY_AFTER_MS'),
  POLL_FAST_MS: kotlinConst(configKt, 'POLL_FAST_MS'),
  POLL_SLOW_MS: kotlinConst(configKt, 'POLL_SLOW_MS'),
  TIMEOUT_GRACE_MS: kotlinConst(jobRunnerKt, 'TIMEOUT_GRACE_MS'),
  CHAPTER_PAGE_SIZE: kotlinConst(gatewayKt, 'CHAPTER_PAGE_SIZE'),
  SORT_ALLOWLIST: (() => {
    const m = /val SORT_ALLOWLIST[^=]*=\s*setOf\(([^)]*)\)/.exec(validatorKt);
    return m[1].split(',').map(s => s.trim().replace(/"/g, '')).filter(Boolean);
  })(),
  // core/Errors.kt : ErrorCode(httpStatus, retryable)
  ERROR_CODES: (() => {
    const body = errorsKt.slice(errorsKt.indexOf('enum class ErrorCode'));
    const out = {};
    for (const m of body.matchAll(/([A-Z_]+)\((\d+),\s*(true|false)\)/g)) {
      out[m[1]] = { httpStatus: Number(m[2]), retryable: m[3] === 'true' };
    }
    return out;
  })(),
};

/** The plugin's own constants, read out of the compiled artefact. */
const jsConst = name => {
  const m = new RegExp(`var ${name} = ([0-9]+);`).exec(code);
  return m ? Number(m[1]) : undefined;
};
const P = {
  METADATA_BUDGET_MS: jsConst('METADATA_BUDGET_MS'),
  CHAPTER_BUDGET_MS: jsConst('CHAPTER_BUDGET_MS'),
  CHAPTER_PAGE_SIZE: jsConst('CHAPTER_PAGE_SIZE'),
  QUEUE_FULL_RETRIES: jsConst('QUEUE_FULL_RETRIES'),
  QUEUE_FULL_RETRY_AFTER_MS: jsConst('QUEUE_FULL_RETRY_AFTER_MS'),
  POLL_FAST_MS: jsConst('POLL_FAST_MS'),
  POLL_SLOW_MS: jsConst('POLL_SLOW_MS'),
  POLL_FAST_POLLS: jsConst('POLL_FAST_POLLS'),
  API_VERSION: jsConst('COMPANION_API_VERSION'),
};

const jsStringConst = name => {
  const m = new RegExp(`var ${name} = '([^']*)'`).exec(code);
  return m ? m[1] : undefined;
};
const P_STR = {
  SORT_POPULAR: jsStringConst('SORT_POPULAR'),
  SORT_LATEST: jsStringConst('SORT_LATEST'),
  ORIGIN: jsStringConst('COMPANION_ORIGIN'),
};

/* ========================================================================== */
/* 2. Mocks derived from the Kotlin emitters                                   */
/* ========================================================================== */

/**
 * api/HttpConnection.kt ApiResponse.error:
 *   jsonObject("apiVersion" to Config.API_VERSION,
 *              "error"     to error.toJson(),
 *              "retryAfterMs" to error.retryAfterMs)
 * core/Json.kt jsonObject maps a null value to Json.Null, and writeJson writes it
 * as `null` - so the key is ALWAYS present, even when there is no retry hint.
 * core/Job.kt ApiError.toJson always writes all four keys.
 */
const apiErrorHttp = (status, code, message, retryAfterMs = null) => ({
  ok: false,
  status,
  json: async () => ({
    apiVersion: K.API_VERSION,
    error: {
      code,
      message,
      retryable: K.ERROR_CODES[code].retryable,
      retryAfterMs,
    },
    retryAfterMs,
  }),
});

/**
 * core/Job.kt Job.toResponse:
 *   apiVersion, jobId, state, [result], [error], [retryAfterMs]
 * NOTE THE ASYMMETRY: Job.toResponse adds the top-level `retryAfterMs` only when
 * it is non-null (`error?.retryAfterMs?.let { ... }`), whereas ApiResponse.error
 * writes the key with a null. This mock reproduces that exactly.
 */
const jobBody = (state, { result, error, retryAfterMs } = {}) => {
  const b = { apiVersion: K.API_VERSION, jobId: 'job-1', state };
  if (result !== undefined) b.result = result;
  if (error !== undefined) {
    b.error = {
      code: error.code,
      message: error.message,
      retryable: error.retryable,
      retryAfterMs: retryAfterMs === undefined ? null : retryAfterMs,
    };
    if (retryAfterMs !== undefined && retryAfterMs !== null) {
      b.retryAfterMs = retryAfterMs;
    }
  }
  return b;
};
const http200 = body => ({ ok: true, status: 200, json: async () => body });
const http202 = body => ({ ok: true, status: 202, json: async () => body });

/**
 * web/WebViewBrowserGateway.kt ChapterPaging, verbatim arithmetic.
 * The complete ascending, de-duplicated list is `list`; the wire result is the
 * requested 50-wide slice plus the size of the whole novel.
 */
const chapterSlice = (list, page, pageSize = K.CHAPTER_PAGE_SIZE) => {
  if (page < 1 || pageSize < 1) return [];
  const start = (page - 1) * pageSize;
  if (start >= list.length) return [];
  return list.slice(start, start + pageSize);
};
const chapterTotalPages = (count, pageSize = K.CHAPTER_PAGE_SIZE) => {
  if (pageSize < 1) return 1;
  if (count <= 0) return 1;
  return Math.ceil(count / pageSize);
};

/**
 * A companion that speaks the CURRENT server contract: `chapters` returns the
 * requested slice only, plus chapterCount/totalPages for the whole novel.
 */
const makeCompanion = ({ chapters = 0, siteTotalPages = null, slug = 'demo-novel' } = {}) => {
  const list = Array.from({ length: chapters }, (_, i) => ({
    name: 'Chapter ' + (i + 1),
    path: '/chapter/' + slug + '-' + (i + 1),
    chapterNumber: i + 1,
    releaseTime: '2024-01-01',
  }));
  const novelResult = {
    name: slug,
    path: '/novel/' + slug,
    cover: 'https://novtales.com/c.jpg',
    summary: 'A summary.',
    author: 'An Author',
    genres: 'Action, Drama',
    status: 'Ongoing',
    rating: 4.5,
    chapters: [],
  };
  if (siteTotalPages !== null) novelResult.totalPages = siteTotalPages;

  return {
    list,
    listFor(path, page) {
      if (list.length === 0) {
        return {
          chapters: [],
          chapterCount: 0,
          totalPages: 1,
        };
      }
      return {
        chapters: chapterSlice(list, page),
        chapterCount: list.length,
        totalPages: chapterTotalPages(list.length),
      };
    },
    novelResult,
  };
};

/* ========================================================================== */
/* 3. The pluginManager wrapper                                                */
/* ========================================================================== */

const NovelStatus = {
  Unknown: 'Unknown',
  Ongoing: 'Ongoing',
  Completed: 'Completed',
  Cancelled: 'Cancelled',
  OnHiatus: 'On Hiatus',
};
const FilterTypes = { TextInput: 'Text', Picker: 'Picker', Switch: 'Switch' };
const DEFAULT_COVER = 'https://example.invalid/cover.jpg';

class MockStorage {
  constructor(id) {
    this.prefix = id + '_DB_';
    this.db = new Map();
  }
  set(k, v) {
    this.db.set(this.prefix + k, JSON.stringify({ value: v }));
  }
  get(k) {
    const raw = this.db.get(this.prefix + k);
    return raw ? JSON.parse(raw).value : undefined;
  }
}

const storage = new MockStorage('novtales');
const requests = [];
let enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
let nextJob = () => http200(jobBody('completed', { result: {} }));
let offline = false;

const fetchApi = async (url, init) => {
  requests.push({ url, init });
  if (offline) throw new Error('Network request failed');
  if (init && init.method === 'POST') return enqueue(url, init);
  return nextJob(url, init);
};

const packages = {
  '@libs/fetch': { fetchApi },
  '@libs/defaultCover': { defaultCover: DEFAULT_COVER },
  '@libs/novelStatus': { NovelStatus },
  '@libs/filterInputs': { FilterTypes },
};

// src/plugins/pluginManager.ts initPlugin, character for character.
const plugin = Function(
  'require',
  'module',
  `const exports = module.exports = {};
      ${code};
      return exports.default`,
)(name => {
  if (name === '@libs/storage') {
    return { storage, localStorage: {}, sessionStorage: {} };
  }
  if (!(name in packages)) throw new Error('unknown package ' + name);
  return packages[name];
}, {});

/* ========================================================================== */
/* 4. Harness                                                                 */
/* ========================================================================== */

let passed = 0;
let failed = 0;
const failures = [];
const defects = [];
const section = t => console.log('\n=== ' + t + ' ===');

function check(name, cond, detail) {
  if (cond) {
    passed++;
    console.log('  ok   ' + name);
  } else {
    failed++;
    failures.push(name + (detail ? '  ->  ' + detail : ''));
    console.log('  FAIL ' + name + (detail ? '  ->  ' + detail : ''));
  }
}

/**
 * A defect the audit is asserting EXISTS. These do not fail the run: the run's
 * pass/fail measures whether the harness is sound, and these record the seam
 * bugs that were found and still stand.
 */
function defect(name, cond, detail) {
  if (cond) {
    defects.push(name + (detail ? '  ->  ' + detail : ''));
    console.log('  DEFECT CONFIRMED  ' + name + (detail ? '  ->  ' + detail : ''));
  } else {
    console.log('  (not reproduced)  ' + name);
  }
}

async function expectThrow(name, run, pred) {
  try {
    const v = await run();
    check(name, false, 'resolved with ' + JSON.stringify(v).slice(0, 160));
  } catch (e) {
    const ok = pred ? pred(e) : true;
    check(name, ok, ok ? undefined : 'got code=' + e.code + ' retryable=' + e.retryable + ' retryAfterMs=' + e.retryAfterMs + ' msg=' + e.message);
  }
}

const posts = () => requests.filter(r => r.init && r.init.method === 'POST').map(r => JSON.parse(r.init.body));
const lastPost = () => posts()[posts().length - 1];
const reset = () => {
  offline = false;
  requests.length = 0;
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => http200(jobBody('completed', { result: {} }));
};
const noFilters = { showLatestNovels: false, filters: undefined };

/* ========================================================================== */

async function run() {
  /* ---------------------------------------------------------------------- */
  section('0. Constants really are the Kotlin constants');
  console.log('  server:', JSON.stringify(K));
  console.log('  plugin:', JSON.stringify(P), JSON.stringify(P_STR));

  check('port matches', P_STR.ORIGIN === 'http://127.0.0.1:' + K.PORT, P_STR.ORIGIN);
  check('apiVersion matches', P.API_VERSION === K.API_VERSION);
  check(
    'chapter page size is the SAME constant on both sides',
    P.CHAPTER_PAGE_SIZE === K.CHAPTER_PAGE_SIZE,
    'server ' + K.CHAPTER_PAGE_SIZE + ' vs plugin ' + P.CHAPTER_PAGE_SIZE,
  );
  check(
    'sort values are in the validator allowlist',
    K.SORT_ALLOWLIST.includes(P_STR.SORT_POPULAR) && K.SORT_ALLOWLIST.includes(P_STR.SORT_LATEST),
    'allowlist=' + K.SORT_ALLOWLIST.join(','),
  );
  check(
    'plugin poll interval matches Config.POLL_FAST/SLOW',
    P.POLL_FAST_MS === K.POLL_FAST_MS && P.POLL_SLOW_MS === K.POLL_SLOW_MS,
  );
  check(
    'plugin QUEUE_FULL back-off matches Config.QUEUE_FULL_RETRY_AFTER_MS',
    P.QUEUE_FULL_RETRY_AFTER_MS === K.QUEUE_FULL_RETRY_AFTER_MS,
  );

  /* ---------------------------------------------------------------------- */
  section('1. Error envelope, status by status, straight from ApiResponse.error');

  storage.set('companionPairingKey', 'k');
  reset();

  // Every one of these is an ApiResponse.error the server can actually emit.
  const httpCases = [
    ['401', apiErrorHttp(401, 'UNAUTHORIZED', 'That pairing key was not accepted.')],
    ['404', apiErrorHttp(404, 'NOT_FOUND', 'No such endpoint.')],
    // api/HttpConnection.kt codeFor(): 405/411/413/417/431 all map to BAD_REQUEST.
    ['405', apiErrorHttp(405, 'BAD_REQUEST', 'That method is not supported on this endpoint.')],
    ['411', apiErrorHttp(411, 'BAD_REQUEST', 'Content-Length is required for POST /v1/jobs.')],
    ['413', apiErrorHttp(413, 'BAD_REQUEST', 'Request body too large.')],
    ['417', apiErrorHttp(417, 'BAD_REQUEST', 'Expectation failed.')],
    ['431', apiErrorHttp(431, 'BAD_REQUEST', 'Request header fields too large.')],
    ['429 QUEUE_FULL', apiErrorHttp(429, 'QUEUE_FULL', 'busy', K.QUEUE_FULL_RETRY_AFTER_MS)],
    ['429 RATE_LIMITED', apiErrorHttp(429, 'RATE_LIMITED', 'slow down')],
    ['500', apiErrorHttp(500, 'INTERNAL', 'The companion could not complete this request.')],
    ['503', apiErrorHttp(503, 'COMPANION_UNAVAILABLE', 'The companion is not ready to accept requests.')],
    ['402 MEMBERSHIP_REQUIRED', apiErrorHttp(402, 'MEMBERSHIP_REQUIRED', 'Locked.')],
    ['409 VERIFICATION_REQUIRED', apiErrorHttp(409, 'VERIFICATION_REQUIRED', 'verify')],
  ];

  for (const [label, response] of httpCases) {
    const wireCode = JSON.parse(JSON.stringify(response)).ok; // keep lint quiet
    enqueue = () => response;
    const wantCode = (() => {
      const body = { code: '', retryable: null };
      return body;
    })(), unused = wantCode;
    void wireCode;
    void unused;
    const expectedCode = {
      401: 'UNAUTHORIZED',
      404: 'NOT_FOUND',
      405: 'BAD_REQUEST',
      411: 'BAD_REQUEST',
      413: 'BAD_REQUEST',
      417: 'BAD_REQUEST',
      431: 'BAD_REQUEST',
      '429 QUEUE_FULL': 'QUEUE_FULL',
      '429 RATE_LIMITED': 'RATE_LIMITED',
      500: 'INTERNAL',
      503: 'COMPANION_UNAVAILABLE',
      '402 MEMBERSHIP_REQUIRED': 'MEMBERSHIP_REQUIRED',
      '409 VERIFICATION_REQUIRED': 'VERIFICATION_REQUIRED',
    }[label];
    const expectedRetryable = K.ERROR_CODES[expectedCode].retryable;
    await expectThrow(
      'HTTP ' + label + ' surfaces ' + expectedCode + ' (not INTERNAL), retryable=' + expectedRetryable,
      () => plugin.parseNovel('/novel/demo-novel'),
      e => e.code === expectedCode && e.retryable === expectedRetryable,
    );
    if (label === '429 QUEUE_FULL') {
      await expectThrow(
        '429 QUEUE_FULL keeps retryAfterMs=' + K.QUEUE_FULL_RETRY_AFTER_MS + ' from the nested envelope',
        () => plugin.parsePage('/novel/demo-novel', '1'),
        e => e.code === 'QUEUE_FULL' && e.retryAfterMs === K.QUEUE_FULL_RETRY_AFTER_MS,
      );
    }
  }

  // retryAfterMs absent: ApiResponse.error writes the key with null.
  check(
    'the server really does write "retryAfterMs": null, not an absent key',
    JSON.stringify(await apiErrorHttp(404, 'NOT_FOUND', 'x').json()).includes('"retryAfterMs":null'),
  );

  /* ---------------------------------------------------------------------- */
  section('2. Job-level failure (Job.toResponse), including needs_user');

  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => http200(jobBody('failed', {
    error: { code: 'INCOMPLETE_CHAPTER', message: 'no marker', retryable: true },
    retryAfterMs: null,
  }));
  await expectThrow(
    'failed job surfaces INCOMPLETE_CHAPTER, not INTERNAL',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'INCOMPLETE_CHAPTER' && e.retryable === true,
  );

  // Job.toResponse adds a top-level retryAfterMs only when it is non-null.
  nextJob = () => http200(jobBody('failed', {
    error: { code: 'TIMEOUT', message: 'too slow', retryable: true },
    retryAfterMs: K.QUEUE_FULL_RETRY_AFTER_MS,
  }));
  await expectThrow(
    'a job failure carries retryAfterMs at BOTH levels',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'TIMEOUT' && e.retryAfterMs === K.QUEUE_FULL_RETRY_AFTER_MS,
  );
  const jobFailBody = await nextJob().json();
  check(
    'Job.toResponse really emits both levels',
    jobFailBody.error.retryAfterMs === 3000 && jobFailBody.retryAfterMs === 3000,
    JSON.stringify(jobFailBody),
  );

  nextJob = () => http200(jobBody('needs_user', {
    error: { code: 'SIGN_IN_REQUIRED', message: 'sign in', retryable: false },
    retryAfterMs: null,
  }));
  await expectThrow(
    'needs_user is terminal and reports SIGN_IN_REQUIRED',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'SIGN_IN_REQUIRED' && e.retryable === false,
  );

  nextJob = () => http200(jobBody('cancelled'));
  await expectThrow(
    'cancelled is terminal',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'CANCELLED',
  );

  nextJob = () => http200(jobBody('failed'));
  await expectThrow(
    'a failed job with no error object is reported, not silently saved',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'INTERNAL' && /without saying why/.test(e.message),
  );

  nextJob = () => http200(jobBody('completed'));
  await expectThrow(
    'a completed job with NO result is refused',
    () => plugin.parseChapter('/chapter/demo-novel-1'),
    e => e.code === 'INCOMPLETE_CHAPTER',
  );

  /* ---------------------------------------------------------------------- */
  section('3. Is the flat fallback reachable in a way that could mis-parse?');

  // A flat body is what the PRE-FIX companion sent. Assert it is understood ...
  enqueue = () => ({
    ok: false,
    status: 401,
    json: async () => ({ apiVersion: 1, code: 'UNAUTHORIZED', message: 'old', retryable: false, retryAfterMs: null }),
  });
  await expectThrow(
    'flat (pre-fix) envelope is still understood',
    () => plugin.parseNovel('/novel/demo-novel'),
    e => e.code === 'UNAUTHORIZED',
  );

  // ... but a nested body must NEVER be read flat. Construct the adversarial
  // case: nested code A, top-level code B. Nested must win.
  enqueue = () => ({
    ok: false,
    status: 429,
    json: async () => ({
      apiVersion: 1,
      error: { code: 'QUEUE_FULL', message: 'busy', retryable: true, retryAfterMs: 3000 },
      retryAfterMs: 3000,
      code: 'INTERNAL',
      message: 'decoy',
    }),
  });
  await expectThrow(
    'a top-level decoy `code` cannot override the nested one',
    () => plugin.parsePage('/novel/demo-novel', '1'),
    e => e.code === 'QUEUE_FULL' && e.retryable === true && e.retryAfterMs === 3000,
  );

  // And a 2xx that carries a stray `code` must not be treated as an error at all.
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued', code: 'INTERNAL' });
  nextJob = () => http200(jobBody('completed', { result: { items: [{ name: 'x', path: '/novel/a' }] } }));
  const stray = await plugin.popularNovels(1, noFilters);
  check('a stray top-level `code` on a 202 is ignored', Array.isArray(stray) && stray.length === 1);

  // A non-JSON body must not throw out of companionJson.
  enqueue = () => ({ ok: false, status: 502, json: async () => { throw new Error('not json'); } });
  await expectThrow(
    'a non-JSON error body becomes a reported INTERNAL, not a crash',
    () => plugin.parseNovel('/novel/demo-novel'),
    e => e.code === 'INTERNAL' && e.retryable === false,
  );

  /* ---------------------------------------------------------------------- */
  section('4. chapters paging: server slice <-> plugin pages');

  const serve = (comp, opts = {}) => {
    reset();
    enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
    nextJob = () => {
      const b = lastPost();
      if (!b) return http200(jobBody('completed', { result: {} }));
      if (b.operation === 'chapters') return http200(jobBody('completed', { result: comp.listFor(b.path, b.page) }));
      if (b.operation === 'novel') return http200(jobBody('completed', { result: comp.novelResult }));
      return http200(jobBody('completed', { result: {} }));
    };
    return opts;
  };

  const c120 = makeCompanion({ chapters: 120, siteTotalPages: 12 });
  serve(c120);
  const novel = await plugin.parseNovel('/novel/demo-novel');
  check(
    'parseNovel totalPages === the number of pages the server will serve (ceil(120/50)=3)',
    novel.totalPages === 3,
    'got ' + novel.totalPages,
  );
  check('parseNovel makes exactly one chapters job', posts().filter(b => b.operation === 'chapters').length === 1);

  const p1 = await plugin.parsePage('/novel/demo-novel', '1');
  const p2 = await plugin.parsePage('/novel/demo-novel', '2');
  const p3 = await plugin.parsePage('/novel/demo-novel', '3');
  const p4 = await plugin.parsePage('/novel/demo-novel', '4');
  const paths = p => p.chapters.map(c => c.path);
  check('page 1 holds 50', p1.chapters.length === 50);
  check('page 2 holds 50', p2.chapters.length === 50);
  check('page 3 holds the last 20', p3.chapters.length === 20);
  check('page 4 is empty', JSON.stringify(p4) === '{"chapters":[]}');
  check('pages 1 and 2 are different lists', JSON.stringify(paths(p1)) !== JSON.stringify(paths(p2)));
  check('page 1 starts at 1', paths(p1)[0] === '/chapter/demo-novel-1');
  check('page 2 starts at 51', paths(p2)[0] === '/chapter/demo-novel-51');
  check('page 3 ends at 120', paths(p3)[19] === '/chapter/demo-novel-120');
  check(
    'no chapter is repeated across the three pages',
    new Set([...paths(p1), ...paths(p2), ...paths(p3)]).size === 120,
  );

  // Exact multiple, and off-by-one boundaries. Each gets its OWN novel path:
  // the plugin caches per path for 5 minutes, so reusing one path would silently
  // reuse the previous case's cache.
  let caseNo = 0;
  for (const [n, expectPages] of [[50, 1], [51, 2], [100, 2], [101, 3]]) {
    caseNo++;
    const slug = 'boundary-' + n;
    const c = makeCompanion({ chapters: n, siteTotalPages: 99, slug });
    serve(c);
    const nv = await plugin.parseNovel('/novel/' + slug);
    check(
      n + ' chapters -> parseNovel totalPages ' + expectPages,
      nv.totalPages === expectPages,
      'got ' + nv.totalPages,
    );
    const last = await plugin.parsePage('/novel/' + slug, String(expectPages));
    const beyond = await plugin.parsePage('/novel/' + slug, String(expectPages + 1));
    check(
      n + ' chapters: page ' + expectPages + ' has ' + (n - (expectPages - 1) * 50) + ', page ' + (expectPages + 1) + ' empty',
      last.chapters.length === n - (expectPages - 1) * 50 && JSON.stringify(beyond) === '{"chapters":[]}',
      'len ' + last.chapters.length,
    );
  }

  /* ---------------------------------------------------------------------- */
  section('5. Does the plugin actually PAGE, or re-ask for page 1?');

  const c80 = makeCompanion({ chapters: 80, siteTotalPages: 99, slug: 'paged-novel' });
  serve(c80);
  await plugin.parseNovel('/novel/paged-novel');
  requests.length = 0;
  await plugin.parsePage('/novel/paged-novel', '1');
  await plugin.parsePage('/novel/paged-novel', '2');
  const asked = posts().filter(b => b.operation === 'chapters').map(b => b.page);
  check(
    'page 1 was served from parseNovel\'s cache, page 2 cost one job asking for page 2',
    JSON.stringify(asked) === '[2]',
    JSON.stringify(asked),
  );

  /* ---------------------------------------------------------------------- */
  section('5b. chapterLists is bounded at 8; novelPages is not bounded at all');

  check(
    'the artifact deletes chapterLists entries but never novelPages entries',
    /delete\s+(?:this|_this)\.chapterLists\[/.test(code) && !/delete\s+(?:this|_this)\.novelPages\[/.test(code),
  );

  // Novel A: 120 chapters, and the site publishes no chapterTotalPages, so
  // parseNovel leaves novelPages['/novel/a'].totalPages = 1.
  const cA = makeCompanion({ chapters: 120, siteTotalPages: null, slug: 'a' });
  serve(cA);
  const nA = await plugin.parseNovel('/novel/a');
  check('novel A reported totalPages=' + nA.totalPages, nA.totalPages === 3, String(nA.totalPages));

  // Read eight OTHER novels: enough to evict A's chapterLists entry while
  // novelPages['/novel/a'] stays put and stays fresh for its own 5 minutes.
  // The eviction is driven by parseNovel -> chapterPage -> evictChapterCaches.
  for (let i = 1; i <= 8; i++) {
    const c = makeCompanion({ chapters: 60, siteTotalPages: null, slug: 'filler-' + i });
    serve(c);
    await plugin.parseNovel('/novel/filler-' + i);
  }
  check('novel A was pushed out of the bounded chapter cache', nA.totalPages === 3);

  // Go straight to page 2 - no intervening page-1 fetch to repopulate the cache.
  serve(cA);
  requests.length = 0;
  const a2 = await plugin.parsePage('/novel/a', '2');
  const a2Calls = posts().filter(b => b.operation === 'chapters').length;
  console.log('       -> parsePage("/novel/a","2") after eviction served ' + a2.chapters.length +
    ' chapters using ' + a2Calls + ' companion call(s)');
  defect(
    'evicted chapterLists + no site totalPages => page 2 is answered EMPTY with no companion call',
    a2.chapters.length === 0 && a2Calls === 0,
    'chapters 51-120 of novel A are invisible until a fresh parseNovel repopulates the cache',
  );

  /* ---------------------------------------------------------------------- */
  section('6. Cache TTL vs pagination drift (new chapters published)');

  const cN = makeCompanion({ chapters: 60, siteTotalPages: 99, slug: 'drift-novel' });
  serve(cN);
  await plugin.parseNovel('/novel/drift-novel');
  await plugin.parsePage('/novel/drift-novel', '1');
  await plugin.parsePage('/novel/drift-novel', '2');
  requests.length = 0;
  const again = await plugin.parsePage('/novel/drift-novel', '2');
  check('a page inside the TTL costs no companion call', posts().length === 0 && again.chapters.length === 10);

  // Publish 40 more chapters, then re-read inside the TTL.
  const grown = makeCompanion({ chapters: 100, siteTotalPages: 99, slug: 'drift-novel' });
  serve(grown);
  const stillOld = await plugin.parsePage('/novel/drift-novel', '2');
  check(
    'inside the TTL the new chapters are NOT visible (expected, but note it)',
    stillOld.chapters.length === 10,
    'len ' + stillOld.chapters.length,
  );

  /* ---------------------------------------------------------------------- */
  section('7. Fallback when the chapters job cannot be read (site omits totalPages)');

  // The site does NOT expose chapterTotalPages, so the `novel` result has no
  // totalPages key at all - exactly what NovTalesExtraction.novel() emits
  // (`put` skips a null), and what the contract allows.
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') {
      return http200(jobBody('failed', {
        error: { code: 'SITE_CHANGED', message: 'no chapter list', retryable: false },
        retryAfterMs: null,
      }));
    }
    return http200(jobBody('completed', {
      result: { name: 'x', path: '/novel/gone', summary: 's', author: 'a', genres: 'Drama', status: 'Ongoing', chapters: [] },
    }));
  };
  const degraded = await plugin.parseNovel('/novel/gone');
  check(
    'with the site totalPages absent and chapters unreadable, parseNovel still opens',
    typeof degraded.totalPages === 'number' && degraded.totalPages >= 1,
    'totalPages=' + degraded.totalPages,
  );
  console.log('       -> parseNovel reported totalPages = ' + degraded.totalPages +
    ' for a novel that actually has 120 chapters');

  // Now the chapters job works again. What can parsePage actually serve?
  const cGone = makeCompanion({ chapters: 120, siteTotalPages: null, slug: 'gone' });
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: cGone.listFor(b.path, b.page) }));
    return http200(jobBody('completed', { result: cGone.novelResult }));
  };
  const p1g = await plugin.parsePage('/novel/gone', '1');
  const p2g = await plugin.parsePage('/novel/gone', '2');
  const p3g = await plugin.parsePage('/novel/gone', '3');
  const reachable = [...p1g.chapters, ...p2g.chapters, ...p3g.chapters].length;
  console.log('       -> parsePage CAN serve ' + reachable + ' of 120 chapters if asked');
  console.log('       -> but LNReader derives its page list ONCE from parseNovel().totalPages');
  console.log('          (bootstrapService.calculatePages -> Array(totalPages)) so it asks 1..' + degraded.totalPages);
  defect(
    'DEGRADED parseNovel truncates the novel: totalPages=' + degraded.totalPages + ' for a 120-chapter novel',
    degraded.totalPages < 3,
    'reader is told ' + degraded.totalPages + ' page(s); chapters 51-120 are never requested',
  );

  // Same shape, but with a site partition SMALLER than ceil(N/50).
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') {
      return http200(jobBody('failed', {
        error: { code: 'TIMEOUT', message: 'the chapter list timed out', retryable: true },
        retryAfterMs: null,
      }));
    }
    // A site whose chapterTotalPages is 2 (i.e. 60-per-page) for 120 chapters.
    return http200(jobBody('completed', {
      result: { name: 'x', path: '/novel/wide', status: 'Ongoing', genres: 'Drama', chapters: [], totalPages: 2 },
    }));
  };
  const wide = await plugin.parseNovel('/novel/wide');
  const cWide = makeCompanion({ chapters: 120, siteTotalPages: 2, slug: 'wide' });
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: cWide.listFor(b.path, b.page) }));
    return http200(jobBody('completed', { result: cWide.novelResult }));
  };
  const w1 = await plugin.parsePage('/novel/wide', '1');
  const w2 = await plugin.parsePage('/novel/wide', '2');
  const wShown = w1.chapters.length + w2.chapters.length;
  console.log('       -> site totalPages=2 -> plugin reports ' + wide.totalPages +
    ' -> the reader shows ' + wShown + ' of 120 chapters');
  defect(
    'the site partition is used as a page count even though it is a DIFFERENT partition',
    wide.totalPages === 2 && wShown < 120,
    wide.totalPages + ' pages x 50 = ' + wide.totalPages * 50 + ' < 120; the last ' + (120 - wShown) + ' chapters are unreachable',
  );

  /* ---------------------------------------------------------------------- */
  section('8. Mixed version: a companion that PREDATES the paging fix');

  // Old server: `chapters` returns the WHOLE novel for any page, and sends no
  // chapterCount / totalPages. This is the shape the previous audit found.
  const oldServer = (count, slug) => {
    const list = Array.from({ length: count }, (_, i) => ({
      name: 'Chapter ' + (i + 1),
      path: '/chapter/' + slug + '-' + (i + 1),
      chapterNumber: i + 1,
      releaseTime: '2024-01-01',
    }));
    return {
      list,
      chaptersResult: { chapters: list },
      novelResult: { name: slug, path: '/novel/' + slug, status: 'Ongoing', genres: 'Drama', chapters: [], totalPages: Math.ceil(count / 12) },
    };
  };

  const old120 = oldServer(120, 'old-novel');
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: old120.chaptersResult }));
    return http200(jobBody('completed', { result: old120.novelResult }));
  };
  const oldNovel = await plugin.parseNovel('/novel/old-novel');
  console.log('       -> parseNovel totalPages against an old companion: ' + oldNovel.totalPages);
  const o1 = await plugin.parsePage('/novel/old-novel', '1');
  const o2 = await plugin.parsePage('/novel/old-novel', '2');
  const o3 = await plugin.parsePage('/novel/old-novel', '3');
  const oUnion = new Set([...o1.chapters, ...o2.chapters, ...o3.chapters].map(c => c.path));
  const oTotal = o1.chapters.length + o2.chapters.length + o3.chapters.length;
  console.log('       -> page sizes: ' + [o1.chapters.length, o2.chapters.length, o3.chapters.length].join('/') +
    '  distinct chapters across the three pages: ' + oUnion.size);
  console.log('       -> 120 chapters x 10 pages means 1200 chapter entries for 120 chapters');
  defect(
    'OLD COMPANION: every page re-serves the WHOLE novel, so the paging bug survives',
    oTotal > oUnion.size,
    oTotal + ' chapter entries returned for ' + oUnion.size + ' distinct chapters across 3 pages',
  );
  defect(
    'OLD COMPANION: parseNovel still reports the site\'s 12-per-page partition (' + oldNovel.totalPages + ')',
    oldNovel.totalPages === 10,
    '10 pages x 50 = 500 "slots" for a 120-chapter novel; every one of them is refetched in full',
  );

  // The old companion is only reached when the plugin is updated first, which is
  // exactly the upgrade order the task calls out.
  check(
    'the artifact under test is the 2.0.0 plugin that speaks the paging contract',
    plugin.version === '2.0.0' && plugin.id === 'novtales',
  );

  // Old server, flat error envelope, small novel (the flat-envelope case).
  const oldSmall = oldServer(30, 'old-small');
  reset();
  enqueue = () => ({
    ok: false,
    status: 401,
    json: async () => ({ apiVersion: 1, code: 'UNAUTHORIZED', message: 'nope', retryable: false, retryAfterMs: null }),
  });
  nextJob = () => http200(jobBody('completed', { result: oldSmall.novelResult }));
  await expectThrow(
    'OLD COMPANION: flat 401 still reaches the reader as UNAUTHORIZED',
    () => plugin.parseNovel('/novel/old-small'),
    e => e.code === 'UNAUTHORIZED' && /pairing key/i.test(e.message),
  );

  /* ---------------------------------------------------------------------- */
  section('9. hasNext and the other result-shape fields');

  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  // NovTalesExtraction.catalogue() always writes items/page/hasNext.
  nextJob = () => http200(jobBody('completed', {
    result: {
      items: [{ name: 'A', path: '/novel/a', cover: 'https://c/a.jpg' }],
      page: 1,
      hasNext: false,
    },
  }));
  const cat = await plugin.popularNovels(1, noFilters);
  check('catalogue items still come back when hasNext is false', cat.length === 1);
  check(
    'the plugin never reads hasNext (it is not referenced anywhere in the artifact)',
    !/hasNext/.test(code),
    'hasNext appears in the compiled plugin',
  );

  const cc = makeCompanion({ chapters: 3, siteTotalPages: null, slug: 'shape-novel' });
  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: cc.listFor(b.path, b.page) }));
    return http200(jobBody('completed', { result: cc.novelResult }));
  };
  const shaped = await plugin.parseNovel('/novel/shape-novel');
  check('name', shaped.name === 'shape-novel', String(shaped.name));
  check('path', shaped.path === '/novel/shape-novel');
  check('cover', shaped.cover === 'https://novtales.com/c.jpg');
  check('summary', shaped.summary === 'A summary.');
  check('author', shaped.author === 'An Author');
  check('genres is a string', typeof shaped.genres === 'string' && shaped.genres === 'Action, Drama', String(shaped.genres));
  check('status mapped', shaped.status === NovelStatus.Ongoing, String(shaped.status));
  check('rating is a number', shaped.rating === 4.5, String(shaped.rating));
  check('chapters is [] for a paged source', Array.isArray(shaped.chapters) && shaped.chapters.length === 0);
  check('totalPages', shaped.totalPages === 1, String(shaped.totalPages));

  // rating absent -> omitted by the server (`put` skips null)
  const noRating = { ...cc.novelResult };
  delete noRating.rating;
  delete noRating.cover;
  delete noRating.summary;
  delete noRating.author;
  delete noRating.genres;
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: cc.listFor(b.path, b.page) }));
    return http200(jobBody('completed', { result: noRating }));
  };
  const bare = await plugin.parseNovel('/novel/shape-novel');
  check('absent rating stays absent', bare.rating === undefined, String(bare.rating));
  check('absent cover falls back to defaultCover', bare.cover === DEFAULT_COVER);
  check('absent summary stays absent', bare.summary === undefined);
  check('absent author stays absent', bare.author === undefined);
  check('absent genres stays absent', bare.genres === undefined, String(bare.genres));
  check('status is still reported (server always writes it)', typeof bare.status === 'string');

  /* ---------------------------------------------------------------------- */
  section('10. sort is only sent where the validator permits it');

  reset();
  enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  nextJob = () => http200(jobBody('completed', { result: { items: [], page: 1, hasNext: false } }));
  await plugin.popularNovels(1, { showLatestNovels: false, filters: undefined });
  check('popularNovels(false) sends sort=' + P_STR.SORT_POPULAR, lastPost().sort === P_STR.SORT_POPULAR, JSON.stringify(lastPost()));
  await plugin.popularNovels(2, { showLatestNovels: true, filters: undefined });
  check('popularNovels(true) sends sort=' + P_STR.SORT_LATEST, lastPost().sort === P_STR.SORT_LATEST);
  await plugin.popularNovels(3, noFilters);
  check('popularNovels(3) sends page 3', lastPost().page === 3);
  requests.length = 0;
  await plugin.searchNovels('a novel', 1);
  check('searchNovels sends NO sort (the validator would accept one, the plugin does not need it)', lastPost().sort === undefined, JSON.stringify(lastPost()));
  check('searchNovels sends the query and the page', lastPost().query === 'a novel' && lastPost().page === 1);
  requests.length = 0;
  const cS = makeCompanion({ chapters: 1, siteTotalPages: null, slug: 's-novel' });
  nextJob = () => {
    const b = lastPost();
    if (b && b.operation === 'chapters') return http200(jobBody('completed', { result: cS.listFor(b.path, b.page) }));
    return http200(jobBody('completed', { result: cS.novelResult }));
  };
  await plugin.parseNovel('/novel/s-novel');
  const novelPost = posts().find(b => b.operation === 'novel');
  check('novel sends no sort', novelPost.sort === undefined && novelPost.path === '/novel/s-novel' && novelPost.page === undefined, JSON.stringify(novelPost));
  await plugin.parsePage('/novel/s-novel', '1');
  check('chapters sends no sort', lastPost().sort === undefined && lastPost().page === 1, JSON.stringify(lastPost()));
  requests.length = 0;
  nextJob = () => http200(jobBody('completed', { result: { path: '/chapter/s-novel-1', chapterNumber: 1, complete: true, content: '<p>text</p>' } }));
  await plugin.parseChapter('/chapter/s-novel-1');
  check('chapter sends no sort and no page', lastPost().sort === undefined && lastPost().page === undefined, JSON.stringify(lastPost()));

  // An unknown sort must be refused by the server and recovered by the plugin.
  reset();
  let catalogueCalls = 0;
  enqueue = (url, init) => {
    const b = JSON.parse(init.body);
    if (b.operation !== 'catalogue') return http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
    catalogueCalls++;
    if (b.sort) return apiErrorHttp(400, 'BAD_REQUEST', '"sort" must be one of ' + K.SORT_ALLOWLIST.join(', '));
    return http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  };
  nextJob = () => http200(jobBody('completed', { result: { items: [], page: 1, hasNext: false } }));
  await plugin.popularNovels(1, noFilters);
  check('a rejected sort is retried once without it', catalogueCalls === 2 && lastPost().sort === undefined);

  /* ---------------------------------------------------------------------- */
  section('11. parseChapter gate - attacked again');

  reset();
  const good = {
    path: '/chapter/demo-novel-12.5',
    chapterNumber: 12.5,
    complete: true,
    content: '<p>Real chapter text.</p>',
  };
  const serveChapter = result => {
    enqueue = () => http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
    nextJob = () => http200(jobBody('completed', { result }));
  };

  serveChapter(good);
  check('a complete chapter is returned verbatim', (await plugin.parseChapter('/chapter/demo-novel-12.5')) === good.content);

  const bad = [
    ['complete:false', { ...good, complete: false }, 'INCOMPLETE_CHAPTER'],
    ['complete:"true" (string)', { ...good, complete: 'true' }, 'INCOMPLETE_CHAPTER'],
    ['complete:1', { ...good, complete: 1 }, 'INCOMPLETE_CHAPTER'],
    ['complete absent', (() => { const c = { ...good }; delete c.complete; return c; })(), 'INCOMPLETE_CHAPTER'],
    ['complete null', { ...good, complete: null }, 'INCOMPLETE_CHAPTER'],
    ['path of another chapter', { ...good, path: '/chapter/demo-novel-13' }, 'WRONG_CHAPTER'],
    ['path of another novel', { ...good, path: '/chapter/other-novel-12.5' }, 'WRONG_CHAPTER'],
    ['path missing', (() => { const c = { ...good }; delete c.path; return c; })(), 'WRONG_CHAPTER'],
    ['path a novel path', { ...good, path: '/novel/demo-novel' }, 'WRONG_CHAPTER'],
    ['path empty', { ...good, path: '' }, 'WRONG_CHAPTER'],
    ['chapterNumber disagrees with path', { ...good, chapterNumber: 11 }, 'WRONG_CHAPTER'],
    ['chapterNumber NaN', { ...good, chapterNumber: 'NaN' }, 'WRONG_CHAPTER'],
    ['chapterNumber an object', { ...good, chapterNumber: {} }, 'WRONG_CHAPTER'],
    ['content empty', { ...good, content: '' }, 'INCOMPLETE_CHAPTER'],
    ['content whitespace', { ...good, content: '   \n\t ' }, 'INCOMPLETE_CHAPTER'],
    ['content markup only', { ...good, content: '<div><br></div>' }, 'INCOMPLETE_CHAPTER'],
    ['content comments only', { ...good, content: '<!--x-->' }, 'INCOMPLETE_CHAPTER'],
    ['content nbsp only', { ...good, content: '&nbsp;&nbsp;' }, 'INCOMPLETE_CHAPTER'],
    ['content not a string', { ...good, content: { a: 1 } }, 'INCOMPLETE_CHAPTER'],
    ['content null', { ...good, content: null }, 'INCOMPLETE_CHAPTER'],
    ['content an array', { ...good, content: ['<p>x</p>'] }, 'INCOMPLETE_CHAPTER'],
    ['result is a string', 'not an object', 'INCOMPLETE_CHAPTER'],
    ['result is null', null, 'INCOMPLETE_CHAPTER'],
    ['result is an array', [good], 'INCOMPLETE_CHAPTER'],
  ];
  for (const [label, result, wantCode] of bad) {
    serveChapter(result);
    await expectThrow(
      'parseChapter refuses: ' + label + (wantCode ? ' -> ' + wantCode : ' -> INCOMPLETE_CHAPTER'),
      () => plugin.parseChapter('/chapter/demo-novel-12.5'),
      wantCode === undefined ? () => true : e => e.code === wantCode,
    );
  }

  // An absolute novtales.com path is normalised down to the relative form, so it
  // is ACCEPTED. That is tolerance, not a hole: the server never emits absolute
  // paths (CONTRACTS.md 3) and normalisePath is what mirrors Paths.normalise.
  serveChapter({ ...good, path: 'https://novtales.com/chapter/demo-novel-12.5' });
  check(
    'absolute novtales.com path is normalised and accepted (tolerance, not a hole)',
    (await plugin.parseChapter('/chapter/demo-novel-12.5')) === good.content,
  );
  serveChapter({ ...good, path: 'https://evil.example/chapter/demo-novel-12.5' });
  await expectThrow(
    'an absolute path on another host is refused',
    () => plugin.parseChapter('/chapter/demo-novel-12.5'),
    e => e.code === 'WRONG_CHAPTER',
  );

  // chapterNumber absent entirely: only path + complete are checked.
  serveChapter((() => { const c = { ...good }; delete c.chapterNumber; return c; })());
  check(
    'a result with NO chapterNumber is accepted on path+complete alone (a hole, see report)',
    (await plugin.parseChapter('/chapter/demo-novel-12.5')) === good.content,
  );

  // Numerically equal spellings must be accepted (contract requires decimals kept).
  for (const alt of [
    { path: '/chapter/demo-novel-12.50', chapterNumber: 12.5 },
    { path: '/chapter/demo-novel-012.5', chapterNumber: 12.5 },
  ]) {
    serveChapter({ ...good, ...alt });
    check('equivalent spelling ' + alt.path + ' is accepted', (await plugin.parseChapter('/chapter/demo-novel-12.5')) === good.content);
  }
  // 12.5 must NOT satisfy 12
  serveChapter({ ...good, path: '/chapter/demo-novel-12', chapterNumber: 12 });
  await expectThrow(
    '12 is not accepted for a request for 12.5',
    () => plugin.parseChapter('/chapter/demo-novel-12.5'),
    e => e.code === 'WRONG_CHAPTER',
  );
  // Entity-only "content" survives isPlainText: it strips tags, &nbsp; and
  // whitespace, but not other entities.
  serveChapter({ ...good, content: '&amp;' });
  let entityAccepted = false;
  try {
    await plugin.parseChapter('/chapter/demo-novel-12.5');
    entityAccepted = true;
  } catch (e) {
    entityAccepted = false;
  }
  defect(
    'isPlainText does not decode entities, so a body of only "&amp;" counts as text',
    entityAccepted,
    'a body of nothing but HTML entities would be saved as a 5-character chapter',
  );

  /* ---------------------------------------------------------------------- */
  section('12. Timing arithmetic, recomputed from Config.kt + JobRunner.kt');

  const worstMetadata =
    P.QUEUE_FULL_RETRIES * K.QUEUE_FULL_RETRY_AFTER_MS +
    K.MAX_QUEUE_WAIT_MS +
    K.METADATA_DEADLINE_MS +
    K.TIMEOUT_GRACE_MS;
  const worstChapter =
    P.QUEUE_FULL_RETRIES * K.QUEUE_FULL_RETRY_AFTER_MS +
    K.MAX_QUEUE_WAIT_MS +
    K.CHAPTER_DEADLINE_MS +
    K.TIMEOUT_GRACE_MS;

  console.log('  metadata: ' + P.QUEUE_FULL_RETRIES + 'x' + K.QUEUE_FULL_RETRY_AFTER_MS +
    ' + ' + K.MAX_QUEUE_WAIT_MS + ' + ' + K.METADATA_DEADLINE_MS + ' + ' + K.TIMEOUT_GRACE_MS +
    ' = ' + worstMetadata + ' ms  (budget ' + P.METADATA_BUDGET_MS + ')');
  console.log('  chapter : ' + P.QUEUE_FULL_RETRIES + 'x' + K.QUEUE_FULL_RETRY_AFTER_MS +
    ' + ' + K.MAX_QUEUE_WAIT_MS + ' + ' + K.CHAPTER_DEADLINE_MS + ' + ' + K.TIMEOUT_GRACE_MS +
    ' = ' + worstChapter + ' ms  (budget ' + P.CHAPTER_BUDGET_MS + ')');
  check('metadata worst case fits the budget', P.METADATA_BUDGET_MS >= worstMetadata,
    P.METADATA_BUDGET_MS + ' < ' + worstMetadata);
  check('metadata has >= 10s margin', P.METADATA_BUDGET_MS - worstMetadata >= 10000,
    'margin ' + (P.METADATA_BUDGET_MS - worstMetadata));
  check('chapter worst case fits the budget', P.CHAPTER_BUDGET_MS >= worstChapter);
  check('chapter has >= 10s margin', P.CHAPTER_BUDGET_MS - worstChapter >= 10000,
    'margin ' + (P.CHAPTER_BUDGET_MS - worstChapter));

  // Deadline is spent from ONE budget, not recomputed per attempt. In the
  // compiled artifact runJob assigns `deadline` once at generator label 0 and
  // hands the same value to pollJob on every attempt.
  const deadlineAssignments = (code.match(/deadline = Date\.now\(\) \+ budgetMs;/g) || []).length;
  check(
    'the compiled artifact computes the deadline exactly ONCE and hands the same value to pollJob',
    deadlineAssignments === 1 && /pollJob\(jobId, deadline\)/.test(code),
    'assignments=' + deadlineAssignments,
  );

  /* ---------------------------------------------------------------------- */
  section('13. Timing, measured (this takes ~90s)');

  reset();
  let polls = 0;
  enqueue = () => {
    polls++;
    if (polls <= P.QUEUE_FULL_RETRIES) {
      return apiErrorHttp(429, 'QUEUE_FULL', 'busy', K.QUEUE_FULL_RETRY_AFTER_MS);
    }
    return http202({ apiVersion: 1, jobId: 'job-1', state: 'queued' });
  };
  nextJob = () => http200(jobBody('loading'));
  const t0 = Date.now();
  await expectThrow(
    'three QUEUE_FULL retries then a stuck job still times out',
    () => plugin.searchNovels('anything', 1),
    e => e.code === 'TIMEOUT',
  );
  const elapsed = Date.now() - t0;
  // The budget is a wall-clock deadline taken at t0, so total elapsed is the
  // budget whether or not the QUEUE_FULL back-off happened. What separates the
  // two designs is the TOTAL: one shared budget = ~95s, per-attempt = ~380s.
  console.log('  elapsed ' + elapsed + ' ms for 3 QUEUE_FULL retries ('
    + P.QUEUE_FULL_RETRIES + ' x ' + K.QUEUE_FULL_RETRY_AFTER_MS + ' ms of back-off) + one stuck job');
  console.log('  a per-attempt budget would have taken >= '
    + ((P.QUEUE_FULL_RETRIES + 1) * P.METADATA_BUDGET_MS) + ' ms');
  check(
    'the whole thing finished in ONE budget, not one budget per attempt',
    elapsed >= P.METADATA_BUDGET_MS - 2000 && elapsed <= P.METADATA_BUDGET_MS + 5000,
    'elapsed ' + elapsed + ', expected ~' + P.METADATA_BUDGET_MS,
  );
  check(
    'the 9s of QUEUE_FULL back-off came out of that same budget',
    elapsed < (P.QUEUE_FULL_RETRIES + 1) * P.METADATA_BUDGET_MS / 2,
    'elapsed ' + elapsed,
  );
  check('four enqueue attempts total', polls === P.QUEUE_FULL_RETRIES + 1, 'polls=' + polls);

  /* ---------------------------------------------------------------------- */
  console.log('\n' + passed + ' passed, ' + failed + ' failed, ' + defects.length + ' confirmed defects');
  if (defects.length) {
    console.log('\nCONFIRMED DEFECTS (still standing):');
    defects.forEach(d => console.log('  * ' + d));
  }
  if (failed) {
    console.log('\nHARNESS FAILURES (a bug in this probe, not in the seam):');
    failures.forEach(f => console.log('  - ' + f));
    process.exitCode = 1;
  }
}

run().catch(e => {
  console.error(e);
  process.exitCode = 1;
});
