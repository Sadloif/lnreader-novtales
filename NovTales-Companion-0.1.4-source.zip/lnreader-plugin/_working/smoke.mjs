/**
 * Runtime smoke test for the compiled plugins/english/novtales.js.
 *
 * It loads the emitted JavaScript through the same `Function('require','module',...)`
 * wrapper src/plugins/pluginManager.ts uses, with a mock of that file's `packages`
 * map, so what is exercised is the committed artefact rather than the TypeScript.
 *
 * The fake companion answers POST /v1/jobs with a 202 and a job id, then answers
 * GET /v1/jobs/{id} with whatever `nextJob` is set to, which is how each test
 * drives the polling loop.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const code = fs.readFileSync(
  path.join(here, '..', 'plugins', 'english', 'novtales.js'),
  'utf8',
);

const NovelStatus = {
  Unknown: 'Unknown',
  Ongoing: 'Ongoing',
  Completed: 'Completed',
  Cancelled: 'Cancelled',
  OnHiatus: 'On Hiatus',
};

const FilterTypes = {
  TextInput: 'Text',
  Picker: 'Picker',
  CheckboxGroup: 'Checkbox',
  Switch: 'Switch',
  ExcludableCheckboxGroup: 'XCheckbox',
};

const DEFAULT_COVER = 'https://example.invalid/cover.jpg';

class MockStorage {
  constructor(pluginId) {
    this.prefix = pluginId + '_DB_';
    this.db = new Map();
  }
  set(key, value) {
    this.db.set(this.prefix + key, JSON.stringify({ value }));
  }
  get(key) {
    const raw = this.db.get(this.prefix + key);
    return raw ? JSON.parse(raw).value : undefined;
  }
}

const storage = new MockStorage('novtales');

const requests = [];
/** Decides the response to POST /v1/jobs. */
let enqueue = () => accepted();
/** Decides the response to GET /v1/jobs/{id}. */
let nextJob = () => jobCompleted({});
/** Set to make every request fail at the socket level. */
let offline = false;

const fetchApi = async (url, init) => {
  requests.push({ url, init });
  if (offline) throw new Error('Network request failed');
  if (init && init.method === 'POST') return enqueue(url, init);
  return nextJob(url, init);
};

const packages = {
  '@libs/fetch': { fetchApi },
  '@libs/defaultCover': { defaultCover: DEFAULT_COVER },
  '@libs/novelStatus': { NovelStatus },
  '@libs/filterInputs': { FilterTypes },
};

const plugin = Function(
  'require',
  'module',
  `const exports = module.exports = {};\n${code}\nreturn exports.default;`,
)(name => {
  if (name === '@libs/storage') {
    return { storage, localStorage: {}, sessionStorage: {} };
  }
  if (!(name in packages)) throw new Error('unknown package ' + name);
  return packages[name];
}, {});

// ---------------------------------------------------------------------------

const accepted = (jobId = 'job-1') => ({
  ok: true,
  status: 202,
  json: async () => ({ apiVersion: 1, jobId, state: 'queued' }),
});

const jobCompleted = result => ({
  ok: true,
  status: 200,
  json: async () => ({ apiVersion: 1, jobId: 'job-1', state: 'completed', result }),
});

const jobFailed = (code, message, retryable, retryAfterMs) => ({
  ok: true,
  status: 200,
  json: async () => ({
    apiVersion: 1,
    jobId: 'job-1',
    state: 'failed',
    error: { code, message, retryable, retryAfterMs },
  }),
});

/**
 * The HTTP-level failure envelope, exactly as `api/HttpConnection.kt`
 * `ApiResponse.error` writes it:
 *
 *   {"apiVersion":1,"error":{"code":...,"message":...,"retryable":...,
 *    "retryAfterMs":null},"retryAfterMs":null}
 *
 * The structured error is **nested under `error`**, and `retryAfterMs` is
 * repeated at the top level so a client can read it without walking in. The
 * harness used to mock a flat `{apiVersion, code, message}` body, which the
 * server never emits - so 57 green assertions covered a client that read the
 * code flat and collapsed every HTTP failure to INTERNAL.
 *
 * `flatHttpError` below deliberately keeps the wrong shape so the plugin's
 * tolerance of a flat envelope is asserted rather than assumed.
 */
const httpError = (status, code, message, retryable, retryAfterMs) => ({
  ok: false,
  status,
  json: async () => ({
    apiVersion: 1,
    error: {
      code,
      message,
      retryable: !!retryable,
      retryAfterMs: retryAfterMs === undefined ? null : retryAfterMs,
    },
    retryAfterMs: retryAfterMs === undefined ? null : retryAfterMs,
  }),
});

/** The shape the harness used to mock and the server never sends. */
const flatHttpError = (status, code, message, retryable, retryAfterMs) => ({
  ok: false,
  status,
  json: async () => ({
    apiVersion: 1,
    code,
    message,
    retryable: !!retryable,
    retryAfterMs: retryAfterMs === undefined ? null : retryAfterMs,
  }),
});

const last = () => requests[requests.length - 1];

const lastJobBody = () => {
  const posts = requests.filter(r => r.init && r.init.method === 'POST');
  return posts.length ? JSON.parse(posts[posts.length - 1].init.body) : undefined;
};

const jobBodies = () =>
  requests
    .filter(r => r.init && r.init.method === 'POST')
    .map(r => JSON.parse(r.init.body));

const chapterJobs = () => jobBodies().filter(b => b.operation === 'chapters');

const chapterPaths = result => result.chapters.map(c => c.path);

// ---------------------------------------------------------------------------
// A fake companion that speaks the real `chapters` contract
// ---------------------------------------------------------------------------

const CHAPTER_PAGE_SIZE = 50;

/**
 * Serves a novel of `chapters` chapters (default 120) the way the companion
 * does: `chapters` returns **one 50-wide slice of the requested page**, plus the
 * size of the whole novel.
 *
 * Before the fix, `runChapters` ignored `page` and returned all 120 chapters for
 * every request, which is why `parsePage(1)` and `parsePage(2)` were identical.
 * Mirroring that here is what makes the paging assertions below meaningful.
 */
const serveNovel = (slug = 'surviving-the-game', chapters = 120) => {
  const novelPath = '/novel/' + slug;
  const list = Array.from({ length: chapters }, (_, i) => {
    const n = i + 1;
    return {
      name: 'Chapter ' + n,
      path: '/chapter/' + slug + '-' + n,
      chapterNumber: n,
      releaseTime: '2024-01-01',
    };
  });
  const slice = page => {
    const from = (page - 1) * CHAPTER_PAGE_SIZE;
    return {
      chapters: list.slice(from, from + CHAPTER_PAGE_SIZE),
      chapterCount: list.length,
      totalPages: Math.max(1, Math.ceil(list.length / CHAPTER_PAGE_SIZE)),
    };
  };
  enqueue = () => accepted();
  nextJob = () => {
    const body = lastJobBody();
    if (body && body.operation === 'chapters') return jobCompleted(slice(body.page));
    if (body && body.operation === 'novel') {
      // `totalPages` here is the WEBSITE's 12-per-page partition, which is the
      // fallback the plugin must not report when it knows the real count.
      return jobCompleted({
        name: slug,
        path: novelPath,
        totalPages: 12,
        chapters: [],
      });
    }
    return jobCompleted({});
  };
  return novelPath;
};

const makeList = (slug, chapters) =>
  Array.from({ length: chapters }, (_, i) => {
    const n = i + 1;
    return {
      name: 'Chapter ' + n,
      path: '/chapter/' + slug + '-' + n,
      chapterNumber: n,
      releaseTime: '2024-01-01',
    };
  });

const novelMeta = (slug, siteTotalPages) => {
  const novel = {
    name: slug,
    path: '/novel/' + slug,
    status: 'Ongoing',
    genres: 'Drama',
    chapters: [],
  };
  // `NovTalesExtraction.novel()` omits totalPages entirely when the site
  // publishes no `chapterTotalPages`; `put` skips a null.
  if (siteTotalPages !== null && siteTotalPages !== undefined) {
    novel.totalPages = siteTotalPages;
  }
  return novel;
};

/**
 * A companion that refuses the `chapters` job, so `parseNovel` has to take its
 * degraded path. `siteTotalPages` is what the WEBSITE counted, in the site's own
 * 12-per-page partition - pass `null` for the common case where the site
 * publishes no count at all.
 */
const serveUnreadableChapters = (slug, siteTotalPages = null, code = 'SITE_CHANGED') => {
  const novelPath = '/novel/' + slug;
  enqueue = () => accepted();
  nextJob = () => {
    const body = lastJobBody();
    if (body && body.operation === 'chapters') {
      return jobFailed(code, 'The website layout changed.', false);
    }
    return jobCompleted(novelMeta(slug, siteTotalPages));
  };
  return novelPath;
};

/**
 * A conforming companion that sends bare pages and no counts.
 *
 * CONTRACTS.md section 3 gives `chapters` as `{chapters: [...]}` only:
 * `chapterCount` and `totalPages` are additive, so a companion is allowed to omit
 * them. This is the shape the plugin has to page correctly against without ever
 * being told how long the novel is.
 */
const serveCountless = (slug = 'countless-novel', chapters = 120) => {
  const novelPath = '/novel/' + slug;
  const list = makeList(slug, chapters);
  enqueue = () => accepted();
  nextJob = () => {
    const body = lastJobBody();
    if (body && body.operation === 'chapters') {
      const from = (body.page - 1) * CHAPTER_PAGE_SIZE;
      return jobCompleted({
        chapters: list.slice(from, from + CHAPTER_PAGE_SIZE),
      });
    }
    return jobCompleted(novelMeta(slug, null));
  };
  return novelPath;
};

/**
 * A companion from BEFORE the paging fix: `chapters` ignores `page` and re-serves
 * the whole novel, and reports neither `chapterCount` nor `totalPages`. The
 * `novel` result still carries the site's own 12-per-page partition.
 *
 * This is what a user gets who updates the plugin before installing the new APK.
 */
const serveOldCompanion = (slug = 'old-novel', chapters = 120) => {
  const novelPath = '/novel/' + slug;
  const list = makeList(slug, chapters);
  enqueue = () => accepted();
  nextJob = () => {
    const body = lastJobBody();
    if (body && body.operation === 'chapters') {
      // No `page` handling at all: the whole novel, every time.
      return jobCompleted({ chapters: list });
    }
    return jobCompleted(novelMeta(slug, Math.ceil(chapters / 12)));
  };
  return novelPath;
};

let passed = 0;
let failed = 0;

function check(name, condition, detail) {
  if (condition) {
    passed++;
    console.log('  ok   ' + name);
  } else {
    failed++;
    console.log('  FAIL ' + name + (detail ? ' -> ' + detail : ''));
  }
}

async function expectThrow(name, run, predicate, describe) {
  try {
    const value = await run();
    check(name, false, 'resolved with ' + JSON.stringify(value));
  } catch (error) {
    const ok = predicate ? predicate(error) : true;
    check(
      name,
      ok,
      !ok ? describe ? describe(error) : 'wrong error: ' + error.message : undefined,
    );
  }
}

const noFilters = { showLatestNovels: false, filters: undefined };

async function run() {
  offline = false;
  enqueue = () => accepted();
  nextJob = () => jobCompleted({});

  console.log('\n1. Instance identity');
  check('id', plugin.id === 'novtales', plugin.id);
  check('name', plugin.name === 'NovTales', plugin.name);
  check('site', plugin.site === 'https://novtales.com', plugin.site);
  check('version', plugin.version === '2.1.0', plugin.version);
  check(
    'filters declares a Text filter',
    plugin.filters &&
      plugin.filters.pairingKey &&
      plugin.filters.pairingKey.type === 'Text' &&
      typeof plugin.filters.pairingKey.value === 'string',
    JSON.stringify(plugin.filters),
  );
  check(
    'resolveUrl points at the real website',
    plugin.resolveUrl('/chapter/slug-1') === 'https://novtales.com/chapter/slug-1' &&
      plugin.resolveUrl('https://novtales.com/novel/slug') ===
        'https://novtales.com/novel/slug',
  );

  console.log('\n2. No saved pairing key');
  requests.length = 0;
  await expectThrow('popularNovels asks for a key', () =>
    plugin.popularNovels(1, noFilters),
  );
  check('no request was sent without a key', requests.length === 0);

  console.log('\n3. popularNovels persists the filter value, then uses it');
  requests.length = 0;
  nextJob = () =>
    jobCompleted({
      items: [
        { name: 'Surviving the Game', path: '/novel/surviving-the-game', cover: 'https://c/1.jpg' },
        { name: 'Duplicate', path: '/novel/surviving-the-game' },
        { name: 'No cover', path: '/novel/second-novel' },
        { name: 'Bad path', path: 'https://evil.example/x' },
      ],
      page: 1,
      hasNext: true,
    });
  const items = await plugin.popularNovels(1, {
    showLatestNovels: true,
    filters: { pairingKey: { type: 'Text', value: '  secret-pairing-key  ' } },
  });
  check(
    'dedupe and path validation leave two items',
    items.length === 2,
    JSON.stringify(items),
  );
  check('cover falls back to defaultCover', items[1].cover === DEFAULT_COVER);
  check(
    'key was persisted trimmed',
    storage.get('companionPairingKey') === 'secret-pairing-key',
  );
  const enqueueCall = requests[0];
  check('request goes to the loopback companion', enqueueCall.url === 'http://127.0.0.1:5301/v1/jobs', enqueueCall.url);
  check(
    'Authorization header carries the stored key',
    enqueueCall.init.headers.Authorization === 'Bearer secret-pairing-key',
    JSON.stringify(enqueueCall.init.headers),
  );
  check(
    'Content-Type is application/json on POST',
    enqueueCall.init.headers['Content-Type'] === 'application/json' &&
      enqueueCall.init.method === 'POST',
  );
  check(
    'poll also carries Authorization',
    requests[1].init.headers.Authorization === 'Bearer secret-pairing-key' &&
      requests[1].url === 'http://127.0.0.1:5301/v1/jobs/job-1',
    requests[1].url,
  );
  const body = JSON.parse(enqueueCall.init.body);
  check(
    'job body carries operation/page/sort',
    body.operation === 'catalogue' && body.page === 1 && typeof body.sort === 'string',
    JSON.stringify(body),
  );

  console.log('\n4. An empty filter field does not wipe a saved key');
  await plugin.popularNovels(1, {
    showLatestNovels: false,
    filters: { pairingKey: { type: 'Text', value: '' } },
  });
  check('saved key survived', storage.get('companionPairingKey') === 'secret-pairing-key');

  console.log('\n5. parseNovel reads the key from storage, with no filter argument');
  requests.length = 0;
  const novelPath = serveNovel('surviving-the-game', 120);
  const novel = await plugin.parseNovel(novelPath);
  check('path preserved', novel.path === novelPath, novel.path);
  check('genres stay a string', novel.genres === undefined || typeof novel.genres === 'string', String(novel.genres));
  check('status is known', typeof novel.status === 'string', String(novel.status));
  check('rating is a number or absent', novel.rating === undefined || typeof novel.rating === 'number', String(novel.rating));
  check(
    'totalPages is ceil(120 / 50) = 3, not the site\'s own 12',
    novel.totalPages === 3,
    String(novel.totalPages),
  );
  check(
    'chapters empty for a paged source',
    Array.isArray(novel.chapters) && novel.chapters.length === 0,
  );
  check(
    'parseNovel made exactly one chapters job',
    chapterJobs().length === 1,
    JSON.stringify(chapterJobs()),
  );
  check(
    'that one job asked for page 1',
    chapterJobs()[0].page === 1,
    JSON.stringify(chapterJobs()[0]),
  );

  console.log('\n6. parsePage is plugin-side paging, not a mirror of the site');
  requests.length = 0;
  const pageOne = await plugin.parsePage(novelPath, '1');
  const jobsAfterPageOne = chapterJobs().length;
  const pageTwo = await plugin.parsePage(novelPath, '2');
  const pageThree = await plugin.parsePage(novelPath, '3');

  const one = chapterPaths(pageOne);
  const two = chapterPaths(pageTwo);
  const three = chapterPaths(pageThree);

  check(
    'parsePage(1) and parsePage(2) are DIFFERENT lists',
    JSON.stringify(one) !== JSON.stringify(two),
    'both were ' + JSON.stringify(one.slice(0, 3)),
  );
  check('page 1 holds 50 chapters', one.length === 50, 'len ' + one.length);
  check('page 2 holds 50 chapters', two.length === 50, 'len ' + two.length);
  check('the last page holds the 20 that remain', three.length === 20, 'len ' + three.length);
  check('page 1 starts at chapter 1', one[0] === '/chapter/surviving-the-game-1', one[0]);
  check('page 2 starts at chapter 51', two[0] === '/chapter/surviving-the-game-51', two[0]);
  check('page 3 ends at chapter 120', three[19] === '/chapter/surviving-the-game-120', three[19]);

  const overlapping = one.filter(p => two.includes(p));
  check('page 2 repeats nothing from page 1', overlapping.length === 0, JSON.stringify(overlapping));
  const union = new Set([...one, ...two, ...three]);
  check('the three pages cover the novel exactly once', union.size === 120, 'union ' + union.size);
  check(
    'each page is ascending',
    [pageOne, pageTwo, pageThree].every(p =>
      p.chapters.every((c, i) => i === 0 || p.chapters[i - 1].chapterNumber <= c.chapterNumber),
    ),
  );
  check(
    'page 1 was served from the cache parseNovel warmed - no new job',
    jobsAfterPageOne === 0,
    'jobs=' + jobsAfterPageOne,
  );
  check(
    'pages 2 and 3 each cost exactly one chapters job',
    chapterJobs().length === 2 && chapterJobs()[0].page === 2 && chapterJobs()[1].page === 3,
    JSON.stringify(chapterJobs()),
  );

  const beyond = await plugin.parsePage(novelPath, '4');
  check(
    'a page past the end is empty',
    JSON.stringify(beyond) === '{"chapters":[]}',
    JSON.stringify(beyond),
  );
  check(
    'a page past the end costs no companion call',
    chapterJobs().length === 2,
    JSON.stringify(chapterJobs()),
  );

  check(
    'page 1 and page 2 are still different after caching',
    JSON.stringify(chapterPaths(await plugin.parsePage(novelPath, '1'))) !==
      JSON.stringify(chapterPaths(await plugin.parsePage(novelPath, '2'))),
  );

  requests.length = 0;
  const coldPath = serveNovel('a-second-novel', 120);
  const coldOne = await plugin.parsePage(coldPath, '1');
  const coldTwo = await plugin.parsePage(coldPath, '2');
  check(
    'a cold cache fetches page 1 then page 2, in order',
    chapterJobs().map(b => b.page).join(',') === '1,2',
    JSON.stringify(chapterJobs()),
  );
  check(
    'a cold cache still yields two different pages',
    JSON.stringify(chapterPaths(coldOne)) !== JSON.stringify(chapterPaths(coldTwo)),
  );

  console.log('\n6b. Chapters within a page keep their exact shape');
  requests.length = 0;
  nextJob = () => {
    const body = lastJobBody();
    if (body && body.operation === 'chapters') {
      return jobCompleted({
        chapters: [
          { name: 'Twelve and a half', path: '/chapter/decimal-novel-12.5', chapterNumber: 12.5 },
          { name: 'Twelve', path: '/chapter/decimal-novel-12', chapterNumber: 12 },
          { name: 'Duplicate', path: '/chapter/decimal-novel-12', chapterNumber: 12 },
          { name: 'Thirteen', path: '/chapter/decimal-novel-13', chapterNumber: 13 },
        ],
        chapterCount: 3,
        totalPages: 1,
      });
    }
    return jobCompleted({ name: 'x', path: body.path, totalPages: 12, chapters: [] });
  };
  const decimals = await plugin.parsePage('/novel/decimal-novel', '1');
  check(
    'four entries dedupe to three',
    decimals.chapters.length === 3,
    JSON.stringify(decimals.chapters),
  );
  check(
    'decimal chapter path preserved exactly',
    decimals.chapters[1].path === '/chapter/decimal-novel-12.5',
    decimals.chapters[1].path,
  );
  check(
    'decimal chapter number read back out of the path',
    decimals.chapters[1].chapterNumber === 12.5,
    String(decimals.chapters[1].chapterNumber),
  );
  check(
    'ascending despite arriving 12.5 first',
    decimals.chapters.map(c => c.chapterNumber).join(',') === '12,12.5,13',
    decimals.chapters.map(c => c.chapterNumber).join(','),
  );
  check(
    'library paths are unchanged: /novel/{slug} and /chapter/{slug}-{number}',
    (await plugin.resolveUrl('/novel/decimal-novel')) === 'https://novtales.com/novel/decimal-novel' &&
      decimals.chapters.every(c => /^\/chapter\/decimal-novel-\d+(\.\d+)?$/.test(c.path)),
    JSON.stringify(decimals.chapters.map(c => c.path)),
  );

  console.log('\n6c. NovelFire-style single-page setting');
  check('native plugin setting is an opt-in Switch',
    plugin.pluginSettings.singlePage.type === 'Switch' && plugin.pluginSettings.singlePage.value === false);
  storage.set('singlePage', true);
  requests.length = 0;
  const fullPath = serveNovel('barbarian-full-list', 961);
  const full = await plugin.parseNovel(fullPath);
  check('961 chapters are reported on one reader page', full.totalPages === 1 && full.chapters.length === 961);
  check('every chapter path occurs once', new Set(full.chapters.map(c => c.path)).size === 961);
  check('full list includes chapters beyond 50 through 961', full.chapters[50].chapterNumber === 51 && full.chapters[960].chapterNumber === 961);
  check('all chapters have the reader page 1 for database migration', full.chapters.every(c => c.page === '1'));
  check('each companion index page is fetched once in sequence', chapterJobs().map(b => b.page).join(',') === Array.from({ length: 20 }, (_, i) => i + 1).join(','));
  requests.length = 0;
  check('parsePage(1) returns the cached whole list', (await plugin.parsePage(fullPath, '1')).chapters.length === 961 && chapterJobs().length === 0);
  check('single-page mode has no second page', (await plugin.parsePage(fullPath, '2')).chapters.length === 0 && chapterJobs().length === 0);
  storage.set('singlePage', false);
  check('turning the setting off takes effect without reloading the plugin', (await plugin.parsePage(fullPath, '2')).chapters[0].chapterNumber === 51);
  // Clear memory to model a restart; the layout marker must survive in storage.
  delete plugin.chapterLists[fullPath];
  const restoredPages = await plugin.parseNovel(fullPath);
  check('turning it off restores normal metadata pagination', restoredPages.totalPages === 20);
  check('turning it off migrates existing rows back after a restart',
    restoredPages.chapters.length === 961 && restoredPages.chapters[50].page === '2' && restoredPages.chapters[960].page === '20');
  storage.set('singlePage', true);
  const emptyFullPath = serveNovel('empty-full-list', 0);
  check('a confirmed empty novel still has one empty page', (await plugin.parseNovel(emptyFullPath)).chapters.length === 0);
  const coldFullPath = serveNovel('cold-full-list', 120);
  check('a cold parsePage also gathers every page', (await plugin.parsePage(coldFullPath, '1')).chapters.length === 120);
  for (const problem of ['repeated', 'missing', 'changed', 'page-count', 'verification']) {
    const slug = 'full-list-' + problem;
    const brokenPath = serveNovel(slug, 120);
    const healthyReply = nextJob;
    nextJob = (url, init) => {
      const body = lastJobBody();
      if (body.operation === 'chapters' && problem === 'page-count') {
        return jobCompleted({ chapters: makeList(slug, 120).slice((body.page - 1) * 50, body.page * 50), chapterCount: 120, totalPages: 2 });
      }
      if (body.operation === 'chapters' && body.page === 2) {
        if (problem === 'verification') return jobFailed('VERIFICATION_REQUIRED', 'Open the companion.', false);
        const rows = makeList(slug, 120);
        return jobCompleted({
          chapters: problem === 'repeated' ? rows.slice(0, 50) : rows.slice(50, problem === 'missing' ? 99 : 100),
          chapterCount: problem === 'changed' ? 121 : 120,
          totalPages: 3,
        });
      }
      return healthyReply(url, init);
    };
    requests.length = 0;
    await expectThrow('full-list ' + problem + ' is an explicit failure',
      () => plugin.parseNovel(brokenPath), e => e.code === (problem === 'verification' ? 'VERIFICATION_REQUIRED' : 'SITE_CHANGED'));
    check('full-list ' + problem + ' stops before page 3 and drops the snapshot',
      chapterJobs().length === 2 && !plugin.chapterLists[brokenPath]);
    serveNovel(slug, 120);
    check('full-list ' + problem + ' can retry cleanly', (await plugin.parseNovel(brokenPath)).chapters.length === 120);
  }
  storage.set('singlePage', false);

  console.log('\n6d. An unreadable chapter index stays an explicit failure');
  const unreadablePath = serveUnreadableChapters('unreadable-novel', 5);
  await expectThrow('no invented page count after a refused index',
    () => plugin.parseNovel(unreadablePath), e => e.code === 'SITE_CHANGED');

  console.log('\n6e. (b) chapterLists and novelPages are evicted together');
  const aPath = serveNovel('novel-a', 120);
  const a = await plugin.parseNovel(aPath);
  check('novel A knows its real page count first', a.totalPages === 3, String(a.totalPages));
  // Browse nine other novels. That is what pushed A out of the chapter cache
  // while its page-count entry was still fresh and still said "one page".
  for (let i = 1; i <= 9; i++) {
    serveNovel('filler-' + i, 60);
    await plugin.parseNovel('/novel/filler-' + i);
  }
  serveNovel('novel-a', 120);
  requests.length = 0;
  const a2 = await plugin.parsePage(aPath, '2');
  const a2Calls = chapterJobs().length;
  check(
    'page 2 of an EVICTED novel is fetched, not answered empty',
    a2.chapters.length === 50 && a2Calls >= 1,
    'chapters=' + a2.chapters.length + ' calls=' + a2Calls,
  );
  check(
    'and it really is chapters 51-100',
    a2.chapters[0].path === '/chapter/novel-a-51' && a2.chapters[49].path === '/chapter/novel-a-100',
    a2.chapters[0].path,
  );
  check(
    'the compiled artifact prunes novelPages as well as chapterLists',
    /delete (?:this|_this)\.novelPages\[/.test(code) &&
      /delete (?:this|_this)\.chapterLists\[/.test(code),
  );
  // The page-count map is bounded on its own terms too: a novel whose `chapters`
  // job failed is in novelPages and NOT in chapterLists.
  check(
    'a degraded novel still has a bounded page-count entry',
    Object.keys(plugin.novelPages).length <= 8,
    'novelPages holds ' + Object.keys(plugin.novelPages).length,
  );

  console.log('\n6f. Empty pages and broken parsers are different outcomes');
  enqueue = () => accepted();
  nextJob = () => jobCompleted({ items: [], page: 9, hasNext: false });
  check('a confirmed empty catalogue page is empty',
    JSON.stringify(await plugin.popularNovels(9, noFilters)) === '[]');
  nextJob = () => jobFailed('SITE_CHANGED', 'The catalogue layout changed.', false);
  await expectThrow('catalogue layout failures are visible',
    () => plugin.popularNovels(9, noFilters), e => e.code === 'SITE_CHANGED');
  await expectThrow('search layout failures are visible',
    () => plugin.searchNovels('anything', 9), e => e.code === 'SITE_CHANGED');
  // Only SITE_CHANGED is absorbed. A real failure still reaches the reader.
  nextJob = () => jobFailed('INTERNAL', 'boom', false);
  await expectThrow(
    'a real catalogue failure still surfaces',
    () => plugin.popularNovels(1, noFilters),
    e => e.code === 'INTERNAL',
  );
  nextJob = () => jobFailed('VERIFICATION_REQUIRED', 'Open the companion.', false);
  await expectThrow(
    'a browser check on the catalogue still surfaces',
    () => plugin.popularNovels(1, noFilters),
    e => e.code === 'VERIFICATION_REQUIRED',
  );
  // And a broken layout on a page that is not a list still surfaces too, so the
  // reader is not told a chapter list ended when the site really did change.
  nextJob = () => jobFailed('SITE_CHANGED', 'no chapter list', false);
  await expectThrow(
    'SITE_CHANGED from `chapters` is still reported',
    () => plugin.parsePage('/novel/x', '1'),
    e => e.code === 'SITE_CHANGED',
  );

  console.log('\n6g. (d) A body of nothing but entities is not chapter text');
  const entityGate = {
    path: '/chapter/surviving-the-game-12.5',
    chapterNumber: 12.5,
    complete: true,
  };
  const refused = async (content, label) => {
    nextJob = () => jobCompleted(Object.assign({}, entityGate, { content }));
    await expectThrow(
      'refused: ' + label,
      () => plugin.parseChapter(entityGate.path),
      e => e.code === 'INCOMPLETE_CHAPTER',
    );
  };
  await refused('', 'empty');
  await refused('   ', 'whitespace');
  await refused('<div><br></div>', 'markup only');
  await refused('<!--x-->', 'comment only');
  await refused('&nbsp;&nbsp;', 'nbsp only');
  await refused('&amp;', 'a named entity on its own');
  await refused('&mdash;', 'a dash entity on its own');
  await refused('&hellip;', 'an ellipsis entity on its own');
  await refused('&#160;', 'a decimal numeric entity');
  await refused('&#xA0;', 'a hex numeric entity');
  await refused('&#8203;', 'a zero-width space entity');
  await refused('&amp;&mdash;&#160;', 'a mixture of entities');
  await refused('<p>&nbsp;</p>', 'entities inside markup');

  const acceptedBody = async (content, label) => {
    nextJob = () => jobCompleted(Object.assign({}, entityGate, { content }));
    const out = await plugin.parseChapter(entityGate.path);
    check('accepted: ' + label, out === content, out);
  };
  await acceptedBody('<p>Tom &amp; Jerry went home.</p>', 'real words around an entity');
  await acceptedBody('<p>AT&T is a company.</p>', 'a bare ampersand in prose');
  await acceptedBody('第一章', 'text with no entities at all');
  await acceptedBody('<p>5 &gt; 3 &amp;&amp; 2 &lt; 4</p>', 'maths made of entities');

  console.log('\n6h. Mixed version: a NEW plugin against an OLD companion');
  const oldPath = serveOldCompanion('old-novel', 120);
  requests.length = 0;
  const oldNovel = await plugin.parseNovel(oldPath);
  check(
    'parseNovel pages the novel ITSELF instead of the site\'s 12-per-page partition',
    oldNovel.totalPages === 3,
    'totalPages=' + oldNovel.totalPages + ' (the site counted 120 chapters as 10 pages)',
  );
  const o1 = await plugin.parsePage(oldPath, '1');
  const o2 = await plugin.parsePage(oldPath, '2');
  const o3 = await plugin.parsePage(oldPath, '3');
  const oldUnion = [...chapterPaths(o1), ...chapterPaths(o2), ...chapterPaths(o3)];
  check(
    'the three pages are 50 / 50 / 20, not 120 / 120 / 120',
    [o1.chapters.length, o2.chapters.length, o3.chapters.length].join('/') === '50/50/20',
    [o1.chapters.length, o2.chapters.length, o3.chapters.length].join('/'),
  );
  check(
    '300 chapter entries are not returned for 120 chapters',
    oldUnion.length === 120 && new Set(oldUnion).size === 120,
    oldUnion.length + ' entries, ' + new Set(oldUnion).size + ' distinct',
  );
  check(
    'and they are the right ones, in order',
    oldUnion[0] === '/chapter/old-novel-1' &&
      oldUnion[49] === '/chapter/old-novel-50' &&
      oldUnion[50] === '/chapter/old-novel-51' &&
      oldUnion[119] === '/chapter/old-novel-120',
    oldUnion[50],
  );
  const o4 = await plugin.parsePage(oldPath, '4');
  check('a page past the end is empty', o4.chapters.length === 0);
  const oldJobs = chapterJobs().length;
  await plugin.parsePage(oldPath, '5');
  check(
    'and once the novel is laid out locally, every page is free',
    chapterJobs().length === oldJobs,
    'jobs=' + chapterJobs().length,
  );

  // The genuinely ambiguous case: a novel of exactly one page, where the old
  // companion's whole novel and the new companion's page 1 are identical. Only
  // asking for a second page tells them apart.
  const oldFifty = serveOldCompanion('old-fifty', 50);
  const fiftyNovel = await plugin.parseNovel(oldFifty);
  check(
    'a 50-chapter novel is reported as one page',
    fiftyNovel.totalPages === 1,
    'totalPages=' + fiftyNovel.totalPages,
  );
  const f1 = await plugin.parsePage(oldFifty, '1');
  const f2 = await plugin.parsePage(oldFifty, '2');
  check(
    'page 2 is empty, not the same 50 chapters again',
    f1.chapters.length === 50 && f2.chapters.length === 0,
    f1.chapters.length + '/' + f2.chapters.length,
  );

  console.log('\n7. parseChapter correctness gate');
  const good = {
    path: '/chapter/surviving-the-game-12.5',
    chapterNumber: 12.5,
    complete: true,
    content: '<p>Real chapter text.</p>',
  };
  enqueue = () => accepted();
  nextJob = () => jobCompleted(good);
  const html = await plugin.parseChapter('/chapter/surviving-the-game-12.5');
  check('complete chapter returned verbatim', html === good.content, html);

  nextJob = () => jobCompleted(Object.assign({}, good, { complete: false }));
  await expectThrow(
    'complete:false is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'INCOMPLETE_CHAPTER',
  );

  nextJob = () => jobCompleted(Object.assign({}, good, { complete: undefined }));
  await expectThrow(
    'missing complete flag is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'INCOMPLETE_CHAPTER',
  );

  nextJob = () =>
    jobCompleted(Object.assign({}, good, { path: '/chapter/surviving-the-game-13' }));
  await expectThrow(
    'different chapter path is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'WRONG_CHAPTER',
  );

  nextJob = () =>
    jobCompleted(Object.assign({}, good, { path: '/chapter/other-novel-12.5' }));
  await expectThrow(
    'different novel slug is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'WRONG_CHAPTER',
  );

  nextJob = () => jobCompleted(Object.assign({}, good, { chapterNumber: 11 }));
  await expectThrow(
    'reported chapterNumber mismatch is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'WRONG_CHAPTER',
  );

  nextJob = () => jobCompleted(Object.assign({}, good, { content: '   ' }));
  await expectThrow(
    'empty content is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'INCOMPLETE_CHAPTER',
  );

  nextJob = () => jobCompleted(Object.assign({}, good, { content: '<div><br></div>' }));
  await expectThrow(
    'markup with no text is rejected',
    () => plugin.parseChapter('/chapter/surviving-the-game-12.5'),
    e => e.code === 'INCOMPLETE_CHAPTER',
  );

  nextJob = () =>
    jobCompleted(
      Object.assign({}, good, {
        path: '/chapter/surviving-the-game-12.50',
        chapterNumber: '12.50',
      }),
    );
  check(
    'numerically equal decimal spelling is accepted',
    (await plugin.parseChapter('/chapter/surviving-the-game-12.5')) === good.content,
  );

  console.log('\n8. needs_user requires an explicit retry');
  let polls = 0;
  nextJob = () => {
    polls++;
    return {
      ok: true,
      status: 200,
      json: async () => ({
        apiVersion: 1,
        jobId: 'job-1',
        state: 'needs_user',
        error: {
          code: 'VERIFICATION_REQUIRED',
          message: 'Open the companion.',
          retryable: false,
        },
      }),
    };
  };
  await expectThrow(
    'needs_user throws',
    () => plugin.parseChapter('/chapter/surviving-the-game-1'),
    e => e.code === 'VERIFICATION_REQUIRED' && e.retryable === false,
  );
  check('polled exactly once, no retry loop', polls === 1, 'polls=' + polls);
  await expectThrow(
    'needs_user message points at the companion',
    () => plugin.parseChapter('/chapter/surviving-the-game-1'),
    e => /companion/i.test(e.message) && /does not retry/i.test(e.message),
  );

  console.log('\n9. needs_user for SIGN_IN_REQUIRED is equally terminal');
  nextJob = () => ({
    ok: true,
    status: 200,
    json: async () => ({
      apiVersion: 1,
      jobId: 'job-1',
      state: 'needs_user',
      error: { code: 'SIGN_IN_REQUIRED', retryable: false },
    }),
  });
  await expectThrow(
    'SIGN_IN_REQUIRED is not retried',
    () => plugin.parseChapter('/chapter/surviving-the-game-1'),
    e => e.code === 'SIGN_IN_REQUIRED' && /companion/i.test(e.message),
  );

  console.log('\n10. Companion unavailable');
  offline = true;
  await expectThrow(
    'network failure becomes COMPANION_UNAVAILABLE',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'COMPANION_UNAVAILABLE' && /Open NovTales Companion/.test(e.message),
  );
  offline = false;

  console.log('\n11. HTTP error envelope (nested under `error`, as the server sends it)');
  enqueue = () => httpError(401, 'UNAUTHORIZED', 'That pairing key was not accepted.', false);
  await expectThrow(
    '401 surfaces UNAUTHORIZED, not INTERNAL',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'UNAUTHORIZED' && e.code !== 'INTERNAL' && /pairing key/.test(e.message),
    e => e.code + ' / ' + e.message,
  );
  enqueue = () =>
    httpError(503, 'COMPANION_UNAVAILABLE', 'The companion is not running.', true, 3000);
  await expectThrow(
    '503 surfaces COMPANION_UNAVAILABLE, not INTERNAL',
    () => plugin.parseNovel('/novel/x'),
    e =>
      e.code === 'COMPANION_UNAVAILABLE' &&
      e.code !== 'INTERNAL' &&
      /Open NovTales Companion/.test(e.message) &&
      e.retryable === true &&
      e.retryAfterMs === 3000,
    e => e.code + ' retryable=' + e.retryable + ' retryAfterMs=' + e.retryAfterMs,
  );
  enqueue = () =>
    httpError(429, 'QUEUE_FULL', 'Four jobs are already waiting.', true, 5000);
  await expectThrow(
    'a nested QUEUE_FULL keeps its retryAfterMs',
    () => plugin.parsePage('/novel/x', '1'),
    e => e.code === 'QUEUE_FULL' && e.retryAfterMs === 5000,
    e => e.code + ' retryAfterMs=' + e.retryAfterMs,
  );
  enqueue = () => httpError(402, 'MEMBERSHIP_REQUIRED', 'Locked.', false);
  await expectThrow(
    '402 never yields a preview',
    () => plugin.parseChapter('/chapter/surviving-the-game-1'),
    e => e.code === 'MEMBERSHIP_REQUIRED' && /membership/.test(e.message),
  );
  enqueue = () => httpError(429, 'RATE_LIMITED', 'Slow down.', true);
  await expectThrow(
    'RATE_LIMITED is reported, not retried here',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'RATE_LIMITED',
  );
  enqueue = () => flatHttpError(401, 'UNAUTHORIZED', 'bad key', false);
  await expectThrow(
    'a flat envelope is still understood, though the server never sends one',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'UNAUTHORIZED',
    e => e.code,
  );
  enqueue = () => ({
    ok: false,
    status: 500,
    json: async () => ({ apiVersion: 1, error: { code: 'INTERNAL', message: 'boom', retryable: false, retryAfterMs: null }, retryAfterMs: null }),
  });
  await expectThrow(
    'a nested INTERNAL is still INTERNAL',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'INTERNAL',
    e => e.code,
  );

  console.log('\n11b. A job-level failure nests under `error` too');
  enqueue = () => accepted();
  nextJob = () =>
    jobFailed('TIMEOUT', 'The companion ran out of time.', true);
  await expectThrow(
    'a failed job reports its own code, not INTERNAL',
    () => plugin.parseChapter('/chapter/surviving-the-game-1'),
    e => e.code === 'TIMEOUT' && e.retryable === true,
    e => e.code,
  );

  console.log('\n12. API version mismatch');
  enqueue = () => ({
    ok: true,
    status: 202,
    json: async () => ({ apiVersion: 2, jobId: 'job-1', state: 'queued' }),
  });
  await expectThrow(
    'apiVersion mismatch is rejected, not misread',
    () => plugin.parseNovel('/novel/x'),
    e => e.code === 'API_VERSION_MISMATCH',
  );

  console.log('\n13. QUEUE_FULL waits and retries a bounded number of times');
  enqueue = () => accepted();
  nextJob = () => jobCompleted({ items: [] });
  let enqueues = 0;
  enqueue = () => {
    enqueues++;
    if (enqueues < 3) {
      return httpError(429, 'QUEUE_FULL', 'Four jobs are already waiting.', true, 5);
    }
    return accepted();
  };
  const queued = await plugin.popularNovels(1, noFilters);
  check(
    'succeeded after two QUEUE_FULL retries',
    Array.isArray(queued) && enqueues === 3,
    'enqueues=' + enqueues,
  );

  enqueues = 0;
  enqueue = () => {
    enqueues++;
    return httpError(429, 'QUEUE_FULL', 'Four jobs are already waiting.', true, 5);
  };
  await expectThrow(
    'QUEUE_FULL gives up at the bound',
    () => plugin.popularNovels(1, noFilters),
    e => e.code === 'QUEUE_FULL',
  );
  check('exactly 4 enqueue attempts (1 + 3 retries)', enqueues === 4, 'enqueues=' + enqueues);

  console.log('\n14. Catalogue falls back when the sort vocabulary is rejected');
  let catalogueCalls = 0;
  enqueue = (url, init) => {
    const body = JSON.parse(init.body);
    if (body.operation !== 'catalogue') return accepted();
    catalogueCalls++;
    if (catalogueCalls === 1 && body.sort) {
      return httpError(400, 'BAD_REQUEST', '"sort" is not accepted.', false);
    }
    return accepted();
  };
  nextJob = () => jobCompleted({ items: [] });
  const fellBack = await plugin.popularNovels(1, noFilters);
  const posts = requests.filter(r => r.init.method === 'POST');
  const fallbackBody = JSON.parse(posts[posts.length - 1].init.body);
  check(
    'second catalogue call omits sort',
    Array.isArray(fellBack) &&
      catalogueCalls === 2 &&
      fallbackBody.operation === 'catalogue' &&
      fallbackBody.sort === undefined,
    JSON.stringify(fallbackBody),
  );

  console.log('\n15. Cancellation');
  enqueue = () => accepted();
  nextJob = () => ({
    ok: true,
    status: 200,
    json: async () => ({ apiVersion: 1, jobId: 'job-1', state: 'cancelled' }),
  });
  check(
    'popularNovels returns an empty list',
    JSON.stringify(await plugin.popularNovels(1, noFilters)) === '[]',
  );
  check(
    'searchNovels returns an empty list',
    JSON.stringify(await plugin.searchNovels('anything', 1)) === '[]',
  );
  check(
    'parsePage returns empty chapters',
    JSON.stringify(await plugin.parsePage('/novel/x', '1')) === '{"chapters":[]}',
  );
  await expectThrow(
    'parseChapter refuses to hand back empty HTML',
    () => plugin.parseChapter('/chapter/x-1'),
    e => e.code === 'CANCELLED' && e.message === 'NovTales: the request was cancelled.',
  );

  console.log('\n16. A stuck job is bounded, not polled forever');
  nextJob = () => ({
    ok: true,
    status: 200,
    json: async () => ({ apiVersion: 1, jobId: 'job-1', state: 'loading' }),
  });
  const started = Date.now();
  await expectThrow(
    'a job that never settles times out',
    () => plugin.searchNovels('anything', 1),
    e => e.code === 'TIMEOUT' && e.retryable === true,
  );
  const elapsed = Math.round((Date.now() - started) / 1000);
  // METADATA_BUDGET_MS is 95,000 ms. The bound below used to say 70..90, which
  // no budget has satisfied since that constant moved to 95s: the assertion was
  // stale, not the plugin. It now brackets the budget it is actually testing.
  check('bounded wait honoured', elapsed >= 90 && elapsed <= 100, 'elapsed ' + elapsed + 's');

  console.log('\n' + passed + ' passed, ' + failed + ' failed');
  if (failed) process.exitCode = 1;
}

run().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
