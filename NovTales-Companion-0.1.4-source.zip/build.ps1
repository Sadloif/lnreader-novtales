# Builds the NovTales Companion APK on this machine.
#
# Gradle comes from the committed wrapper (novtales-companion\gradlew.bat), the
# same thing docs/BUILD.md tells a reviewer to use. The downloaded distribution
# under tools\gradle-dist is only a fallback for when the wrapper cannot run.
#
# The DSH sandbox denies writes to %TEMP% and %USERPROFILE%, which stops Gradle's
# native library from loading, so those are redirected inside the workspace.
# Pass -NoRedirect to leave the ambient environment alone.
#
# On a normal developer machine just use docs/BUILD.md:
#     cd novtales-companion
#     gradlew.bat assembleRelease
param(
    [switch]$Debug,
    [string]$Task = "assembleRelease",
    [switch]$NoRedirect
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSCommandPath
$work = Join-Path $root "_working"
$project = Join-Path $root "novtales-companion"

# ---------------------------------------------------------------------------
# JDK. gradlew.bat needs JAVA_HOME. Resolve it rather than assuming one path:
# this machine keeps a JDK under the Linksi toolchain, other machines use an
# Adoptium/Temurin or Android Studio install.
# ---------------------------------------------------------------------------
function Test-Jdk([string]$path) {
    if (-not $path) { return $false }
    return (Test-Path (Join-Path $path "bin\java.exe")) -or
           (Test-Path (Join-Path $path "bin\java"))
}

if (-not (Test-Jdk $env:JAVA_HOME)) {
    # Built defensively: Join-Path throws if an env var is unset, and
    # $ErrorActionPreference is Stop.
    $candidates = @("E:\Deepseek\Linksi\toolchain\jdk-17")   # this build machine
    $pf = ${env:ProgramFiles}
    $lf = ${env:LOCALAPPDATA}
    if ($pf) {
        $candidates += (Join-Path $pf "Eclipse Adoptium")
        $candidates += (Join-Path $pf "Android\Android Studio\jbr")
    }
    if ($lf) { $candidates += (Join-Path $lf "Programs\Android Studio\jbr") }
    $candidates = $candidates | Where-Object { $_ }

    $found = $null
    foreach ($c in $candidates) {
        # Adoptium/Android Studio install into versioned subfolders.
        if (Test-Jdk $c) { $found = $c; break }
        if (Test-Path $c) {
            $sub = Get-ChildItem $c -Directory -ErrorAction SilentlyContinue |
                   Where-Object { Test-Jdk $_.FullName } |
                   Sort-Object Name -Descending | Select-Object -First 1
            if ($sub) { $found = $sub.FullName; break }
        }
    }

    if (-not $found) {
        throw "No JDK 17 found. Set JAVA_HOME, or install Temurin 17. Tried: $($candidates -join '; ')"
    }
    $env:JAVA_HOME = $found
}

# ---------------------------------------------------------------------------
# State directories. AGP writes its debug keystore and AVD state under the
# Android user home, which is outside the sandbox; Gradle needs a writable
# temp dir for its native library.
# Only ANDROID_USER_HOME is set: ANDROID_SDK_HOME changes the layout AGP expects
# and made its Android-locations service fail.
# ---------------------------------------------------------------------------
$androidHome = Join-Path $work "android-home"
if (-not $NoRedirect) {
    $env:GRADLE_USER_HOME = Join-Path $work "gradle-home"
    $env:TEMP = Join-Path $work "tmp"
    $env:TMP = $env:TEMP
    $env:ANDROID_USER_HOME = $androidHome
    New-Item -ItemType Directory -Force -Path `
        $env:GRADLE_USER_HOME, $env:TEMP, $androidHome | Out-Null
} elseif (-not (Test-Path $androidHome)) {
    New-Item -ItemType Directory -Force -Path $androidHome | Out-Null
}

# ---------------------------------------------------------------------------
# Gradle. Prefer the committed wrapper. Fall back to the downloaded
# distribution only when the wrapper is unusable, and say so loudly - a silent
# fallback would make the delivered build.ps1 look like it used the wrapper.
# ---------------------------------------------------------------------------
$wrapper = Join-Path $project "gradlew.bat"
$dist = Join-Path $root "tools\gradle-dist\gradle-8.9\bin\gradle.bat"

if (Test-Path $wrapper) {
    $gradle = $wrapper
} elseif (Test-Path $dist) {
    $gradle = $dist
    Write-Host ""
    Write-Host "WARNING: committed Gradle wrapper not found at $wrapper" -ForegroundColor Yellow
    Write-Host "WARNING: falling back to the downloaded distribution at $dist." -ForegroundColor Yellow
    Write-Host "WARNING: that directory is not part of the delivery; expect this" -ForegroundColor Yellow
    Write-Host "WARNING: fallback to fail on any machine that has not downloaded it." -ForegroundColor Yellow
    Write-Host ""
} else {
    throw "No Gradle. Expected the committed wrapper at $wrapper. tools\gradle-dist is not shipped either - restore gradle\wrapper\ from source, or install Gradle 8.9 and put it on PATH."
}

# Accepts several tasks: -Task "test assembleRelease"
$gradleArgs = @("-p", $project) + ($Task -split '\s+' | Where-Object { $_ }) + @("--no-daemon", "--console=plain")
if ($Debug) { $gradleArgs = @("-p", $project, "assembleDebug", "--no-daemon", "--console=plain") }

# Gradle reports progress on stderr; capture both streams so a failure is readable.
# ErrorActionPreference must be relaxed here or PowerShell turns Gradle's normal
# stderr progress output into a terminating error.
# A timestamped name so two concurrent invocations cannot fight over the file.
New-Item -ItemType Directory -Force -Path $work | Out-Null
$log = Join-Path $work ("build-{0}.log" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
$previous = $ErrorActionPreference
$ErrorActionPreference = "Continue"
& $gradle @gradleArgs *> $log
$code = $LASTEXITCODE
$ErrorActionPreference = $previous
Get-Content $log -Tail 60

Write-Host ""
Write-Host ("gradle : {0}" -f $gradle)
Write-Host ("log    : {0}" -f $log)
exit $code