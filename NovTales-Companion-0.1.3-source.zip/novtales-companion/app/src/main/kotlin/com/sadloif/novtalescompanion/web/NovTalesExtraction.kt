package com.sadloif.novtalescompanion.web

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.Paths
import com.sadloif.novtalescompanion.core.jsonObject

/**
 * Turns a NovTales page payload into the exact JSON shapes in CONTRACTS.md
 * section 3, and decodes the Next.js streaming payload that carries them.
 *
 * Pure JVM: no `android.*` import anywhere in this file, so all of it is
 * unit-testable off-device. The WebView only ever produces text; every decision
 * about what that text means is made here.
 *
 * Verified live shapes this is written against (see the report):
 *  - catalogue cards: `{slug, title, published, coverUrl, altNames[], hearts, added}`
 *  - novel: `{title, slug, author, coverUrl, synopsis, genres[], status,
 *    ratingAverage, chapterTotalPages, chapterList[]}` with `status` uppercase
 *    and `ratingAverage` already out of five.
 *  - chapter numbers carry decimals (`944.5`) and must survive verbatim.
 *
 * Nothing here guesses. If the site does not expose a rating or a release date,
 * the field is absent from the result rather than filled in.
 */
object NovTalesExtraction {

    // ---- Routes -------------------------------------------------------------
    //
    // These three defaults are the only unverified assumptions in the whole
    // adapter, and they are deliberately isolated here so a maintainer can
    // correct one without touching the parsers. Everything else is derived from
    // the payload the page itself carried.

    /** Server-rendered listing. Verified to carry the whole catalogue in one payload. */
    @Volatile
    var cataloguePath: String = "/explore"

    /** Fallback search route, used only when the caller does not supply a path. */
    @Volatile
    var searchPathTemplate: String = "/explore?q={query}"

    /** Public JSON chapter index, preferred over scraping for the chapters operation. */
    const val CHAPTERS_API_PATH = "/api/public/novel-chapters"

    /**
     * A chapter list label is synthesised from the real chapter number when the
     * site gives a chapter no title of its own. Turn this off to emit a nameless
     * chapter instead; nothing else in the adapter depends on it.
     */
    const val SYNTHESISE_CHAPTER_NAME: Boolean = true

    /** Ceiling on chapter-index pages fetched in one `chapters` operation. */
    const val MAX_CHAPTER_PAGES: Int = 400

    fun chapterListUrl(slug: String, page: Int, pageSize: Int): String =
        "$SITE_ORIGIN$CHAPTERS_API_PATH/$slug?page=$page&pageSize=$pageSize"

    fun catalogueUrl(page: Int): String = "$SITE_ORIGIN$cataloguePath?page=$page"

    fun novelUrl(path: String): String = "$SITE_ORIGIN$path"

    /**
     * Builds a search URL. A caller-supplied [path] always wins, so a client that
     * knows the site's search route never depends on [searchPathTemplate].
     */
    fun searchUrl(path: String?, query: String?, page: Int): String {
        if (path != null && path.isNotBlank()) {
            val normalised = Paths.normalise(path)
                ?: throw CompanionException.badRequest("Not a NovTales path: ${path.take(40)}")
            val separator = if (normalised.contains('?')) '&' else '?'
            val suffix = buildString {
                if (!query.isNullOrBlank()) append("${separator}q=").append(encodeQuery(query))
                if (page > 1) {
                    if (isNotEmpty()) append('&')
                    append("page=").append(page)
                }
            }
            return "$SITE_ORIGIN$normalised$suffix"
        }
        val template = searchPathTemplate
            .replace("{query}", encodeQuery(query.orEmpty()))
            .replace("{page}", page.toString())
        return SITE_ORIGIN + template
    }

    // ---- Chapter numbers ----------------------------------------------------

    /**
     * Normalises a chapter number without ever changing its value.
     *
     * `12.50` becomes `12.5`, `12.0` becomes `12`, `012` becomes `12`, and
     * anything that is not a plain number is rejected. This is the only place a
     * chapter number is formatted, so `12.50` can never leak into a result.
     */
    fun normaliseChapterNumber(raw: String?): String? {
        val text = raw?.trim()?.removePrefix("\u00A0")?.trim() ?: return null
        if (text.isEmpty() || text.length > 24) return null
        if (!Paths.isChapterNumber(text)) return null
        val dot = text.indexOf('.')
        if (dot < 0) {
            val whole = text.trimStart('0')
            return whole.ifEmpty { "0" }
        }
        val wholePart = text.substring(0, dot).trimStart('0').ifEmpty { "0" }
        val fraction = text.substring(dot + 1).trimEnd('0')
        return if (fraction.isEmpty()) wholePart else "$wholePart.$fraction"
    }

    private fun chapterNumberValue(number: String): Json =
        Json.Num(number.toDoubleOrNull() ?: 0.0)

    // ---- Paths --------------------------------------------------------------

    /**
     * Turns anything the site calls a link into the relative form the local API
     * requires. Absolute URLs off the site, and anything that is not a
     * `/novel/...` or `/chapter/...` path, return null and the item is dropped.
     */
    fun toRelativePath(raw: String?): String? {
        val value = raw?.trim()?.replace("\u00A0", " ") ?: return null
        if (value.isEmpty() || value.length > 512) return null
        val candidate = when {
            value.startsWith("/") -> value
            value.startsWith(SITE_ORIGIN) -> value.removePrefix(SITE_ORIGIN)
            value.startsWith("https://") || value.startsWith("http://") -> return null
            value.startsWith("../") || value.contains("..") -> return null
            else -> "/$value"
        }
        val normalised = Paths.normalise(candidate) ?: return null
        return if (Paths.isNovel(normalised) || Paths.isChapter(normalised)) normalised else null
    }

    fun toAbsoluteUrl(raw: String?): String? {
        val value = raw?.trim() ?: return null
        if (value.isEmpty() || value.length > 1024) return null
        if (value.contains('"') || value.contains('\n')) return null
        val absolute = when {
            value.startsWith("//") -> "https:$value"
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.startsWith("/") -> SITE_ORIGIN + value
            else -> SITE_ORIGIN + "/" + value.trimStart('.', '/')
        }
        return if (absolute.startsWith("https://") || absolute.startsWith("http://")) absolute else null
    }

    // ---- Result shapes ------------------------------------------------------

    /**
     * `{ items: [...], page: n, hasNext: bool }` for both `catalogue` and
     * `search`. `hasNext` comes from the payload when the site exposes it; the
     * fallback is deliberately pessimistic (assume another page exists when this
     * one returned anything) so a reader is never cut off early.
     */
    const val CATALOGUE_PAGE_SIZE = 24

    fun catalogue(payload: Json?, page: Int, sort: String?, query: String? = null): Json {
        val root = NextFlight.rootOf(payload)
        val cards = NextFlight.findArray(root) { isNovelCard(it) }
            ?: throw siteChanged("The catalogue payload had no recognisable novels in it.")
        val term = query.orEmpty().trim().lowercase()
        val matches = cards.filter { card ->
            term.isEmpty() || listOfNotNull(titleOf(card), slugOf(card))
                .plus(card.arr("altNames")?.items?.mapNotNull { (it as? Json.Str)?.value }.orEmpty())
                .any { it.lowercase().contains(term) }
        }.distinctBy { slugOf(it) }
        val ordered = sortCards(matches, sort).mapNotNull { novelCard(it) }
        val start = (page.toLong() - 1).coerceAtLeast(0) * CATALOGUE_PAGE_SIZE
        val items = if (start >= ordered.size) emptyList() else
            ordered.subList(start.toInt(), minOf(ordered.size, start.toInt() + CATALOGUE_PAGE_SIZE))
        val hasNext = start + items.size < ordered.size
        return jsonObject(
            "items" to items,
            "page" to page,
            "hasNext" to hasNext,
        )
    }

    /** Only the site's pages overlapping this ascending reader page are needed. */
    fun indexPages(total: Int, page: Int, pageSize: Int): IntRange {
        val start = (page.toLong() - 1) * pageSize
        if (total <= 0 || start >= total || start < 0) return IntRange.EMPTY
        val end = minOf(total.toLong(), start + pageSize)
        return ((total - end) / pageSize + 1).toInt()..((total - start - 1) / pageSize + 1).toInt()
    }

    fun validateIndexPage(body: Json, page: Int, pageSize: Int, expectedTotal: Int? = null): Int {
        val total = body.int("total") ?: throw siteChanged("The chapter index omitted its count.")
        val entries = body.arr("chapters") ?: throw siteChanged("The chapter index omitted its chapters.")
        val expectedCount = minOf(pageSize.toLong(), (total.toLong() - (page.toLong() - 1) * pageSize).coerceAtLeast(0)).toInt()
        if (total < 0 || (expectedTotal != null && total != expectedTotal) ||
            body.int("page") != page || body.int("pageSize") != pageSize ||
            body.int("totalPages") != ChapterPaging.totalPages(total, pageSize) || entries.items.size != expectedCount) {
            throw siteChanged("The chapter index changed or returned an incomplete page. Retry the list.")
        }
        return total
    }

    fun chapterWindow(pages: List<Json>, path: String, total: Int, page: Int, pageSize: Int): Json {
        val range = indexPages(total, page, pageSize)
        if (range.isEmpty()) return jsonObject("chapters" to Json.Arr(emptyList()), "chapterCount" to total,
            "totalPages" to ChapterPaging.totalPages(total, pageSize))
        if (pages.size != range.count()) throw siteChanged("An index page was missing.")
        pages.forEachIndexed { index, body -> validateIndexPage(body, range.first + index, pageSize, total) }
        val rows = pages.flatMap { it.arr("chapters")!!.items }
        val start = (page.toLong() - 1) * pageSize
        val end = minOf(total.toLong(), start + pageSize)
        val offset = (total - end - (range.first.toLong() - 1) * pageSize).toInt()
        val wanted = rows.subList(offset, offset + (end - start).toInt())
        val parsed = chaptersFromApiPages(listOf(jsonObject("chapters" to Json.Arr(wanted))), path, true)
        if (parsed.arr("chapters")?.items?.size != wanted.size) throw siteChanged("The index contained invalid or duplicate chapters.")
        return jsonObject("chapters" to parsed.arr("chapters"), "chapterCount" to total,
            "totalPages" to ChapterPaging.totalPages(total, pageSize))
    }

    /** `{name, path, cover, summary, author, genres, status, rating, chapters, totalPages}`. */
    fun novel(payload: Json?, path: String): Json {
        val slug = Paths.novelSlug(path)
            ?: throw CompanionException.badRequest("Not a novel path: $path")
        // Resolve the stream first, including references inside inline props.
        // A fully inline prop is still usable if the stream is unavailable.
        val direct = if (payload is Json.Obj) NextFlight.rootOf(payload.fields["value"]) else null
        val matches: (Json.Obj) -> Boolean = { candidate ->
            slugOf(candidate) == slug && titleOf(candidate) != null && looksLikeNovel(candidate)
        }
        val node = NextFlight.findObject(NextFlight.rootOf(payload), matches)
            ?: NextFlight.findObject(direct, matches)
            ?: throw siteChanged("The novel payload for '$slug' was not recognised.")

        val resolvedSlug = slugOf(node) ?: slug
        val fields = LinkedHashMap<String, Json>()
        put(fields, "name", titleOf(node)?.let { Json.Str(it) })
        fields["path"] = Json.Str("/novel/$resolvedSlug")
        put(fields, "cover", absoluteImage(firstString(node, COVER_KEYS)))
        put(fields, "summary", firstString(node, SUMMARY_KEYS)?.let { Json.Str(it) })
        put(fields, "author", authorName(node))
        put(fields, "genres", genresOf(node))
        fields["status"] = Json.Str(statusOf(node))
        put(fields, "rating", ratingOf(node))
        fields["chapters"] = Json.Arr(chapterItemsOf(node))
        val totalPages = firstInt(node, TOTAL_PAGES_KEYS)
        put(fields, "totalPages", totalPages?.let { Json.Num(it.toDouble()) })
        return Json.Obj(fields)
    }

    /** `{ chapters: [...] }` ascending, de-duplicated by path. */
    fun chaptersFromPayload(payload: Json?, path: String): Json {
        val slug = Paths.novelSlug(path)
            ?: throw CompanionException.badRequest("Not a novel path: $path")
        val root = NextFlight.rootOf(payload)
        val entries = NextFlight.findArray(root) { isChapterEntry(it) }
            ?.mapNotNull { chapterEntry(it, slug) }
            .orEmpty()
        if (entries.isEmpty()) {
            throw siteChanged("No chapter list was present in the novel payload for '$slug'.")
        }
        return jsonObject("chapters" to ascending(entries))
    }

    /**
     * Merges the pages returned by the public JSON chapter index into one result.
     *
     * A list that stopped early because the deadline ran out is **not** returned:
     * a half chapter index would silently truncate the novel in the reader, so it
     * fails as a timeout instead.
     */
    fun chaptersFromApiPages(pages: List<Json>, path: String, exhausted: Boolean): Json {
        val slug = Paths.novelSlug(path)
            ?: throw CompanionException.badRequest("Not a novel path: $path")
        if (!exhausted) {
            throw CompanionException.timeout("the chapter list for $slug")
        }
        val entries = ArrayList<ChapterEntry>()
        for (page in pages) {
            NextFlight.findArray(page) { isChapterEntry(it) }
                ?.mapNotNullTo(entries) { chapterEntry(it, slug) }
        }
        if (entries.isEmpty()) throw siteChanged("The chapter index for '$slug' returned nothing usable.")
        return jsonObject("chapters" to ascending(entries))
    }

    /**
     * How many chapter entries one page of the public JSON index holds.
     *
     * The caller uses a short page as the signal that the server has nothing
     * more, which is how the chapter loop knows it may stop and mark the list
     * exhausted. Returns 0 when the page holds nothing recognisable, which
     * correctly ends the loop instead of paging forever.
     */
    fun chapterEntryCount(payload: Json?): Int =
        NextFlight.findArray(NextFlight.rootOf(payload)) { isChapterEntry(it) }?.size ?: 0

    /** `{path, chapterNumber, complete, content}` - assembled by the gateway, kept here for the cache key. */
    fun chapterResult(
        path: String,
        chapterNumber: String,
        complete: Boolean,
        content: String,
    ): Json = jsonObject(
        "path" to path,
        "chapterNumber" to chapterNumberValue(chapterNumber),
        "complete" to complete,
        "content" to content,
    )

    // ---- Item mapping -------------------------------------------------------

    private val PAGE_SIZE_KEYS = setOf("pageSize", "perPage", "page_size", "itemsPerPage", "limit", "count")
    private val HAS_NEXT_KEYS = setOf("hasNext", "hasNextPage", "has_more", "hasMore", "nextPage")
    private val SLUG_KEYS = setOf("slug", "novelSlug", "novel_slug", "path", "href", "url", "link")
    private val TITLE_KEYS = setOf("title", "name", "novelTitle", "novel_title")
    private val COVER_KEYS = setOf("coverUrl", "cover_url", "cover", "coverImage", "image", "thumbnail", "poster")
    private val SUMMARY_KEYS = setOf("synopsis", "summary", "description", "about", "blurb", "excerpt")
    private val AUTHOR_KEYS = setOf("author", "authors", "writer", "by")
    private val GENRES_KEYS = setOf("genres", "genre", "tags", "categories", "category")
    private val STATUS_KEYS = setOf("status", "novelStatus", "novel_status", "serialization", "serialisation", "state")
    private val RATING_KEYS = setOf("ratingAverage", "rating_average", "averageRating", "rating", "score", "ratingValue")
    private val RATING_SCALE_KEYS = setOf("ratingScale", "rating_scale", "maxRating", "ratingMax", "scale", "maxScore")
    private val TOTAL_PAGES_KEYS = setOf("chapterTotalPages", "chapter_total_pages", "totalPages", "total_pages", "pageCount", "chapterPages")
    private val CHAPTER_LIST_KEYS = setOf("chapterList", "chapter_list", "chapters", "chapterItems", "items")
    private val CHAPTER_NUMBER_KEYS = setOf("number", "chapterNumber", "chapter_number", "chapterNo", "no", "index", "ordinal")
    private val CHAPTER_NAME_KEYS = setOf("title", "name", "chapterTitle", "chapter_title")
    private val CHAPTER_TIME_KEYS = setOf("releaseTime", "release_time", "releasedAt", "publishedAt", "postedAt", "added", "published", "createdAt", "updatedAt")

    data class ChapterEntry(
        val path: String,
        val name: String?,
        val number: String,
        val releaseTime: String?,
    )

    private fun novelCard(node: Json.Obj): Json? {
        val slug = slugOf(node) ?: return null
        val path = toRelativePath("/novel/$slug") ?: return null
        val title = titleOf(node) ?: slug
        val fields = LinkedHashMap<String, Json>()
        fields["name"] = Json.Str(title)
        fields["path"] = Json.Str(path)
        put(fields, "cover", absoluteImage(firstString(node, COVER_KEYS)))
        return Json.Obj(fields)
    }

    private fun chapterEntry(node: Json.Obj, novelSlug: String): ChapterEntry? {
        val delivered = toRelativePath(firstString(node, SLUG_KEYS))
            ?: chapterPathFromFields(node, novelSlug)
            ?: return null
        if (!Paths.isChapter(delivered)) return null
        val slug = Paths.chapterSlug(delivered) ?: return null
        // A chapter belonging to a different novel is not this novel's chapter.
        if (slug != novelSlug) return null
        val number = normaliseChapterNumber(Paths.chapterNumber(delivered)) ?: return null
        val name = firstString(node, CHAPTER_NAME_KEYS)
            ?: if (SYNTHESISE_CHAPTER_NAME) "Chapter $number" else null
        return ChapterEntry(
            path = "/chapter/$slug-$number",
            name = name,
            number = number,
            releaseTime = firstString(node, CHAPTER_TIME_KEYS),
        )
    }

    private fun chapterPathFromFields(node: Json.Obj, novelSlug: String): String? {
        val raw = CHAPTER_NUMBER_KEYS
            .firstNotNullOfOrNull { key -> (node.fields[key] as? Json.Str)?.value ?: numberText(node.fields[key]) }
            ?: return null
        val number = normaliseChapterNumber(raw) ?: return null
        val slug = slugOf(node) ?: novelSlug
        if (!Paths.isSlug(slug)) return null
        return toRelativePath("/chapter/$slug-$number")
    }

    private fun chapterItemsOf(node: Json.Obj): List<Json> {
        val slug = slugOf(node) ?: return emptyList()
        CHAPTER_LIST_KEYS.forEach { key ->
            val array = node.arr(key) ?: return@forEach
            val items = array.items.filterIsInstance<Json.Obj>()
                .mapNotNull { chapterEntry(it, slug) }
            if (items.isNotEmpty()) return ascending(items)
        }
        return emptyList()
    }

    private fun chapterItemJson(entry: ChapterEntry): Json {
        val fields = LinkedHashMap<String, Json>()
        entry.name?.let { fields["name"] = Json.Str(it) }
        fields["path"] = Json.Str(entry.path)
        fields["chapterNumber"] = chapterNumberValue(entry.number)
        put(fields, "releaseTime", entry.releaseTime?.let { Json.Str(it) })
        return Json.Obj(fields)
    }

    private fun ascending(entries: List<ChapterEntry>): List<Json> =
        entries
            .distinctBy { it.path }
            // Ascending by number, oldest first, which is the reverse of the
            // website's newest-first listing. Ties fall back to the raw path so
            // the order is stable between runs.
            .sortedWith(compareBy({ it.number.toDoubleOrNull() ?: Double.MAX_VALUE }, { it.path }))
            .map(::chapterItemJson)

    /**
     * `popular` and `latest` are real site fields (`hearts`, `added`), not
     * invented scores. Any other sort is left to the order the page delivered.
     */
    private fun sortCards(cards: List<Json.Obj>, sort: String?): List<Json.Obj> = when (sort?.lowercase()) {
        "popular", "top", "trending" -> cards.sortedByDescending { numberOf(it, "hearts") ?: Long.MIN_VALUE }
        "latest", "new", "recent" -> cards.sortedByDescending { numberOf(it, "added") ?: Long.MIN_VALUE }
        else -> cards
    }

    // ---- Field readers ------------------------------------------------------

    private fun slugOf(node: Json.Obj): String? {
        SLUG_KEYS.forEach { key ->
            val value = (node.fields[key] as? Json.Str)?.value?.trim() ?: return@forEach
            if (Paths.isSlug(value)) return value
            val fromPath = toRelativePath(value)
            if (fromPath != null) return Paths.novelSlug(fromPath) ?: Paths.chapterSlug(fromPath)
        }
        return null
    }

    private fun titleOf(node: Json.Obj): String? {
        TITLE_KEYS.forEach { key ->
            val value = (node.fields[key] as? Json.Str)?.value?.trim() ?: return@forEach
            if (value.isNotEmpty()) return value
        }
        (node.fields["altNames"] as? Json.Arr)?.items?.forEach { item ->
            val value = (item as? Json.Str)?.value?.trim()
            if (!value.isNullOrEmpty()) return value
        }
        return null
    }

    private fun authorName(node: Json.Obj): Json? {
        AUTHOR_KEYS.forEach { key ->
            when (val value = node.fields[key]) {
                is Json.Str -> if (value.value.isNotBlank()) return Json.Str(value.value.trim())
                is Json.Arr -> {
                    val names = value.items.mapNotNull { item ->
                        when (item) {
                            is Json.Str -> item.value.trim()
                            is Json.Obj -> firstString(item, setOf("name", "author", "displayName", "username"))
                            else -> null
                        }
                    }.filter { it.isNotEmpty() }
                    if (names.isNotEmpty()) return Json.Str(names.joinToString(", "))
                }
                is Json.Obj -> firstString(value, setOf("name", "displayName", "username"))
                    ?.let { return Json.Str(it) }
                else -> Unit
            }
        }
        return null
    }

    /** Always a comma-separated string, never an array, per CONTRACTS.md. */
    private fun genresOf(node: Json.Obj): Json? {
        GENRES_KEYS.forEach { key ->
            when (val value = node.fields[key]) {
                is Json.Str -> {
                    val cleaned = value.value.split(',')
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .distinct()
                    if (cleaned.isNotEmpty()) return Json.Str(cleaned.joinToString(", "))
                }
                is Json.Arr -> {
                    val cleaned = value.items.mapNotNull { item ->
                        when (item) {
                            is Json.Str -> item.value.trim()
                            is Json.Obj -> firstString(item, setOf("name", "title", "genre"))
                            else -> null
                        }
                    }?.filter { it.isNotEmpty() }?.distinct()
                    if (!cleaned.isNullOrEmpty()) return Json.Str(cleaned.joinToString(", "))
                }
                else -> Unit
            }
        }
        return null
    }

    /**
     * The site publishes `status` uppercase (`HIATUS` observed). Anything the
     * adapter does not recognise becomes `Unknown` rather than a guess.
     */
    fun statusOf(node: Json.Obj): String {
        val raw = STATUS_KEYS.firstNotNullOfOrNull { key ->
            (node.fields[key] as? Json.Str)?.value?.trim()?.takeIf { it.isNotEmpty() }
        } ?: return "Unknown"
        val token = raw.uppercase().filter { it.isLetter() }
        return when {
            token.contains("HIATUS") || token.contains("PAUSED") || token.contains("ONHOLD") -> "OnHiatus"
            token.contains("CANCEL") || token.contains("DROPPED") || token.contains("DISCONTINUED") -> "Cancelled"
            token.contains("COMPLETE") || token.contains("FINISH") || token.contains("ENDED") -> "Completed"
            token.contains("ONGOING") || token.contains("UPDATING") ||
                token.contains("CONTINU") || token.contains("RELEASING") ||
                token.contains("ACTIVE") || token.contains("PUBLISHING") -> "Ongoing"
            else -> "Unknown"
        }
    }

    /**
     * `ratingAverage` is already out of five. A value outside 0..5 is only
     * accepted when the payload also states the scale, and then it is converted;
     * otherwise it is omitted rather than reported as something the site never
     * said.
     */
    private fun ratingOf(node: Json.Obj): Json? {
        val scale = firstInt(node, RATING_SCALE_KEYS)
        RATING_KEYS.forEach { key ->
            // numberText keeps the site's own digits (chapter numbers need the
            // string); only the rating path wants a Double.
            val raw = numberText(node.fields[key])?.toDoubleOrNull() ?: return@forEach
            if (!raw.isFinite()) return@forEach
            val value = when {
                raw in 0.0..5.0 -> raw
                scale != null && scale > 0 && raw >= 0 && raw <= scale -> raw / scale * 5.0
                else -> return@forEach
            }
            val rounded = Math.round(value * 100.0) / 100.0
            if (rounded in 0.0..5.0) return Json.Num(rounded)
        }
        return null
    }

    private fun isNovelCard(node: Json.Obj): Boolean =
        slugOf(node) != null && titleOf(node) != null &&
            (node.fields.keys.any { it in COVER_KEYS } || node.fields["altNames"] != null || node.fields["hearts"] != null)

    private fun looksLikeNovel(node: Json.Obj): Boolean =
        slugOf(node) != null && titleOf(node) != null &&
            (SUMMARY_KEYS.any { node.fields.containsKey(it) } ||
                GENRES_KEYS.any { node.fields.containsKey(it) } ||
                STATUS_KEYS.any { node.fields.containsKey(it) } ||
                CHAPTER_LIST_KEYS.any { node.fields.containsKey(it) })

    private fun isChapterEntry(node: Json.Obj): Boolean =
        CHAPTER_NUMBER_KEYS.any { node.fields.containsKey(it) } ||
            SLUG_KEYS.any { key ->
                val value = (node.fields[key] as? Json.Str)?.value ?: return@any false
                value.contains("/chapter/")
            }

    private fun firstString(node: Json.Obj, keys: Set<String>): String? {
        keys.forEach { key ->
            val value = (node.fields[key] as? Json.Str)?.value?.trim()
            if (!value.isNullOrEmpty()) return value
        }
        return null
    }

    private fun firstInt(node: Json.Obj, keys: Set<String>): Int? {
        keys.forEach { key ->
            val value = (node.fields[key] as? Json.Num)?.value ?: return@forEach
            if (value.isFinite() && value >= 0) return value.toInt()
        }
        return null
    }

    private fun numberOf(node: Json.Obj, key: String): Long? {
        val value = (node.fields[key] as? Json.Num)?.value ?: return null
        return if (value.isFinite()) value.toLong() else null
    }

    private fun numberText(value: Json?): String? = when (value) {
        is Json.Num -> if (value.value.isFinite()) formatNumberExact(value.value) else null
        is Json.Str -> value.value.trim().takeIf { it.isNotEmpty() }
        else -> null
    }

    private fun formatNumberExact(value: Double): String =
        if (value == Math.floor(value) && Math.abs(value) < 1e15) value.toLong().toString() else value.toString()

    private fun absoluteImage(raw: String?): Json? {
        val url = toAbsoluteUrl(raw) ?: return null
        return if (url.startsWith("https://") || url.startsWith("http://")) Json.Str(url) else null
    }

    private fun put(fields: MutableMap<String, Json>, key: String, value: Json?) {
        if (value != null) fields[key] = value
    }

    private fun encodeQuery(value: String): String =
        value.trim().take(120).map { char ->
            if (char.isLetterOrDigit() || char in "-_.~") char.toString() else {
                "%" + char.code.toString(16).uppercase().padStart(2, '0')
            }
        }.joinToString("")

    private fun siteChanged(message: String) = CompanionException(
        ErrorCode.SITE_CHANGED,
        "NovTales' page layout changed and the companion could not read it. $message",
    )

    private const val SITE_ORIGIN = Config.SITE_ORIGIN
}

/**
 * A minimal reader for the Next.js App Router streaming payload.
 *
 * The page ships its data as a sequence of `self.__next_f.push([1,"..."])` calls.
 * Once the string arguments are JSON-decoded and concatenated, the result is a
 * run of `id:value` chunks where values may reference each other by id. This
 * object decodes the chunks, resolves those references, and then lets callers
 * search the resolved tree.
 *
 * The balanced-value scanner below is hand written on purpose: no `eval`, no
 * `Function` constructor, and no regex that could run past a string boundary.
 * Website strings are data, never code.
 */
object NextFlight {

    private const val MAX_DEPTH = 40
    private const val MAX_NODES = 60_000

    /**
     * Collects every `self.__next_f.push([1,"..."])` payload out of the page's
     * inline scripts and concatenates the decoded chunks in document order.
     *
     * Each encoded string is JSON-decoded with a real JSON parser (never `eval`),
     * so escaped quotes and line continuations survive intact.
     */
    fun decodeInlineScripts(scriptTexts: List<String>): String {
        val builder = StringBuilder(64 * 1024)
        for (text in scriptTexts) {
            appendPushCalls(text, builder)
        }
        return builder.toString()
    }

    private val PUSH_CALL = Regex("self\\.__next_f\\.push\\(\\s*\\[\\s*\\d+\\s*,\\s*")
    private val JSON_STRING = Regex("\"(?:[^\"\\\\]|\\\\.)*\"")

    private fun appendPushCalls(text: String, out: StringBuilder) {
        var cursor = 0
        while (cursor < text.length) {
            val match = PUSH_CALL.find(text, cursor) ?: return
            val valueStart = match.range.last + 1
            if (valueStart >= text.length || text[valueStart] != '"') {
                cursor = match.range.last + 1
                continue
            }
            val literal = JSON_STRING.find(text, valueStart)
                ?.takeIf { it.range.first == valueStart }
            if (literal == null) {
                // Hoisted out of any lambda: `continue` inside an inline lambda
                // is an experimental language feature this build does not enable.
                cursor = match.range.last + 1
                continue
            }
            val decoded = try {
                // JSON.parse of one string literal: no code from the site is executed.
                when (val parsed = Json.parse(literal.value)) {
                    is Json.Str -> parsed.value
                    else -> null
                }
            } catch (_: Exception) {
                null
            }
            if (decoded != null) out.append(decoded)
            cursor = literal.range.last + 1
        }
    }

    /**
     * Normalises whatever the adapter handed back into a search root.
     *
     * Accepts the `{ok, key, source, value}` envelope, a bare JSON value, or the
     * decoded flight text itself. Cross-chunk `$L12` references are followed once,
     * against a table built in a single pass, so the tree is fully resolved
     * before anything searches it.
     */
    fun rootOf(payload: Json?): Json? {
        if (payload == null) return null
        val seed: Json = when (payload) {
            is Json.Obj -> payload.fields["flight"]?.takeIf { it is Json.Str }
                ?: payload.fields["value"]?.takeIf { it !is Json.Null }
                ?: payload.fields["data"]?.takeIf { it !is Json.Null }
                ?: payload
            else -> payload
        }
        val forest = toForest(seed) ?: return null
        val roots = if (forest.values.isNotEmpty()) forest.values else ArrayList(forest.refs.values)
        if (roots.isEmpty()) return null
        val table = ReferenceTable(forest.refs)
        return if (roots.size == 1) {
            table.resolve(roots[0], 0)
        } else {
            Json.Arr(roots.map { table.resolve(it, 0) })
        }
    }

    /** Top level values of a flight payload plus the cross-reference table. */
    class Forest(val values: MutableList<Json>, val refs: MutableMap<String, Json>)

    private fun toForest(seed: Json): Forest? = when (seed) {
        is Json.Str -> {
            val text = seed.value.trim()
            if (text.isEmpty()) null else if (text[0] == '{' || text[0] == '[') {
                val parsed = try { Json.parse(text) } catch (_: Exception) { null }
                if (parsed != null) Forest(mutableListOf(parsed), HashMap()) else flightForest(text)
            } else {
                flightForest(text)
            }
        }
        else -> Forest(mutableListOf(seed), HashMap())
    }

    /**
     * Follows React Flight references. Only an id that exists as a chunk in the
     * same payload is followed, so an ordinary string starting with `$` is left
     * alone, and a reference cycle terminates on the depth limit.
     */
    private class ReferenceTable(private val refs: Map<String, Json>) {
        private var budget = MAX_NODES

        fun resolve(value: Json, depth: Int): Json {
            if (depth > MAX_DEPTH || budget-- <= 0) return value
            return when (value) {
                is Json.Str -> {
                    val reference = referenceOf(value.value)
                    val target = if (reference == null) null else refs[reference]
                    if (target == null || target === value) value else resolve(target, depth + 1)
                }
                is Json.Arr -> Json.Arr(value.items.map { resolve(it, depth + 1) })
                is Json.Obj -> Json.Obj(value.fields.mapValues { resolve(it.value, depth + 1) })
                else -> value
            }
        }
    }

    /**
     * React Flight chunk ids look like `12`, `$L12`, `$@12` or `$12`. Only an id
     * of a plausible shape is even considered a reference.
     */
    private fun referenceOf(value: String): String? {
        if (value.length < 2 || value.length > 24) return null
        if (value[0] != '$') return null
        var index = 1
        if (index < value.length && (value[index] == 'L' || value[index] == 'I' || value[index] == '@')) index++
        val id = value.substring(index)
        return if (id.isNotEmpty() && id.all { char -> char.isLetterOrDigit() || char == '_' }) id else null
    }

    // ---- Balanced scanner ---------------------------------------------------

    /**
     * Extracts the balanced JSON value that follows `"key":` in [text].
     *
     * Brace and bracket depth are tracked by hand and string literals are skipped
     * with their escapes, so a `}` inside a chapter title can never end the
     * value early. Returns null when the key is absent or the value is truncated.
     */
    fun extractBalancedValue(text: String, key: String): String? {
        val needle = "\"$key\""
        var cursor = text.indexOf(needle)
        while (cursor >= 0) {
            var index = cursor + needle.length
            while (index < text.length && text[index].isWhitespace()) index++
            if (index < text.length && text[index] == ':') {
                index++
                while (index < text.length && text[index].isWhitespace()) index++
                val end = scanBalanced(text, index)
                if (end > index) return text.substring(index, end)
            }
            cursor = text.indexOf(needle, cursor + needle.length)
        }
        return null
    }

    /** Returns the exclusive end index of the JSON value starting at [start], or -1. */
    fun scanBalanced(text: String, start: Int): Int {
        if (start >= text.length) return -1
        var index = start
        while (index < text.length && text[index].isWhitespace()) index++
        if (index >= text.length) return -1
        val open = text[index]
        if (open != '{' && open != '[') {
            // A scalar value: a quoted string, a number, or a literal.
            if (open == '"') {
                var cursor = index + 1
                while (cursor < text.length) {
                    if (text[cursor] == '\\') { cursor += 2; continue }
                    if (text[cursor] == '"') return cursor + 1
                    cursor++
                }
                return -1
            }
            var cursor = index
            while (cursor < text.length && text[cursor] != ',' && text[cursor] != '}' &&
                text[cursor] != ']' && !text[cursor].isWhitespace()
            ) cursor++
            return if (cursor > index) cursor else -1
        }
        var depth = 0
        while (index < text.length) {
            val char = text[index]
            when {
                char == '"' -> {
                    index++
                    while (index < text.length) {
                        if (text[index] == '\\') { index += 2; continue }
                        if (text[index] == '"') break
                        index++
                    }
                    if (index >= text.length) return -1
                }
                char == '{' || char == '[' -> depth++
                char == '}' || char == ']' -> {
                    depth--
                    if (depth == 0) return index + 1
                }
            }
            index++
        }
        return -1
    }

    /**
     * Pulls the top level JSON values out of concatenated flight text and parses
     * them. Chunks prefixed with an id (`12:[...]`) are also indexed so a later
     * `$L12` reference can be resolved.
     */
    fun parseFlightText(text: String): Forest {
        val values = ArrayList<Json>()
        val refs = HashMap<String, Json>()
        var index = 0
        var budget = MAX_NODES
        while (index < text.length && budget-- > 0) {
            val char = text[index]
            // Flight text rows are byte-length-prefixed, not JSON strings.
            // Quotes/braces in an image caption or synopsis must not swallow
            // later rows. Preserve the text too, for referenced long fields.
            if (char == 'T') {
                val id = idBefore(text, index)
                val comma = text.indexOf(',', index + 1)
                if (id != null && comma in (index + 2)..(index + 10)) {
                    val bytes = text.substring(index + 1, comma).toIntOrNull(16)
                    val end = bytes?.let { textRowEnd(text, comma + 1, it) }
                    if (end != null) {
                        refs.putIfAbsent(id, Json.Str(text.substring(comma + 1, end)))
                        index = end
                        continue
                    }
                }
            }
            when {
                char == '"' -> {
                    val id = idBefore(text, index)
                    val start = index
                    index++
                    while (index < text.length) {
                        if (text[index] == '\\') { index += 2; continue }
                        if (text[index] == '"') break
                        index++
                    }
                    if (index < text.length && id != null) {
                        // A string chunk is still addressable by id.
                        val parsed = try { Json.parse(text.substring(start, index + 1)) } catch (_: Exception) { null }
                        if (parsed != null) refs.putIfAbsent(id, parsed)
                    }
                    index++
                }
                char == '{' || char == '[' -> {
                    val id = idBefore(text, index)
                    val end = scanBalanced(text, index)
                    if (end <= index) { index++; continue }
                    val slice = text.substring(index, end)
                    val parsed = try {
                        Json.parse(slice)
                    } catch (_: Exception) {
                        index = end
                        continue
                    }
                    values.add(parsed)
                    if (id != null) refs.putIfAbsent(id, parsed)
                    index = end
                }
                else -> index++
            }
        }
        return Forest(values, refs)
    }

    private fun textRowEnd(text: String, start: Int, byteLength: Int): Int? {
        if (byteLength < 0 || byteLength > 4_000_000) return null
        var index = start
        var consumed = 0
        while (index < text.length && consumed < byteLength) {
            val point = text.codePointAt(index)
            consumed += when {
                point <= 0x7f -> 1
                point <= 0x7ff -> 2
                point <= 0xffff -> 3
                else -> 4
            }
            index += Character.charCount(point)
        }
        return index.takeIf { consumed == byteLength }
    }

    private fun flightForest(text: String): Forest = parseFlightText(text)

    /** The `12:` chunk id immediately preceding [at], if any. */
    private fun idBefore(text: String, at: Int): String? {
        var index = at - 1
        while (index >= 0 && (text[index].isWhitespace() || text[index] == ',')) index--
        if (index < 0 || text[index] != ':') return null
        index--
        val end = index + 1
        while (index >= 0 && (text[index].isLetterOrDigit() || text[index] == '_' || text[index] == '-')) index--
        val id = text.substring(index + 1, end)
        return if (id.isNotEmpty() && id.length <= 24) id else null
    }

    // ---- Tree search --------------------------------------------------------

    /**
     * Returns the array in [root] whose elements match [predicate], preferring
     * the one with the most matches. Novel and chapter listings both live in
     * arrays whose key name has changed at least once, so the shape of the
     * elements is a more durable signal than the key.
     */
    fun findArray(root: Json?, predicate: (Json.Obj) -> Boolean): List<Json.Obj>? {
        val best = ArrayList<Json.Obj>()
        var bestCount = 0
        walk(root) { node ->
            if (node is Json.Arr) {
                val objects = node.items.filterIsInstance<Json.Obj>()
                if (objects.isEmpty()) return@walk
                val matching = objects.filter(predicate)
                if (matching.isNotEmpty() && matching.size > bestCount) {
                    bestCount = matching.size
                    best.clear()
                    best.addAll(matching)
                }
            }
        }
        return best.takeIf { it.isNotEmpty() }
    }

    /** Returns the richest object in [root] that matches [predicate]. */
    fun findObject(root: Json?, predicate: (Json.Obj) -> Boolean): Json.Obj? {
        var best: Json.Obj? = null
        var bestScore = -1
        walk(root) { node ->
            if (node is Json.Obj && predicate(node)) {
                val score = node.fields.size
                if (score > bestScore) {
                    bestScore = score
                    best = node
                }
            }
        }
        return best
    }

    fun findInt(root: Json?, keys: Set<String>): Int? {
        var found: Int? = null
        walk(root) { node ->
            if (node is Json.Obj && found == null) {
                keys.forEach { key ->
                    val value = (node.fields[key] as? Json.Num)?.value
                    if (value != null && value.isFinite() && value >= 0 && found == null) {
                        found = value.toInt()
                    }
                }
            }
        }
        return found
    }

    fun findBoolean(root: Json?, keys: Set<String>): Boolean? {
        var found: Boolean? = null
        walk(root) { node ->
            if (node is Json.Obj && found == null) {
                keys.forEach { key ->
                    val value = (node.fields[key] as? Json.Bool)?.value
                    if (value != null && found == null) found = value
                }
            }
        }
        return found
    }

    private inline fun walk(root: Json?, visit: (Json) -> Unit) {
        if (root == null) return
        val stack = ArrayDeque<Json>()
        stack.addLast(root)
        // Identity, not equality: two identical title strings are two places in
        // the payload, and only containers need cycle protection.
        val seen: MutableSet<Json> =
            java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Json, Boolean>())

        var budget = MAX_NODES
        while (stack.isNotEmpty() && budget-- > 0) {
            val node = stack.removeLast()
            if ((node is Json.Arr || node is Json.Obj) && !seen.add(node)) continue
            visit(node)
            when (node) {
                is Json.Arr -> node.items.forEach { stack.addLast(it) }
                is Json.Obj -> node.fields.values.forEach { stack.addLast(it) }
                else -> Unit
            }
        }
    }
}
