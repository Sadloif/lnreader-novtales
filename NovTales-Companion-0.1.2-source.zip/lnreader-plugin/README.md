# NovTales for official LNReader — 2.0.1

Use this TypeScript source plugin with NovTales Companion **0.1.1** on the same Android phone. Official LNReader remains the reader and download manager.

## Setup

1. Install the companion APK and press **Start**.
2. Add or refresh your existing LNReader repository:
   `https://raw.githubusercontent.com/Sadloif/lnreader-novtales/main/plugins.min.json`
3. Install/update NovTales to **2.0.1** after that version has been published.
4. Copy the companion pairing key. Open NovTales in LNReader, open its filter panel, paste the key into **Companion pairing key**, and apply.

The key is a local companion credential, not a NovTales account token. Public chapters do not require sign-in. Site checks, paid access and reading notices require the appropriate action in the companion website.

## Behaviour

Popular/latest catalogue and title/alternative-title search use distinct pages. Novel metadata and ascending chapter pages retain the existing `/novel/{slug}` and `/chapter/{slug}-{number}` paths, including decimals. The plugin accepts only complete chapter HTML. Catalogue errors and incomplete chapter lists stay visible rather than being treated as empty pages.

Keep the companion running while fetching or downloading. Downloaded chapters are stored in LNReader and work offline with the companion stopped. No computer or remote service is used during normal reading.

## Validation

The 2.1.4 tagged LNReader source supports the text pairing filter. The connected Oppo CPH2825 runs Android 16 and official LNReader 2.1.4. See `../REVIEW.md` for the phone evidence and remaining limits.

Run `npm run check`, `npm run build` and `node _working/smoke.mjs`. Type checking expects the official lnreader-plugins checkout at `../../lnreader-plugins`; the production build uses its usual ES5/CommonJS plugin format. The smoke harness tests the compiled JavaScript through LNReader's module wrapper.
