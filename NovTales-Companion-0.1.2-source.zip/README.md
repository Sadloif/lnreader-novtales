# NovTales companion and official LNReader plugin

Reviewed and repaired on 4 October 2026. Use companion **0.1.2** with plugin **2.0.2**.
This is a separate Android app; official LNReader continues to manage your library, reading, downloads and offline chapters.

Read [the review and setup guide](REVIEW.md) for the fixes, evidence and installation steps.

## Deliverables

- `dist/NovTales-Companion-0.1.2.apk` — signed companion APK.
- `dist/NovTales-Companion-0.1.2-source.zip` — reviewed source and plugin, excluding signing secrets.
- `lnreader-plugin/plugins/english/novtales.js` — compiled LNReader plugin.
- `lnreader-plugin/plugins/english/novtales.ts` — editable plugin source.
- `lnreader-plugin/plugins.min.json` — source repository manifest.
- `novtales-companion/` — Kotlin Android project, Gradle wrapper, tests and API documentation.

The original 0.1.0 APK and source ZIP are retained. Historical build reports describe the initial delivery; REVIEW.md and the final verification record describe this repair.

## Pairing: copy once, paste once

Your Oppo is already paired. Updating either app keeps the saved key. These steps are for a new phone or a replacement key:

1. Open **NovTales Companion**, press **Start**, then **Copy pairing key**. A guide appears; tap **Open LNReader**.
2. In official LNReader, choose **Browse → Sources → NovTales**.
3. Tap the **NovTales source name** to open its catalogue, close the search box if it is open, then tap **Filter** at the bottom.
4. Long-press the **Companion pairing key (paste here)** field and tap **Paste**. If a previous key is present, select all and replace it.
5. Tap **Filter** at the top-right of the filter panel. This saves the key and loads the catalogue.

The key is private to this phone. Do not send it to anyone. Use **Reset pairing key** only when you want to replace it; then repeat the steps. Public chapters do not need NovTales sign-in.

Keep the companion running while fetching new content. Keep LNReader open for batch downloads. Saved chapters stay in LNReader and can be read offline with the companion stopped.

## Supported sources

This companion supports **NovTales only**. Other LNReader sources continue to work as usual through their own plugins; they do not use this companion. Adding another site would require a site-specific companion adapter and a compatible plugin.

## Build

Use JDK 17, Android SDK 35 and the committed Gradle wrapper. Run `build.ps1 -Task "testDebugUnitTest lintDebug assembleDebug"` for review. Release packaging requires the original private signing identity in the ignored `keystore.properties`; see `novtales-companion/docs/BUILD.md`. Signing secrets are never part of the source ZIP.

Plugin verification: `npm run check`, `npm run build`, then `node _working/smoke.mjs` from `lnreader-plugin`. The checking configuration expects the official `lnreader-plugins` repository alongside APP; emission uses the official plugin build format.
