/*
 * Tests for app/src/main/assets/adapter/novtales-adapter.js.
 *
 * The adapter is injected JavaScript, so it cannot be reached from the Gradle
 * unit-test source set; these checks run on Node against the mini DOM in
 * mini-dom.js instead. Run with:
 *
 *     node adapter.test.js
 *
 * Every check below is a regression pin. Two of them are for real bugs this
 * suite found:
 *   - `scanBalanced` used to advance twice on a boundary, so the payload value
 *     came back one token late; see "the scan stopped at the novel object, not
 *     one brace late" and "braces inside the synopsis did not end the value
 *     early".
 *   - "End of Chapter 10" was truncated to "End of Chapter 1" by the marker
 *     regex; see section 4.
 *
 * Promoted from _working/b-harness/adapter-check.js, which is kept untouched as
 * the historical record.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const dom = require('./mini-dom.js');

const El = dom.El;
const makeDocument = dom.makeDocument;

const ADAPTER = path.join(
  __dirname, '..', '..', 'app', 'src', 'main', 'assets', 'adapter', 'novtales-adapter.js'
);
if (!fs.existsSync(ADAPTER)) {
  console.error('adapter not found at ' + ADAPTER);
  process.exit(2);
}
const source = fs.readFileSync(ADAPTER, 'utf8');

let failCount = 0, passCount = 0;
function check(name, condition, extra) {
  if (condition) { passCount++; console.log('  ok   ' + name); }
  else { failCount++; console.log('  FAIL ' + name + (extra !== undefined ? ' :: ' + extra : '')); }
}

function run(env) {
  global.window = env.window;
  global.self = env.window;
  global.document = env.document;
  global.location = env.location;
  global.NodeFilter = { SHOW_TEXT: 4, FILTER_ACCEPT: 1, FILTER_REJECT: 2 };
  new Function(source)();
}

function baseEnv(root, pathname, title) {
  return {
    window: {
      __next_f: [],
      fetch: () => {},
      scrollTo: () => {},
      getComputedStyle: () => ({ display: 'block', visibility: 'visible' })
    },
    document: makeDocument(root, title),
    location: { pathname: pathname, href: 'https://novtales.com' + pathname }
  };
}

/* ---- 1. payload extraction ------------------------------------------------ */

console.log('\n[1] __novExtractPayload');

const novelPayload = {
  title: 'Surviving the Game as a Barbarian',
  slug: 'surviving-the-game-as-a-barbarian',
  author: 'Nobody',
  coverUrl: 'https://cdn.novtales.com/covers/x.jpg',
  synopsis: 'A brace } and a { bracket and an escaped \\" quote.',
  genres: ['Action', 'Drama'],
  status: 'HIATUS',
  ratingAverage: 4.42,
  chapterTotalPages: 79,
  chapterList: [
    { number: 2, title: 'Two', slug: 'surviving-the-game-as-a-barbarian-2' },
    { number: 944.5, title: 'Half', slug: 'surviving-the-game-as-a-barbarian-944.5' },
    { number: 1, title: 'One', slug: 'surviving-the-game-as-a-barbarian-1' }
  ]
};

// Real flight chunks are already decoded strings in self.__next_f, so the
// harness must NOT double-encode them.
const chunk1 = '7:["$","x",null,{"novel":' + JSON.stringify(novelPayload) + ',"other":{"tricky":"}}}"}}]}]\n';
const chunk2 = '8:["tail"]\n';

let env = baseEnv(new El('main', {}), '/novel/x', 'NovTales');
env.window.__next_f = [[1, chunk1], [1, chunk2]];
run(env);

let out = JSON.parse(window.__novExtractPayload('novel'));
check('novel payload found by key', out.ok === true && out.source === 'next_f:novel', JSON.stringify(out).slice(0, 200));
check('title survived', out.value && out.value.title === novelPayload.title);
check('braces inside the synopsis did not end the value early', out.value && out.value.synopsis === novelPayload.synopsis);
check(
  'the scan stopped at the novel object, not one brace late',
  out.value && Object.keys(out.value).length === Object.keys(novelPayload).length,
  out.value ? JSON.stringify(Object.keys(out.value)) : 'no value'
);
check('decimal chapter numbers survived', out.value && out.value.chapterList[1].number === 944.5);

out = JSON.parse(window.__novExtractPayload('chapter'));
check('structural fallback when the key is absent', out.ok === true, JSON.stringify(out).slice(0, 120));

/* structural fallback with NO key from any alias list */
env = baseEnv(new El('main', {}), '/novel/x', 'NovTales');
env.window.__next_f = [[1, '3:["$","x",null,' + JSON.stringify({ deep: { book: novelPayload } }) + ']\n']];
run(env);
out = JSON.parse(window.__novExtractPayload('novel'));
check('structural fallback works with no matching key', out.ok === true && out.source === 'next_f:structural', JSON.stringify(out).slice(0, 120));

/* the inline <script> path: build the call the way the page really emits it */
const scriptChunk = '5:["$","x",null,{"novel":' + JSON.stringify(novelPayload) + '}]\n';
const scriptEl = new El('script', { text: 'self.__next_f.push([1,' + JSON.stringify(scriptChunk) + ']);' });
env = baseEnv(new El('main', { children: [scriptEl] }), '/novel/x', 'NovTales');
run(env);
out = JSON.parse(window.__novExtractPayload('novel'));
check('inline script push() path decodes too', out.ok === true, JSON.stringify(out).slice(0, 160));

/* nothing at all */
run(baseEnv(new El('main', {}), '/novel/x', 'NovTales'));
out = JSON.parse(window.__novExtractPayload('novel'));
check('empty payload reports ok:false rather than throwing', out.ok === false && out.value === null);

/* ---- 2. chapter state, finished ------------------------------------------- */

console.log('\n[2] __novChapterState (finished chapter)');

function chapterDom(markerText, loading) {
  const marker = new El('span', { text: markerText });
  const body = new El('div', {
    attrs: { class: 'nv-chapter-body relative' },
    innerHTML: '<p>One.</p><p>Two.</p><p>Three.</p>',
    children: [new El('p', { text: 'One.' }), new El('p', { text: 'Two.' }), new El('p', { text: 'Three.' })]
  });
  const articleChildren = [new El('h2', { text: 'Chapter 1: The Start' }), body, marker];
  const article = new El('article', { children: articleChildren });
  const mainChildren = [article];
  if (loading) mainChildren.push(new El('section', { attrs: { 'aria-label': 'Loading chapter' } }));
  return new El('main', { children: mainChildren });
}

let root = chapterDom('End of Chapter 1', false);
run(baseEnv(root, '/chapter/surviving-the-game-as-a-barbarian-1', 'Chapter 1 - NovTales'));

let state = JSON.parse(window.__novChapterState(false));
check('path reported', state.path === '/chapter/surviving-the-game-as-a-barbarian-1', state.path);
check('chapterNumber from the article h2', state.chapterNumber === '1', state.chapterNumber);
check('heading captured', state.heading === 'Chapter 1: The Start', state.heading);
check('end marker found exactly', state.endMarker === 'End of Chapter 1', JSON.stringify(state.endMarker));
check('endMarkerNumber parsed', state.endMarkerNumber === '1');
check('body omitted on the cheap poll', state.bodyHtml === '');
check('bodyLength reported', state.bodyLength > 0, state.bodyLength);
check('not still loading', state.stillLoading === false);
check('no user flags', !state.signInRequired && !state.membershipRequired && !state.verificationRequired);

state = JSON.parse(window.__novChapterState(true));
check('body present on the full poll', state.bodyHtml.indexOf('<p>Three.</p>') > 0, state.bodyHtml);

const scroll = JSON.parse(window.__novScrollForMore());
check('scroll returns the before-length for growth comparison', scroll.requested === true && scroll.beforeLength === state.bodyLength);

/* ---- 3. negative markers -------------------------------------------------- */

console.log('\n[3] negative markers');

run(Object.assign(baseEnv(new El('main', { children: [new El('div', { text: "We're verifying your browser" })] }), '/', ''), {
  document: makeDocument(new El('main', { children: [new El('div', { text: "We're verifying your browser" })] }), 'Vercel Security Checkpoint')
}));
state = JSON.parse(window.__novChapterState(false));
check('Vercel Security Checkpoint detected as verification', state.verificationRequired === true);
check('a challenge is not reported as rate limited', state.rateLimited === false);

run(Object.assign(baseEnv(new El('main', {}), '/', ''), {
  document: makeDocument(new El('main', { children: [new El('div', { text: 'Too Many Requests' })] }), 'NovTales')
}));
state = JSON.parse(window.__novChapterState(false));
check('plain 429 copy is rate limited, NOT verification', state.rateLimited === true && state.verificationRequired === false);

const signedOutRoot = new El('main', {
  children: [
    new El('div', { text: 'Protected reading is paused — Sign in' }),
    new El('div', { attrs: { class: 'nv-chapter-body' }, innerHTML: '' })
  ]
});
run(baseEnv(signedOutRoot, '/chapter/some-slug-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(false));
check('signed-out copy detected', state.signInRequired === true);
check('empty body reports zero length', state.bodyLength === 0);
check('a sign-in page is not reported as verification', state.verificationRequired === false);

run(baseEnv(new El('main', { children: [new El('h2', { text: 'Unlock Access' })] }), '/chapter/some-slug-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(false));
check('Unlock Access detected as membership', state.membershipRequired === true);

/* chapter prose must never trip the chrome detectors: the prose lives INSIDE
   .nv-chapter-body, which is excluded from every chrome scan */
const proseBody = new El('div', {
  attrs: { class: 'nv-chapter-body' },
  innerHTML: '<p>prose</p>',
  children: [new El('p', {
    text: 'Sign in to read the rest of this chapter. Unlock Access is a premium chapter feature. ' +
          'We are verifying your browser is not needed here.'
  })]
});
const proseRoot = new El('main', { children: [proseBody] });
run(baseEnv(proseRoot, '/chapter/some-slug-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(false));
check('chapter prose does not fake a sign-in prompt', state.signInRequired === false);
check('chapter prose does not fake a pay wall', state.membershipRequired === false);
check('chapter prose does not fake a challenge', state.verificationRequired === false);

/* ---- 4. marker must not match a longer number ---------------------------- */

console.log('\n[4] marker matching');
run(baseEnv(chapterDom('End of Chapter 10', false), '/chapter/surviving-the-game-as-a-barbarian-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(false));
check('"End of Chapter 10" is reported verbatim, never truncated to 1', state.endMarker === 'End of Chapter 10', JSON.stringify(state.endMarker));
check('marker number is 10, not 1', state.endMarkerNumber === '10');

/* ---- 5. still loading ---------------------------------------------------- */

console.log('\n[5] still loading');
run(baseEnv(chapterDom('End of Chapter 1', true), '/chapter/surviving-the-game-as-a-barbarian-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(false));
check('Loading chapter section sets stillLoading', state.stillLoading === true);

/* ---- 6. the marker must come from a place the sanitiser keeps ------------- */

console.log('\n[6] marker vs. dropped/hidden subtrees');

/*
 * REGRESSION (bug 2, critical). `findEndMarker` walked *every* text node of the
 * article with no tag and no visibility test, while `HtmlSanitiser` deletes
 * <script>, <style>, <template>, <noscript>, `hidden`, `aria-hidden="true"` and
 * `display:none` together with their subtrees. A preview whose only marker sat
 * inside one of those was stored as a complete chapter - a one-sentence preview
 * with `complete: true` and no signal to the reader.
 *
 * The invariant these pin: the marker and the stored body are read from the same
 * view of the document.
 */

function markerOnly(bodyChildren) {
  const body = new El('div', { attrs: { class: 'nv-chapter-body' }, children: bodyChildren });
  const article = new El('article', { children: [body] });
  run(baseEnv(new El('main', { children: [article] }), '/chapter/myslug-10', 'NovTales'));
  return JSON.parse(window.__novChapterState(true));
}

function P(tag, text, attrs) { return new El(tag, { text: text, attrs: attrs || {} }); }

const PREVIEW = P('p', 'Only a preview sentence.');

const DROPPED_MARKERS = [
  ['script', new El('script', { text: 'var d = "End of Chapter 10";' })],
  ['style', new El('style', { text: '/* End of Chapter 10 */' })],
  ['template', new El('template', { text: 'End of Chapter 10' })],
  ['noscript', new El('noscript', { text: 'End of Chapter 10' })],
  ['iframe', new El('iframe', { text: 'End of Chapter 10' })],
  ['aria-hidden container', new El('div', { attrs: { 'aria-hidden': 'true' }, children: [P('p', 'End of Chapter 10')] })],
  ['hidden attribute', new El('div', { attrs: { hidden: '' }, children: [P('p', 'End of Chapter 10')] })],
  ['display:none container', new El('div', { attrs: { style: 'display:none' }, children: [P('p', 'End of Chapter 10')] })]
];

for (const [label, marker] of DROPPED_MARKERS) {
  const st = markerOnly([PREVIEW, marker]);
  check(
    'a marker only inside ' + label + ' is NOT an end marker',
    st.endMarker === '',
    JSON.stringify(st.endMarker)
  );
  check('a marker only inside ' + label + ' yields no chapter number from it', st.endMarkerNumber === '');
}

/* A marker in ordinary prose is still found, so the filter above is not just
   "find nothing ever". */
let kept = markerOnly([PREVIEW, P('p', 'End of Chapter 10')]);
check('a marker in plain prose is still found', kept.endMarker === 'End of Chapter 10', JSON.stringify(kept.endMarker));
check('and it still yields the number', kept.endMarkerNumber === '10');

/* A hidden *container* around an otherwise ordinary marker, with the marker also
   present in a kept node: the kept one must win, not the hidden one. */
let mixed = markerOnly([
  new El('div', { attrs: { 'aria-hidden': 'true' }, children: [P('p', 'End of Chapter 9')] }),
  P('p', 'End of Chapter 10')
]);
check('the kept marker wins over one inside a hidden container', mixed.endMarker === 'End of Chapter 10', JSON.stringify(mixed.endMarker));

/* visibility:hidden, the sibling of display:none that isHidden also drops. */
let vis = markerOnly([PREVIEW, new El('div', { attrs: { style: 'visibility:hidden' }, children: [P('p', 'End of Chapter 10')] })]);
check('visibility:hidden is treated like display:none', vis.endMarker === '', JSON.stringify(vis.endMarker));

/* ---- 7. marker selection, case and node splitting ------------------------ */

console.log('\n[7] marker selection, case and node splitting');

/*
 * REGRESSION (bug 3, liveness). Three defects, all of which made a visibly
 * complete chapter fail forever instead of being delivered:
 *   - the LAST matching node won, so a "previous chapter" teaser after the real
 *     marker produced `End of Chapter 9` and a WRONG_CHAPTER failure;
 *   - the adapter matched case-insensitively but Kotlin's END_MARKER was
 *     case-sensitive, so `end of chapter 10` was found here and rejected there;
 *   - only one text node's raw value was ever considered, and any node over 200
 *     characters was discarded, so a marker split across nodes, split across a
 *     <br>, produced by React's `End of Chapter {n}`, or sitting in a long node
 *     was missed.
 */

let first = markerOnly([P('p', 'End of Chapter 10'), P('p', 'prose'), P('p', 'End of Chapter 9')]);
check('the FIRST marker wins, not the last', first.endMarker === 'End of Chapter 10', JSON.stringify(first.endMarker));
check('the first marker yields the right number', first.endMarkerNumber === '10');

/* Case: the adapter accepts any case, so Kotlin must too. */
for (const [label, text] of [
  ['lowercase', 'end of chapter 10'],
  ['uppercase', 'END OF CHAPTER 10'],
  ['shouting', 'End Of Chapter 10']
]) {
  const st = markerOnly([P('p', 'Real prose.'), P('p', text)]);
  check(label + ' marker is reported verbatim', st.endMarker === text, JSON.stringify(st.endMarker));
  check(label + ' marker yields number 10', st.endMarkerNumber === '10');
}

/* Split across sibling text nodes - the React `End of Chapter {n}` shape. */
let split = markerOnly([P('p', 'Real prose.'), new El('span', { children: [P('span', 'End of Chapter '), P('b', '10')] })]);
check('a marker split across sibling nodes reassembles', split.endMarker === 'End of Chapter 10', JSON.stringify(split.endMarker));
check('the reassembled marker yields the number', split.endMarkerNumber === '10');

/* Split across a <br>. */
let brSplit = markerOnly([
  P('p', 'Real prose.'),
  new El('p', { children: [new El('br'), P('span', 'End of'), new El('br'), P('span', 'Chapter 10')] })
]);
check('a marker split across <br> reassembles', brSplit.endMarker === 'End of Chapter 10', JSON.stringify(brSplit.endMarker));

/*
 * A long document. The old code discarded any node over 200 characters, so a
 * marker could be lost because of what came *before* it. The marker element
 * itself is short now - it has to be, it must be nothing but the marker - so
 * the shape that has to survive is a lot of prose in front of it.
 */
let long = markerOnly([P('p', 'Real prose here. '.repeat(60)), P('p', 'End of Chapter 10')]);
check('a marker after 960 characters of prose is still found', long.endMarker === 'End of Chapter 10', JSON.stringify(long.endMarker));
check('...and still yields the number', long.endMarkerNumber === '10', JSON.stringify(long.endMarkerNumber));

/*
 * Trailing prose in the same element is NOT a marker any more. It used to be
 * trimmed to one, which is exactly the 2-02 defect: "End of Chapter 12 was the
 * night the gate opened." is a sentence, not a marker. Pinned as a negative so
 * the change cannot be undone silently.
 */
let trailing = markerOnly([P('p', 'Real prose.'), P('p', 'End of Chapter 10 and that was that.')]);
check('trailing prose in the same element is not a marker', trailing.endMarker === '', JSON.stringify(trailing.endMarker));
check('...and yields no chapter number', trailing.endMarkerNumber === '', JSON.stringify(trailing.endMarkerNumber));

/*
 * Leading zeros. The site writes `End of Chapter 010` for chapter 10 and the
 * string must cross the bridge exactly as written, because Kotlin's END_MARKER
 * is what decides, not this side.
 */
let padded = markerOnly([P('p', 'Real prose.'), P('p', 'End of Chapter 010')]);
check('a leading-zero chapter number is reported verbatim', padded.endMarker === 'End of Chapter 010', JSON.stringify(padded.endMarker));
check('...and yields 010', padded.endMarkerNumber === '010', JSON.stringify(padded.endMarkerNumber));

/* Decimal chapter numbers still survive intact. */
let decimal = markerOnly([P('p', 'Real prose.'), P('p', 'End of Chapter 944.5')]);
check('a decimal chapter number survives', decimal.endMarker === 'End of Chapter 944.5', JSON.stringify(decimal.endMarker));
check('a decimal chapter number parses', decimal.endMarkerNumber === '944.5');

/* A large integer must not be truncated (the 2^53 class of bug). */
let big = markerOnly([P('p', 'Real prose.'), P('p', 'End of Chapter 9007199254740993')]);
check('a 16-digit chapter number is reported in full', big.endMarkerNumber === '9007199254740993', big.endMarkerNumber);

/* ---- 8. the two drop lists are one rule ---------------------------------- */

console.log('\n[8] SANITISER_DROP_TAGS and DROP_SUBTREE_TAGS are the same list');

/*
 * The end marker and the chapter body have to be read from the SAME view of the
 * document: a marker the sanitiser deletes cannot be part of the stored chapter,
 * so it cannot complete it. That rule is written down twice - here, as
 * `SANITISER_DROP_TAGS`, and in `HtmlSanitiser.kt` as `DROP_SUBTREE_TAGS` - and
 * nothing but this section stops one being edited without the other. When they
 * drifted, a marker inside a deleted subtree completed a chapter whose stored
 * body was a single preview sentence.
 *
 * This is a source-level pin on purpose. A behavioural check can only cover the
 * tags the mini DOM happens to implement, which is how a drift on `svg` or
 * `math` would slip through; comparing the two declared lists covers every entry.
 */
const SANITISER = path.join(
  __dirname, '..', '..', 'app', 'src', 'main', 'kotlin', 'com', 'sadloif',
  'novtalescompanion', 'web', 'HtmlSanitiser.kt'
);
if (!fs.existsSync(SANITISER)) {
  console.error('HtmlSanitiser.kt not found at ' + SANITISER);
  process.exit(2);
}
const sanitiserSource = fs.readFileSync(SANITISER, 'utf8');

/**
 * Every lower-case tag name inside a Kotlin `setOf(...)` declaration.
 * Returns null when the declaration cannot be found, so a rename is a failure
 * rather than an empty set that silently matches nothing.
 */
function kotlinDropTags(text) {
  const at = text.indexOf('DROP_SUBTREE_TAGS');
  if (at < 0) return null;
  const open = text.indexOf('(', at);
  const close = text.indexOf(')', open);
  if (open < 0 || close < 0) return null;
  return (text.slice(open, close).match(/"([a-z][a-z0-9-]*)"/g) || [])
    .map(t => t.slice(1, -1)).sort();
}

/** Every key of the adapter's `SANITISER_DROP_TAGS = { tag: 1, ... }` literal. */
function adapterDropTags(text) {
  const at = text.indexOf('SANITISER_DROP_TAGS');
  if (at < 0) return null;
  const open = text.indexOf('{', at);
  const close = text.indexOf('}', open);
  if (open < 0 || close < 0) return null;
  return (text.slice(open, close).match(/([a-z][a-z0-9-]*)\s*:\s*1\b/g) || [])
    .map(pair => pair.split(':')[0].trim()).sort();
}

const jsTags = adapterDropTags(source);
const kotlinTags = kotlinDropTags(sanitiserSource);

check('the adapter declaration was found', jsTags !== null && jsTags.length > 0, String(jsTags));
check('the sanitiser declaration was found', kotlinTags !== null && kotlinTags.length > 0, String(kotlinTags));
check(
  'both lists declare the same tags, in the same order',
  jsTags !== null && kotlinTags !== null && jsTags.join(',') === kotlinTags.join(','),
  'adapter:   ' + jsTags + '\n       sanitiser: ' + kotlinTags
);
check(
  'only the tags both sides drop are listed',
  jsTags !== null && kotlinTags !== null &&
    jsTags.every(t => kotlinTags.indexOf(t) >= 0) &&
    kotlinTags.every(t => jsTags.indexOf(t) >= 0),
  'adapter-only: ' + (jsTags || []).filter(t => (kotlinTags || []).indexOf(t) < 0) +
    '  sanitiser-only: ' + (kotlinTags || []).filter(t => (jsTags || []).indexOf(t) < 0)
);
check('the list is not empty of substance', jsTags !== null && jsTags.length >= 20, String(jsTags && jsTags.length));
check(
  'script, style and template are in both, so the original repro cannot come back',
  jsTags !== null && kotlinTags !== null &&
    ['script', 'style', 'template'].every(t => jsTags.indexOf(t) >= 0 && kotlinTags.indexOf(t) >= 0)
);

/*
 * The pin is only worth having if it can fail. Extracting from a *perturbed
 * copy* of each source proves both directions: one extra tag on either side is
 * caught, and the helper reports a missing declaration as null rather than an
 * empty list that would match the other empty list.
 */
const perturbedAdapter = adapterDropTags(source.replace('script: 1,', 'script: 1, marquee: 1,'));
const perturbedSanitiser = kotlinDropTags(sanitiserSource.replace('"script",', '"script", "marquee",'));
check(
  'an extra tag on the adapter side alone is caught',
  perturbedAdapter !== null && perturbedAdapter.join(',') !== kotlinTags.join(','),
  'adapter: ' + perturbedAdapter
);
check(
  'an extra tag on the sanitiser side alone is caught',
  perturbedSanitiser !== null && perturbedSanitiser.join(',') !== jsTags.join(','),
  'sanitiser: ' + perturbedSanitiser
);
check(
  'a tag removed from one side alone is caught too',
  adapterDropTags(source.replace('template: 1, ', '')) !== null &&
    adapterDropTags(source.replace('template: 1, ', '')).join(',') !== jsTags.join(',')
);
check(
  'a renamed declaration is a failure, not an empty match',
  adapterDropTags('var SOMETHING_ELSE = { script: 1 };') === null &&
    kotlinDropTags('private val OTHER = setOf("script")') === null
);

/* ---- 9. the marker must be an element of its own (finding 2-02) ----------- */

console.log('\n[9] the marker must be an element of its own');

/*
 * REGRESSION (finding 2-02, safety). The end marker was found by an **unanchored**
 * `/end\s+of\s+chapter/i` over the whole assembled article text, and then cut to
 * the number that followed. Any sentence containing the words therefore *was* an
 * end marker, and a truncated chapter that happened to mention the phrase was
 * stored with `complete: true`.
 *
 * The rule now: the marker is the **entire text of one element**, and that
 * element is not run into prose in its own parent. The site's markup is
 * `<article><span>End of Chapter 1</span></article>` - a dedicated element
 * carrying nothing else - so this is what a marker actually looks like, and it
 * is what no sentence can look like.
 *
 * The fix keeps the robustness the unanchored search was added for (a React
 * `End of Chapter {n}` split across nodes, a `<br>` in the middle, a long
 * document) by assembling **inside the element** instead of across the article.
 * The pattern stays anchored; only the window it runs on changed.
 *
 * The test this replaced could not fail. It spelt the number as the word "one"
 * (so no digits were in the window at all, and the adapter returned the bare
 * phrase) and compared against the cased string "End of Chapter 1" while
 * `trimToMarker` preserves the source case - so on the real attack input, which
 * returns "end of chapter 1", the assertion still passed. Every case below
 * asserts `=== ''` against the exact string the broken code returns.
 */

/* The confirmed triggers. Each carries a real number in the window. */
const MENTIONS = [
  ['a truncated body that merely contains the substring',
    P('p', 'She thought about the end of chapter 12, and then went to bed.')],
  ['a sentence that opens with the phrase',
    P('p', 'End of Chapter 12 was the night the gate opened.')],
  ['a mixed-case recap aside',
    P('p', 'Skipping ahead: the End Of Chapter 12 recap was wrong.')],
  ['a <strong> recap header carrying extra words',
    P('strong', 'End of Chapter 12 recap')],
  ['a <strong> recap header run into the prose of its paragraph',
    new El('p', { text: 'Recap: ', children: [P('strong', 'End of Chapter 12')] })],
  ['prose run in before a dedicated marker element',
    new El('p', { text: 'Recap:', children: [new El('br'), P('span', 'End of Chapter 12')] })],
  ['the phrase buried in the middle of a long paragraph',
    P('p', 'Real prose here. '.repeat(20) + 'End of Chapter 12')],
  ['prose after the phrase in the same element',
    P('p', 'She reached the end of chapter 12 and closed the book.')],
  ['the phrase in a list item among other items',
    new El('ul', { children: [
      P('li', 'the end of chapter 12'),
      P('li', 'and then some')
    ] })]
];

for (const [label, node] of MENTIONS) {
  const st = markerOnly([P('p', 'Only a preview sentence.'), node]);
  check(
    'prose that mentions the phrase is not a marker: ' + label,
    st.endMarker === '',
    JSON.stringify(st.endMarker)
  );
  check(
    '...and yields no chapter number: ' + label,
    st.endMarkerNumber === '',
    JSON.stringify(st.endMarkerNumber)
  );
}

/* The control: with no marker at all the Kotlin side must reach
   NotReady(PREVIEW_WITHOUT_MARKER), never a contradiction. Pinned in
   ChapterCompletionRegressionTest; here it is enough that the adapter reports
   nothing for any of the triggers above, which is what makes that verdict. */

/* ---- 9b. everything the rule must still accept ----------------------------- */

console.log('\n[9b] marker forms that must keep working');

const ACCEPTED = [
  ['the site markup: a dedicated span holding only the marker',
    [P('p', 'Real prose.'), P('span', 'End of Chapter 10')]],
  ['a dedicated <p>',
    [P('p', 'Real prose.'), P('p', 'End of Chapter 10')]],
  ['React\'s `End of Chapter {n}` split across two nodes',
    [P('p', 'Real prose.'), new El('span', { children: [P('span', 'End of Chapter '), P('b', '10')] })]],
  ['a marker split across a <br>',
    [P('p', 'Real prose.'), new El('p', { children: [new El('br'), P('span', 'End of'), new El('br'), P('span', 'Chapter 10')] })]],
  ['a marker split across three nodes',
    [new El('p', { children: [P('em', 'End '), P('em', 'of Chapter'), P('em', ' 10')] })]],
  ['a decimal chapter number',
    [P('p', 'Real prose.'), P('p', 'End of Chapter 944.5')]],
  ['a 16-digit chapter number',
    [P('p', 'Real prose.'), P('p', 'End of Chapter 9007199254740993')]],
  ['leading zeros',
    [P('p', 'Real prose.'), P('p', 'End of Chapter 010')]],
  ['lowercase',
    [P('p', 'Real prose.'), P('p', 'end of chapter 10')]],
  ['uppercase',
    [P('p', 'Real prose.'), P('p', 'END OF CHAPTER 10')]],
  ['mixed case',
    [P('p', 'Real prose.'), P('p', 'End Of Chapter 10')]],
  ['leading and trailing space, which norm() strips',
    [P('p', 'Real prose.'), P('p', '   End of Chapter 10   ')]],
  ['an ideographic space (U+3000) between two words, which norm() folds',
    [P('p', 'Real prose.'), P('p', 'End of\u3000Chapter 10')]],
  ['a thin space (U+2009) and a six-per-em space (U+2006), which norm() folds',
    [P('p', 'Real prose.'), P('p', 'End\u2009of\u2006Chapter 10')]],
  ['an ogham space mark (U+1680) and a narrow no-break space (U+202F)',
    [P('p', 'Real prose.'), P('p', 'End\u1680of\u202FChapter 10')]],
  ['a medium mathematical space (U+205F) and an em space (U+2003)',
    [P('p', 'Real prose.'), P('p', 'End\u205Fof\u2003Chapter 10')]]
];

/*
 * The expected marker is judged by the adapter's own pattern, read out of
 * novtales-adapter.js, never by a literal typed into this file. The two checks
 * below used to assert against `/^end of chapter \d+(\.\d+)?$/i` typed here -
 * the same defect as the Kotlin test this audit found: a third declaration of
 * the rule, edited by whoever edits this file and never checked against the
 * adapter. See section 13, which reads both sides.
 */
const MARKER_PATTERN = adapterRegex(source, 'END_MARKER_COMPLETE');

for (const [label, body] of ACCEPTED) {
  const st = markerOnly(body);
  check('still accepted: ' + label,
    MARKER_PATTERN !== null &&
      new RegExp(MARKER_PATTERN.source, MARKER_PATTERN.flags).test(st.endMarker),
    JSON.stringify(st.endMarker));
  check('...with a number: ' + label, /^\d+(\.\d+)?$/.test(st.endMarkerNumber),
    JSON.stringify(st.endMarkerNumber));
}

/*
 * Every accepted fixture must actually carry a number in the marker window. The
 * test this file replaced asserted against a marker spelled "End of Chapter
 * one", where no digits were present at all, so the adapter - which requires
 * `[0-9]+` - reported the bare phrase and the comparison passed anyway. A
 * fixture without digits cannot fail, so the fixtures are checked, not trusted.
 */
for (const [label, body] of ACCEPTED) {
  const text = body[body.length - 1].textContent || '';
  check('the fixture for "' + label + '" carries digits in the marker window',
    /\d/.test(text), JSON.stringify(text));
}

/* The observed site markup end to end: the marker is a child of the article,
   after the chapter body, with no prose of its own. */
const siteMarkup = new El('article', {
  children: [new El('div', { attrs: { class: 'nv-chapter-body' }, children: [P('p', 'The caravan left at dawn.')] }),
             new El('span', { text: 'End of Chapter 1' })]
});
run(baseEnv(new El('main', { children: [siteMarkup] }), '/chapter/surviving-the-game-as-a-barbarian-1', 'NovTales'));
state = JSON.parse(window.__novChapterState(true));
check('<article><span>End of Chapter 1</span></article> is still a marker', state.endMarker === 'End of Chapter 1', JSON.stringify(state.endMarker));
check('...and the body is untouched', state.bodyHtml.indexOf('The caravan left at dawn.') >= 0, state.bodyHtml);

/* ---- 10. the mirror: scene breaks and canaries (finding 2-03) ------------- */

console.log('\n[10] scene-break and canary subtrees are discarded too');

/*
 * REGRESSION (finding 2-03). `HtmlSanitiser` deletes a subtree for four
 * mechanisms. The adapter modelled two of them (dropped tags, and
 * hidden/aria-hidden/inline-style) and had never heard of the other two:
 *
 *   - a scene break: `class="scene-break"` / `data-scene-break`;
 *   - `data-security-canary`, and any `<a>` whose `href` mentions it.
 *
 * So `<p>Real prose</p><p class="scene-break">End of Chapter 12</p>` completed a
 * chapter whose stored HTML was `<p>Real prose</p><hr>`: the marker that
 * justified completion was not in the file that was saved.
 *
 * The canary is the case that still bites: `<a>` is an unwrap tag, so without
 * the rule its text is kept and a marker inside it is found.
 *
 * A scene break only ever discarded *glyph* text - see the second group below -
 * but the rule is modelled exactly rather than approximately, because that is
 * the only way the two halves stay in step.
 */

const ALSO_DISCARDED = [
  ['a data-security-canary anchor', new El('a', { attrs: { 'data-security-canary': '1' }, children: [P('span', 'End of Chapter 10')] })],
  ['a canary href', new El('a', { attrs: { href: '/login#data-security-canary' }, children: [P('span', 'End of Chapter 10')] })],
  ['a canary href in mixed case', new El('a', { attrs: { href: '/login#DATA-Security-Canary' }, children: [P('span', 'End of Chapter 10')] })]
];

for (const [label, node] of ALSO_DISCARDED) {
  const st = markerOnly([P('p', 'Real prose.'), node]);
  check('a marker inside ' + label + ' is NOT an end marker', st.endMarker === '', JSON.stringify(st.endMarker));
  check('...and yields no chapter number: ' + label, st.endMarkerNumber === '', JSON.stringify(st.endMarkerNumber));
}

/*
 * A scene break only deletes text that is **nothing but separator glyphs**,
 * because that is what a scene break is: `* * *`, `***`, a long dash. Anything
 * else - including the words "End of Chapter" - is prose the sanitiser keeps,
 * so the adapter has to find it there too. These are the shapes that used to be
 * silently swallowed with their text.
 */
const GLYPHS_ARE_DISCARDED = [
  ['a scene-break glyph run', new El('p', { attrs: { class: 'scene-break' }, text: '* * *' })],
  ['a scene-break star run', new El('p', { attrs: { class: 'scene-break' }, text: '***' })],
  ['a scene-break dash', new El('p', { attrs: { class: 'scene-break' }, text: '—' })],
  ['a scene-break middot', new El('p', { attrs: { class: 'scene-break' }, text: '· · ·' })]
];

for (const [label, node] of GLYPHS_ARE_DISCARDED) {
  const st = markerOnly([P('p', 'Real prose.'), node]);
  check('glyph text in ' + label + ' is discarded', st.endMarker === '', JSON.stringify(st.endMarker));
}

/*
 * The other direction, and the reason this is a *mirror* rather than "delete
 * more": a scene-break slot holding prose is unwrapped, so the prose is in the
 * stored chapter and a marker in it counts. A rule that deleted every scene
 * break would reject these and lose real downloads; the reverse - keeping
 * everything - would store chapters shorter than the page rendered.
 */
const KEPT_BY_SANITISER = [
  ['a scene-break slot holding the marker itself',
    P('p', 'End of Chapter 10', { class: 'scene-break' })],
  ['a scene-break container that holds block content',
    new El('div', { attrs: { class: 'scene-break' }, children: [P('p', 'Real prose.'), P('p', 'End of Chapter 10')] })],
  ['a scene break wrapping the marker paragraph',
    new El('div', { attrs: { class: 'scene-divider' }, children: [P('p', 'Real prose.'), P('p', 'End of Chapter 10')] })],
  ['a scene break around a table',
    new El('table', { attrs: { class: 'scene-break' }, children: [P('p', 'End of Chapter 10')] })],
  ['a scene break on a thead',
    new El('thead', { attrs: { class: 'scene-break' }, children: [P('p', 'End of Chapter 10')] })],
  ['a scene break on an anchor',
    new El('a', { attrs: { class: 'scene-break' }, children: [P('span', 'End of Chapter 10')] })],
  ['a scene break around inline-only content',
    new El('div', { attrs: { class: 'scene-break' }, children: [P('span', 'End of Chapter 10')] })],
  ['a scene break written with inline emphasis',
    new El('p', { attrs: { class: 'scene-break' }, children: [P('em', 'End of Chapter 10')] })],
  ['data-scene-break="false"', new El('p', { attrs: { 'data-scene-break': 'false' }, text: 'End of Chapter 10' })],
  ['data-scene-break="off"', new El('p', { attrs: { 'data-scene-break': 'off' }, text: 'End of Chapter 10' })],
  ['data-scene-break="undefined"', new El('p', { attrs: { 'data-scene-break': 'undefined' }, text: 'End of Chapter 10' })],
  ['a Tailwind break-* utility class', new El('p', { attrs: { class: 'break-words' }, children: [P('span', 'End of Chapter 10')] })],
  ['the bare class "break"', new El('p', { attrs: { class: 'break' }, children: [P('span', 'End of Chapter 10')] })],
  ['an ordinary anchor', new El('a', { attrs: { href: '/chapter/x-10' }, children: [P('span', 'End of Chapter 10')] })]
];

for (const [label, node] of KEPT_BY_SANITISER) {
  const st = markerOnly([P('p', 'Real prose.'), node]);
  check('the sanitiser keeps it, so it still counts: ' + label,
    st.endMarker === 'End of Chapter 10', JSON.stringify(st.endMarker));
}

/* ---- 11. the adapter must model the sanitiser, not a stricter browser ---- */

console.log('\n[11] a stylesheet-hidden marker still counts');

/*
 * Finding 2-05. `droppedOrHidden` consulted `getComputedStyle` on every
 * ancestor, but `HtmlSanitiser.isHidden` reads only the **inline** `style`
 * attribute. So a site that hides its own marker with a stylesheet had a
 * complete chapter that the sanitiser stored in full and the adapter refused
 * for ever - a denial of service on the reader, not a bypass. The sanitiser is
 * a security control and cannot be weakened to match, and it is a plain string
 * scanner so it cannot ask a browser what a stylesheet said. So the adapter was
 * brought back to the sanitiser's view: what survives sanitising can complete a
 * chapter, and nothing else.
 */
function styleEnv(root, pathname, hiddenClasses) {
  const env = baseEnv(root, pathname, 'NovTales');
  env.window.getComputedStyle = (el) => {
    const cls = el && el.getAttribute ? (el.getAttribute('class') || '') : '';
    const hidden = cls.split(/\s+/).some(c => c && hiddenClasses.indexOf(c) >= 0);
    return hidden
      ? { display: 'none', visibility: 'hidden' }
      : { display: 'block', visibility: 'visible' };
  };
  return env;
}

{
  const root = new El('main', {
    children: [new El('article', {
      children: [
        new El('div', { attrs: { class: 'nv-chapter-body' }, children: [P('p', 'The caravan left at dawn.')] }),
        P('p', 'End of Chapter 1', { class: 'marker-holder' })
      ]
    })]
  });
  run(styleEnv(root, '/chapter/surviving-the-game-as-a-barbarian-1', ['marker-holder']));
  const st = JSON.parse(window.__novChapterState(true));
  check('a marker a stylesheet hides is still a marker: the sanitiser keeps it',
    st.endMarker === 'End of Chapter 1', JSON.stringify(st.endMarker));
}

{
  const root = new El('main', {
    children: [new El('article', {
      children: [
        new El('div', { attrs: { class: 'nv-chapter-body' }, children: [P('p', 'The caravan left at dawn.')] }),
        P('p', 'End of Chapter 1', { class: 'marker-holder', style: 'display:none' })
      ]
    })]
  });
  run(styleEnv(root, '/chapter/surviving-the-game-as-a-barbarian-1', ['marker-holder']));
  const st = JSON.parse(window.__novChapterState(true));
  check('an inline display:none is still discarded: the sanitiser deletes it',
    st.endMarker === '', JSON.stringify(st.endMarker));
}

/* ---- 12. every mirror, pinned against the sanitiser's own source ---------- */

console.log('\n[12] all four discard rules are pinned to HtmlSanitiser.kt');

/** A named `Regex("...")` literal in the Kotlin source, with its escapes resolved. */
function kotlinRegex(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const r = text.indexOf('Regex(', at);
  // The declaration must be the one that follows: no other statement in between.
  if (r < 0 || r - at > name.length + 40 || text.slice(at, r).indexOf(';') >= 0) return null;
  // The literal may sit on the next line, so skip whitespace rather than
  // insisting on `"` at exactly this offset.
  let q = r + 'Regex('.length;
  while (q < text.length && /\s/.test(text.charAt(q))) q++;
  if (text.charAt(q) !== '"') return null;
  let out = '';
  let i = q + 1;
  while (i < text.length && text[i] !== '"') {
    if (text[i] === '\\') { out += text[i + 1]; i += 2; continue; }
    out += text[i];
    i++;
  }
  return i >= text.length ? null : out;
}

/** A named JS regex literal, with its flags. */
function adapterRegex(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('/', at);
  if (open < 0) return null;
  const close = text.indexOf('/', open + 1);
  if (close < 0) return null;
  return { source: text.slice(open + 1, close), flags: (text.slice(close + 1).match(/^[gimsuy]*/) || [''])[0] };
}

/** The lower-case tag names of a Kotlin `setOf("a", "b", ...)`. */
function kotlinSet(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('setOf(', at);
  if (open < 0 || open - at > name.length + 40 || text.slice(at, open).indexOf(';') >= 0) return null;
  const close = text.indexOf(')', open);
  if (close < 0) return null;
  const tags = text.slice(open, close).match(/"([a-z][a-z0-9-]*)"/g) || [];
  return tags.map(t => t.slice(1, -1)).sort();
}

/** The quoted names of a JS `['a', 'b']` array. */
function adapterArray(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('[', at);
  if (open < 0 || open - at > name.length + 40 || text.slice(at, open).indexOf(';') >= 0) return null;
  const close = text.indexOf(']', open);
  if (close < 0) return null;
  const names = text.slice(open, close).match(/'([^']+)'/g) || [];
  return names.map(n => n.slice(1, -1)).sort();
}

/** The quoted values of a Kotlin `when (...) { "a", "b" -> false; ... }` branch. */
function kotlinWhenValues(text, marker) {
  const at = text.indexOf(marker);
  if (at < 0) return null;
  const close = text.indexOf('}', at);
  if (close < 0) return null;
  const body = text.slice(text.indexOf('->', at) < 0 ? at : text.lastIndexOf('{', close), close);
  const values = body.match(/"([^"]*)"/g) || [];
  return values.map(v => v.slice(1, -1)).sort();
}

/** The keys of the adapter's `NAME = { 'a': 1, ... }` literal. */
function adapterKeys(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('{', at);
  const close = text.indexOf('}', open);
  if (open < 0 || close < 0) return null;
  const keys = text.slice(open, close).match(/'([^']+)'\s*:\s*1\b/g) || [];
  return keys.map(k => k.split(':')[0].replace(/'/g, '').trim()).sort();
}

// -- the scene-break class expression, character for character ----------------
const ktScene = kotlinRegex(sanitiserSource, 'SCENE_BREAK_CLASS');
const jsScene = adapterRegex(source, 'SANITISER_SCENE_BREAK_CLASS');
check('both scene-break declarations were found', ktScene !== null && jsScene !== null, String(ktScene) + ' / ' + JSON.stringify(jsScene));
check(
  'the scene-break class expression is the same on both sides',
  ktScene !== null && jsScene !== null &&
    ktScene.replace(/^\(\?i\)/, '') === jsScene.source,
  'sanitiser: ' + ktScene + '\n       adapter:   ' + (jsScene && jsScene.source)
);
check(
  'and it is case-insensitive on both sides',
  ktScene !== null && jsScene !== null && ktScene.startsWith('(?i)') && jsScene.flags.indexOf('i') >= 0,
  String(ktScene) + ' / ' + (jsScene && jsScene.flags)
);

/*
 * Behaviour, not string surgery: run the shared expression over the class values
 * the two sides actually disagree about, so the pin says what it means.
 */
const sceneRe = ktScene !== null ? new RegExp(ktScene.replace(/^\(\?i\)/, ''), 'i') : null;
if (sceneRe) {
  check('"scene-break" is a scene break', sceneRe.test('scene-break'));
  check('"scene divider" is a scene break', sceneRe.test('scene divider'));
  check('"Scene_Divider" is a scene break', sceneRe.test('Scene_Divider'));
  check('it matches inside a longer class list', sceneRe.test('prose scene-break mt-4'));
  check('the bare word "break" is not one, so no real prose is lost', !sceneRe.test('break'));
  check('"break-words" is not one (Tailwind)', !sceneRe.test('break-words'));
  check('"text-break" is not one', !sceneRe.test('text-break'));
  check(
    '"md:scene-break" is not one - the responsive prefix is deliberately not matched',
    !sceneRe.test('md:scene-break'),
    'do not loosen this: the sanitiser does not recognise it either'
  );
}

// -- the glyph run that decides marker vs prose --------------------------------
const ktGlyph = kotlinRegex(sanitiserSource, 'SCENE_BREAK_GLYPHS');
const jsGlyph = adapterRegex(source, 'SANITISER_SCENE_BREAK_GLYPHS');
check('both scene-break glyph declarations were found', ktGlyph !== null && jsGlyph !== null, String(ktGlyph) + ' / ' + JSON.stringify(jsGlyph));
check(
  'the scene-break glyph expression is the same on both sides',
  ktGlyph !== null && jsGlyph !== null &&
    ktGlyph === jsGlyph.source.replace(/^\^/, '').replace(/\$$/, ''),
  'sanitiser: ' + ktGlyph + '\n       adapter:   ' + (jsGlyph && jsGlyph.source)
);
if (ktGlyph !== null) {
  const glyph = new RegExp('^(?:' + ktGlyph + ')$');
  for (const sample of ['* * *', '***', '· · ·', '—', '   ', '', '~-~ 3']) {
    check('"' + sample + '" is a scene-break marker', glyph.test(sample));
  }
  for (const sample of ['End of Chapter 12', 'Click through.', 'One.', 'Chapter body in a cell.']) {
    check('"' + sample + '" is prose, and is kept', !glyph.test(sample));
  }
  let letterMatched = '';
  for (const code of 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz') {
    if (glyph.test(code)) { letterMatched = code; break; }
  }
  check(
    'no ASCII letter matches the glyph run, which is why no prose can match it',
    letterMatched === '',
    letterMatched ? 'matched ' + JSON.stringify(letterMatched) : String(ktGlyph)
  );
}

// -- the values `data-scene-break="false"` style attributes are refused -------
const ktNegative = kotlinWhenValues(sanitiserSource, 'private fun isAffirmative');
const jsNegative = adapterKeys(source, 'SANITISER_NEGATIVE_VALUES');
check('both negative-value declarations were found', ktNegative !== null && jsNegative !== null, String(ktNegative) + ' / ' + String(jsNegative));
check(
  'the negative value sets are identical',
  ktNegative !== null && jsNegative !== null && ktNegative.join(',') === jsNegative.join(','),
  'sanitiser: ' + ktNegative + '\n       adapter:   ' + jsNegative
);
check(
  'and the 20-character ceiling is present on both sides',
  source.indexOf('length > 20') >= 0 && sanitiserSource.indexOf('trimmed.length > 20') >= 0
);

// -- the canary attribute ------------------------------------------------------
function kotlinFunBody(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('{', at);
  if (open < 0) return null;
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    if (text[i] === '{') depth++;
    else if (text[i] === '}') { depth--; if (depth === 0) return text.slice(open, i + 1); }
  }
  return null;
}
const ktCanary = kotlinFunBody(sanitiserSource, 'private fun isCanary');
const jsCanary = kotlinFunBody(source, 'function isCanary');
check('both canary declarations were found', ktCanary !== null && jsCanary !== null);
check(
  'the canary attribute name is the same on both sides',
  ktCanary !== null && jsCanary !== null &&
    ktCanary.indexOf('data-security-canary') >= 0 && jsCanary.indexOf('data-security-canary') >= 0,
  String(ktCanary) + ' / ' + String(jsCanary)
);
check(
  'and it is matched on the href too, case-insensitively',
  ktCanary !== null && jsCanary !== null &&
    ktCanary.indexOf('href') >= 0 &&
    /toLowerCase\(\)[\s\S]{0,80}indexOf\('data-security-canary'\)/.test(jsCanary),
  String(jsCanary)
);
check(
  'both sides apply the canary to <a> only',
  /name\s*==\s*"a"\s*&&\s*isCanary\(/.test(sanitiserSource) &&
    /tag\s*===\s*'a'\s*&&\s*isCanary\(/.test(source)
);

// -- the invisible rule that makes the mirror exact ---------------------------
check(
  'the adapter no longer consults getComputedStyle for the marker',
  kotlinFunBody(source, 'function discardsSubtree') !== null &&
    kotlinFunBody(source, 'function discardsSubtree').indexOf('getComputedStyle') === -1,
  String(kotlinFunBody(source, 'function discardsSubtree'))
);
check(
  'the inline style attribute is still read, exactly as the sanitiser reads it',
  source.indexOf("indexOf('display:none') >= 0") >= 0 && source.indexOf("indexOf('visibility:hidden') >= 0") >= 0
);

// -- and a perturbation on each side, to prove the pin can fail ---------------
check(
  'an extra glyph on the sanitiser side alone is caught',
  (kotlinRegex(sanitiserSource.replace('0-9]', '0-9A]'), 'SCENE_BREAK_GLYPHS') || '') !== String(ktGlyph)
);
check(
  'a removed negative value on the adapter side alone is caught',
  (adapterKeys(source.replace("'none': 1, ", ''), 'SANITISER_NEGATIVE_VALUES') || []).join(',') !== (jsNegative || []).join(',')
);
check(
  'a loosened scene-break expression on one side alone is caught',
  (kotlinRegex(sanitiserSource.replace('scene[-_ ]?(?:break|divider)', 'scene[-_ ]?(?:break|divider)|div'), 'SCENE_BREAK_CLASS') || '') !== String(ktScene)
);
check(
  'an unescaped Kotlin literal is not mistaken for the real one',
  kotlinRegex('private val X = Regex("a\\\\sb")', 'X') === 'a\\sb'
);

/* ---- 13. the marker pattern is one rule in both implementations ----------- */

console.log('\n[13] END_MARKER_COMPLETE and ChapterCompletion.END_MARKER agree');

/*
 * REGRESSION (the audit's finding that this file could not catch). The adapter
 * and `ChapterCompletion` each decide "is this exactly `End of Chapter N`", and
 * they have drifted about it three times. A test that re-declares the adapter's
 * pattern in the *other* language proves nothing: delete `END_MARKER_COMPLETE`
 * from novtales-adapter.js and such a test stays green. The only honest check
 * reads both declarations out of their own files and makes them answer the same
 * questions, which is what this section does - the same technique section 8
 * uses for the drop tags, applied to the pattern.
 *
 * Translation guard: the Kotlin pattern is run in JavaScript. That is only
 * sound while the pattern uses constructs the two regex engines define the same
 * way, so the translation REFUSES anything else rather than quietly reading it
 * differently. `\s` is deliberately *not* in that safe set - Java's is
 * `[ \t\n\x0B\f\r]` and ECMAScript's is Unicode-aware - which is exactly why
 * both sides normalise whitespace first (below) and why the normalised strings
 * are asserted to be pure ASCII before either pattern sees them.
 */
const COMPLETION = path.join(
  __dirname, '..', '..', 'app', 'src', 'main', 'kotlin', 'com', 'sadloif',
  'novtalescompanion', 'web', 'ChapterCompletion.kt'
);
if (!fs.existsSync(COMPLETION)) {
  console.error('ChapterCompletion.kt not found at ' + COMPLETION);
  process.exit(2);
}
const completionSource = fs.readFileSync(COMPLETION, 'utf8');

/** Constructs whose meaning is NOT identical between Java and ECMAScript.
 *  `\d` and `.` are deliberately absent: both engines define them as
 *  `[0-9]` and "any character but a line terminator" respectively, and neither
 *  side compiles this pattern with the Unicode flag. `\s` is deliberately
 *  absent too, but only because both sides normalise whitespace first - see the
 *  ASCII assertion on the normalised strings below. */
const UNTRANSLATABLE = /\(\?[=!]|\\p\{|\\P\{|\\k<|\\Q|\\[0-9]|\\u\{|\(\?<[^=!]|\(\?'/;

/**
 * Reads Kotlin's `END_MARKER` out of [text] and re-expresses it as a JavaScript
 * regex. The parameter matters: the perturbation checks below hand this a
 * *modified copy* of `ChapterCompletion.kt` and expect the answer to change, so
 * it must read what it is given and not a module-level constant.
 */
function translateKotlinMarker(text) {
  const raw = kotlinRegex(text, 'END_MARKER');
  if (raw === null) return null;
  if (UNTRANSLATABLE.test(raw)) return { refused: raw };
  const flags = raw.indexOf('(?i)') === 0 ? 'i' : '';
  const body = raw.replace(/^\(\?i\)/, '');
  return { flags: flags, source: body };
}

const ktMarker = translateKotlinMarker(completionSource);

check('the adapter declaration END_MARKER_COMPLETE was found', MARKER_PATTERN !== null, String(MARKER_PATTERN));
check('the Kotlin declaration END_MARKER was found', ktMarker !== null && !ktMarker.refused, String(ktMarker && (ktMarker.refused || ktMarker.source)));
check('the Kotlin marker pattern carries the case-insensitive flag', ktMarker !== null && !ktMarker.refused && ktMarker.flags === 'i', String(ktMarker && ktMarker.flags));
check('the adapter marker pattern carries the case-insensitive flag', MARKER_PATTERN !== null && MARKER_PATTERN.flags.indexOf('i') >= 0, String(MARKER_PATTERN && MARKER_PATTERN.flags));
check(
  'both patterns are anchored, so a sentence containing the phrase can never match',
  ktMarker !== null && !ktMarker.refused && ktMarker.source.indexOf('^') === 0 && ktMarker.source.indexOf('$') > 0 &&
    MARKER_PATTERN !== null && MARKER_PATTERN.source.indexOf('^') === 0 &&
    MARKER_PATTERN.source.lastIndexOf('$') === MARKER_PATTERN.source.length - 1,
  String(ktMarker && ktMarker.source) + ' / ' + String(MARKER_PATTERN && MARKER_PATTERN.source)
);

const jsMarkerRe = MARKER_PATTERN === null ? null : new RegExp(MARKER_PATTERN.source, MARKER_PATTERN.flags);
const ktMarkerRe = ktMarker === null || ktMarker.refused ? null : new RegExp(ktMarker.source, ktMarker.flags);

/* -- the whitespace classes are one class --------------------------------- */

/** The string literal(s) of a `new RegExp('a' + 'b', 'g')` declaration. */
function newRegExpSource(text, name) {
  const at = text.indexOf(name);
  if (at < 0) return null;
  const open = text.indexOf('new RegExp(', at);
  if (open < 0 || open - at > name.length + 20) return null;
  if (text.substring(at, open).indexOf(';') >= 0) return null;
  const close = text.indexOf(')', open);
  if (close < 0) return null;
  const parts = text.slice(open + 'new RegExp('.length, close).match(/'([^']*)'/g);
  if (!parts || !parts.length) return null;
  // The pattern is the concatenation **up to and including** the part that
  // closes the character class; the flags string after it is not part of it.
  let joined = '';
  for (const part of parts) {
    joined += part.slice(1, -1);
    if (joined.indexOf(']') >= 0) break;
  }
  // Unescaped by hand rather than with `JSON.parse`, because JSON has no `\v`
  // and these classes legitimately contain one (`[\t\n\v\f\r ...]`).
  const SIMPLE = { t: '\t', n: '\n', v: '\v', f: '\f', r: '\r', b: '\b', '0': '\0' };
  let out = '';
  for (let i = 0; i < joined.length; i++) {
    const c = joined[i];
    if (c !== '\\') { out += c; continue; }
    const n = joined[++i];
    if (n === 'u') {
      out += String.fromCharCode(parseInt(joined.substr(i + 1, 4), 16));
      i += 4;
      continue;
    }
    out += SIMPLE[n] !== undefined ? SIMPLE[n] : n;
  }
  return out;
}

/**
 * Every code point a single-class `[...]` body matches, as a Set.
 * Understands `\t \n \v \f \r \s`, `\p{...}`, `\uXXXX`, literal characters and
 * `X-Y` ranges - which is the whole of what these two declarations use.
 */
function codePointsOfClass(body) {
  const out = new Set();
  let i = 0;
  const simple = { t: 9, n: 10, v: 11, f: 12, r: 13 };
  while (i < body.length) {
    let lo;
    if (body[i] === '\\') {
      const c = body[i + 1];
      if (simple[c] !== undefined) { lo = simple[c]; i += 2; }
      else if (c === 's') { [0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x20].forEach(p => out.add(p)); i += 2; }
      else if (c === 'p') {
        const close = body.indexOf('}', i);
        if (close < 0) return null;
        const cat = body.slice(i + 3, close);
        for (let p = 0; p <= 0xFFFF; p++) {
          if (new RegExp('\\p{' + cat + '}', 'u').test(String.fromCharCode(p))) out.add(p);
        }
        i = close + 1;
      } else if (c === 'u') {
        lo = parseInt(body.substr(i + 2, 4), 16); i += 6;
      } else return null;
    } else { lo = body.charCodeAt(i); i += 1; }
    if (body[i] === '-' && body[i + 1] !== ']') {
      let hi;
      if (body[i + 1] === '\\' && body[i + 2] === 'u') { hi = parseInt(body.substr(i + 3, 4), 16); i += 7; }
      else { hi = body.charCodeAt(i + 1); i += 2; }
      for (let p = lo; p <= hi; p++) out.add(p);
    } else {
      out.add(lo);
    }
  }
  return out;
}

const jsSpaceBody = newRegExpSource(source, 'ANY_SPACE');
const ktSpaceBody = kotlinRegex(completionSource, 'ANY_WHITESPACE');
const jsSpaces = jsSpaceBody === null ? null : codePointsOfClass(jsSpaceBody.replace(/^\[/, '').replace(/\]\+?$/, ''));
const ktSpaces = ktSpaceBody === null ? null : codePointsOfClass(ktSpaceBody.replace(/^\[/, '').replace(/\]\+?$/, ''));

check('the adapter whitespace class was found', jsSpaces !== null && jsSpaces.size > 0, String(jsSpaceBody));
check('the Kotlin whitespace class was found', ktSpaces !== null && ktSpaces.size > 0, String(ktSpaceBody));
/** `U+XXXX ` for each code point, for a failure message that has to be readable. */
function codePointList(set) {
  if (!set) return '(not found)';
  return [...set]
    .filter(p => typeof p === 'number')
    .sort((a, b) => a - b)
    .map(p => 'U+' + p.toString(16).toUpperCase().padStart(4, '0'))
    .join(' ') || '(none)';
}

check(
  'ANY_SPACE and ANY_WHITESPACE are the same set of code points',
  jsSpaces !== null && ktSpaces !== null &&
    jsSpaces.size === ktSpaces.size && [...jsSpaces].every(p => ktSpaces.has(p)),
  'adapter-only: ' + codePointList(jsSpaces && new Set([...jsSpaces].filter(p => !ktSpaces.has(p)))) +
    '\n       kotlin-only:  ' + codePointList(ktSpaces && new Set([...ktSpaces].filter(p => !jsSpaces.has(p))))
);

/* -- the corpus ---------------------------------------------------------- */

/** Java's `\s`, from the language spec. ECMAScript's `\s` is Unicode-aware,
 *  which is the whole reason both sides normalise before matching. */
const JAVA_S = [0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x20];

const UNICODE_SPACES = [
  [0x1680, 'OGHAM SPACE MARK'],
  [0x2003, 'EM SPACE'],
  [0x2006, 'SIX-PER-EM SPACE'],
  [0x2009, 'THIN SPACE'],
  [0x200A, 'HAIR SPACE'],
  [0x202F, 'NARROW NO-BREAK SPACE'],
  [0x205F, 'MEDIUM MATHEMATICAL SPACE'],
  [0x3000, 'IDEOGRAPHIC SPACE']
];

for (const [cp, name] of UNICODE_SPACES) {
  const ch = String.fromCharCode(cp);
  check(
    'the Java class and the ECMAScript class both call U+' + cp.toString(16).toUpperCase() + ' (' + name + ') a space',
    JAVA_S.indexOf(cp) < 0 && jsSpaces.has(cp) && ktSpaces.has(cp)
  );
}

/** What `norm()` in the adapter does, rebuilt from the class it reads out of
 *  novtales-adapter.js. The two literal replaces and the trim are `norm`'s
 *  scaffolding; the character class is the part that could drift, so that is
 *  the part that is read rather than typed. */
function adapterNorm(text) {
  return String(text)
    .replace(/ /g, ' ')
    .replace(/[ \t\r\n]+/g, ' ')
    .replace(new RegExp(jsSpaceBody, 'g'), ' ')
    .replace(/^ +| +$/g, '');
}

/** The same, from ChapterCompletion.kt's class. */
function kotlinNorm(text) {
  return String(text).replace(new RegExp(ktSpaceBody, 'g'), ' ').replace(/^ +| +$/g, '');
}

/**
 * The corpus, and what both implementations must say about each entry.
 *
 * Restricted to the chapter that is actually requested (10), because Kotlin
 * additionally compares the marker's number to the request and the adapter
 * deliberately does not - it finds a marker, Kotlin decides. A marker for a
 * different chapter would disagree for a reason that has nothing to do with
 * the pattern, so it is not in here.
 */
const CORPUS = [
  ['the site markup', 'End of Chapter 10', true],
  ['lowercase', 'end of chapter 10', true],
  ['uppercase', 'END OF CHAPTER 10', true],
  ['mixed case', 'End Of Chapter 10', true],
  ['shouted case', 'eNd oF cHaPtEr 10', true],
  ['padded with spaces', '   End of Chapter 10   ', true],
  ['a decimal chapter number', 'End of Chapter 10.0', true],
  ['leading zeros', 'End of Chapter 010', true],
  ['a sixteen-digit number', 'End of Chapter 9007199254740993', true]
];
for (const [cp] of UNICODE_SPACES) {
  const ch = String.fromCharCode(cp);
  CORPUS.push(['U+' + cp.toString(16).toUpperCase() + ' between "of" and "Chapter"',
    'End of' + ch + 'Chapter 10', true]);
  CORPUS.push(['U+' + cp.toString(16).toUpperCase() + ' between "End" and "of"',
    'End' + ch + 'of Chapter 10', true]);
}
CORPUS.push(
  ['a chapter count after the number', 'End of Chapter 1 of 3', false],
  ['a parenthetical after the number', 'THE END OF CHAPTER 10 (FINAL)', false],
  ['the number spelled as a word', 'End of Chapter ten', false],
  ['a mid-sentence mention', 'She reached the end of chapter 10 and closed the book.', false],
  ['a sentence that opens with the phrase', 'End of Chapter 10 was the night the gate opened.', false],
  ['the phrase with no number at all', 'End of Chapter', false],
  ['a trailing full stop', 'End of Chapter 10.', false],
  ['trailing prose in the same element', 'End of Chapter 10 and that was that.', false]
);

for (const [label, text, expected] of CORPUS) {
  const jsNorm = adapterNorm(text);
  const ktNorm = kotlinNorm(text);
  check(
    'both sides normalise ' + label + ' to the same ASCII string',
    jsNorm === ktNorm && jsNorm.split('').every(c => c.charCodeAt(0) < 128),
    'adapter: ' + JSON.stringify(jsNorm) + '  kotlin: ' + JSON.stringify(ktNorm)
  );
  check(
    'the adapter pattern ' + (expected ? 'accepts' : 'refuses') + ': ' + label,
    jsMarkerRe !== null && jsMarkerRe.test(jsNorm) === expected, JSON.stringify(jsNorm)
  );
  check(
    'the Kotlin pattern ' + (expected ? 'accepts' : 'refuses') + ': ' + label,
    ktMarkerRe !== null && ktMarkerRe.test(ktNorm) === expected, JSON.stringify(ktNorm)
  );
}

/*
 * And end to end through the real adapter, because the pattern is only half of
 * what decides a marker: the whole-element rule is the other half, and only the
 * shipped code can apply it.
 */
for (const [label, text, expected] of CORPUS) {
  if (!expected) continue;
  const st = markerOnly([P('p', 'Real prose.'), P('p', text)]);
  check('the shipped adapter really delivers: ' + label,
    st.endMarker === adapterNorm(text) && st.endMarkerNumber !== '',
    JSON.stringify(st.endMarker) + ' / ' + JSON.stringify(st.endMarkerNumber));
}

/* -- and the third copy, the one that fills in endMarkerNumber -------------- */

/*
 * `__novChapterState` extracts the number with its own inline pattern,
 * `/end of chapter\s+(\d+(?:\.\d+)?)/i`, rather than with END_MARKER_COMPLETE.
 * It is a third declaration of "what a marker is" in one file, so it is pinned
 * too: on every accepted corpus entry it must yield the number the marker
 * carries.
 */
const inlineNumber = /\/end of chapter\\s\+\(\\d\+\(\?:\\\.\\d\+\)\?\)\/i/;
check('the inline endMarkerNumber pattern is still where it was', inlineNumber.test(source));
const inlineMatch = source.match(/\/\s*end of chapter\\s\+\(\\d\+\(\?:\\\.\\d\+\)\?\)\/i/);
const inlineRe = inlineMatch ? new RegExp(inlineMatch[0].slice(1, -2), 'i') : null;
for (const [label, text, expected] of CORPUS) {
  if (!expected) continue;
  const m = inlineRe === null ? null : inlineRe.exec(adapterNorm(text));
  const reported = markerOnly([P('p', 'Real prose.'), P('p', text)]).endMarkerNumber;
  check('endMarkerNumber matches the marker: ' + label,
    m !== null && m[1] === reported && reported !== '',
    'regex: ' + (m === null ? 'no match' : m[1]) + '  adapter: ' + JSON.stringify(reported));
}

/* -- perturbations, so the pin is shown to be able to fail ------------------ */

/** Re-reads END_MARKER_COMPLETE out of an arbitrary copy of the adapter. */
function perturbedAdapterPattern(text) {
  const m = adapterRegex(text, 'END_MARKER_COMPLETE');
  return m === null ? null : new RegExp(m.source, m.flags);
}

check(
  'an adapter pattern change is noticed: END_MARKER_COMPLETE -> /^fin\\b/i',
  (function () {
    const perturbed = perturbedAdapterPattern(
      source.replace(/END_MARKER_COMPLETE = \/[^/]*\/i/, 'END_MARKER_COMPLETE = /^fin\\b/i'));
    return perturbed !== null && !perturbed.test('End of Chapter 10');
  })(),
  'the adapter pattern is read out of the file, so changing it must change the answer'
);
check(
  'a Kotlin pattern change is noticed: the capture group and \\s* dropped',
  (function () {
    const perturbed = translateKotlinMarker(
      completionSource.replace(
        'Regex("(?i)^\\\\s*End of Chapter\\\\s+(\\\\d+(?:\\\\.\\\\d+)?)\\\\s*$")',
        'Regex("(?i)^End of Chapter\\\\s+\\\\d+$")'));
    if (perturbed === null || perturbed.refused) return false;
    return perturbed.source === '^End of Chapter\\s+\\d+$';
  })(),
  String(ktMarker && (ktMarker.refused || ktMarker.source))
);
check(
  'a whitespace-class change is noticed: U+3000 dropped from the adapter class',
  (function () {
    const perturbed = newRegExpSource(source.replace('\\u3000', ''), 'ANY_SPACE');
    const set = perturbed === null ? null : codePointsOfClass(perturbed.replace(/^\[/, '').replace(/\]\+?$/, ''));
    return set !== null && jsSpaces.has(0x3000) && !set.has(0x3000);
  })()
);
check(
  'the translation refuses a pattern the two engines read differently',
  translateKotlinMarker(
    completionSource.replace(
      'Regex("(?i)^\\\\s*End of Chapter\\\\s+(\\\\d+(?:\\\\.\\\\d+)?)\\\\s*$")',
      'Regex("(?i)^\\\\s*End of Chapter(?=\\\\s)\\\\s+(\\\\d+(?:\\\\.\\\\d+)?)\\\\s*$")'
    )
  ).refused !== undefined
);
check(
  'a renamed Kotlin declaration is a failure, not an empty match',
  (function () {
    const at = completionSource.indexOf('END_MARKER');
    const renamed = completionSource.slice(0, at) + 'SOMETHING_ELSE' + completionSource.slice(at + 'END_MARKER'.length);
    return kotlinRegex(renamed, 'END_MARKER') === null;
  })()
);

/* ---- 14. the hidden rule is one rule too ---------------------------------- */

console.log('\n[14] hidden, aria-hidden, display:none and visibility:hidden are mirrored');

/*
 * `DROP_SUBTREE_TAGS` is pinned in section 8 and `BLOCK_TAGS`,
 * `SCENE_BREAK_CLASS`, `SANITISER_NEGATIVE_VALUES` and the canary in section 12.
 * The other half of the same rule - an element hidden by the page rather than
 * dropped by tag - has two hand-written implementations and no pin at all:
 *
 *   Kotlin   HtmlSanitiser.Parser.isHidden(attributes)
 *   adapter  discardsSubtree(element)
 *
 * `hidden`, `aria-hidden="true"`, an inline `display:none` and an inline
 * `visibility:hidden` each mean "this element and its text are not part of the
 * chapter", and the two halves have to mean it for the same spellings and the
 * same casings. Make Kotlin's copy case-sensitive on "true" and leave the
 * adapter alone and every other check in both suites stays green while the two
 * halves have silently diverged - which is the class of bug section 8 was
 * written to prevent, one directory over.
 *
 * So: both spellings are checked against the real sanitiser here, the same
 * spellings are checked against the real adapter, and the two declared
 * implementations are compared as source.
 */
const HIDDEN_SPELLINGS = [
  ['hidden, bare', { hidden: '' }, true],
  ['hidden="hidden"', { hidden: 'hidden' }, true],
  ['aria-hidden="true"', { 'aria-hidden': 'true' }, true],
  ['aria-hidden="TRUE"', { 'aria-hidden': 'TRUE' }, true],
  ['aria-hidden=" true "', { 'aria-hidden': ' true ' }, true],
  ['style="display:none"', { style: 'display:none' }, true],
  ['style="display: none"', { style: 'display: none' }, true],
  ['style="DISPLAY : NONE"', { style: 'DISPLAY : NONE' }, true],
  ['style="display: none"', { style: 'display: none' }, true],
  ['style="visibility:hidden"', { style: 'visibility:hidden' }, true],
  ['style="visibility: hidden"', { style: 'visibility: hidden' }, true],
  ['style="VISIBILITY:HIDDEN"', { style: 'VISIBILITY:HIDDEN' }, true],
  ['aria-hidden="false" is not hidden', { 'aria-hidden': 'false' }, false],
  ['aria-hidden="" is not hidden', { 'aria-hidden': '' }, false],
  ['style="display:block" is not hidden', { style: 'display:block' }, false],
  ['style="color:red" is not hidden', { style: 'color:red' }, false],
  ['no attributes at all', {}, false]
];

function attrsToHtml(attrs) {
  return Object.keys(attrs)
    .map(k => k + '="' + String(attrs[k]).replace(/"/g, '&quot;') + '"')
    .join(' ');
}

for (const [label, attrs, hidden] of HIDDEN_SPELLINGS) {
  const el = new El('div', { attrs: attrs, children: [P('p', 'End of Chapter 10')] });
  const article = new El('article', { children: [new El('div', { attrs: { class: 'nv-chapter-body' }, children: [el] })] });
  run(baseEnv(new El('main', { children: [article] }), '/chapter/myslug-10', 'NovTales'));
  const st = JSON.parse(window.__novChapterState(true));
  check('the adapter ' + (hidden ? 'discards' : 'keeps') + ' a marker under: ' + label,
    (st.endMarker === '') === hidden,
    JSON.stringify(st.endMarker) + ' from <div ' + attrsToHtml(attrs) + '>');
}

/* The same spellings, decided by the real Kotlin sanitiser rather than by the
   adapter. The Gradle side of this pin is HtmlSanitiserMirrorTest, which owns
   the Kotlin half; these are the source-level probes that pin the two halves
   together, each expressed as a function of the source so a perturbation of one
   side can be shown to change its answer. */
function kotlinIsHidden(text) { return kotlinFunBody(text, 'private fun isHidden'); }
function adapterDiscards(text) { return kotlinFunBody(text, 'function discardsSubtree'); }

/** True when the sanitiser folds the aria-hidden value's case. */
function ariaFoldsCase(text) {
  const body = kotlinIsHidden(text) || '';
  return /equals\("true",\s*ignoreCase\s*=\s*true\)/.test(body);
}
/** True when the adapter folds the aria-hidden value's case. */
function adapterAriaFoldsCase(text) {
  const body = adapterDiscards(text) || '';
  return /\.trim\(\)\.toLowerCase\(\)\s*===\s*'true'/.test(body);
}
/**
 * The two inline style properties each side looks for, as sorted **names**.
 *
 * Canonicalised because the probes are spelled differently on each side even
 * when the rule is identical - Kotlin writes `contains("display:none")` and the
 * adapter writes `indexOf('display:none')` - so the raw text is not comparable.
 * The property is what the rule is about.
 */
function styleProperties(body) {
  return ((body || '').match(/\b(display|visibility)\s*:\s*(?:none|hidden)\b/g) || [])
    .map(m => m.split(':')[0].trim())
    .filter((v, i, a) => a.indexOf(v) === i)
    .sort()
    .join(',');
}
/** True when a body strips whitespace from the style value before looking. */
function stripsStyleWhitespace(body) {
  return /filterNot\s*\{\s*it\.isWhitespace\(\)\s*\}/.test(body || '') ||
         /replace\(\/\\s\+\/g,\s*''\)/.test(body || '');
}

const ktHidden = kotlinIsHidden(sanitiserSource);
const jsDiscards = adapterDiscards(source);

check('isHidden was found in HtmlSanitiser.kt', ktHidden !== null, String(ktHidden));
check('discardsSubtree was found in the adapter', jsDiscards !== null, String(jsDiscards));
check('it recognises the bare hidden attribute',
  ktHidden !== null && /"hidden"\s*->\s*return true/.test(ktHidden), String(ktHidden));
check('discardsSubtree reads the hidden attribute by name',
  jsDiscards !== null && /hasAttribute\('hidden'\)/.test(jsDiscards), String(jsDiscards));
check('both sides fold the aria-hidden value case-insensitively',
  ariaFoldsCase(sanitiserSource) && adapterAriaFoldsCase(source),
  String(ktHidden) + ' / ' + String(jsDiscards));
check('both sides trim the aria-hidden value first',
  ktHidden !== null && /value\.trim\(\)/.test(ktHidden) && /\.trim\(\)\.toLowerCase\(\)/.test(jsDiscards || ''),
  String(ktHidden) + ' / ' + String(jsDiscards));
check('it does not consult a computed style, like the adapter',
  ktHidden !== null && ktHidden.indexOf('getComputedStyle') < 0 &&
    jsDiscards !== null && jsDiscards.indexOf('getComputedStyle') < 0,
  String(ktHidden) + ' / ' + String(jsDiscards));
check('both sides look for the same two inline style properties',
  styleProperties(ktHidden) === 'display,visibility' &&
    styleProperties(jsDiscards) === 'display,visibility',
  'kotlin: ' + styleProperties(ktHidden) + '  adapter: ' + styleProperties(jsDiscards));
check('both sides strip whitespace from the style value before looking',
  stripsStyleWhitespace(ktHidden) && stripsStyleWhitespace(jsDiscards),
  String(ktHidden) + ' / ' + String(jsDiscards));

/* Perturbations. Each is applied to one side and shown to change that side's
   answer, so none of the probes above is a rubber stamp. */
check(
  'a case-sensitive aria-hidden on the sanitiser side alone is caught',
  ariaFoldsCase(sanitiserSource) &&
    !ariaFoldsCase(sanitiserSource.replace('equals("true", ignoreCase = true)', 'equals("true")')),
  'perturbation must change what the probe sees'
);
check(
  'a case-sensitive aria-hidden on the adapter side alone is caught',
  adapterAriaFoldsCase(source) &&
    !adapterAriaFoldsCase(source.replace(".trim().toLowerCase() === 'true'", ".trim() === 'true'")),
  'perturbation must change what the probe sees'
);
check(
  'a dropped visibility:hidden on the sanitiser side alone is caught',
  styleProperties(ktHidden).indexOf('visibility') >= 0 &&
    styleProperties((ktHidden || '').replace('"visibility:hidden"', '')).indexOf('visibility') < 0,
  'perturbation must change what the probe sees'
);
check(
  'a dropped visibility:hidden on the adapter side alone is caught',
  styleProperties(jsDiscards).indexOf('visibility') >= 0 &&
    styleProperties((jsDiscards || '').replace("'visibility:hidden'", '')).indexOf('visibility') < 0,
  'perturbation must change what the probe sees'
);
check(
  'a dropped hidden attribute on the sanitiser side alone is caught',
  /"hidden"\s*->\s*return true/.test(ktHidden || '') &&
    !/"hidden"\s*->\s*return true/.test((ktHidden || '').replace('"hidden" -> return true', '"hidden" -> {}')),
  'perturbation must change what the probe sees'
);
check(
  'a whitespace-stripping removal on the sanitiser side alone is caught',
  stripsStyleWhitespace(ktHidden) &&
    !stripsStyleWhitespace((ktHidden || '').replace('filterNot { it.isWhitespace() }', '')),
  'perturbation must change what the probe sees'
);
check(
  'a renamed isHidden on the sanitiser side alone is a failure, not an empty match',
  kotlinIsHidden(sanitiserSource.replace('private fun isHidden', 'private fun somethingElse')) === null
);
check(
  'a renamed discardsSubtree on the adapter side alone is a failure, not an empty match',
  adapterDiscards(source.replace('function discardsSubtree', 'function somethingElse')) === null
);

console.log('\n' + passCount + ' passed, ' + failCount + ' failed');
process.exit(failCount === 0 ? 0 : 1);
