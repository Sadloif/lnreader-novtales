/*
 * NovTales page adapter.
 *
 * Injected into https://novtales.com by the companion's WebView and run in the
 * page's own context. It only ever *reads* the page and returns a JSON string;
 * it never modifies the site, never navigates, and never touches cookies or
 * tokens. The companion deliberately installs no JavaScript interface
 * (CONTRACTS.md section 11), so this is the only channel between page and app.
 *
 * Written as plain ES5 (var, function, no arrow functions, no template
 * literals, no Array#includes) so it cannot trip an older WebView, and with no
 * dependency of any kind.
 *
 * Every function returns a JSON *string*; the app decodes that string with its
 * own parser and revalidates the structure natively. Nothing here is trusted.
 */
(function () {
  'use strict';

  var VERSION = '1.0.0';
  var MAX_FLIGHT_TEXT = 4000000;
  var ORIGIN = 'https://novtales.com';

  /* ------------------------------------------------------------------ utils */

  /**
   * Every code point ECMAScript's `\s` matches, as one character class.
   *
   * `norm` rewrites all of them to a plain space and collapses runs, so no text
   * that leaves this file can contain anything but an ASCII space. That is what
   * keeps this file and `ChapterCompletion.END_MARKER` accepting the **same**
   * strings: Java's `\s` is `[ \t\n\x0B\f\r]` and is not Unicode-aware, so a
   * thin space (U+2009) or an ideographic space (U+3000) between two words would
   * be found here and refused there - a visibly complete chapter failing
   * `INCOMPLETE_CHAPTER` on every poll until the deadline. This is the third
   * time these two implementations disagreed about what a marker is; the Kotlin
   * side does the same normalisation on its own input, so neither has to trust
   * the other.
   */
  var ANY_SPACE = new RegExp(
    '[\t\n\v\f\r \u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000\ufeff]+',
    'g'
  );

  function norm(value) {
    if (value === null || value === undefined) return '';
    return String(value)
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t\r\n]+/g, ' ')
      .replace(ANY_SPACE, ' ')
      .replace(/^ +| +$/g, '');
  }

  function isVisible(element) {
    if (!element || !element.getBoundingClientRect) return false;
    if (element.hasAttribute && element.hasAttribute('hidden')) return false;
    if (element.getAttribute && element.getAttribute('aria-hidden') === 'true') return false;
    var style = null;
    try {
      style = window.getComputedStyle(element);
    } catch (ignored) {
      style = null;
    }
    if (style) {
      if (style.display === 'none') return false;
      if (style.visibility === 'hidden') return false;
    }
    var rect = element.getBoundingClientRect();
    return rect.width > 0 || rect.height > 0 || element === document.body;
  }

  function queryAll(selector, root) {
    try {
      return (root || document).querySelectorAll(selector);
    } catch (ignored) {
      return [];
    }
  }

  function query(selector, root) {
    try {
      return (root || document).querySelector(selector);
    } catch (ignored) {
      return null;
    }
  }

  function firstMatch(patterns, root) {
    var i;
    var nodes;
    for (i = 0; i < patterns.length; i++) {
      nodes = queryAll(patterns[i], root);
      if (nodes && nodes.length) return nodes[0];
    }
    return null;
  }

  /**
   * Page text with the chapter body **excluded**.
   *
   * Every "the site is asking for something" decision is made against this, not
   * against the whole document. Chapter prose regularly contains phrases like
   * "sign in to read the rest", and a chapter titled "Unlock Access" is not a pay
   * wall. Excluding the body element removes that whole class of false positive.
   */
  function boundedChromeText() {
    var body = document.body;
    if (!body) return '';
    var chapterBodyElement = chapterBody();
    var out = [];
    var total = 0;
    var walker;
    try {
      walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, {
        acceptNode: function (node) {
          var parent = node.parentNode;
          if (chapterBodyElement && chapterBodyElement.contains && parent &&
              chapterBodyElement.contains(parent)) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }, false);
    } catch (ignored) {
      return boundedBodyText();
    }
    var node = walker.nextNode();
    var guard = 0;
    while (node && guard < 40000 && total < 20000) {
      var value = node.nodeValue || '';
      total += value.length;
      out.push(value);
      node = walker.nextNode();
      guard++;
    }
    return out.join('');
  }

  /** Bounded whole-document text, used only as a last resort. */
  function boundedBodyText() {
    var body = document.body;
    if (!body) return '';
    var text = body.textContent || '';
    if (text.length > 20000) text = text.substring(0, 20000);
    return text;
  }

  /* ------------------------------------------------------- balanced scanner */

  /**
   * Returns the index just past the JSON value that starts at `start`, or -1.
   * Written by hand so that a brace inside a string (a chapter title, a "}" in
   * prose) can never terminate the value early.
   */
  function scanBalanced(text, start) {
    var i = start;
    var n = text.length;
    while (i < n && /\s/.test(text.charAt(i))) i++;
    if (i >= n) return -1;
    var open = text.charAt(i);
    if (open !== '{' && open !== '[') {
      // A scalar value: a quoted string, a number, or a literal.
      if (open === '"') return skipString(text, i);
      // Compared against the post-whitespace index, so a delimiter sitting
      // where a value was expected is reported as "no value" (-1) rather than
      // as a zero-length one.
      var valueStart = i;
      while (i < n && text.charAt(i) !== ',' && text.charAt(i) !== '}' &&
             text.charAt(i) !== ']' && !/\s/.test(text.charAt(i))) i++;
      return i > valueStart ? i : -1;
    }
    var depth = 0;
    while (i < n) {
      var c = text.charAt(i);
      if (c === '"') {
        // skipString already returns the index *after* the closing quote. Adding
        // another step here would step over the brace that follows the string and
        // make every value ending in a string overshoot by one character.
        var afterString = skipString(text, i);
        if (afterString < 0) return -1;
        i = afterString;
        continue;
      }
      if (c === '{' || c === '[') depth++;
      else if (c === '}' || c === ']') {
        depth--;
        if (depth === 0) return i + 1;
      }
      i++;
    }
    return -1;
  }

  /** Index just past the closing quote of the string starting at `start`. */
  function skipString(text, start) {
    var i = start + 1;
    var n = text.length;
    while (i < n) {
      var c = text.charAt(i);
      if (c === '\\') { i += 2; continue; }
      if (c === '"') return i + 1;
      i++;
    }
    return -1;
  }

  /** Index just past the `"key":` value in `text`, or -1 when absent. */
  function balancedAfterKey(text, key) {
    var needle = '"' + key + '"';
    var from = 0;
    var at;
    while (from < text.length) {
      at = text.indexOf(needle, from);
      if (at < 0) return -1;
      var i = at + needle.length;
      while (i < text.length && /\s/.test(text.charAt(i))) i++;
      if (text.charAt(i) === ':') {
        i++;
        while (i < text.length && /\s/.test(text.charAt(i))) i++;
        var end = scanBalanced(text, i);
        if (end > i) return end;
      }
      from = at + needle.length;
    }
    return -1;
  }

  function valueStartAfterKey(text, key) {
    var needle = '"' + key + '"';
    var at = text.indexOf(needle);
    if (at < 0) return -1;
    var i = at + needle.length;
    while (i < text.length && /\s/.test(text.charAt(i))) i++;
    if (text.charAt(i) !== ':') return -1;
    i++;
    while (i < text.length && /\s/.test(text.charAt(i))) i++;
    return i;
  }

  /* --------------------------------------------------- payload extraction */

  /**
   * Reads every `self.__next_f.push([1,"..."])` chunk.
   *
   * Two sources, in order: the live `self.__next_f` array (authoritative, in
   * page order) and the inline <script> texts (still present after hydration).
   * Each encoded string is decoded with JSON.parse - the site's data is never
   * passed to eval or to the Function constructor.
   */
  function readFlightText() {
    var chunks = [];
    var i;
    var sink = self.__next_f;

    if (sink && typeof sink.length === 'number') {
      for (i = 0; i < sink.length && i < 20000; i++) {
        var entry = sink[i];
        if (!entry) continue;
        if (entry.length > 1 && typeof entry[1] === 'string') {
          chunks.push(entry[1]);
        }
      }
    }

    var scripts = queryAll('script');
    for (i = 0; i < scripts.length && i < 400; i++) {
      var text = scripts[i].textContent || '';
      if (text.length > 0 && text.indexOf('__next_f.push') >= 0) {
        appendPushCalls(text, chunks);
      }
    }

    if (!chunks.length) {
      var legacy = query('#__NEXT_DATA__');
      if (legacy && legacy.textContent) {
        try {
          var parsed = JSON.parse(legacy.textContent);
          if (parsed) chunks.push(JSON.stringify(parsed));
        } catch (ignored) { /* not usable */ }
      }
    }

    var joined = chunks.join('');
    if (joined.length > MAX_FLIGHT_TEXT) joined = joined.substring(0, MAX_FLIGHT_TEXT);
    return joined;
  }

  var PUSH_RE = /self\.__next_f\.push\(\s*\[\s*\d+\s*,\s*/g;
  var STRING_RE = /"(?:[^"\\]|\\.)*"/;

  function appendPushCalls(text, out) {
    PUSH_RE.lastIndex = 0;
    var match;
    while ((match = PUSH_RE.exec(text)) !== null) {
      var start = match.index + match[0].length;
      if (text.charAt(start) !== '"') { PUSH_RE.lastIndex = start; continue; }
      STRING_RE.lastIndex = start;
      var literal = STRING_RE.exec(text);
      if (!literal || literal.index !== start) continue;
      try {
        out.push(JSON.parse(literal[0]));
      } catch (ignored) { /* a malformed chunk is skipped, not executed */ }
      PUSH_RE.lastIndex = literal.index + literal[0].length;
    }
  }

  var KEY_ALIASES = {
    catalogue: ['catalogue', 'catalog', 'novels', 'novelList', 'novel_list', 'list', 'items', 'explore', 'result', 'data'],
    novel: ['novel', 'novelData', 'novel_data', 'novelDetail', 'novel_detail', 'result', 'data'],
    chapter: ['chapter', 'chapterData', 'chapter_data', 'chapterDetail', 'chapter_detail', 'result', 'data']
  };

  var SLUG_KEYS = ['slug', 'novelSlug', 'novel_slug'];
  var TITLE_KEYS = ['title', 'name', 'novelTitle'];
  var NUMBER_KEYS = ['number', 'chapterNumber', 'chapter_number', 'index'];

  function shapeScore(value, key) {
    if (!value || typeof value !== 'object') return -1;
    var list = value;
    if (!Array.isArray(list)) list = [value];
    var score = 0;
    for (var i = 0; i < list.length && i < 400; i++) {
      var item = list[i];
      if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
      var hasSlug = false;
      var hasTitle = false;
      var hasNumber = false;
      var hasChapterLink = false;
      for (var k in item) {
        if (!Object.prototype.hasOwnProperty.call(item, k)) continue;
        var v = item[k];
        if (SLUG_KEYS.indexOf(k) >= 0) hasSlug = true;
        else if (TITLE_KEYS.indexOf(k) >= 0) hasTitle = true;
        else if (NUMBER_KEYS.indexOf(k) >= 0) hasNumber = true;
        else if (typeof v === 'string' && v.indexOf('/chapter/') === 0) hasChapterLink = true;
      }
      if (key === 'chapter') {
        if ((hasSlug || hasNumber) && (hasTitle || hasChapterLink)) score++;
      } else if (hasSlug && hasTitle) {
        score++;
      }
    }
    return score;
  }

  /**
   * Structural fallback: walk the top level values of the flight text and return
   * the first one whose *elements* look like the thing being asked for. Used
   * only when no keyed value was found, because the element shape has survived
   * site changes better than the key name has.
   */
  function structuralValue(text, key) {
    var candidates = [];
    collectBalanced(text, 0, text.length, 0, candidates);
    var best = null;
    var bestScore = 0;
    for (var i = 0; i < candidates.length; i++) {
      var parsed;
      try {
        parsed = JSON.parse(candidates[i]);
      } catch (ignored) {
        continue;
      }
      var score = shapeScore(parsed, key);
      if (score > bestScore) { bestScore = score; best = candidates[i]; }
    }
    return bestScore >= 1 ? best : null;
  }

  /**
   * Every balanced JSON value in [start, end), nested ones included.
   *
   * Flight data sits a few levels deep inside ["$", ...] elements, so the
   * structural fallback has to look past the top level to find a listing.
   */
  function collectBalanced(text, start, end, depth, out) {
    if (depth > 3 || out.length > 200) return;
    var i = start;
    while (i < end) {
      var c = text.charAt(i);
      if (c === '"') {
        var s = skipString(text, i);
        if (s < 0) return;
        i = s;
        continue;
      }
      if (c === '{' || c === '[') {
        var stop = scanBalanced(text, i);
        if (stop <= i) { i++; continue; }
        var bounded = stop > end ? end : stop;
        out.push(text.substring(i, bounded));
        collectBalanced(text, i + 1, bounded, depth + 1, out);
        i = bounded;
        continue;
      }
      i++;
    }
  }

  /**
   * Returns a JSON string: `{ok, key, source, value}`.
   * `value` is the extracted JSON value itself, not a string inside a string.
   */
  window.__novExtractPayload = function (key) {
    var wanted = (key === 'novel' || key === 'chapter' || key === 'catalogue') ? key : 'catalogue';
    var result = { ok: false, key: wanted, source: 'none', version: VERSION, value: null };
    var text;
    try {
      text = readFlightText();
    } catch (ignored) {
      return JSON.stringify(result);
    }
    if (!text) return JSON.stringify(result);

    var aliases = KEY_ALIASES[wanted];
    var i;
    var start;
    for (i = 0; i < aliases.length; i++) {
      start = valueStartAfterKey(text, aliases[i]);
      if (start < 0) continue;
      var end = balancedAfterKey(text, aliases[i]);
      if (end <= start) continue;
      var parsed = null;
      try {
        parsed = JSON.parse(text.substring(start, end));
      } catch (ignored) {
        parsed = null;
      }
      if (parsed === null) continue;
      result.ok = true;
      result.source = 'next_f:' + aliases[i];
      result.value = parsed;
      return JSON.stringify(result);
    }

    var structural = structuralValue(text, wanted);
    if (structural) {
      try {
        result.ok = true;
        result.source = 'next_f:structural';
        result.value = JSON.parse(structural);
        return JSON.stringify(result);
      } catch (ignored) { /* fall through */ }
    }
    return JSON.stringify(result);
  };

  /* ------------------------------------------------------- chapter reading */

  function chapterBody() {
    return firstMatch(['.nv-chapter-body', '[class*="nv-chapter-body"]', 'article .prose']);
  }

  /** Text nodes of the article, walked once. */
  function articleRoot() {
    return firstMatch(['article', 'main article', 'article.nv-chapter']) || chapterBody();
  }

  /* ----------------------------------------------------- the sanitiser mirror */

  /**
   * The sanitiser's ways of throwing content away, mirrored here.
   *
   * This is the adapter's half of one rule: **the end marker and the chapter
   * body have to be read from the same view of the document.** A marker the
   * sanitiser is going to delete cannot be in the stored chapter, so it cannot
   * complete it.
   *
   * `HtmlSanitiser` has four such mechanisms and there used to be a mirror of
   * two of them here, which is how a marker inside a scene break completed a
   * chapter whose stored HTML did not contain the marker at all. All four are
   * modelled now, and `tools/js-tests/adapter.test.js` section 12 and
   * `HtmlSanitiserMirrorTest` compare this file's source with the Kotlin's, so
   * the lists cannot be edited apart again - this pair has drifted three times.
   * `DROP_SUBTREE_TAGS` in HtmlSanitiser.kt is the normative copy.
   */

  /**
   * Tags whose whole subtree `HtmlSanitiser` deletes.
   *
   * Kotlin's `DROP_SUBTREE_TAGS`, entry for entry and in the same order.
   */
  var SANITISER_DROP_TAGS = {
    script: 1, style: 1, noscript: 1, iframe: 1, object: 1, embed: 1, form: 1,
    input: 1, button: 1, select: 1, textarea: 1, template: 1, svg: 1, math: 1,
    canvas: 1, audio: 1, video: 1, head: 1, title: 1, meta: 1, link: 1,
    base: 1, applet: 1, frame: 1, frameset: 1, dialog: 1
  };

  /**
   * Class values that mark a scene break. Kotlin's `SCENE_BREAK_CLASS`, verbatim.
   *
   * Note what this deliberately does **not** match: `break`, `break-words`,
   * `text-break` and `md:scene-break`. The bare token `break` was removed
   * because Tailwind spells its utilities that way and the scene-break branch
   * runs before the keep-list, so matching it replaced whole paragraphs of prose
   * with `<hr>`. `md:scene-break` is not recognised either: the responsive
   * prefix is not part of the token. Do not "fix" either one by loosening this
   * expression - the sanitiser would then disagree with it again.
   */
  var SANITISER_SCENE_BREAK_CLASS = /(?:^|\s)scene[-_ ]?(?:break|divider)(?:$|\s)/i;

  /**
   * What a scene-break **marker** may consist of: separator glyphs, digits and
   * whitespace, and nothing else. Kotlin's `SCENE_BREAK_GLYPHS`, verbatim.
   *
   * `HtmlSanitiser` skips a scene-break element's text only when the element is a
   * leaf whose whole text matches this - `* * *`, `***`, a long dash, nothing.
   * Anything else is unwrapped and its text survives, because losing prose is
   * the failure mode that matters: an extra `<hr>` is cosmetic, deleted chapter
   * text is not. The expression deliberately contains no letters, so a
   * scene-break slot holding `End of Chapter 12` is prose and is kept.
   */
  var SANITISER_SCENE_BREAK_GLYPHS =
    /^[\s*+\u00b7\u2022\u2027\u2219\u30fb\u301c\u203b\u2010-\u2015~_.,\-0-9]*$/;

  /**
   * Values of `data-scene-break` that mean **off**. Kotlin's `isAffirmative`.
   *
   * Matched on the value, not on presence: `data-scene-break="false"`, `="0"`
   * and `="off"` all say the element is *not* a scene break, and an earlier
   * presence-only test deleted their content - the exact inverse of what they
   * say.
   */
  var SANITISER_NEGATIVE_VALUES = {
    'false': 1, '0': 1, 'no': 1, 'off': 1, 'none': 1, 'null': 1, 'undefined': 1
  };

  /** True when [element] is itself a scene break, value and all. */
  function sceneBreak(element) {
    var cls = element.getAttribute ? element.getAttribute('class') : null;
    if (cls !== null && cls !== undefined &&
        SANITISER_SCENE_BREAK_CLASS.test(String(cls))) {
      return true;
    }
    var flag = element.getAttribute ? element.getAttribute('data-scene-break') : null;
    if (flag === null || flag === undefined) return false;
    var value = String(flag).trim();
    if (value === '') return true;              // `<div data-scene-break>`
    if (value.length > 20) return false;        // Kotlin's budget, same bound
    return SANITISER_NEGATIVE_VALUES[value.toLowerCase()] !== 1;
  }

  /** Kotlin's `Parser.isLeafGlyphMarker`, in DOM terms. */
  function isLeafGlyphMarker(element) {
    var kids = markerChildren(element);
    for (var i = 0; i < kids.length; i++) {
      if (!isTextNode(kids[i])) return false;   // any nested tag: not a leaf
    }
    return SANITISER_SCENE_BREAK_GLYPHS.test(norm(markerTextOf(element)));
  }

  /** Kotlin's `Parser.isCanary`. Only ever consulted for an `<a>`. */
  function isCanary(element) {
    if (element.hasAttribute && element.hasAttribute('data-security-canary')) return true;
    var href = element.getAttribute ? element.getAttribute('href') : null;
    if (href === null || href === undefined) return false;
    return String(href).toLowerCase().indexOf('data-security-canary') >= 0;
  }

  /**
   * True when the sanitiser deletes [element]'s subtree on its own account.
   *
   * This is [droppedOrHidden] without the ancestor walk. The marker walk calls it
   * once per element and propagates the answer down the tree, which gives the
   * same result for a fraction of the work. The order of the tests is the
   * sanitiser's own: dropped tag, then canary, then hidden - and the scene break
   * last, because `handleTag` writes images before it reaches that branch.
   */
  function discardsSubtree(element) {
    // `tagName` in a browser, `tag` in the test DOM; absent on the document
    // node and on text nodes, which is where the walk stops.
    var tag = String(element.tagName || element.tag || '').toLowerCase();
    if (!tag) return false;
    if (SANITISER_DROP_TAGS[tag] === 1) return true;
    if (tag === 'a' && isCanary(element)) return true;
    if (element.hasAttribute && element.hasAttribute('hidden')) return true;
    var aria = element.getAttribute ? element.getAttribute('aria-hidden') : null;
    if (aria !== null && aria !== undefined && String(aria).trim().toLowerCase() === 'true') {
      return true;
    }
    // The inline `style` attribute, checked exactly as HtmlSanitiser.isHidden
    // checks it, whitespace-insensitively so "display : none" is caught too.
    // Reading the attribute rather than the computed style is deliberate and is
    // not a shortcut: the sanitiser reads the attribute, so the attribute is
    // what decides what survives into the stored chapter.
    var inline = element.getAttribute ? element.getAttribute('style') : null;
    if (inline !== null && inline !== undefined) {
      var compact = String(inline).toLowerCase().replace(/\s+/g, '');
      if (compact.indexOf('display:none') >= 0) return true;
      if (compact.indexOf('visibility:hidden') >= 0) return true;
    }
    if (tag !== 'img' && sceneBreak(element) && isLeafGlyphMarker(element)) return true;
    return false;
  }

  /**
   * True when [element] is inside something the sanitiser drops or hides.
   *
   * The whole of the mirror in one predicate. It used to consult
   * `getComputedStyle` on every ancestor as well, and that was **stricter** than
   * the sanitiser, which reads only the inline `style` attribute. The gap was a
   * denial of service on the reader: a site that hides its own marker with a
   * stylesheet had a chapter that the sanitiser stored in full and this function
   * refused for ever, so it polled to the deadline and failed
   * `INCOMPLETE_CHAPTER`. The sanitiser is a security control and must not be
   * weakened to match, and it is a plain string scanner that cannot ask a browser
   * what a stylesheet said - so the adapter was brought back to the sanitiser's
   * view. What survives sanitising can complete a chapter; nothing else can.
   */
  function droppedOrHidden(element) {
    var node = element;
    var depth = 0;
    while (node && depth < 512) {
      if (discardsSubtree(node)) return true;
      node = node.parentNode || node.parent || null;
      depth++;
    }
    return false;
  }

  /* --------------------------------------------------------- the end marker */

  /**
   * `End of Chapter <number>` and nothing else, in any case.
   *
   * This is the whole marker, and it accepts the same set of strings as Kotlin's
   * `END_MARKER`, `(?i)^\s*End of Chapter\s+(\d+(?:\.\d+)?)\s*$`. The two agree
   * because [norm] has already reduced every Unicode space to an ASCII one,
   * which is all Java's `\s` covers; see [ANY_SPACE].
   *
   * It is **anchored on purpose**. The rule it replaces was
   * `/end\s+of\s+chapter/i` anywhere in the assembled article text, trimmed to
   * the number that followed, which is why any sentence containing the words
   * completed a truncated chapter.
   */
  var END_MARKER_COMPLETE = /^end\s+of\s+chapter\s+[0-9]+(?:\.[0-9]+)?$/i;

  /** Longer than any marker can be, so a longer element is dismissed at once. */
  var MARKER_WINDOW = 64;

  /** How deep the marker walk descends before it stops looking. */
  var MARKER_WALK_LIMIT = 256;

  /** True for a DOM text node, in a browser and in the test DOM alike. */
  function isTextNode(node) {
    if (node.nodeType !== undefined) return node.nodeType === 3;
    return !node.tag;                 // the test DOM puts the text on the element
  }

  /** The text a node contributes, under either DOM's convention. */
  function markerTextOf(node) {
    if (typeof node.nodeValue === 'string') return node.nodeValue;
    return typeof node.text === 'string' ? node.text : '';
  }

  function markerChildren(node) {
    return node.childNodes || node.children || [];
  }

  /**
   * One element's text as the sanitiser would leave it.
   *
   * Recurses, carrying down whether the subtree has already been discarded, so a
   * dropped element costs one check and everything under it is skipped. Text
   * past [MARKER_WINDOW] is never built - an element that long cannot be a
   * marker - but the walk still descends past it, so a marker deep inside a
   * long paragraph is still found.
   *
   * Nodes are joined with a single space rather than concatenated. That is what
   * lets `End of<br>Chapter 10` and `End of Chapter ` + `10` reassemble: the
   * robustness the unanchored search was added for, kept without the unanchored
   * search, because the window is now one element and never the article.
   *
   * Every surviving element is appended to [out] as `{element, text}`, and its
   * **own** text - its direct text children, never a descendant's - is recorded
   * in [ownOf] under the element itself. [findEndMarker] compares the two: an
   * element whose *parent* has text of its own has been run into prose.
   */
  function walkMarker(node, depth, dropped, out, ownOf) {
    if (depth > MARKER_WALK_LIMIT) return '';
    var isDropped = dropped || discardsSubtree(node);
    var kids = markerChildren(node);
    var parts = [];
    var length = 0;
    var tooLong = false;
    var i;

    function take(value) {
      if (!value || tooLong) return;
      length += value.length + (parts.length ? 1 : 0);
      if (length > MARKER_WINDOW) { tooLong = true; return; }
      parts.push(value);
    }

    take(norm(markerTextOf(node)));
    for (i = 0; i < kids.length; i++) {
      var kid = kids[i];
      var piece = isTextNode(kid)
        ? norm(markerTextOf(kid))
        : walkMarker(kid, depth + 1, isDropped, out, ownOf);
      take(piece);
    }

    // Recorded even when the element is dropped or too long: a candidate child
    // still has to be able to ask what its parent's own text was.
    if (!isDropped) {
      var own = norm(markerTextOf(node));
      for (i = 0; i < kids.length; i++) {
        if (!isTextNode(kids[i])) continue;
        var direct = norm(markerTextOf(kids[i]));
        if (direct) own = own ? own + ' ' + direct : direct;
      }
      ownOf.set(node, own);
    }
    if (isDropped || tooLong) return '';

    var text = parts.join(' ');
    if (text) out.push({ element: node, text: text });
    return text;
  }

  /**
   * The end marker, or `''`.
   *
   * This only *finds* a candidate. Whether it is exactly `End of Chapter N` for
   * the requested N is decided natively in ChapterCompletion, so the strictness
   * lives in one place and cannot drift.
   *
   * **The rule.** The marker is the entire text of one element, and that element
   * is not run into prose inside its own parent. Both halves are load-bearing:
   *
   *  - "the entire text of one element" is what a sentence can never be.
   *    "End of Chapter 12 was the night the gate opened." and "Skipping ahead:
   *    the End Of Chapter 12 recap was wrong." fail it, because no element's
   *    whole text is the marker. So does any truncated chapter whose prose
   *    happens to contain the phrase, however it is capitalised.
   *  - "not run into prose in its parent" is what stops `<p>Recap:
   *    <strong>End of Chapter 12</strong></p>`, where the marker is a dedicated
   *    element but sits in the middle of a sentence. Only the parent's *direct*
   *    text counts, because the site's markup is `<article><h2/><div
   *    class="nv-chapter-body">…</div><span>End of Chapter 1</span></article>`,
   *    where the marker is a sibling of the whole chapter and must still count.
   *
   * Everything the unanchored search had been bought for still works, because
   * the assembly happens *within* the element: React's `End of Chapter {n}` split
   * across sibling nodes, a `<br>` in the middle, any casing, `944.5`, `010`,
   * and a marker that follows a document's worth of prose.
   *
   * The **first** qualifying element in document order wins, which is the rule
   * that stops a "previous chapter" teaser after the real marker from being
   * delivered as the chapter. Nothing requires the marker to be the last thing
   * in the article: a footer or a "next chapter" link after it is ordinary page
   * furniture, and demanding that the marker end the article would reject pages
   * that are complete.
   */
  function findEndMarker() {
    var article = articleRoot();
    if (!article) return '';
    if (droppedOrHidden(article)) return '';

    var out = [];
    var ownOf = new Map();
    walkMarker(article, 0, false, out, ownOf);

    // Elements come back depth-first, children before parents. A parent can only
    // qualify when its single text-bearing child does, so the two carry the same
    // text and the order between them cannot change the answer.
    for (var i = 0; i < out.length; i++) {
      var candidate = out[i];
      if (!END_MARKER_COMPLETE.test(candidate.text)) continue;
      var parent = candidate.element.parentNode || candidate.element.parent || null;
      if (parent && ownOf.get(parent)) continue;   // run into prose in its parent
      return candidate.text;
    }
    return '';
  }

  /**
   * `section[aria-label="Loading chapter"]` is the site's own precise negative
   * signal: it is present for the whole of delivery and gone afterwards.
   *
   * The spinner check is deliberately scoped to the chapter's own container. A
   * bare `.animate-spin` anywhere on the page (a nav spinner, a refresh icon)
   * would otherwise report "still loading" forever and stall a chapter that had
   * actually finished.
   */
  function deliveryRunning() {
    var loader = firstMatch([
      'section[aria-label="Loading chapter"]',
      '[aria-label="Loading chapter"]'
    ]);
    if (loader && isVisible(loader)) return true;

    var scope = firstMatch(['.nv-chapter-body', 'article', 'main']);
    if (scope) {
      var spinner = firstMatch([
        '.animate-spin',
        '[role="progressbar"]',
        '[aria-busy="true"]',
        '.skeleton',
        '[class*="skeleton"]'
      ], scope);
      if (spinner && isVisible(spinner)) return true;
    }
    return false;
  }

  function loadMoreButton() {
    var candidates = queryAll('button, a[role="button"], [role="button"]');
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      var text = norm(el.textContent || '').toLowerCase();
      if (!text) continue;
      if (text.indexOf('load more') >= 0 || text.indexOf('next part') >= 0 ||
          text.indexOf('continue reading') >= 0 || text.indexOf('show more') >= 0) {
        if (isVisible(el)) return el;
      }
    }
    return null;
  }

  /* --------------------------------------------------------- page diagnosis */

  /**
   * Verification is only ever reported from a **verified marker**: a challenge
   * title, the challenge interstitial itself, or the site's own challenge copy.
   * An HTTP 429 is a rate limit and is reported as such, never as verification
   * (CONTRACTS.md section 5, spec section 10).
   */
  function verificationState(bodyText) {
    var title = norm(document.title).toLowerCase();
    var titles = [
      'just a moment',
      'checking your browser',
      'attention required',
      'vercel security checkpoint'
    ];
    for (var i = 0; i < titles.length; i++) {
      if (title.indexOf(titles[i]) >= 0) return true;
    }
    if (query('#challenge-running, #cf-challenge-running, .cf-browser-verification, [data-vercel-challenge]')) {
      return true;
    }
    var body = bodyText.toLowerCase();
    var phrases = [
      "we're verifying your browser",
      'we are verifying your browser',
      'verifying you are human',
      'verify you are human',
      'checking your browser before accessing',
      'enable javascript and cookies to continue',
      'performance & security by cloudflare',
      'ray id'
    ];
    for (var j = 0; j < phrases.length; j++) {
      if (body.indexOf(phrases[j]) >= 0) return true;
    }
    return false;
  }

  /** The measured signed-out copy: "Protected reading is paused — Sign in". */
  function readingNoticeState() {
    var headings = queryAll('h2, [aria-label="Reading notice pending"]');
    for (var i = 0; i < headings.length; i++) {
      var text = norm(headings[i].textContent || '').toLowerCase();
      if (text === 'suspicious activity detected' || text === 'you’re reading very fast' ||
          text === "you're reading very fast" || text.indexOf('reading remains paused until you acknowledge') >= 0) return true;
    }
    return false;
  }

  function signInState(bodyText) {
    var body = bodyText.toLowerCase();
    var phrases = [
      'protected reading is paused — sign in',
      'sign in to continue reading',
      'sign in to read',
      'log in to continue reading',
      'you need to be signed in',
      'sign in to unlock'
    ];
    for (var i = 0; i < phrases.length; i++) {
      if (body.indexOf(phrases[i]) >= 0) return true;
    }
    var headings = queryAll('h1, h2, h3');
    for (var j = 0; j < headings.length; j++) {
      var text = norm(headings[j].textContent || '').toLowerCase();
      if (text === 'sign in' || text === 'log in' || text === 'sign-in required') {
        if (isVisible(headings[j])) return true;
      }
    }
    return false;
  }

  /** `<h2>Unlock Access</h2>` and its relatives are the measured locked notice. */
  function membershipState(bodyText) {
    var headings = queryAll('h1, h2, h3');
    for (var i = 0; i < headings.length; i++) {
      var text = norm(headings[i].textContent || '').toLowerCase();
      if (text === 'unlock access' || text === 'members only' || text === 'premium chapter') {
        if (isVisible(headings[i])) return true;
      }
    }
    var body = bodyText.toLowerCase();
    var phrases = [
      'this chapter is locked',
      'unlock this chapter',
      'subscribers only',
      'subscribe to read',
      'membership required',
      'upgrade to continue reading'
    ];
    for (var j = 0; j < phrases.length; j++) {
      if (body.indexOf(phrases[j]) >= 0) return true;
    }
    return false;
  }

  /** The site's own rate-limit copy. Distinct from verification by design. */
  function rateLimitState(bodyText) {
    var body = bodyText.toLowerCase();
    return body.indexOf('too many requests') >= 0 ||
           body.indexOf('rate limit') >= 0 ||
           body.indexOf('slow down') >= 0;
  }

  function headingNumber(headingText) {
    var match = /chapter\s+(\d+(?:\.\d+)?)/i.exec(headingText || '');
    if (!match) return '';
    var number = match[1];
    var dot = number.indexOf('.');
    if (dot >= 0) {
      var whole = number.substring(0, dot).replace(/^0+(?=\d)/, '');
      var fraction = number.substring(dot + 1).replace(/0+$/, '');
      return fraction ? whole + '.' + fraction : whole;
    }
    return number.replace(/^0+(?=\d)/, '');
  }

  /**
   * Returns a JSON string with the page's chapter state.
   *
   * `includeBody` is false while polling, because shipping the whole chapter
   * across the bridge every 400ms is wasteful; the body is fetched exactly once,
   * after the completion rule has already been satisfied.
   */
  window.__novChapterState = function (includeBody) {
    var wantBody = includeBody !== false;
    var body = chapterBody();
    var bodyHtml = '';
    var bodyLength = 0;
    var paragraphs = 0;
    if (body) {
      bodyLength = (body.innerHTML || '').length;
      paragraphs = body.getElementsByTagName('p').length;
      if (wantBody) bodyHtml = body.innerHTML || '';
    }
    var bodyText = boundedChromeText();
    var heading = norm((firstMatch(['article h2', 'article h1', 'main h2']) || {}).textContent || '');
    var path = '';
    try {
      path = location.pathname || '';
    } catch (ignored) {
      path = '';
    }
    var marker = findEndMarker();
    var markerMatch = /end of chapter\s+(\d+(?:\.\d+)?)/i.exec(marker);
    var number = headingNumber(heading);
    if (!number && markerMatch) number = headingNumber(markerMatch[0]);
    if (!number) {
      var pathMatch = /\/chapter\/[a-z0-9-]+-(\d+(?:\.\d+)?)$/.exec(path);
      if (pathMatch) number = headingNumber('chapter ' + pathMatch[1]);
    }

    return JSON.stringify({
      version: VERSION,
      url: safeHref(),
      path: path,
      chapterNumber: number,
      heading: heading,
      bodyHtml: bodyHtml,
      bodyLength: bodyLength,
      paragraphCount: paragraphs,
      endMarker: marker,
      endMarkerNumber: markerMatch ? markerMatch[1] : '',
      signInRequired: signInState(bodyText),
      readingNoticeRequired: readingNoticeState(),
      membershipRequired: membershipState(bodyText),
      verificationRequired: verificationState(bodyText),
      rateLimited: rateLimitState(bodyText),
      stillLoading: deliveryRunning(),
      hasLoadMore: !!loadMoreButton(),
      documentTitle: norm(document.title)
    });
  };

  function safeHref() {
    try {
      return location.href || '';
    } catch (ignored) {
      return '';
    }
  }

  /**
   * Scrolls to the bottom so the site's own next-part loader fires, and clicks
   * its button when there is one.
   *
   * Synchronous on purpose. `evaluateJavascript` does not reliably await a
   * returned promise, so the app measures growth by comparing `bodyLength`
   * across consecutive polls instead of trusting a promise.
   */
  window.__novScrollForMore = function () {
    var pageText = norm(document.body ? document.body.textContent : '');
    if (readingNoticeState() || signInState(pageText) || membershipState(pageText)) {
      return JSON.stringify({ requested: false, clicked: false });
    }
    var body = chapterBody();
    var before = body ? (body.innerHTML || '').length : 0;
    var button = loadMoreButton();
    var clicked = false;
    if (button) {
      try {
        button.click();
        clicked = true;
      } catch (ignored) { /* the site may re-render it out from under us */ }
    }
    try {
      window.scrollTo(0, document.body ? document.body.scrollHeight : 0);
    } catch (ignored) { /* nothing to scroll */ }
    return JSON.stringify({
      version: VERSION,
      requested: true,
      clicked: clicked,
      beforeLength: before,
      hasLoadMore: !!button,
      running: deliveryRunning()
    });
  };

  /* ------------------------------------------------------------- DOM backup */

  /**
   * Last-resort DOM read, used only when the payload route produced nothing.
   * It reports what the page itself renders; it never fabricates an item.
   */
  window.__novDomSnapshot = function (key) {
    var result = { ok: false, key: key || 'catalogue', source: 'dom', items: [] };
    var wanted = key === 'chapter' ? '/chapter/' : '/novel/';
    var nodes = queryAll('a[href*="' + wanted + '"]');
    var seen = {};
    var items = [];
    for (var i = 0; i < nodes.length && items.length < 500; i++) {
      var anchor = nodes[i];
      var path = pathOf(anchor.getAttribute('href'));
      if (!path || seen[path]) continue;
      seen[path] = true;
      var name = norm(anchor.textContent || '');
      var container = anchor.closest ? anchor.closest('article, li, .card, div') : anchor;
      var image = container ? query('img', container) : null;
      var cover = image ? absolute(image.getAttribute('src') || '') : '';
      var item = { path: path, name: name };
      if (cover) item.cover = cover;
      if (wanted === '/chapter/') {
        var m = /\/chapter\/[a-z0-9-]+-(\d+(?:\.\d+)?)$/.exec(path);
        if (m) item.chapterNumber = Number(m[1]);
      }
      items.push(item);
    }
    result.ok = items.length > 0;
    result.items = items;
    return JSON.stringify(result);
  };

  function pathOf(href) {
    if (!href) return '';
    var value = href.trim();
    if (value.indexOf('//') === 0) value = 'https:' + value;
    if (value.indexOf(ORIGIN) === 0) value = value.substring(ORIGIN.length);
    if (value.charAt(0) !== '/') return '';
    return value.split('#')[0].split('?')[0];
  }

  function absolute(src) {
    if (!src) return '';
    if (src.indexOf('//') === 0) return 'https:' + src;
    if (src.indexOf('/') === 0) return 'https://novtales.com' + src;
    return src;
  }

  /* -------------------------------------------------------- async JSON read */

  /**
   * A promise-free JSON fetch.
   *
   * The chapter index lives at `/api/public/novel-chapters/{slug}`. The page's
   * own code already knows how to authenticate to it, so rather than
   * reimplementing that (or exporting anything) the app asks the page to fetch
   * with its own credentials and then polls a global for the outcome.
   */
  window.__novFetchJson = function (url) {
    var job = { state: 'pending', url: url, body: '', status: 0 };
    window.__novAsync = job;
    try {
      window.fetch(url, { credentials: 'include', headers: { 'accept': 'application/json' } })
        .then(function (response) {
          return response.text().then(function (body) {
            if (window.__novAsync !== job) return;
            window.__novAsync = { state: 'done', url: url, body: body, status: response.status };
          });
        })
        .catch(function (error) {
          if (window.__novAsync !== job) return;
          window.__novAsync = {
            state: 'error', url: url, body: '', status: 0,
            error: String(error && error.message ? error.message : error)
          };
        });
    } catch (error) {
      window.__novAsync = { state: 'error', url: url, body: '', status: 0, error: String(error) };
    }
    return JSON.stringify({ state: 'pending' });
  };

  window.__novAsyncResult = function () {
    return JSON.stringify(window.__novAsync || { state: 'idle' });
  };

  window.__novAdapterVersion = VERSION;
  return VERSION;
})();
