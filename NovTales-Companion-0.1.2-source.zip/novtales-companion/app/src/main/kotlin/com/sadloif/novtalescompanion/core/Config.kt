package com.sadloif.novtalescompanion.core

/**
 * Every tunable the specification calls an "initial default", in one place so the
 * phone measurement pass (spec section 10) has a single file to edit.
 *
 * These are measured starting points on an Oppo Reno 15, not website guarantees.
 */
object Config {

    /** Loopback only. Never bind this to a LAN or public interface. */
    const val LOOPBACK_HOST = "127.0.0.1"
    const val PORT = 5301

    /** Independent of the website adapter version. Bump when the local API changes shape. */
    const val API_VERSION = 1

    /** Matches BuildConfig.VERSION_NAME. Kept here so the API and the app cannot drift. */
    const val COMPANION_VERSION = "0.1.2"

    // ---- Queue bounds (spec section 10) -------------------------------------

    /** Jobs allowed to wait behind the single active WebView operation. */
    const val MAX_WAITING_JOBS = 4

    /** Separate ceiling on how long a job may sit in the queue before it is rejected. */
    const val MAX_QUEUE_WAIT_MS = 20_000L

    /** Metadata deadline (catalogue, search, novel, chapters). */
    const val METADATA_DEADLINE_MS = 45_000L

    /** Chapter deadline, measured from when the operation actually starts. */
    const val CHAPTER_DEADLINE_MS = 120_000L

    /** Delay the plugin should wait after a QUEUE_FULL response. */
    const val QUEUE_FULL_RETRY_AFTER_MS = 3_000L

    // ---- Transfer bounds (spec section 11) ---------------------------------

    /** Max request line + headers accepted, in bytes. */
    const val MAX_HEADER_BYTES = 16 * 1024

    /** Max JSON request body accepted, in bytes. */
    const val MAX_REQUEST_BODY_BYTES = 16 * 1024

    /** Max response bytes written before the connection is dropped. */
    const val MAX_RESPONSE_BYTES = 8L * 1024 * 1024

    /** Completed jobs are retained this long so a slow poller can still read the result. */
    const val JOB_RETENTION_MS = 120_000L

    /** Finished and expired jobs are swept on this interval. */
    const val JOB_SWEEP_INTERVAL_MS = 15_000L

    // ---- Connection bounds (spec section 11) -----------------------------------

    /**
     * How long a request head may take to arrive, counted from the **first byte
     * the peer actually sends**, with the head and any body inside that one
     * window. An accepted socket that has not sent a byte at all gets the same
     * budget, because an idle connection is the cheapest way to occupy a thread.
     *
     * Why it is absolute, and not an `SO_TIMEOUT`: a socket read timeout applies
     * per read, so a peer that dribbles one byte at a time resets it forever and
     * holds a worker indefinitely. This is the deadline a worker checks between
     * reads; [SOCKET_READ_POLL_MS] only decides how often it gets the chance to.
     *
     * The trade-off, stated plainly: this is the window in which a legitimate
     * plugin must get its whole request out. It is a loopback socket and the
     * entire request - head plus body - is under 16 KiB, so a responsive client
     * spends single-digit milliseconds here and the budget is two orders of
     * magnitude larger. It is *not* two orders of magnitude larger than a phone
     * under load, which is the real constraint: the plugin polls once a second,
     * a WebView is rendering a chapter while it does, and a GC pause or a
     * descheduled process can cost hundreds of milliseconds. One second leaves
     * room for that and costs an attacker only the ability to stall one request
     * for one second per socket, instead of the fifteen it used to get. Going
     * much below this would start refusing real plugins under load, which is a
     * worse failure than a slow one.
     */
    const val HEAD_READ_DEADLINE_MS = 1_000L

    /**
     * How long one socket read blocks before the deadline is re-checked.
     *
     * Strictly an implementation detail of [HEAD_READ_DEADLINE_MS]: it bounds
     * how long a hung-up connection can take to be noticed, nothing else. It has
     * to be well under the deadline so that a pause inside a legitimate head
     * costs nothing - the read is simply retried.
     */
    const val SOCKET_READ_POLL_MS = 250L

    // ---- Session ------------------------------------------------------------

    /** Only novtales.com pages may be loaded in the companion WebView. */
    const val ALLOWED_HOST = "novtales.com"
    const val SITE_ORIGIN = "https://novtales.com"

    /** Suggested plugin poll interval (spec section 7). */
    const val POLL_FAST_MS = 1_000L
    const val POLL_SLOW_MS = 2_000L
}
