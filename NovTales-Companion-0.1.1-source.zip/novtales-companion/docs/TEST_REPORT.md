# Test report — NovTales Companion

**Build status: installable test build. NOT a verified working release.**

Spec section 12 is explicit: *"Passing compilation, mocked tests or a desktop
browser demonstration is not sufficient to claim Android success. Record which
tests ran on an emulator, which ran on the actual Oppo, and which remain
untested."* This report does exactly that, and is written to be updated as
on-device results arrive.

---

## 1. Versions under test

| Item | Value | Source |
|---|---|---|
| Companion APK version | `0.1.0` (versionCode 1) | `app/build.gradle.kts` |
| Plugin version | `2.0.0` | `lnreader-plugin/plugins/english/novtales.ts` |
| Local API version | 1 | `core/Config.kt` |
| Gradle / AGP / Kotlin | 8.9 / 8.7.3 / 2.0.21 | `build.gradle.kts` |
| JDK | Temurin 17.0.20.1 | build machine |
| compileSdk / targetSdk / minSdk | 35 / 35 / 26 | `app/build.gradle.kts` |

### To be recorded on the phone — do NOT infer

Spec section 2 requires these to be read from the device, not guessed from the
model name. **All four are currently unrecorded.**

| Item | Value |
|---|---|
| Phone model | Oppo Reno 15 |
| Android version | ⬜ *unrecorded* |
| ColorOS version | ⬜ *unrecorded* |
| Android System WebView version | ⬜ *unrecorded* |
| Installed LNReader version | reported as 2.1.4 — ⬜ *to be confirmed on device* |

---

## 2. Build evidence

| Check | Result |
|---|---|
| `test assembleRelease` | ✅ **BUILD SUCCESSFUL** |
| Tests | ✅ **704 tests, 0 failures** (section 3) |
| APK produced | ✅ `dist/NovTales-Companion-0.1.0.apk` — 867,033 bytes |
| APK Signature Scheme v1 | ✅ **applied and verified** — see the note below |
| APK Signature Scheme v2 | ✅ verified |
| APK Signature Scheme v3 | ✅ verified |
| R8 minification + resource shrinking | ✅ enabled, build passes |
| Lint | ⚠️ **non-blocking and only partly recorded** — see the note below |

### `assembleRelease` fails on the delivered tree — by design

The delivered tree has **no** `novtales-release.jks` or `keystore.properties`;
the private key is deliberately not published. `app/build.gradle.kts` therefore
**throws** when a release task is requested, and `docs/BUILD.md` gives the
`keytool` command to create a real identity.

This replaced a silent fallback to the debug signing config, which an audit
showed was dangerous: it produced an APK that reported `BUILD SUCCESSFUL`,
`apksigner verify` → `Verifies`, and a correct package name and version, while
being signed `CN=Android Debug` (`752e16af…`) instead of the release identity
(`b8643bc4…`). Such an APK **cannot update an existing installation** — it forces
an uninstall and loses the user's app data, with nothing warning them.

The digests below are therefore the digest of the **staged release APK**, which
was built with the real identity. They cannot be reproduced from the delivered
tree alone; see "The published APK digest is not re-derivable by rebuilding"
below.

To check an APK is the release artefact, compare the **certificate digest** —
`b8643bc425e4d4f3d387e91af74c0c940a9a6a14fb8eb7344d69a6b83ac38890` — rather
than trusting that `verify` exited zero.

### Where the APK lives

The shipped artefact is **`dist/NovTales-Companion-0.1.0.apk`**.

`novtales-companion/app/build/outputs/apk/release/app-release.apk` is where Gradle
writes it, but `app/build/` is excluded by `sync-to-app.ps1` as a build cache, so
that path **does not exist in the delivery**. Anyone reviewing the delivered tree
should look in `dist/`.

### APK Signature Scheme v1 — applied, not "not needed"

This was previously recorded here as *"not applied (not needed at minSdk 26)"*.
That was wrong on both counts.

* `app/build.gradle.kts` sets `enableV1Signing = true` alongside v2 and v3.
* The APK contains `META-INF/MANIFEST.MF`, `META-INF/CERT.SF` and
  `META-INF/CERT.RSA` — the three files a v1/JAR signature is made of.
* `apksigner verify --verbose` prints `Verified using v1 scheme: false`, which is
  what made the original claim. **That line is not evidence of absence.**
  `apksigner` takes its min-SDK from the APK manifest; at minSdk 26 the JAR scheme
  is unnecessary, so it skips the check and reports it as not-required.

Forcing the check proves it:

```sh
apksigner verify --verbose --min-sdk-version 23 dist/NovTales-Companion-0.1.0.apk
#   Verifies
#   Verified using v1 scheme (JAR signing): true
#   Verified using v2 scheme (APK Signature Scheme v2): true
#   Verified using v3 scheme (APK Signature Scheme v3): true
```

`scripts/release-evidence.ps1` now runs apksigner **twice** — once at the
manifest's min-SDK and once forced to 23 — so its output cannot reproduce this
error again.

### Lint — what actually happened

This was previously recorded as *"✅ runs, `abortOnError = false`"*, which reads
as a green check it is not.

The honest position:

* `lint { abortOnError = false }` in `app/build.gradle.kts` means **a lint error
  can never fail this build**. Lint is advisory here.
* Only `lintVitalRelease` ran, and only because `assembleRelease` triggers it.
  Lint-vital checks are the fatal-severity subset; the full `lint` task has
  **not** been run, and no `lint-results-*.xml` exists for either variant.
* The one recorded result is
  `app/build/intermediates/lint_vital_intermediate_text_report/release/lintVitalReportRelease/lint-results-release.txt`,
  which reads **`No issues found.`** — i.e. no fatal-severity issues. It is an
  intermediate build artefact and is **not** in the delivery.

So: lint runs, it is non-blocking, and only the vital subset has a recorded
result. A reviewer wanting the full analysis should run `gradlew.bat lint` and
read `app/build/reports/lint-results-release.html`.

### Release digests — record these

| Digest | Value |
|---|---|
| **APK SHA-256** | `39f9363965c9bc8a1a928377d6303e17c0e4574a69afb6f850efc504c7c198d4` |
| **Certificate SHA-256** | `b8:64:3b:c4:25:e4:d4:f3:d3:87:e9:1a:f7:4c:0c:94:0a:9a:6a:14:fb:8e:b7:34:4d:69:a6:b8:3a:c3:88:90` |
| Certificate DN | `CN=NovTales Companion, OU=NovTales, O=NovTales, C=GB` |
| Key | RSA 4096, valid to 2056-09-25 |
| **Source ZIP SHA-256** | see `dist/` — regenerate with `make-source-zip.ps1` |

Regenerate after any source change with `scripts/release-evidence.ps1`.

The private keystore and `keystore.properties` are git-ignored and are **not**
part of the delivered source. Without the keystore a later APK cannot update an
installed copy.

### Spec section 13 — what the delivery contains

Spec section 13: *"For review, supply a source repository or source ZIP alongside
the APK. APK-only review cannot fully assess lifecycle, parsing, security or
maintainability."*

| Required | Supplied | Where |
|---|---|---|
| The APK | ✅ | `dist/NovTales-Companion-0.1.0.apk` |
| Source alongside it | ✅ | `dist/NovTales-Companion-0.1.0-source.zip` |
| A source *repository* | ❌ | There is **no `.git`** in this tree — see `docs/DEVIATIONS.md` §7. The ZIP stands in for the repository. |
| Sanitised logs | ❌ | Section 6 — nothing has run on the device |
| Screenshots | ❌ | Section 6 — nothing has run on the device |

The source ZIP is a plain archive of the delivered tree, minus `_working/`,
`tools/gradle-dist/`, `node_modules/`, every `build/` directory, `local.properties`
and the signing secrets. `make-source-zip.ps1` rebuilds it and refuses to package
if a `.jks` or `keystore.properties` ever reaches the staging tree.

### The published APK digest is not re-derivable by rebuilding

An audit asked whether a reviewer could rebuild and land on the same SHA-256.
The precise answer is no, and the reason is worth recording rather than hiding:

* Three consecutive rebuilds from the delivered tree produced an **identical**
  digest.
* A byte-level comparison found **all 385 zip entries identical** — `classes.dex`,
  `resources.arsc`, the manifest, the assets, and the v1 JAR signature — and the
  v2 and v3 signature blocks identical too.
* The only differing bytes: **3,018**, inside one auxiliary signing-block pair
  (`0x504b4453`, "PKDS"). That region is not part of the signed content.

The build is therefore **content-reproducible** and **cryptographically
equivalent**, but **not bit-reproducible**. The digest above is the digest of the
**shipped file**. Hash the APK you were given to verify it; do not expect a
rebuild to reproduce it, and do not read a differing rebuild digest as evidence
of tampering without first comparing the 385 entries one by one.

**A false alarm worth naming.** The archive holds `res/9N.9.png` and
`res/9n.9.png`. They look like a duplicate pair but are **case-differing
names**, and there are **385 distinct entries**. PowerShell's `Group-Object` is
case-insensitive, so piping the entry list through it misreports these as
duplicates. It is a measurement artefact, not a defect.

---

## 3. Automated tests

### 3.1 Gradle JVM unit tests

`./gradlew test` → **704 tests, 0 failures, 0 errors, 0 skipped.**

⚠ **Always pass `--rerun-tasks`.** On a warm tree Gradle reports
`BUILD SUCCESSFUL` while running **zero** tests, because every task is
UP-TO-DATE. A green result without that flag verifies nothing — this bit an
auditor during review.

That figure is not a remembered number. It is the sum of the `tests` attribute
across every `TEST-*.xml` in `app/build/test-results/testDebugUnitTest/`, which
you can recompute after any test change:

```powershell
(Get-ChildItem app\build\test-results\testDebugUnitTest -Filter TEST-*.xml |
  ForEach-Object { ([xml](Get-Content $_.FullName)).testsuite.tests } |
  Measure-Object -Sum).Sum
```

The per-class figures in the table below are that same sum, grouped.

| Class | Tests | Covers |
|---|---|---|
| `core.PathsTest` | 74 | Path normalisation; literal, percent-encoded, double-encoded and 5×-encoded traversal rejection; protocol-relative, plaintext-scheme and foreign-host refusal; CRLF/NUL injection; length bounds; novel vs chapter classification; exact-string slug and chapter-number extraction including decimals; the `isSameChapter` identity guard |
| `core.JsonTest` | 57 | Round trip; whole numbers serialising without `.0` (the contract the plugin depends on); escaping and `\uXXXX`; nesting; ~20 malformed-input rejections; the 64-level depth limit; accessor range and integrality, including refusal to saturate at the `Long` boundary |
| `core.JobTest` | 76 | Lifecycle and terminal-state finality; the `needs_user` guard; exact `toResponse()` wire strings; queue-wait and deadline on an injected clock; `collapseKey` field by field; `JobStore` put/get/remove, sweep and count cap; change notification |
| `api.HttpRequestParserTest` | 49 | Request line, the three target forms, header limits, framing, connection reuse |
| `api.JobRequestValidatorTest` | 43 | The five operations, path classification, paging bounds, query and sort rules, malformed bodies |
| `api.JobRunnerTest` | 17 | Queue expiry, queue bounds, missing gateway, per-caller release, stopping |
| `api.LocalApiServerTest` | 84 | **Real loopback sockets.** Auth, health, routing, framing, POST validation, accepted requests, collapse and queueing, per-caller DELETE, `needs_user`, failure redaction, stopping, missing gateway, key rotation, restart, keep-alive |
| `web.HtmlSanitiserTest` | 46 | Unsafe markup, structure preservation, text and entity fidelity, image sources |
| `web.HtmlSanitiserRegressionTest` | 50 | The red-team repros: `&nbsp;` bodies carrying no prose, entity decoding, the linear entity scan, the `/_next/image` endpoint, scene-break prose loss |
| `web.HtmlSanitiserMirrorTest` | 28 | Pins the sanitiser's discard rules and the adapter's model of them **to each other**, with a perturbation on each side proving the pin can fail |
| `web.ChapterLoopDecisionTest` | 16 | The `runChapter` decision, extracted and tested: no marker means the body is never read, a marker means exactly one read, a wrong-chapter marker costs nothing || `web.ChapterCompletionTest` | 31 | The completion conjunction, the four rejection cases, rate-limit separation, bodies, numbers |
| `web.ChapterCompletionRegressionTest` | 43 | Prose that merely mentions the phrase is never a marker; nine dropped-subtree fixtures; the marker pattern agreeing with the adapter's across 40 corpus entries |
| `web.ChapterPagingTest` | 31 | `chapters` paging arithmetic, plus a source-level pin on the `plan.page` to `pageResult` wiring |
| `web.NovTalesExtractionTest` | 59 | Catalogue, novel, chapters, number handling, relative paths, failure modes, the Next.js flight scanner |

Gradle runs the suite for both the `debug` and `release` variants, so a raw XML
count shows roughly double. **704 is the unique test count.**

### 3.1a Node tests for the injected page script

Run from `novtales-companion/`:

```sh
node tools/js-tests/adapter.test.js     # -> 420 passed, 0 failed
```

This ships with the delivery. It covers the flight scanner, the chapter-state
reader, end-marker parsing (including that `End of Chapter 10` is never reported
as chapter `1`) and the `Loading chapter` still-loading signal, against a fake
DOM.

### 3.2 Standalone harnesses run during development

Because five agents worked in one tree, most verification used isolated
harnesses rather than Gradle. All of these passed, and the bugs they caught are
listed in section 3.3.

**Read the "In the delivery?" column before going looking for these files.**
Five of the six harnesses live under the top-level `_working/` scratch tree,
which `sync-to-app.ps1` excludes. Only the plugin harness is shipped, because
`lnreader-plugin/README.md` tells reviewers to run it. The development-only
harnesses depend on `_working/gradle-home` and hard-coded absolute paths into
the build machine's JDK and Gradle cache, so they are not runnable from a clean
checkout either.

| Harness | Checks | Subject | In the delivery? |
|---|---|---|---|
| `_working\verify\run.ps1` | 83 | `HtmlSanitiser`, `NovTalesExtraction`, `ChapterCompletion` on a real JVM | ❌ development-only |
| `_working\compilecheck\check.ps1` | 101 | The loopback HTTP server over real sockets | ❌ development-only |
| `_working\compilecheck\test\QueueExpiryTest.kt` | 12 | `MAX_QUEUE_WAIT_MS` expiry, both enforcement paths | ❌ development-only |
| `_working\b-harness\adapter-check.js` | 33 | The injected page-adapter JS against a fake DOM | ❌ development-only |
| `_working\b-harness\scanner-diff.js` | 275 | Kotlin scanner vs the JS scanner, 17 cases × 40 offsets | ❌ development-only |
| `lnreader-plugin\_working\smoke.mjs` | 81 | The compiled plugin JS through LNReader's own module wrapper | ✅ **shipped** |

These six numbers were re-run and confirmed against the current tree, not
carried over from the original session.

**The durable replacements.** Where a development harness covered behaviour that
outlived it, the coverage was moved somewhere a reviewer can actually reach:

* `_working\b-harness\adapter-check.js` (33) is superseded by
  `novtales-companion/tools/js-tests/adapter.test.js`, which ships and still
  reports **420 passed, 0 failed**. Run it with `node tools/js-tests/adapter.test.js`.
* `_working\verify\` (83) and `_working\compilecheck\` (101 + 12) are covered by
  the Gradle suite in section 3.1, which ships and is a superset of both.
* `_working\b-harness\scanner-diff.js` (275) is a Kotlin-vs-JS differential. The
  JS half still ships (`tools/js-tests/`); the Kotlin half is the Gradle suite.
  The two implementations are checked against each other only by this harness,
  which is **not** in the delivery — a genuine coverage gap a reviewer should
  know about.
* `lnreader-plugin\_working\` ships in full, so `node _working/smoke.mjs` works
  from the delivered tree.

### 3.3 Bugs that testing found — none of these were visible by reading

Recorded because a reviewer's time is better spent knowing where the traps were.

| # | Bug | Effect had it shipped |
|---|---|---|
| 1 | `plan()` validated the novel path and chapter path against each other up front, but their shapes are mutually exclusive | **Every one of the five operations would have failed with `BAD_REQUEST` before doing any work** |
| 2 | JS `scanBalanced` advanced twice past a string's closing quote | Any payload value ending in a string overshot by one brace; `JSON.parse` threw. Most extractions would have failed |
| 3 | `HtmlSanitiser` regex kept a `^` anchor while using `find(input, startIndex)` | Every HTML entity after the first character was missed: `&amp;` → `&amp;amp;`, `&nbsp;` never converted. Broke the exact paragraph-text preservation TTS needs |
| 4 | Blank end-marker treated as "marker present but unparseable" | Every chapter **preview** returned `WRONG_CHAPTER` instead of `INCOMPLETE_CHAPTER` — exactly the false positive the settle-window design exists to prevent |
| 5 | `Calendar.DAY_OF_WEEK` is 1-based | The `Date:` response header indexed out of bounds and **every response was silently swallowed** |
| 6 | Queue sweeper shared the single worker thread | A blocking gateway starved the sweeper; a caller could wait past `MAX_QUEUE_WAIT_MS` for ever |
| 7 | `Job.fail()` checked `isTerminal` before its `NEEDS_USER` branch | A `needs_user` job could never say *why*; the plugin could not tell "sign in" from "the companion broke" |
| 8 | `Json.long()`/`int()` only checked `isFinite()` | `12.75` became `12`; `3000000000` became `Int.MAX_VALUE` |
| 9 | `Paths.isSameChapter` compared through `Double` | `2^53` and `2^53+1` were accepted as the same chapter |
| 10 | Kotlin block comments nest, so `` `api/**` `` in a KDoc opened a second comment | The whole file failed to compile |
| 11 | `onRenderProcessGone` overrode a type that does not exist | Renderer crashes were never detected |
| 12 | `LocalApiServer.setGateway()` built the runner as `JobRunner({ gateway }, …)`, where the bare name resolved to the **constructor parameter**, not the `@Volatile` field | `/v1/health` reported `READY` while every job still failed `COMPANION_UNAVAILABLE`; a server built without a gateway could never be brought to life |
| 13 | `JobRequestValidator` never required `path` for `novel` | A malformed request passed validation and failed later with a less useful message |

Bugs 7, 8, 9, 12 and 13 were in the shared core and API and were found by the
test agents. Bug 7 was a regression the parent agent introduced during
integration and was caught in the same session; bug 12's `this.gateway` fix and
bug 13's fix each landed with a regression test in the same change.

### 3.3a Second round — found by independent adversarial review

A second pass ran six independent auditors against the finished build: artefact
integrity, security, spec conformance, plugin/companion contract, test-suite
honesty, and a red team attacking the chapter extractor. They found **seven more
defects that the 527-test suite reported as green**, including two that would
have made the product fail at its primary job.

| # | Bug | Effect had it shipped |
|---|---|---|
| 14 | **The plugin read the error envelope flat; the server nests it under `error`.** `docs/API.md` documented a third shape | **Every HTTP-level failure became `INTERNAL`** — 401 read as "internal error" instead of "copy the pairing key again". The `QUEUE_FULL` retry and the catalogue sort fallback were dead code |
| 15 | **`chapters` ignored its `page` argument** — the validator required it, the gateway never read it, and it returned the whole novel every time | LNReader calls `parsePage` once per page. With `chapterTotalPages: 81`, that is **81 full WebView index crawls**; the load appears to hang and most concurrent calls hit `QUEUE_FULL` |
| 16 | **`runChapter`'s body re-read sat inside an unreachable branch.** The cheap poll omits the body, so `evaluate` returned `NotReady(EMPTY_BODY)` before any completion check, on every poll, for ever | **The chapter operation could never succeed.** A fully delivered chapter failed as `INCOMPLETE_CHAPTER` while its `End of Chapter N` marker sat in the DOM |
| 17 | `textOf` never decoded entities, and the sanitiser rewrites `&nbsp;` → `&#160;` | `<p>&nbsp;</p>` counted as prose, so a body with **no words at all** could be stored with `complete: true` |
| 18 | `findEndMarker` walked every text node with no visibility check, while the sanitiser deletes `<script>`/`<template>`/hidden subtrees | A preview whose only marker sat in a deleted subtree was **stored as a complete chapter** |
| 19 | `SCENE_BREAK_CLASS` matched the bare token `break`, and that branch runs before `KEEP_TAGS` and calls `skipSubtree` | `<p class="text-break">prose</p>` became `<hr>` — **silent deletion of chapter prose**, and Tailwind `break-*` utilities are ordinary on this site |
| 20 | `HTML_ENTITY.find(raw, index)` scanned to end-of-string on every miss | Quadratic in `&`: 24k `&#` in 48 KB took **25.9 s**, uninterruptible inside `withContext(io)`, so `withTimeout` could not stop it |
| 21 | The plugin's metadata budget was 75 000 ms against a 76 000 ms worst case | Every metadata request on a busy queue returned `TIMEOUT` |

Bugs 16–20 were all in the chapter path — the exact code the project exists to get
right. **A green suite did not protect them**, because the tests went wide rather
than to the edge of each rule. Bugs 14, 15 and 21 were contract mismatches
between two components written in parallel from one document; the plugin's own
57-assertion harness had mocked the flat envelope and so confirmed itself.

Every one of these is now fixed with a regression test that reproduces the
original repro. The suite grew from 527 to **704** JVM tests and from 33 to
**80** Node tests.

### 3.3b The lesson worth keeping

Three separate reviewers independently concluded that the **plugin harness was
self-confirming**: `smoke.mjs` mocked an envelope shape the server never emitted,
so 57 green assertions coexisted with a total client/server incompatibility. The
harness has since been regenerated against the real server shape, and it now
carries assertions that a 401 surfaces as `UNAUTHORIZED` and a 503 as
`COMPANION_UNAVAILABLE` — both of which fail against the old mock.

If you change the wire format, regenerate the mock from the Kotlin, not the other
way round.

### 3.3c Third round — auditing the *fixes*, not the original work

A third pass was run against the repaired build, specifically to check whether the
repairs held. It found **three defects that were reintroduced by the fixes
themselves**, plus three tests that could not fail.

| # | Defect | Effect |
|---|---|---|
| 22 | The release-signing guard added in round one matched `gradle.startParameter.taskNames` for the string `"Release"` | **`gradle assemble` and `gradle build` — the commands people actually type — bypassed it entirely** and produced a `CN=Android Debug` APK with `BUILD SUCCESSFUL` and no warning. It cannot update an installed copy. The same match also wrongly blocked `lintVitalRelease`, which needs no key |
| 23 | The marker reader used an **unanchored** `/end\s+of\s+chapter/i` over the whole assembled article — introduced to catch React's split-node marker | **Prose merely mentioning the phrase counted as the marker.** A *truncated* chapter 12 containing the words "the end of chapter 12" was stored with `complete: true`. Same bug class the `"Unlock Access"` prose guard already solved, applied to the marker |
| 24 | The JS/Kotlin "same view of the document" mirror modelled two of the sanitiser's four discard mechanisms | A marker inside a `scene-break` or `data-security-canary` slot was **deleted by the sanitiser but still counted**, producing a chapter stored as complete with no marker in it |
| 25 | The entity decoder handled named entities through a table whose code points fell in gaps the invisibility predicate did not cover | `<p>&zwj;</p>` — zero glyphs — still satisfied `isNotBlank()`. One predicate now serves both the named and numeric branches, with a test that fails if the table and the predicate ever disagree again |
| 26 | `ChapterCompletion.evaluate` sanitised the body **twice per poll** (`textOf` re-sanitises) and the loop re-read the whole body on every poll while a marker was present | 31.6 ms per poll instead of ~0, ~300 full `innerHTML` serialisations across the bridge on a slow page. The decision is now extracted to `ChapterCompletion.decideState` and tested directly |
| 27 | The plugin's fallback page count was the site's 12-per-page partition while the plugin pages at 50 | A novel could be silently truncated — 120 chapters reported as 3 pages of 50 instead of 10 pages. Also, **new plugin against an old companion** reproduced the original pagination bug verbatim |

### 3.3d Three tests that could not fail

Mutation testing — re-introducing each real bug and recording what goes red —
found three pieces of decoration:

- A "seven cases" loop that fed **identical input on every iteration**; the loop
  label only reached the assertion message. Mutating the marker rule to accept
  anything left **0 of 3** assertions red. Replaced with nine real fixtures, each
  building the actual HTML and asserting the marker is inside the dropped subtree.
- A "cross-language agreement" test that re-declared the adapter's regex **in
  Kotlin** and never opened `novtales-adapter.js`. Deleting the deleted test was
  byte-for-byte unaffected by mutating the real adapter pattern. Replaced with a
  test that reads both declarations from disk and makes them answer the same 40
  corpus entries.
- A paging test that called the helper directly, so changing
  `pageResult(complete, plan.page, …)` to `pageResult(complete, 1, …)` failed
  **nothing anywhere in the suite**. Now pinned by four source-level assertions.

After the repairs, each of those mutations reds tests: adapter `END_MARKER`
mutation → 3 red; the one-token paging change → 3 red and nothing else in 704;
`DROP_SUBTREE_TAGS` losing `"template"` → red; `isHidden` losing
`visibility:hidden` → red on both sides.

### 3.4 What unit tests cannot prove

Every JVM test above runs on a bare JVM. None of them exercises:

* a real Android System WebView,
* the real NovTales site,
* the official LNReader build,
* the phone's network or background restrictions.

A green test suite here is **not** evidence that the architecture works.

---

## 4. Spec section 12 acceptance matrix

| Test | Pass condition | Where run | Status |
|---|---|---|---|
| Fresh setup | Install, start, pair, load catalogue in official LNReader | Oppo | ⬜ **not run** |
| Signed-out public chapter | Full chapter loads without imposing sign-in | Oppo | ⬜ **not run** |
| Multi-part chapter | Every part returned, completion explicit | Oppo | ⬜ **not run** |
| Pagination | Several pages ordered correctly, no duplicate paths | JVM + Oppo | ⬜ partial |
| Simultaneous requests | Small batch returns correct text per path | Oppo | ⬜ **not run** |
| Website access check | User completes it visibly, no automatic bypass | Oppo | ⬜ **not run** |
| App switching / screen off | Reliable on the Oppo, fails clearly if interrupted | Oppo | ⬜ **not run** |
| Download completeness | Stored HTML matches completed website content | Oppo | ⬜ **not run** |
| Offline reopening | Airplane mode + companion stopped + LNReader restart | Oppo | ⬜ **not run** |
| Reader features | Progress, bookmarks, themes, TTS still work | Oppo | ⬜ **not run** |
| Failure and recovery | Lost internet, renderer crash, killed service, wrong key | Oppo | ⬜ **not run** |
| Local API security | Wrong keys, oversized input, arbitrary URLs rejected | JVM + Oppo | ⬜ partial |

**Stage A (spec section 12) has not been executed.** Stage A requires proving an
authenticated health call from a real LNReader plugin to the APK, then fetching
one complete signed-out public chapter with LNReader foregrounded, then showing
the WebView session survives app switching. None of that has been done, because
it requires the physical device.

---

## 5. Known limitations, stated up front

1. **The architecture is unproven on Android.** The specification itself says the
   companion design "is not yet validated on Android" and requires the critical
   path be validated before a polished interface. The code is complete; the proof
   is outstanding.
2. **Background behaviour is unmeasured.** ColourOS battery restrictions on the
   Oppo may stop the companion while LNReader is in the foreground. The app does
   not request blanket battery exemption or hold an indefinite wake lock, so some
   interruptions are expected and should surface as a clear error rather than a
   hang.
3. **`dataSync` has a 6-hour cap per 24 hours on Android 15.** The service stops
   cleanly and fails pending jobs. This is accepted, not worked around — see
   `docs/DEVIATIONS.md`.
4. **Chapter text remains membership-gated by the website.** The companion does
   not bypass, forge or work around access control. Locked chapters report the
   site's requirement instead of returning a preview.
5. **The site can change.** The adapter fails safely with `SITE_CHANGED` rather
   than returning wrong or partial data.

### 5.1 Additional unresolved items, found during implementation

| Item | Status | Where to fix |
|---|---|---|
| **Search endpoint unverified.** The site's search URL template is a guess (`/explore?q={query}`). No search endpoint was confirmed. The value is an overridable `@Volatile var` and the adapter refuses to invent one. | ⬜ unverified | `NovTalesExtraction.searchPathTemplate` |
| **Chapter-index access.** `GET /api/public/novel-chapters/{slug}` is reached with a plain page `fetch`. The site's own client attaches a Supabase Bearer token, so this may return 401. There is an SSR fallback, but it only yields the 12 chapters on that page — so for a large novel the `chapters` operation may return a short list. | ⬜ unverified on device | `NovTalesExtraction.CHAPTERS_API_PATH` |
| **`chapters` deadline.** Paging a 944-chapter index at 50/page is ~19 round trips, which can exceed `Config.METADATA_DEADLINE_MS` (45 s). `chapters` throws `TIMEOUT` rather than returning a partial list. | ⚠️ possible | `core/Config.kt` |
| **One WebView.** While a job runs, the WebView navigates, so a user watching the site sees it blank between operations. Inherent to a single service-owned session; two WebViews would mean two site sessions and defeat the purpose. | by design | — |
| **Stall heuristic.** 8 s of no growth yields a retryable `INCOMPLETE_CHAPTER`. On a genuinely slow connection this could be premature. | ⚠️ tunable | `WebViewBrowserGateway.STALL_POLLS` |
| **`withTimeout` backstop and the 8 MB response cap** are implemented but not exercised by a test — the 45 s/120 s deadlines make them impractical to exercise without injectable deadlines. | ⬜ untested | `api/JobRunner.kt` |
| **R8 keep rules unverified.** `minifyEnabled` is on and the release build succeeds, but whether the WebView gateway survives shrinking has not been confirmed on a device. | ⬜ untested | `app/proguard-rules.pro` |
| **`res/xml/network_security_config.xml` is dead.** The manifest sets `android:usesCleartextTraffic="false"` and never references this file (`android:networkSecurityConfig` is absent), so the config is never applied. Its policy — `cleartextTrafficPermitted="false"` — is **not weaker** than the manifest's, so there is no live security hole; it is dead weight that reads as protection it does not provide. Fixing it means editing the manifest, which is out of scope for the documentation pass. **Decision needed:** either add `android:networkSecurityConfig="@xml/network_security_config"` to `<application>`, or delete the file. Until then, the manifest attribute is the only thing enforcing this. | ⬜ dead config | `app/src/main/res/xml/network_security_config.xml` + `AndroidManifest.xml` |

---

## 6. Screenshots and sanitised device logs — still outstanding

Spec section 13 asks for *"sanitized logs and screenshots of setup and results;
exclude account credentials, pairing keys and copied copyrighted chapter text"*.

**This delivery contains none.** There are no screenshots, no `adb logcat`
captures, and no device logs anywhere in the tree, because **nothing has been run
on the physical Oppo Reno 15 yet.** A screenshot of a run that did not happen, or
a log excerpt typed from memory, would be worse than an honest gap: it would
manufacture the exact evidence this report exists to distinguish from real.

The checklist below is what has to be captured once the device run in section 4
happens. Each item is tied to a row that is currently ⬜.

| # | Capture | Tied to |
|---|---|---|
| 1 | Companion at **Stopped**, then after **Start** — the status states are user-visible proof the lifecycle works | §4 fresh setup |
| 2 | The WebView showing NovTales, with any verification page visible and being completed by hand — this is the "no automatic bypass" evidence | §4 website access check |
| 3 | **Copy pairing key** screen, with the key itself redacted | §4 fresh setup |
| 4 | LNReader's NovTales plugin settings with the key pasted, key redacted | §4 fresh setup |
| 5 | LNReader catalogue listing novels from the companion | §4 fresh setup |
| 6 | A **complete** chapter opened in LNReader's reader, long enough to show body text, not a preview | §4 signed-out public chapter |
| 7 | The same chapter with the companion stopped — LNReader must still reopen it (airplane mode) | §4 offline reopening |
| 8 | A **failure** case: wrong pairing key, or the website demanding sign-in — the error the user actually sees | §4 failure and recovery |
| 9 | `adb logcat` across a full request, sanitised | all of §4 |

**Sanitisation rules when they are captured:** strip the pairing key, any
NovTales account identifier, cookies, Supabase tokens and browser storage, and
any copied chapter text. The pairing key authorises the local API — it must not
appear in a shared artefact. `build.ps1` writes Gradle logs to `_working/`, which
is excluded from the delivery, so build logs are already kept out of the way.

---

## 7. How to complete this report

1. `adb install dist/NovTales-Companion-0.1.0.apk` on the Oppo.
2. Open the companion, press **Start**, complete any website check.
3. **Copy pairing key**, paste into the LNReader NovTales plugin settings.
4. Run each row of the section 4 matrix and record the actual outcome.
5. Fill in the four unrecorded version rows in section 1 from
   `Settings → About phone` and the WebView app's version screen.
6. Re-run `scripts/release-evidence.ps1` and paste in the final APK SHA-256.
   It now verifies all three signature schemes and exits non-zero if
   `apksigner` is unavailable, so a digest cannot be recorded unverified by
   accident.
7. Capture the screenshots and sanitised logs in section 6.

Until section 4 is complete with real on-device outcomes, this build must be
described as an **installable test build**.