# Deviations from the build specification

Every departure from `NovTales_Android_Companion_Build_Specification.md` is
recorded here with its evidence, as required by section 15.

---

## 1. No third-party embedded HTTP server

**Spec says (section 4):** *"Use a maintained embedded HTTP server, such as an
Android-compatible NanoHTTPD implementation or equivalent, rather than an
unrestricted ad hoc proxy. Verify its current maintenance and suitability before
choosing the dependency."*

**What was done:** The local API server is implemented directly on
`java.net.ServerSocket` with a strict, bounded HTTP/1.1 parser
(`api/HttpRequestParser.kt`, `api/LocalApiServer.kt`). No HTTP dependency is
added to the build.

### Why

The instruction has two parts: avoid an *unrestricted ad hoc proxy*, and *verify
maintenance before choosing the dependency*. The verification was carried out
against Maven Central, and re-checked on **2026-10-04**:

| Artifact | Latest version | Last published | Verdict |
|---|---|---|---|
| `org.nanohttpd:nanohttpd` | **2.3.1** | **2016-08-12** | Unmaintained ~10 years |
| `io.ktor:ktor-server-core` | **3.6.0** | **2026-09-16** | Actively maintained |
| `com.github.arteam:embedded-http-server` | 1.2 | 2022-03 | Not Android-targeted |
| `net.kut3.http.server:embedded-jetty` | 0.1.0 | 2019-05 | Not Android-targeted |

`repo1.maven.org/maven2/org/nanohttpd/nanohttpd/maven-metadata.xml` reports
`<latest>2.3.1</latest>` and `<lastUpdated>20160812182031</lastUpdated>`.
`repo1.maven.org/maven2/io/ktor/ktor-server-core/maven-metadata.xml` reports
`<latest>3.6.0</latest>` and `<lastUpdated>20260916113545</lastUpdated>`. The
spec's own suggested dependency therefore fails the spec's own maintenance test,
and the maintained alternative it points at is **Ktor 3.6.0** — still wrong for
this component, for the reason below.

### Why a hand-written parser is the *safer* choice here, not the riskier one

Almost everything the specification demands of this component is enforcement code
that a library cannot supply:

- authenticate before any body is parsed,
- compare the pairing key in constant time,
- bound header bytes, body bytes and response bytes independently,
- reject oversized/malformed requests without unbounded buffering,
- refuse to become a proxy — no `CONNECT`, no forwarding, no outbound socket,
- reject every operation and path outside a fixed allowlist.

A general-purpose HTTP library implements none of these by default; they would be
layered on top of it anyway. Putting a parser that has had no security review
since 2016 directly on the pairing-key boundary is the worse trade. The server
here has no proxy capability at all and cannot be steered to a foreign host,
which is the property the specification actually asks for.

The parser contains no `android.*` imports and is unit-tested on the JVM.

---

## 2. Foreground service type: `dataSync`

**Spec says (section 6):** *"Choose and justify the foreground-service type using
Android's current rules. `dataSync` is subject to time limits on recent Android
versions; `specialUse` requires a legitimate declared explanation and must not be
selected merely to avoid a timeout."*

**What was done:** `android:foregroundServiceType="dataSync"` with
`FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_DATA_SYNC`.

**Justification:** the companion transfers website data to LNReader on the user's
behalf, at the user's request, which is what `dataSync` describes. The
specification explicitly forbids choosing `specialUse` merely to dodge the
`dataSync` timeout, so the timeout is accepted and handled rather than avoided:
`onTimeout(startId, fgsType)` stops the service cleanly and fails every pending
job with a recoverable error. The app is never classified as media playback or any
other unrelated type.

**Consequence the reader must understand:** `dataSync` is capped (6 hours in a
24-hour window on Android 15). After the cap the companion stops and pending
requests fail with a clear message. This is documented rather than hidden.

---

## 3. Target SDK 35

**Spec says (section 4):** *"API 35 can be an initial prototype baseline, but is
not a promise that it satisfies every future distribution requirement."*

**What was done:** `compileSdk = 35`, `targetSdk = 35`, `minSdk = 26`.

The spec names API 35 as an acceptable initial baseline and the primary test
device is an Oppo Reno 15. This is a baseline for the stated test device, not a
distribution guarantee.

---

## 4. Development environment pinning (not a product deviation)

The build machine's JDK, Android SDK and Gradle live outside the delivered source
tree. `scripts/setup-env.ps1` and `build.ps1` record the exact versions used.
This affects only how the project is built on *this* machine; a normal developer
machine needs only JDK 17 and the Android SDK, as `docs/BUILD.md` states.

| Component | Version |
|---|---|
| JDK | Temurin 17.0.20.1 |
| Gradle | 8.9 (wrapper committed) |
| Android Gradle Plugin | 8.7.3 |
| Kotlin | 2.0.21 |
| Build tools | 35.0.0 |
| compileSdk / targetSdk | 35 |
| minSdk | 26 |

---

## 5. Not yet demonstrated: Stage A

**Spec says (section 12):** Stage A must be proven on the phone before the rest is
trusted, and *"Passing compilation, mocked tests or a desktop browser
demonstration is not sufficient to claim Android success."*

**Status:** the architecture is implemented and compiles to an installable signed
APK, and the parsers are unit-tested on the JVM. **The critical request path has
not been run on the Oppo Reno 15**, because that requires the physical device.

This is reported as an installable test build, **not** a verified working
release. See `docs/TEST_REPORT.md` for exactly which tests have run and which are
outstanding.

---

## 6. Plugin is type-checked against lnreader-plugins 3.0.0, not 2.1.4 — OPEN RISK

**Spec says:** the plugin targets **LNReader 2.1.4**, and for the pairing key,
*"use the text-input filter if the installed version supports it."*

**What was done:** the plugin is type-checked against the upstream
`lnreader-plugins` repository at version **3.0.0**
(`lnreader-plugin/tsconfig.json` points `paths` at
`../../../../CodexData/lnreader-plugins/`, whose `package.json` reads `"version":
"3.0.0"`). `npx tsc --project tsconfig.json` reports zero errors — against 3.0.0.

**The risk, stated plainly:**

`FilterTypes.TextInput` **is** present in the 3.0.0 checkout —
`src/types/filters.ts:13` declares `TextInput = 'Text'` and
`src/components/filters/text-filter.tsx` renders it. The plugin uses it at
`plugins/english/novtales.ts:389` for the **Companion pairing key** field.

**Its presence in a 2.1.4 runtime is UNVERIFIED.** No 2.1.4 checkout was
available on this build machine to type-check against, and no 2.1.4 device has
run the plugin. So the pairing-key field compiles against a newer type surface
than the spec names. The spec's wording — *"if the installed version supports
it"* — makes this conditional, and that condition has not been tested.

**Consequence if 2.1.4 lacks `TextInput`:** the pairing key cannot be collected
through the filter UI. The plugin reads the key from LNReader plugin storage, so
the data path is unaffected; only the entry point would need a fallback (for
example a settings screen, or LNReader's generic key/value plugin storage).

**Why it was not resolved here:** verifying it needs either an LNReader 2.1.4
source checkout or a physical device running 2.1.4. Neither is available. This
is recorded as an open risk rather than quietly closed.

---

## 7. No source repository — source ZIP only

**Spec says (section 13):** *"For review, supply a source repository or source
ZIP alongside the APK."*

**What was done:** the **source ZIP** branch. There is **no `.git`** anywhere in
this tree and no remote. Reviewers get
`dist/NovTales-Companion-0.1.0-source.zip`, alongside the APK.

**What this costs:** history is absent, so a reviewer cannot see when a line
changed or why. §15's "every departure, with its evidence" is carried by
`docs/DEVIATIONS.md` and `docs/TEST_REPORT.md` instead of by commit messages.
The source ZIP is regenerated with `make-source-zip.ps1`; its SHA-256 changes
whenever the tree does, so it is as current as the last run of that script.

---

## 8. Search route template is invented and unverified

**Spec says (section 5):** the search operation must be implemented, and the
adapter must fail safely rather than invent behaviour.

**What was done:** `NovTalesExtraction.searchPathTemplate` is set to
**`/explore?q={query}`**. **No search endpoint was ever confirmed.** This is the
one genuinely invented piece of the adapter.

**Mitigation, not a fix:** the value is an overridable `@Volatile var` and the
adapter refuses to return a fabricated result set — a search that finds nothing
reports an explicit error rather than an empty-but-successful listing.

**Full analysis, including the adjacent unverified `chapters` endpoint, is in
`docs/TEST_REPORT.md` §5.1** — not duplicated here. Search stays ⬜ unverified
until it runs on the device.

---

## 9. No screenshots and no sanitised device logs

**Spec says (section 13):** *"Supply sanitized logs and screenshots of setup and
results; exclude account credentials, pairing keys and copied copyrighted chapter
text from shared logs."*

**Status: not supplied.** There are no screenshots and no device logs in this
delivery. **Nothing has run on the physical Oppo Reno 15**, so there is nothing
to capture; see `docs/TEST_REPORT.md` §4 (acceptance matrix, all rows ⬜) and §6
(the nine captures still owed, each tied to an unrun row, with the sanitisation
rules).

**Nothing has been fabricated to fill the gap.** A synthesised screenshot or a
typed-from-memory `logcat` excerpt would be worse than a recorded omission: it
would create exactly the false evidence this document set exists to rule out.

Section 13's *other* requirement — a source repository or source ZIP alongside
the APK — **is** met; see §7.