package com.sadloif.novtalescompanion.api

import com.sadloif.novtalescompanion.core.CompanionException
import com.sadloif.novtalescompanion.core.Config
import com.sadloif.novtalescompanion.core.ErrorCode
import com.sadloif.novtalescompanion.core.Json
import com.sadloif.novtalescompanion.core.JobRequest
import com.sadloif.novtalescompanion.core.jsonObject
import com.sadloif.novtalescompanion.web.BrowserGateway
import com.sadloif.novtalescompanion.web.Readiness
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.experimental.runners.Enclosed
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.Socket
import java.util.Collections
import java.util.concurrent.TimeUnit

/**
 * Real-socket smoke tests for [LocalApiServer].
 *
 * Promoted from `_working/compilecheck/test/SmokeTest.kt`. These drive the server
 * over a genuine loopback TCP connection, because the thing worth pinning is the
 * *wire* behaviour: the status line, the `Allow` header, the exact 202 body and
 * what the server refuses to read off a socket.
 *
 * Every server binds port 0 (an ephemeral loopback port) and is stopped in
 * `@After`, so nothing leaks between groups and no fixed port can collide.
 * Nothing sleeps: waits poll for the state the test is actually waiting for.
 *
 * Pure JVM: the whole `api` package is Android-free by design.
 *
 * JUnit 4 has no @Nested, so the groups are static nested classes run by Enclosed.
 */
@RunWith(Enclosed::class)
class LocalApiServerTest {

    // =========================================================================
    // Authentication runs before everything else
    // =========================================================================

    class Auth {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `no Authorization header is 401`() {
            assertEquals(401, send(port, listOf("GET /v1/health HTTP/1.1", "Host: h"), null, key = null).status)
        }

        @Test
        fun `the 401 body carries UNAUTHORIZED`() {
            val reply = send(port, listOf("GET /v1/health HTTP/1.1", "Host: h"), null, key = null)
            assertEquals("UNAUTHORIZED", reply.code())
        }

        @Test
        fun `a 401 challenges with a Bearer realm`() {
            val reply = send(port, listOf("GET /v1/health HTTP/1.1", "Host: h"), null, key = null)
            assertTrue(
                "was ${reply.headers["www-authenticate"]}",
                reply.headers["www-authenticate"]?.startsWith("Bearer") == true,
            )
        }

        @Test
        fun `a wrong key is 401`() {
            assertEquals(401, get(port, "/v1/health", key = "nope").status)
        }

        @Test
        fun `an unknown path without a key is 401 and not 404`() {
            // Authentication runs first so an unauthenticated caller cannot map
            // the API surface.
            assertEquals(401, send(port, listOf("GET /v1/nope HTTP/1.1", "Host: h"), null, key = null).status)
        }

        @Test
        fun `an unknown path with a key is 404`() {
            assertEquals(404, get(port, "/v1/nope").status)
        }

        @Test
        fun `authentication happens before the body is read`() {
            // An unauthenticated caller must not be able to make the server buffer
            // a payload at all.
            assertEquals(401, post(port, "not json", key = null).status)
        }

        @Test
        fun `a key sent as a query parameter is not a key`() {
            assertEquals(401, send(port, listOf("GET /v1/health?key=$TEST_KEY HTTP/1.1", "Host: h"), null, key = null).status)
        }

        @Test
        fun `a key sent in a cookie is not a key`() {
            assertEquals(
                401,
                send(
                    port,
                    listOf("GET /v1/health HTTP/1.1", "Host: h", "Cookie: key=$TEST_KEY"),
                    null,
                    key = null,
                ).status,
            )
        }

        @Test
        fun `the bearer scheme is matched case-insensitively`() {
            assertEquals(
                200,
                send(
                    port,
                    listOf("GET /v1/health HTTP/1.1", "Host: h", "Authorization: bearer $TEST_KEY"),
                    null,
                    key = null,
                ).status,
            )
        }
    }

    // =========================================================================
    // /v1/health
    // =========================================================================

    class Health {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `health is 200 with the contract body`() {
            val reply = get(port, "/v1/health")
            assertEquals(200, reply.status)
            assertEquals(
                """{"apiVersion":1,"companionVersion":"0.1.1","state":"READY"}""",
                reply.body,
            )
        }

        @Test
        fun `health reports no-store because results are per session`() {
            assertEquals("no-store", get(port, "/v1/health").headers["cache-control"])
        }

        @Test
        fun `health reports nosniff`() {
            assertEquals("nosniff", get(port, "/v1/health").headers["x-content-type-options"])
        }

        @Test
        fun `health emits no CORS header`() {
            assertFalse(
                "a wildcard CORS header would publish the pairing-key API",
                get(port, "/v1/health").headers.containsKey("access-control-allow-origin"),
            )
        }

        @Test
        fun `health names the companion and does not leak its version internals`() {
            assertEquals("NovTales-Companion/0.1.1", get(port, "/v1/health").headers["server"])
        }

        @Test
        fun `health reports READY while a gateway is present`() {
            assertEquals("READY", get(port, "/v1/health").json?.str("state"))
        }

        @Test
        fun `health reports the gateway's own readiness`() {
            val loading = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(
                readiness = com.sadloif.novtalescompanion.web.Readiness.LOADING,
            ), port = 0)
            loading.start()
            try {
                assertEquals("LOADING", get(loading.boundPort, "/v1/health").json?.str("state"))
            } finally {
                loading.stop()
            }
        }
    }

    // =========================================================================
    // Routing and the method allowlist
    // =========================================================================

    class Routing {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `an unknown job id is 404`() {
            assertEquals(404, get(port, "/v1/jobs/00000000-0000-0000-0000-000000000000").status)
        }

        @Test
        fun `a crafted job id is 404 rather than a store lookup`() {
            assertEquals(404, get(port, "/v1/jobs/not-a-uuid").status)
        }

        @Test
        fun `a method outside the allowlist is 405 with Allow`() {
            val reply = send(port, listOf("PUT /v1/health HTTP/1.1", "Host: h"))
            assertEquals(405, reply.status)
            assertEquals("GET, OPTIONS", reply.headers["allow"])
        }

        @Test
        fun `DELETE on health is 405`() {
            assertEquals(405, delete(port, "/v1/health").status)
        }

        @Test
        fun `GET on the jobs collection is 405`() {
            assertEquals(405, get(port, "/v1/jobs").status)
        }

        @Test
        fun `CONNECT with an origin-form target is 405 not a tunnel`() {
            assertEquals(
                405,
                send(port, listOf("CONNECT /v1/health HTTP/1.1", "Host: h"), null).status,
            )
        }

        @Test
        fun `an authority-form target is 400`() {
            assertEquals(
                400,
                send(port, listOf("CONNECT 127.0.0.1:5301 HTTP/1.1", "Host: h"), null).status,
            )
        }

        @Test
        fun `an absolute-form target is 400`() {
            assertEquals(
                400,
                send(port, listOf("GET http://example.com/x HTTP/1.1", "Host: h"), null).status,
            )
        }

        @Test
        fun `an asterisk-form target is 400`() {
            assertEquals(400, send(port, listOf("OPTIONS * HTTP/1.1", "Host: h"), null).status)
        }

        @Test
        fun `a percent-encoded target is 400`() {
            assertEquals(
                400,
                send(port, listOf("GET /v1/jobs/%2e%2e HTTP/1.1", "Host: h"), null).status,
            )
        }

        @Test
        fun `OPTIONS on a known path is 204 with Allow and no body`() {
            val reply = send(port, listOf("OPTIONS /v1/jobs HTTP/1.1", "Host: h"), null)
            assertEquals(204, reply.status)
            assertEquals("POST, OPTIONS", reply.headers["allow"])
            assertEquals("", reply.body)
        }

        @Test
        fun `OPTIONS on a job is 204 with Allow`() {
            val reply = send(port, listOf("OPTIONS /v1/jobs/abc HTTP/1.1", "Host: h"), null)
            assertEquals(204, reply.status)
            assertEquals("GET, DELETE, OPTIONS", reply.headers["allow"])
        }

        @Test
        fun `OPTIONS without a key is 401`() {
            assertEquals(
                401,
                send(port, listOf("OPTIONS /v1/jobs HTTP/1.1", "Host: h"), null, key = null).status,
            )
        }
    }

    // =========================================================================
    // Request framing: every one of these is a transport refusal
    // =========================================================================

    class Framing {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `Transfer-Encoding is 400`() {
            assertEquals(
                400,
                send(
                    port,
                    listOf("POST /v1/jobs HTTP/1.1", "Host: h", "Transfer-Encoding: chunked"),
                    "",
                ).status,
            )
        }

        @Test
        fun `a duplicate Content-Length is 400`() {
            assertEquals(
                400,
                send(
                    port,
                    listOf(
                        "POST /v1/jobs HTTP/1.1",
                        "Host: h",
                        "Content-Length: 1",
                        "Content-Length: 1",
                    ),
                    "{}",
                ).status,
            )
        }

        @Test
        fun `HTTP one point one with no Host is 400`() {
            assertEquals(400, send(port, listOf("GET /v1/health HTTP/1.1")).status)
        }

        @Test
        fun `HTTP 2 is 505`() {
            assertEquals(505, send(port, listOf("GET /v1/health HTTP/2.0", "Host: h"), null).status)
        }

        @Test
        fun `an over long header line is 431`() {
            assertEquals(
                431,
                send(
                    port,
                    listOf("GET /v1/health HTTP/1.1", "Host: h", "X-Big: " + "a".repeat(20_000)),
                    null,
                ).status,
            )
        }

        @Test
        fun `an oversized body is 413`() {
            assertEquals(
                413,
                send(
                    port,
                    listOf("POST /v1/jobs HTTP/1.1", "Host: h", "Content-Length: 20000"),
                    "{}",
                ).status,
            )
        }

        @Test
        fun `a POST with no Content-Length is 411`() {
            assertEquals(411, send(port, listOf("POST /v1/jobs HTTP/1.1", "Host: h"), null).status)
        }

        @Test
        fun `an Expect header is 417`() {
            assertEquals(
                417,
                send(
                    port,
                    listOf(
                        "POST /v1/jobs HTTP/1.1",
                        "Host: h",
                        "Expect: 100-continue",
                        "Content-Length: 2",
                    ),
                    "{}",
                ).status,
            )
        }

        @Test
        fun `every transport refusal closes the connection`() {
            val reply = send(port, listOf("GET /v1/health HTTP/2.0", "Host: h"), null)
            assertEquals("close", reply.headers["connection"])
        }

        @Test
        fun `a refusal still answers with the shared no-store and nosniff headers`() {
            val reply = send(port, listOf("GET /v1/nope HTTP/1.1", "Host: h"), null)
            assertEquals("no-store", reply.headers["cache-control"])
            assertEquals("nosniff", reply.headers["x-content-type-options"])
        }
    }

    // =========================================================================
    // POST /v1/jobs validation, over the wire
    // =========================================================================

    class PostValidation {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        private fun assertRejected(body: String, why: String) {
            assertEquals(why, 400, post(port, body).status)
        }

        @Test
        fun `every documented rejection is 400`() {
            assertRejected("{}", "missing operation")
            assertRejected("""{"operation":"nope"}""", "unknown operation")
            assertRejected("""{"operation":"chapter"}""", "chapter needs path")
            assertRejected("""{"operation":"chapter","path":"/novel/slug"}""", "chapter needs chapter path")
            assertRejected("""{"operation":"novel","path":"/chapter/slug-1"}""", "novel needs novel path")
            assertRejected("""{"operation":"novel","path":"/novel/slug/../../etc"}""", "traversal")
            assertRejected("""{"operation":"novel","path":"https://evil.example/novel/x"}""", "foreign absolute url")
            assertRejected("""{"operation":"novel","path":"http://novtales.com/novel/x"}""", "plaintext site url")
            assertRejected("""{"operation":"chapters","path":"/novel/slug"}""", "chapters needs page")
            assertRejected("""{"operation":"chapters","path":"/novel/slug","page":0}""", "page must be >= 1")
            assertRejected("""{"operation":"chapters","path":"/novel/slug","page":1.5}""", "page must be whole")
            assertRejected("""{"operation":"chapters","path":"/novel/slug","page":1e400}""", "page must be finite")
            assertRejected("""{"operation":"chapters","path":"/novel/slug","page":"1"}""", "page must be a number")
            assertRejected("""{"operation":"chapters","path":"/novel/slug","page":100001}""", "page bound")
            assertRejected("""{"operation":"search"}""", "search needs query")
            assertRejected("""{"operation":"search","query":"   "}""", "search query blank")
            assertRejected("""{"operation":"catalogue","path":"/novel/slug"}""", "catalogue rejects path")
            assertRejected("""{"operation":"chapter","path":"/chapter/slug-1","page":1}""", "chapter rejects page")
            assertRejected("""{"operation":"search","query":"x","sort":";drop"}""", "sort allowlist")
        }

        @Test
        fun `a search query carrying a control character is 400`() {
            // The harness embedded a raw U+0001 in the body; the project's own JSON
            // reader refuses an unescaped control character outright. The escaped
            // form decodes to the same character and is caught by the validator's
            // own check, which is the case worth pinning.
            assertRejected(
                "{\"operation\":\"search\",\"query\":\"a\\u0001b\"}",
                "control character in a query",
            )
        }

        @Test
        fun `an unescaped control character in the body is 400 too`() {
            assertRejected("{\"operation\":\"search\",\"query\":\"a" + '\u0001' + "b\"}", "raw control character")
        }

        @Test
        fun `a body that is not JSON is 400`() {
            assertRejected("not json", "not JSON")
        }

        @Test
        fun `a blank body is 400`() {
            assertEquals(400, post(port, "").status)
        }

        @Test
        fun `a rejection never echoes the pairing key`() {
            for (body in listOf("{}", """{"operation":"nope"}""", """{"operation":7}""", "not json")) {
                val message = post(port, body).json?.obj("error")?.str("message").orEmpty()
                assertFalse("leaked the key in '$message'", message.contains(TEST_KEY))
            }
        }

        @Test
        fun `a rejection carries the structured error envelope`() {
            val reply = post(port, "{}")
            assertEquals("BAD_REQUEST", reply.code())
            assertEquals(1L, reply.json?.long("apiVersion"))
        }
    }

    // =========================================================================
    // An accepted request
    // =========================================================================

    class AcceptedRequests {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `an accepted job is 202 with the exact contract body`() {
            val reply = post(port, """{"operation":"catalogue","page":1}""")
            assertEquals(202, reply.status)
            assertEquals("queued", reply.state())
            assertEquals(
                """{"apiVersion":1,"jobId":"${reply.json?.str("jobId")}","state":"queued"}""",
                reply.body,
            )
        }

        @Test
        fun `a job completes and its result is readable`() {
            val id = post(port, """{"operation":"catalogue","page":1}""").json!!.str("jobId")!!
            assertEquals("completed", awaitJob(port, id, setOf("completed")))

            val done = get(port, "/v1/jobs/$id")
            assertEquals("catalogue", done.json?.obj("result")?.str("echo"))
            assertEquals(1, done.json?.int("apiVersion"))
            assertEquals("completed", done.state())
        }

        @Test
        fun `a job that has not finished reports no result and no error`() {
            // A gateway that stays busy, so "in flight" is deterministic rather
            // than a race against a job that might finish first.
            val gateway = FakeGateway(blockUntilReleased = true)
            val local = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            local.start()
            try {
                val localPort = local.boundPort
                val id = post(localPort, """{"operation":"catalogue","page":1}""")
                    .json!!.str("jobId")!!
                assertTrue(gateway.started.await(5, TimeUnit.SECONDS))

                val fresh = get(localPort, "/v1/jobs/$id")

                assertEquals("loading", fresh.state())
                assertFalse(fresh.json!!.has("result"))
                assertFalse(fresh.json!!.has("error"))
            } finally {
                local.stop()
            }
        }

        @Test
        fun `the gateway is handed the operation deadline it expects`() {
            val gateway = FakeGateway()
            val local = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            local.start()
            try {
                val localPort = local.boundPort
                val id = post(localPort, """{"operation":"chapter","path":"/chapter/slug-1"}""")
                    .json!!.str("jobId")!!
                assertEquals("completed", awaitJob(localPort, id, setOf("completed")))
                assertEquals(120_000L, gateway.lastDeadlineMs)
            } finally {
                local.stop()
            }
        }
    }

    // =========================================================================
    // Collapsing and the queue bound
    // =========================================================================

    class CollapseAndQueue {

        private lateinit var gateway: BlockingGateway
        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            gateway = BlockingGateway()
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() {
            gateway.release.countDown()
            server.stop()
        }

        @Test
        fun `a second identical request joins the running job`() {
            val first = post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")
            assertEquals("queued", first.state())
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))

            val second = post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")

            assertEquals(first.json?.str("jobId"), second.json?.str("jobId"))
            // A collapsed request reports the state the shared job really is;
            // claiming "queued" for work that is already loading would be a lie.
            assertEquals("loading", second.state())
            assertEquals(1, gateway.executions)
        }

        @Test
        fun `a different request gets its own job`() {
            val first = post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))

            val other = post(port, """{"operation":"chapter","path":"/chapter/slug-2"}""")

            assertFalse(first.json?.str("jobId") == other.json?.str("jobId"))
            assertEquals("queued", other.state())
        }

        @Test
        fun `the queue is refused with 429 and a retry hint`() {
            post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))

            repeat(4) { index ->
                val reply = post(port, """{"operation":"novel","path":"/novel/slug-$index"}""")
                assertEquals("slug-$index must fit in the queue", 202, reply.status)
            }

            val full = post(port, """{"operation":"novel","path":"/novel/slug-99"}""")

            assertEquals(429, full.status)
            assertEquals("QUEUE_FULL", full.code())
            assertEquals(3_000L, full.json?.long("retryAfterMs"))
            assertEquals("3", full.headers["retry-after"])
        }
    }

    // =========================================================================
    // DELETE releases one caller at a time
    // =========================================================================

    class PerCallerDelete {

        private lateinit var gateway: BlockingGateway
        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            gateway = BlockingGateway()
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() {
            gateway.release.countDown()
            server.stop()
        }

        @Test
        fun `the first DELETE keeps the job alive`() {
            val id = post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")
                .json!!.str("jobId")!!
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))
            post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""") // second waiter

            val first = delete(port, "/v1/jobs/$id")

            assertEquals(200, first.status)
            assertEquals("loading", first.state())
            assertFalse("must not cancel while another caller waits", gateway.cancelled)
        }

        @Test
        fun `the second DELETE cancels the job and the browser`() {
            val id = post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")
                .json!!.str("jobId")!!
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))
            post(port, """{"operation":"chapter","path":"/chapter/slug-1"}""")

            delete(port, "/v1/jobs/$id")
            val second = delete(port, "/v1/jobs/$id")

            assertEquals(200, second.status)
            assertEquals("cancelled", second.state())
            assertTrue("cancel must reach the browser", gateway.cancelled)
        }

        @Test
        fun `DELETE on an unknown job is 404`() {
            assertEquals(
                404,
                delete(port, "/v1/jobs/00000000-0000-0000-0000-000000000000").status,
            )
        }
    }

    // =========================================================================
    // needs_user: terminal, carries its reason, never auto-retried
    // =========================================================================

    class NeedsUser {

        /** Fails the first operation with a verification challenge, then succeeds. */
        private class ChallengeGateway : BrowserGateway {
            @Volatile
            override var readiness: Readiness = Readiness.READY

            val executed = Collections.synchronizedList(mutableListOf<String>())

            @Volatile
            var cancelled: Boolean = false

            override suspend fun execute(request: JobRequest, deadlineMs: Long): Json {
                executed.add(request.path ?: "<none>")
                if (executed.size == 1) {
                    throw CompanionException(ErrorCode.VERIFICATION_REQUIRED, "Verify.")
                }
                return jsonObject("echo" to request.operation.wireName)
            }

            override fun cancelActive() {
                cancelled = true
            }

            override fun onSessionCleared() = Unit
        }

        private lateinit var gateway: ChallengeGateway
        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            gateway = ChallengeGateway()
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `a challenge becomes needs_user and carries its reason`() {
            val id = post(port, """{"operation":"chapter","path":"/chapter/some-slug-1"}""")
                .json!!.str("jobId")!!

            assertEquals("needs_user", awaitJob(port, id, setOf("needs_user", "failed")))
            assertEquals("VERIFICATION_REQUIRED", get(port, "/v1/jobs/$id").code())
        }

        @Test
        fun `a needs_user job is never retried automatically`() {
            // Proved without waiting: a second, different job is drained to
            // completion, and the first was still only executed once.
            val id = post(port, """{"operation":"chapter","path":"/chapter/some-slug-1"}""")
                .json!!.str("jobId")!!
            assertEquals("needs_user", awaitJob(port, id, setOf("needs_user", "failed")))

            val secondId = post(port, """{"operation":"catalogue","page":1}""").json!!.str("jobId")!!
            assertEquals("completed", awaitJob(port, secondId, setOf("completed")))

            assertEquals(1, gateway.executed.count { it == "/chapter/some-slug-1" })
            assertEquals(2, gateway.executed.size)
        }

        @Test
        fun `DELETE on a needs_user job is 200 and leaves the record readable`() {
            // The job is terminal, so cancel() correctly refuses it. The caller
            // still stops waiting and the record stays readable with its error.
            val id = post(port, """{"operation":"chapter","path":"/chapter/some-slug-1"}""")
                .json!!.str("jobId")!!
            assertEquals("needs_user", awaitJob(port, id, setOf("needs_user", "failed")))

            assertEquals(200, delete(port, "/v1/jobs/$id").status)

            val after = get(port, "/v1/jobs/$id")
            assertEquals("needs_user", after.state())
            assertEquals("VERIFICATION_REQUIRED", after.code())
            assertFalse("nothing was left to interrupt", gateway.cancelled)
        }
    }

    // =========================================================================
    // A throwable the runner does not recognise
    // =========================================================================

    class FailureRedaction {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            val boom = FakeGateway(behaviour = { _, _ -> throw IllegalStateException("secret token $TEST_KEY") })
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = boom, port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `an unknown throwable fails the job as INTERNAL`() {
            val id = post(port, """{"operation":"catalogue","page":2}""").json!!.str("jobId")!!
            assertEquals("failed", awaitJob(port, id, setOf("failed")))
            assertEquals("INTERNAL", get(port, "/v1/jobs/$id").code())
        }

        @Test
        fun `nothing from the throwable reaches the client`() {
            val id = post(port, """{"operation":"catalogue","page":2}""").json!!.str("jobId")!!
            assertEquals("failed", awaitJob(port, id, setOf("failed")))

            val reply = get(port, "/v1/jobs/$id")
            assertFalse("leaked the key", reply.body.contains(TEST_KEY))
            assertFalse("leaked the exception type", reply.body.contains("IllegalState"))
            assertFalse("leaked the message", reply.body.contains("secret"))
        }
    }

    // =========================================================================
    // stop()
    // =========================================================================

    class Stopping {

        @Test
        fun `stop fails pending work and cancels the browser`() {
            val gateway = FakeGateway(blockUntilReleased = true)
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = gateway, port = 0)
            server.start()
            val port = server.boundPort

            val loadingId = post(port, """{"operation":"chapter","path":"/chapter/slug-9"}""")
                .json!!.str("jobId")!!
            assertTrue(gateway.started.await(5, TimeUnit.SECONDS))
            val queuedId = post(port, """{"operation":"novel","path":"/novel/behind"}""")
                .json!!.str("jobId")!!

            server.stop()

            assertEquals(
                "COMPANION_UNAVAILABLE",
                server.jobs.job(loadingId)?.error?.code?.name,
            )
            assertEquals(
                "COMPANION_UNAVAILABLE",
                server.jobs.job(queuedId)?.error?.code?.name,
            )
            assertTrue(gateway.cancelled)
        }

        @Test
        fun `stop is idempotent`() {
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            server.stop()
            server.stop()
        }

        @Test
        fun `a stopped server refuses connections`() {
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            val port = server.boundPort
            server.stop()

            assertTrue(
                "a stopped server must not answer",
                runCatching { get(port, "/v1/health") }.isFailure,
            )
        }
    }

    // =========================================================================
    // No gateway at all
    // =========================================================================

    class MissingGateway {

        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = null, port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `health reports STOPPED when there is no gateway`() {
            // Null is not "no auth": it means the companion cannot do browser work.
            assertEquals("STOPPED", get(port, "/v1/health").json?.str("state"))
        }

        @Test
        fun `a job without a gateway fails as COMPANION_UNAVAILABLE`() {
            val id = post(port, """{"operation":"catalogue","page":1}""").json!!.str("jobId")!!
            assertEquals("failed", awaitJob(port, id, setOf("failed")))
            assertEquals("COMPANION_UNAVAILABLE", get(port, "/v1/jobs/$id").code())
        }

        // Regression: `LocalApiServer.setGateway()` used to update the
        // `@Volatile private var gateway` field, while the runner was built in a
        // property initializer as `JobRunner({ gateway }, clock)` — where the bare
        // name resolves to the *constructor parameter*, not the field. The runner
        // kept handing out the gateway captured at construction, so
        // `net/GatewayBootstrap.kt`'s "when the WebView is rebuilt" wiring was dead
        // and a server built with `gateway = null` could never be brought to life:
        // `/v1/health` reported READY while every job still failed
        // COMPANION_UNAVAILABLE.
        @Test
        fun `a gateway installed later is used for the next job`() {
            assertEquals("STOPPED", get(port, "/v1/health").json?.str("state"))

            val gateway = FakeGateway()
            server.setGateway(gateway)

            // Health and the queue must agree, not just health.
            assertEquals("READY", get(port, "/v1/health").json?.str("state"))

            val id = post(port, """{"operation":"catalogue","page":1}""").json!!.str("jobId")!!
            assertEquals("completed", awaitJob(port, id, setOf("completed")))
            assertEquals(1, gateway.executions)
        }

        @Test
        fun `a swapped gateway replaces the previous one for later jobs`() {
            val first = FakeGateway()
            val second = FakeGateway()
            server.setGateway(first)
            val firstId = post(port, """{"operation":"catalogue","page":1}""")
                .json!!.str("jobId")!!
            assertEquals("completed", awaitJob(port, firstId, setOf("completed")))

            server.setGateway(second)
            val secondId = post(port, """{"operation":"catalogue","page":2}""")
                .json!!.str("jobId")!!
            assertEquals("completed", awaitJob(port, secondId, setOf("completed")))

            assertEquals(1, first.executions)
            assertEquals(1, second.executions)
        }
    }

    // =========================================================================
    // Pairing-key rotation
    // =========================================================================

    class KeyRotation {

        private val rotated = "rotated-key-9999999999"
        private lateinit var server: LocalApiServer
        private var port: Int = 0

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() = server.stop()

        @Test
        fun `the original key works before rotation`() {
            assertEquals(200, get(port, "/v1/health").status)
        }

        @Test
        fun `the old key is refused and the new one accepted after rotation`() {
            server.updatePairingKey(rotated)

            assertEquals(401, get(port, "/v1/health", key = TEST_KEY).status)
            assertEquals(200, get(port, "/v1/health", key = rotated).status)
        }

        @Test
        fun `a blank key is refused and never weakens authentication`() {
            server.updatePairingKey(rotated)
            server.updatePairingKey("  ")

            assertEquals("the rotated key must still work", 200, get(port, "/v1/health", key = rotated).status)
            assertEquals(401, get(port, "/v1/health", key = TEST_KEY).status)
        }

        @Test
        fun `a rotation applies to the very next request`() {
            server.updatePairingKey(rotated)
            // No restart, no cache: the field is volatile and read per request.
            assertEquals(401, get(port, "/v1/health", key = TEST_KEY).status)
        }
    }

    // =========================================================================
    // Restart
    // =========================================================================

    class Restart {

        @Test
        fun `a stopped server binds and serves again`() {
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            val firstPort = server.boundPort
            server.stop()

            server.start()

            try {
                assertTrue(server.boundPort > 0)
                assertTrue(server.isRunning)
                assertEquals(200, get(server.boundPort, "/v1/health").status)
            } finally {
                server.stop()
            }
            assertTrue(firstPort > 0)
        }
    }

    // =========================================================================
    // Keep-alive
    // =========================================================================

    class KeepAlive {

        @Test
        fun `two requests are served on one connection`() {
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            val port = server.boundPort
            try {
                Socket("127.0.0.1", port).use { socket ->
                    socket.tcpNoDelay = true
                    socket.soTimeout = 15_000
                    val out = socket.getOutputStream()

                    fun exchange(requestLine: String): Reply {
                        val head = StringBuilder()
                        head.append(requestLine).append("\r\n")
                        head.append("Host: 127.0.0.1\r\nAuthorization: Bearer $TEST_KEY\r\n\r\n")
                        out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
                        out.flush()

                        val raw = ByteArrayOutputStream()
                        val buffer = ByteArray(1024)
                        while (true) {
                            val count = socket.getInputStream().read(buffer)
                            if (count < 0) throw AssertionError("connection closed mid-response")
                            raw.write(buffer, 0, count)
                            val text = String(raw.toByteArray(), Charsets.UTF_8)
                            val split = text.indexOf("\r\n\r\n")
                            if (split < 0) continue
                            val length = text.substring(0, split).split("\r\n")
                                .firstOrNull { it.startsWith("Content-Length:", ignoreCase = true) }
                                ?.substringAfter(':')?.trim()?.toIntOrNull() ?: 0
                            if (text.length - split - 4 >= length) {
                                return parseReply(
                                    text.substring(0, split),
                                    text.substring(split + 4, split + 4 + length),
                                )
                            }
                        }
                    }

                    val first = exchange("GET /v1/health HTTP/1.1")
                    assertEquals(200, first.status)
                    assertEquals("keep-alive", first.headers["connection"])

                    val second = exchange(
                        "GET /v1/jobs/00000000-0000-0000-0000-000000000000 HTTP/1.1",
                    )
                    assertEquals("the same socket must serve the second request", 404, second.status)
                }
            } finally {
                server.stop()
            }
        }

        @Test
        fun `Connection close is honoured`() {
            val server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            try {
                assertEquals("close", get(server.boundPort, "/v1/health").headers["connection"])
            } finally {
                server.stop()
            }
        }
    }

    // =========================================================================
    // Unauthenticated peers must not be able to hold the server hostage
    // =========================================================================

    /**
     * A local slowloris: peers that send a request head and then stop, without a
     * pairing key, without ever finishing the head.
     *
     * Before these tests the workers blocked in `readLine()` for up to 15 seconds
     * each, so eight such sockets occupied the whole pool and a correctly
     * authenticated `/v1/health` got nothing at all. Nothing here needs a key:
     * the pool was stuck *before* authentication ran.
     */
    class UnauthenticatedHeadHold {

        private lateinit var server: LocalApiServer
        private var port: Int = 0
        private val attackers = mutableListOf<Socket>()

        @Before
        fun setUp() {
            server = LocalApiServer(pairingKey = TEST_KEY, gateway = FakeGateway(), port = 0)
            server.start()
            port = server.boundPort
        }

        @After
        fun tearDown() {
            closeAll(attackers)
            server.stop()
        }

        /** Opens [count] peers that each send a partial head and then go quiet. */
        private fun silentPeers(count: Int): List<Socket> {
            repeat(count) { attackers.add(openPartialHeadAndGoSilent(port)) }
            return attackers
        }

        /**
         * The headline test. Six idle peers is well under the worker count, so a
         * correctly authenticated request has a worker free and must be answered
         * essentially immediately.
         *
         * The bound is **1 second**, polled rather than stopwatched: the claim
         * under test is "answered, and answered now", not a stopwatch figure. On
         * the unfixed server this did not answer within six seconds at all.
         */
        @Test
        fun `six peers holding a partial head cannot stall a legitimate request`() {
            silentPeers(6)

            val probe = probeGet(port, "/v1/health", budgetMs = 1_000L)

            assertTrue("the legitimate request was $probe", probe is Probe.Answered)
            val reply = (probe as Probe.Answered).reply
            assertEquals(200, reply.status)
            assertEquals(
                """{"apiVersion":1,"companionVersion":"0.1.1","state":"READY"}""",
                reply.body,
            )
            assertEquals("no-store", reply.headers["cache-control"])
        }

        /**
         * The queue must not be fillable into an instant refusal.
         *
         * Forty peers is more than the worker pool and more than the old sixteen
         * slot accept queue, so this is the reviewer's "instantly closed in 2 ms"
         * scenario. The answer may be *delayed* - that is the point of the head
         * deadline - but it must arrive, with its real body, and never as a
         * closed connection.
         */
        @Test
        fun `a burst of silent peers does not turn a legitimate request into a refusal`() {
            silentPeers(40)

            val probe = probeGet(port, "/v1/health", budgetMs = 15_000L)

            assertTrue("the legitimate request was $probe", probe is Probe.Answered)
            assertEquals(200, (probe as Probe.Answered).reply.status)

            // And the server is still healthy afterwards, not just briefly.
            assertEquals(200, get(port, "/v1/health").status)
        }

        /**
         * The number that matters, stated exactly: **the pool size** is how many
         * peers it takes to stall a legitimate request at all.
         *
         * With one silent peer per worker every worker is blocked, so the
         * legitimate request queues - but it is answered as soon as the first
         * head runs out its [Config.HEAD_READ_DEADLINE_MS], so the stall is one
         * deadline rather than the fifteen seconds it used to be, and it is not
         * an outright refusal. The generous budget below is deliberate: this
         * test asserts that the answer *arrives*, and the elapsed time is what
         * the report quotes as the stall.
         */
        @Test
        fun `one peer per worker delays a legitimate request without denying it`() {
            silentPeers(LocalApiServer.WORKER_THREADS)

            val probe = probeGet(port, "/v1/health", budgetMs = 15_000L)

            assertTrue("the legitimate request was $probe", probe is Probe.Answered)
            assertEquals(200, (probe as Probe.Answered).reply.status)
        }

        /**
         * The server holds a bounded number of connections no matter how many are
         * opened. Without this the accept queue, the OS backlog and the pool were
         * all unbounded from the attacker's point of view.
         */
        @Test
        fun `a flood of silent peers never exceeds the connection cap`() {
            var peak = 0
            repeat(120) {
                attackers.add(openPartialHeadAndGoSilent(port))
                peak = maxOf(peak, server.liveConnections)
            }

            assertTrue("no connection was ever counted", peak > 0)
            assertTrue(
                "held $peak live connections, cap is ${LocalApiServer.MAX_CONNECTIONS}",
                peak <= LocalApiServer.MAX_CONNECTIONS,
            )
        }

        /**
         * The head deadline is a real bound, not decoration: a peer that stops
         * mid-head is hung up on within [Config.HEAD_READ_DEADLINE_MS].
         */
        @Test
        fun `a peer that never finishes its head is hung up on`() {
            val peer = openPartialHeadAndGoSilent(port)
            attackers.add(peer)

            assertTrue(
                "the server kept an unfinished head open for far longer than its deadline",
                awaitHangUp(peer, Config.HEAD_READ_DEADLINE_MS * 5L),
            )
        }

        /**
         * ...and it is a bound on the *whole* head, not on any one read.
         *
         * A peer that dribbles a single byte every 100 ms resets a naive
         * `SO_TIMEOUT` on every read and can therefore hold a worker forever.
         * The deadline here is absolute and counted from the first byte, so the
         * dribble is cut off on schedule.
         */
        @Test
        fun `a peer that dribbles its head one byte at a time is still hung up on`() {
            val peer = Socket("127.0.0.1", port)
            peer.tcpNoDelay = true
            attackers.add(peer)

            val dribble = Thread {
                try {
                    val out = peer.getOutputStream()
                    repeat(60) {
                        out.write("G".toByteArray(Charsets.ISO_8859_1))
                        out.flush()
                        Thread.sleep(100)
                    }
                } catch (_: IOException) {
                    // The server hung up mid-dribble, which is the point.
                }
            }.apply { isDaemon = true; start() }

            val ceilingMs = Config.HEAD_READ_DEADLINE_MS * 4L
            assertTrue(
                "a dribbling head held a worker past the absolute deadline",
                awaitHangUp(peer, ceilingMs),
            )
            dribble.interrupt()
        }

        /**
         * The other half of the trade-off: the deadline must be long enough that
         * a slow-but-legitimate plugin still gets served.
         *
         * A busy phone can deschedule the plugin between writing its request line
         * and finishing its headers. The pause below is a third of the head
         * deadline; a server that cannot survive that is not usable, and one that
         * survives it has a fifteen-fold margin over the fifteen seconds this
         * used to allow.
         */
        @Test
        fun `a slow but legitimate client still gets its answer`() {
            val pauseMs = Config.HEAD_READ_DEADLINE_MS / 3
            assertTrue("the pause must sit inside the deadline", pauseMs < Config.HEAD_READ_DEADLINE_MS)

            Socket("127.0.0.1", port).use { socket ->
                socket.tcpNoDelay = true
                socket.soTimeout = 15_000
                val out = socket.getOutputStream()
                out.write(
                    ("GET /v1/health HTTP/1.1\r\nHost: h\r\nAuthorization: Bearer $TEST_KEY\r\n")
                        .toByteArray(Charsets.ISO_8859_1),
                )
                out.flush()
                Thread.sleep(pauseMs)
                out.write("\r\n".toByteArray(Charsets.ISO_8859_1))
                out.flush()

                // Framed by Content-Length, not read to end-of-stream: a
                // successful request is kept alive, so there is no EOF to wait
                // for and waiting for one would prove nothing.
                val reply = readReply(socket)
                assertEquals(200, reply.status)
                assertEquals(
                    """{"apiVersion":1,"companionVersion":"0.1.1","state":"READY"}""",
                    reply.body,
                )
            }
        }

        /**
         * A legitimate keep-alive client may sit idle between polls. The long
         * wait between requests must not be governed by the head deadline, or
         * the plugin's one-second poll would break the connection every time.
         */
        @Test
        fun `an authenticated keep-alive connection may idle between requests`() {
            Socket("127.0.0.1", port).use { socket ->
                socket.tcpNoDelay = true
                socket.soTimeout = 15_000
                val out = socket.getOutputStream()

                fun ask(path: String): Reply {
                    out.write(
                        ("GET $path HTTP/1.1\r\nHost: h\r\nAuthorization: Bearer $TEST_KEY\r\n\r\n")
                            .toByteArray(Charsets.ISO_8859_1),
                    )
                    out.flush()
                    return readReply(socket)
                }

                assertEquals(200, ask("/v1/health").status)

                // Idle for longer than the head deadline, then ask again.
                Thread.sleep(Config.HEAD_READ_DEADLINE_MS + 400L)

                assertEquals(200, ask("/v1/health").status)
            }
        }
    }
}
