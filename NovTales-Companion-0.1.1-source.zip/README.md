# NovTales companion and official LNReader plugin

Reviewed and repaired on 4 October 2026. Use companion **0.1.1** with plugin **2.0.1**.
This is a separate Android app; official LNReader continues to manage your library, reading, downloads and offline chapters.

Read [the review and setup guide](REVIEW.md) for the fixes, evidence and installation steps.

## Deliverables

- `dist/NovTales-Companion-0.1.1.apk` — signed companion APK.
- `dist/NovTales-Companion-0.1.1-source.zip` — reviewed source and plugin, excluding signing secrets.
- `lnreader-plugin/plugins/english/novtales.js` — compiled LNReader plugin.
- `lnreader-plugin/plugins/english/novtales.ts` — editable plugin source.
- `lnreader-plugin/plugins.min.json` — source repository manifest.
- `novtales-companion/` — Kotlin Android project, Gradle wrapper, tests and API documentation.

The original 0.1.0 APK and source ZIP are retained. Historical build reports describe the initial delivery; REVIEW.md and the final verification record describe this repair.

## Build

Use JDK 17, Android SDK 35 and the committed Gradle wrapper. Run `build.ps1 -Task "testDebugUnitTest lintDebug assembleDebug"` for review. Release packaging requires the original private signing identity in the ignored `keystore.properties`; see `novtales-companion/docs/BUILD.md`. Signing secrets are never part of the source ZIP.

Plugin verification: `npm run check`, `npm run build`, then `node _working/smoke.mjs` from `lnreader-plugin`. The checking configuration expects the official `lnreader-plugins` repository alongside APP; emission uses the official plugin build format.
